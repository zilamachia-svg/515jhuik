import { useEffect, useState } from 'react';
import { useLocation, useNavigate, Link } from 'react-router-dom';
import { toast } from 'sonner';
import { formatApiErrorForToast } from '../utils';
import { PATHS } from '../constants/paths';
import { Spinner } from '@/components/ui/spinner';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { ApiError } from '../types';
import { Button } from '@/components/ui/button';
import { CheckCircle, XCircle } from 'lucide-react';
import { verifyFromLink } from '../services/authService';

export default function VerifyEmailPage() {
    const [status, setStatus] = useState<'verifying' | 'success' | 'failed'>('verifying');
    const [message, setMessage] = useState('Đang xác thực email của bạn...');
    const location = useLocation();
    const navigate = useNavigate();

    useEffect(() => {
        const verify = async () => {
            const url = `${location.pathname}${location.search}`;

            if (!url.includes('?')) {
                setStatus('failed');
                setMessage('URL xác thực không hợp lệ.');
                return;
            }

            try {
                await verifyFromLink({ url: url });
                setStatus('success');
                setMessage('Xác thực email thành công! Bạn sẽ được chuyển hướng sau giây lát.');
                toast.success('Xác thực email thành công!');
                
                setTimeout(() => {
                    navigate(PATHS.STORE, { replace: true });
                }, 3000);

            } catch (error) {
                setStatus('failed');
                const errorMessage = formatApiErrorForToast(error as ApiError, 'Xác thực thất bại. Liên kết có thể đã hết hạn.');
                setMessage(errorMessage);
                toast.error(errorMessage);
            }
        };

        verify();
    }, [location, navigate]);

    return (
        <div className="flex items-center justify-center min-h-full p-4">
            <Card className="w-full max-w-md text-center">
                <CardHeader>
                    {status === 'verifying' && <CardTitle>Đang xác thực</CardTitle>}
                    {status === 'success' && <CardTitle>Thành công!</CardTitle>}
                    {status === 'failed' && <CardTitle>Thất bại!</CardTitle>}
                </CardHeader>
                <CardContent className="space-y-4">
                    {status === 'verifying' && (
                        <div className="flex flex-col items-center gap-4">
                            <Spinner className="h-10 w-10" />
                            <p>{message}</p>
                        </div>
                    )}
                    
                    {status === 'success' && (
                        <div className="space-y-4 flex flex-col items-center">
                            <CheckCircle className="h-12 w-12 text-green-500" />
                            <p>{message}</p>
                        </div>
                    )}

                    {status === 'failed' && (
                        <div className="space-y-4 flex flex-col items-center">
                             <XCircle className="h-12 w-12 text-destructive" />
                            <p>{message}</p>
                            <Button asChild>
                                <Link to={PATHS.HOME}>Về trang chủ</Link>
                            </Button>
                        </div>
                    )}
                </CardContent>
            </Card>
        </div>
    );
}