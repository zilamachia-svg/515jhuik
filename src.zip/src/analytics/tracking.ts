import { User } from '../types';

/**
 * A basic analytics event logger. In a real-world application, this would
 * send data to a service like Google Analytics, Mixpanel, or a custom backend.
 * For this implementation, it logs structured data to the console.
 *
 * @param eventName The name of the event being tracked.
 * @param properties An object containing additional data about the event.
 */
const trackEvent = (eventName: string, properties: Record<string, any>) => {
    console.log(
        `[ANALYTICS] Event: ${eventName}`,
        {
            ...properties,
            timestamp: new Date().toISOString(),
        }
    );
};

/**
 * Tracks a login attempt event.
 * @param email The email used for the login attempt.
 */
export const trackLoginAttempt = (email: string) => {
    trackEvent('Login Attempt', { email });
};

/**
 * Tracks a successful login event.
 * @param user The user object of the successfully logged-in user.
 */
export const trackLoginSuccess = (user: User) => {
    trackEvent('Login Success', {
        userId: user.id,
        userRole: user.role,
    });
};

/**
 * Tracks a failed login event.
 * @param email The email used for the failed attempt.
 * @param reason A string describing the reason for failure.
 */
export const trackLoginFailure = (email: string, reason: string) => {
    trackEvent('Login Failure', { email, reason });
};
