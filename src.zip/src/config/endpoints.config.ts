/**
 * API Endpoints Configuration
 * Centralized endpoint definitions
 */

import { API_CONFIG } from './api.config';

const API_VERSION = API_CONFIG.apiVersion;
const BASE_URL = API_CONFIG.baseURL;

/**
 * Helper to build endpoint URL
 */
const endpoint = (path: string): string => {
  // Remove leading slash if present
  const cleanPath = path.startsWith('/') ? path.slice(1) : path;
  return `${BASE_URL}/api/${API_VERSION}/${cleanPath}`;
};

/**
 * API Endpoints
 */
export const API_ENDPOINTS = {
  // Auth
  auth: {
    login: endpoint('login'),
    register: endpoint('register'),
    logout: endpoint('logout'),
    me: endpoint('me'),
    forgotPassword: endpoint('forgot-password'),
    resetPassword: endpoint('reset-password'),
    verifyEmail: endpoint('verify-email'),
    resendVerification: endpoint('resend-verification'),
  },

  // User
  user: {
    me: endpoint('me'),
    update: endpoint('me'),
  },

  // Products
  products: {
    list: endpoint('products'),
    show: (id: string | number) => endpoint(`products/${id}`),
    // compatibility aliases used across the codebase
    detail: (id: string | number) => endpoint(`products/${id}`),
    create: endpoint('products'),
    update: (id: string | number) => endpoint(`products/${id}`),
    delete: (id: string | number) => endpoint(`products/${id}`),
    upload: endpoint('products/upload'),
    categories: endpoint('product-categories'),
  },

  // Orders
  orders: {
    list: endpoint('orders'),
    create: endpoint('orders'),
    show: (id: string | number) => endpoint(`orders/${id}`),
    cancel: (id: string | number) => endpoint(`orders/${id}/cancel`),
  },

  // Deposits
  deposits: {
    list: endpoint('deposits'),
    create: endpoint('deposits'),
    show: (id: string | number) => endpoint(`deposits/${id}`),
  },

  // Payment Methods
  paymentMethods: {
    list: endpoint('payment-methods'),
  },

  // Posts
  posts: {
    list: endpoint('posts'),
    show: (slug: string) => endpoint(`posts/${slug}`),
  },

  // FAQ
  faq: {
    list: endpoint('faq'),
  },

  // Settings
  settings: {
    public: endpoint('settings'),
    admin: endpoint('admin/settings'),
    // theme endpoints used by frontend
    theme: endpoint('settings/theme'),
  },

  // Admin
  admin: {
    dashboard: endpoint('admin/dashboard'),
    users: endpoint('admin/users'),
    products: endpoint('admin/products'),
    orders: endpoint('admin/orders'),
    deposits: endpoint('admin/deposits'),
    apiKeys: endpoint('admin/api-keys'),
    settings: endpoint('admin/settings'),
  },

  // Webhooks
  webhooks: {
    sepay: endpoint('webhooks/sepay'),
  },
} as const;

