/**
 * API Configuration
 * Centralized configuration for API client and endpoints
 */

// Helper function to normalize baseURL
// Sử dụng relative URLs (empty string) để đảm bảo cookies được gửi đúng domain
const normalizeBaseURL = (url: string | undefined): string => {
  // Nếu có VITE_API_BASE_URL được set, ưu tiên dùng nó
  if (url) {
    // Nếu đã có protocol, return nguyên
    if (url.startsWith('http://') || url.startsWith('https://')) {
      return url;
    }
    // Nếu không có protocol, thêm https://
    return `https://${url}`;
  }
  
  // Production hoặc không có config: Sử dụng empty string để dùng relative URLs
  // API requests sẽ được route qua .htaccess từ /api/* đến Laravel backend
  // Điều này đảm bảo cookies được gửi đúng domain (cùng domain với frontend)
  return ''; // Relative URL - cùng domain với frontend
};

const finalBaseURL = normalizeBaseURL(import.meta.env.VITE_API_BASE_URL);

// Debug log (only in development)
if (import.meta.env.DEV) {
  console.log('[API Config] Hostname:', typeof window !== 'undefined' ? window.location.hostname : 'server');
  console.log('[API Config] VITE_API_BASE_URL:', import.meta.env.VITE_API_BASE_URL || '(not set)');
  console.log('[API Config] Final Base URL:', finalBaseURL);
}

export const API_CONFIG = {
  // Base URL - Sử dụng relative URLs (empty string) để đảm bảo cookies được gửi đúng domain
  // API requests sẽ được route qua .htaccess từ /api/* đến Laravel backend
  // Format: '' (relative) cho production, 'http://localhost:8000' cho development
  baseURL: finalBaseURL,
  
  // Timeout - Tăng lên 30 giây để tránh timeout với requests lớn
  timeout: 30000,
  
  // API Version
  apiVersion: 'v1',
  
  // Headers
  headers: {
    accept: 'application/json',
    contentType: 'application/json',
    requestedWith: 'XMLHttpRequest',
  },
  
  // CSRF
  csrf: {
    cookieEndpoint: '/sanctum/csrf-cookie',
    tokenHeader: 'X-XSRF-TOKEN',
  },
  
  // Retry configuration
  retry: {
    maxAttempts: 1,
    retryableStatusCodes: [419], // CSRF token mismatch
  },
} as const;
