import { createContext, useReducer, useContext, PropsWithChildren, Dispatch } from 'react';

// Define a max price for the slider and export it for use in other components
export const MAX_PRICE = 5000000;

// 1. Define the state shape
export interface FilterState {
    search: string;
    category: string;
    country: string;
    sortBy: string;
    priceMin: number;
    priceMax: number;
    inStockOnly: boolean;
    page: number;
}

const initialState: FilterState = {
    search: '',
    category: 'all',
    country: 'all',
    sortBy: 'default',
    priceMin: 0,
    priceMax: MAX_PRICE,
    inStockOnly: false,
    page: 1,
};

// 2. Define action types
type FilterAction =
    | { type: 'SET_SEARCH'; payload: string }
    | { type: 'SET_CATEGORY'; payload: string }
    | { type: 'SET_COUNTRY'; payload: string }
    | { type: 'SET_SORT_BY'; payload: string }
    | { type: 'SET_PRICE_RANGE'; payload: { min: number; max: number } }
    | { type: 'TOGGLE_IN_STOCK' }
    | { type: 'SET_PAGE'; payload: number }
    | { type: 'RESET_FILTERS' };

// 3. Create the reducer
const filterReducer = (state: FilterState, action: FilterAction): FilterState => {
    switch (action.type) {
        case 'SET_SEARCH':
            // Reset page to 1 when search changes
            return { ...state, search: action.payload, page: 1 };
        case 'SET_CATEGORY':
            return { ...state, category: action.payload, page: 1 };
        case 'SET_COUNTRY':
            return { ...state, country: action.payload, page: 1 };
        case 'SET_SORT_BY':
            return { ...state, sortBy: action.payload, page: 1 };
        case 'SET_PRICE_RANGE':
            return { ...state, priceMin: action.payload.min, priceMax: action.payload.max, page: 1 };
        case 'TOGGLE_IN_STOCK':
            return { ...state, inStockOnly: !state.inStockOnly, page: 1 };
        case 'SET_PAGE':
            return { ...state, page: action.payload };
        case 'RESET_FILTERS':
            // When resetting, keep the current search term but reset everything else
            return { ...initialState, search: state.search, priceMax: MAX_PRICE };
        default:
            return state;
    }
};

// 4. Create the context
interface FilterContextType {
    filters: FilterState;
    dispatch: Dispatch<FilterAction>;
}

const FilterContext = createContext<FilterContextType | undefined>(undefined);

// 5. Create the provider
export const FilterProvider = ({ children }: PropsWithChildren) => {
    const [state, dispatch] = useReducer(filterReducer, initialState);

    return (
        <FilterContext.Provider value={{ filters: state, dispatch }}>
            {children}
        </FilterContext.Provider>
    );
};

// 6. Create the custom hook
export const useFilters = () => {
    const context = useContext(FilterContext);
    if (!context) {
        throw new Error('useFilters must be used within a FilterProvider');
    }
    return context;
};