import { createContext, useState, useEffect, useContext, useCallback, PropsWithChildren, useMemo } from 'react';
import { languages, LanguageCode, getLanguageConfig, defaultLanguage } from '../locales/config';

// A simple nested key accessor
const getNestedValue = (obj: any, key: string): string | undefined => {
    return key.split('.').reduce((acc, part) => acc && acc[part], obj);
};

interface LanguageContextType {
    language: LanguageCode;
    availableLanguages: typeof languages;
    setLanguage: (lang: LanguageCode) => void;
    t: (key: string, replacements?: Record<string, string | number>) => string;
    isTranslationsLoading: boolean;
}

const LanguageContext = createContext<LanguageContextType | undefined>(undefined);

export const useLanguage = () => {
    const context = useContext(LanguageContext);
    if (!context) {
        throw new Error('useLanguage must be used within a LanguageProvider');
    }
    return context;
};

export const LanguageProvider = ({ children }: PropsWithChildren) => {
    const [language, setLanguageState] = useState<LanguageCode>(() => {
        const storedLang = localStorage.getItem('language');
        const isValidLang = languages.some(l => l.code === storedLang);
        return isValidLang ? (storedLang as LanguageCode) : defaultLanguage;
    });

    const [translations, setTranslations] = useState<Record<string, any> | null>(null);
    const [isTranslationsLoading, setIsLoading] = useState(true);

    useEffect(() => {
        const loadTranslations = async (langCode: LanguageCode) => {
            setIsLoading(true);
            try {
                const langConfig = getLanguageConfig(langCode);
                if (langConfig) {
                    const module = await langConfig.import();
                    setTranslations(module.default);
                } else {
                    // Fallback to default if config not found (shouldn't happen with proper types)
                    const fallbackConfig = getLanguageConfig(defaultLanguage);
                    const module = await fallbackConfig!.import();
                    setTranslations(module.default);
                }
            } catch (error) {
                console.error(`Failed to load translations for ${langCode}`, error);
                // In case of error, you might want to load a default language or show an error
                setTranslations({}); // Set to empty to avoid crashing
            } finally {
                setIsLoading(false);
            }
        };

        loadTranslations(language);
    }, [language]);


    const setLanguage = useCallback((lang: LanguageCode) => {
        setLanguageState(lang);
        localStorage.setItem('language', lang);
        document.documentElement.lang = lang;
    }, []);

    const t = useCallback((key: string, replacements?: Record<string, string | number>): string => {
        // Return key or a placeholder if translations are not loaded yet
        if (isTranslationsLoading || !translations) {
            return key;
        }

        const translation = getNestedValue(translations, key);
        
        // If translation not found or is not a string, return the key
        if (!translation || typeof translation !== 'string') {
            return key;
        }

        if (replacements) {
            return Object.keys(replacements).reduce((acc, currentKey) => {
                return acc.replace(`{${currentKey}}`, String(replacements[currentKey]));
            }, translation);
        }

        return translation;
    }, [isTranslationsLoading, translations]);
    
    const value = useMemo(() => ({
        language,
        availableLanguages: languages,
        setLanguage,
        t,
        isTranslationsLoading,
    }), [language, setLanguage, t, isTranslationsLoading]);

    return (
        <LanguageContext.Provider value={value}>
            {children}
        </LanguageContext.Provider>
    );
};
