import { createContext, useState, useEffect, useContext, useCallback, PropsWithChildren } from 'react';
import { ApiLogEntry, subscribe } from '../services/apiLogService';

interface ApiLogContextType {
    logs: ApiLogEntry[];
    clearLogs: () => void;
}

const ApiLogContext = createContext<ApiLogContextType | undefined>(undefined);

export const useApiLog = (): ApiLogContextType => {
    const context = useContext(ApiLogContext);
    if (!context) {
        throw new Error('useApiLog must be used within an ApiLogProvider');
    }
    return context;
};

export const ApiLogProvider = ({ children }: PropsWithChildren) => {
    const [logs, setLogs] = useState<ApiLogEntry[]>([]);

    useEffect(() => {
        // Lắng nghe các log mới từ service và thêm vào đầu danh sách
        const unsubscribe = subscribe((newLog) => {
            setLogs(prevLogs => [newLog, ...prevLogs]);
        });

        // Hủy đăng ký khi component unmount
        return () => {
            unsubscribe();
        };
    }, []);

    const clearLogs = useCallback(() => {
        setLogs([]);
    }, []);

    const value: ApiLogContextType = {
        logs,
        clearLogs,
    };

    return (
        <ApiLogContext.Provider value={value}>
            {children}
        </ApiLogContext.Provider>
    );
};
