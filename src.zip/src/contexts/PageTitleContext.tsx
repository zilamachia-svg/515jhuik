import { createContext, useState, useContext, useEffect, PropsWithChildren, useMemo } from 'react';

interface PageTitleContextType {
    setTitle: (title: string) => void;
    title: string;
}

const PageTitleContext = createContext<PageTitleContextType | undefined>(undefined);

export const usePageTitleContext = () => {
    const context = useContext(PageTitleContext);
    if (!context) {
        throw new Error('usePageTitleContext must be used within a PageTitleProvider');
    }
    return context;
};

// Hook cho các trang sử dụng để đặt tiêu đề của mình
export const usePageTitle = (title: string) => {
    const { setTitle } = usePageTitleContext();
    useEffect(() => {
        setTitle(title);
        // Reset tiêu đề khi component unmount để tránh hiển thị tiêu đề cũ
        return () => setTitle(''); 
    }, [title, setTitle]);
};

export const PageTitleProvider = ({ children }: PropsWithChildren) => {
    const [title, setTitle] = useState('');

    const value = useMemo(() => ({ title, setTitle }), [title]);

    return (
        <PageTitleContext.Provider value={value}>
            {children}
        </PageTitleContext.Provider>
    );
};
