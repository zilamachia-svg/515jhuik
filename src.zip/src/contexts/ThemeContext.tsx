import { createContext, useContext, useState, useEffect, useMemo, useCallback, PropsWithChildren } from 'react';
import { hexToHSL } from '../utils';

// FIX: Restore theme settings functionality to make the admin settings page work.
// This page was broken by a previous refactor that removed dynamic color settings.
export interface ThemeSettings {
    primaryColor: string;
    secondaryColor: string;
    accentColor: string;
    textColor: string;
    cardColor: string;
    headerColor: string;
}

interface ThemeContextType {
    isDarkMode: boolean;
    toggleTheme: () => void;
    settings: ThemeSettings;
    setSettings: (settings: ThemeSettings) => void;
}

const ThemeContext = createContext<ThemeContextType | undefined>(undefined);

export const useTheme = () => {
    const context = useContext(ThemeContext);
    if (!context) {
        throw new Error('useTheme must be used within a ThemeProvider');
    }
    return context;
};

// Default colors for light theme (approximations)
const defaultLightSettings: ThemeSettings = {
    primaryColor: '#0A0A0A',
    secondaryColor: '#f1f5f9',
    accentColor: '#3b82f6',
    textColor: '#0f172a',
    cardColor: '#ffffff',
    headerColor: '#ffffff',
};

// Default colors for dark theme (approximations)
const defaultDarkSettings: ThemeSettings = {
    primaryColor: '#f8fafc',
    secondaryColor: '#1e293b',
    accentColor: '#60a5fa',
    textColor: '#f8fafc',
    cardColor: '#0f172a',
    headerColor: '#020617',
};


export const ThemeProvider = ({ children }: PropsWithChildren) => {
    // Read persisted theme preference (if any)
    const [isDarkMode, setIsDarkMode] = useState<boolean>(() => {
        try {
            const stored = localStorage.getItem('theme');
            return stored === 'dark';
        } catch {
            return false;
        }
    });
    
    // ... rest of the code remains the same ...

    const [lightSettings, setLightSettings] = useState<ThemeSettings>(() => {
        try {
            const stored = localStorage.getItem('lightThemeSettings');
            return stored ? { ...defaultLightSettings, ...JSON.parse(stored) } : defaultLightSettings;
        } catch {
            return defaultLightSettings;
        }
    });

    const [darkSettings, setDarkSettings] = useState<ThemeSettings>(() => {
        try {
            const stored = localStorage.getItem('darkThemeSettings');
            return stored ? { ...defaultDarkSettings, ...JSON.parse(stored) } : defaultDarkSettings;
        } catch {
            return defaultDarkSettings;
        }
    });

    // Optimize: Debounce localStorage writes to avoid excessive I/O
    useEffect(() => {
        const timeoutId = setTimeout(() => {
            localStorage.setItem('lightThemeSettings', JSON.stringify(lightSettings));
        }, 300);
        return () => clearTimeout(timeoutId);
    }, [lightSettings]);

    useEffect(() => {
        const timeoutId = setTimeout(() => {
            localStorage.setItem('darkThemeSettings', JSON.stringify(darkSettings));
        }, 300);
        return () => clearTimeout(timeoutId);
    }, [darkSettings]);


    // Effect to update CSS variables and body attribute based on current theme
    useEffect(() => {
        const rootStyle = document.documentElement.style;
        const currentSettings = isDarkMode ? darkSettings : lightSettings;

        document.body.dataset.theme = isDarkMode ? 'dark' : 'light';
        if (isDarkMode) {
            document.documentElement.classList.add('dark');
        } else {
            document.documentElement.classList.remove('dark');
        }
        try {
            localStorage.setItem('theme', isDarkMode ? 'dark' : 'light');
        } catch {}

        // Map settings to CSS variables used by Tailwind
        rootStyle.setProperty('--primary', hexToHSL(currentSettings.primaryColor));
        rootStyle.setProperty('--secondary', hexToHSL(currentSettings.secondaryColor));
        rootStyle.setProperty('--accent', hexToHSL(currentSettings.accentColor));
        rootStyle.setProperty('--foreground', hexToHSL(currentSettings.textColor));
        rootStyle.setProperty('--card', hexToHSL(currentSettings.cardColor));
        rootStyle.setProperty('--background', hexToHSL(currentSettings.headerColor));
    }, [lightSettings, darkSettings, isDarkMode]);
    
    // Toggle theme and persist
    const toggleTheme = useCallback(() => {
        setIsDarkMode(prev => {
            const next = !prev;
            try { localStorage.setItem('theme', next ? 'dark' : 'light'); } catch {}
            return next;
        });
    }, []);

    const settings = useMemo(() => (isDarkMode ? darkSettings : lightSettings), [isDarkMode, darkSettings, lightSettings]);

    const setSettings = useCallback((newSettings: ThemeSettings) => {
        if (isDarkMode) {
            setDarkSettings(newSettings);
            try { localStorage.setItem('darkThemeSettings', JSON.stringify(newSettings)); } catch {}
        } else {
            setLightSettings(newSettings);
            try { localStorage.setItem('lightThemeSettings', JSON.stringify(newSettings)); } catch {}
        }
    }, [isDarkMode]);
    
    const value = useMemo(() => ({
        isDarkMode,
        toggleTheme,
        settings,
        setSettings,
    }), [isDarkMode, toggleTheme, settings, setSettings]);

    return (
        <ThemeContext.Provider value={value}>
            {children}
        </ThemeContext.Provider>
    );
};
