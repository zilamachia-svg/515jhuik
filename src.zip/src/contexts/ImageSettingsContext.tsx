import { createContext, useContext, useState, useEffect, useMemo, useCallback, PropsWithChildren } from 'react';

export type ImageFormat = 'webp' | 'avif';

export interface ImageSettings {
    format: ImageFormat;
    quality: number;
}

interface ImageSettingsContextType {
    settings: ImageSettings;
    setSettings: (settings: ImageSettings) => void;
}

const defaultSettings: ImageSettings = {
    format: 'webp',
    quality: 80,
};

const ImageSettingsContext = createContext<ImageSettingsContextType | undefined>(undefined);

export const useImageSettings = () => {
    const context = useContext(ImageSettingsContext);
    if (!context) {
        throw new Error('useImageSettings must be used within an ImageSettingsProvider');
    }
    return context;
};

export const ImageSettingsProvider = ({ children }: PropsWithChildren) => {
    const [settings, setSettings] = useState<ImageSettings>(() => {
        try {
            const storedSettings = localStorage.getItem('imageSettings');
            if (storedSettings) {
                const parsed = JSON.parse(storedSettings);
                // Merge with defaults to ensure all keys are present
                return { ...defaultSettings, ...parsed };
            }
        } catch (error) {
            console.error("Failed to parse image settings from localStorage", error);
        }
        return defaultSettings;
    });

    useEffect(() => {
        try {
            localStorage.setItem('imageSettings', JSON.stringify(settings));
        } catch (error) {
            console.error("Failed to save image settings to localStorage", error);
        }
    }, [settings]);

    const handleSetSettings = useCallback((newSettings: ImageSettings) => {
        setSettings(newSettings);
    }, []);

    const value = useMemo(() => ({
        settings,
        setSettings: handleSetSettings,
    }), [settings, handleSetSettings]);

    return (
        <ImageSettingsContext.Provider value={value}>
            {children}
        </ImageSettingsContext.Provider>
    );
};
