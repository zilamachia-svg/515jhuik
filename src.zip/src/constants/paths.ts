// src/constants/paths.ts

export const PATHS = {
  // --- General Pages ---
  HOME: '/',
  STORE: '/store',
  DEPOSIT: '/deposit',
  DEPOSIT_HISTORY: '/history/deposits',
  ORDERS_HISTORY: '/history/orders',
  LEADERBOARD: '/leaderboard',
  DOCUMENTS: '/documents',
  API_DOCS: '/api-docs',
  AFFILIATE: '/affiliate',
  CONTACT: '/contact',
  POSTS: '/posts',
  FAQ: '/faq',
  TERMS: '/terms',
  PRIVACY_POLICY: '/privacy-policy',
  WARRANTY: '/warranty',
  CONDITIONS: '/conditions',
  GUIDE: '/guide',

  // --- Auth Pages ---
  LOGIN: '/login',
  REGISTER: '/register',
  FORGOT_PASSWORD: '/forgot-password',
  RESET_PASSWORD: '/reset-password',
  VERIFY_EMAIL: '/email/verify',

  // --- Tool Pages ---
  TOOLS: '/cong-cu',
  TOOLS_GET_2FA: '/cong-cu/get-2fa',
  TOOLS_CHECK_LIVE_FB: '/cong-cu/check-live-fb',

  // --- Settings Pages ---
  SETTINGS: '/settings',
  PROFILE: '/settings/profile',
  PREFERENCES: '/settings/preferences',
  // Tasks moved to settings
  TASKS: '/settings/tasks',

  // --- Admin Pages ---
  ADMIN: '/admin',
  ADMIN_DASHBOARD: '/admin/dashboard',
  ADMIN_USERS: '/admin/users',
  
  // Admin Store
  ADMIN_ORDERS: '/admin/orders',
  ADMIN_DEPOSITS: '/admin/deposits',
  ADMIN_PRODUCTS: '/admin/products',
  ADMIN_PRODUCT_CATEGORIES: '/admin/product-categories',
  ADMIN_UPLOAD_PRODUCTS: '/admin/products/upload',
  ADMIN_ACCOUNTS_IMPORT: '/admin/accounts/import',
  ADMIN_SUPPLIERS: '/admin/suppliers',

  // Admin Content
  ADMIN_POSTS: '/admin/posts',
  ADMIN_FAQ: '/admin/faq',
  ADMIN_FILES: '/admin/files',

  // Admin Marketing
  ADMIN_API_KEYS: '/admin/api-keys',
  ADMIN_AFFILIATE: '/admin/affiliate',
  
  // Admin Settings
  ADMIN_SETTINGS: '/admin/settings',
  ADMIN_SETTINGS_GENERAL: '/admin/settings/general',
  ADMIN_SETTINGS_PAYMENT: '/admin/settings/payment',
  ADMIN_SETTINGS_THEME: '/admin/settings/theme',
  ADMIN_SETTINGS_IMAGES: '/admin/settings/images',
  ADMIN_SETTINGS_SERVICE_API: '/admin/settings/service-api',
  ADMIN_SETTINGS_TOOLS: '/admin/settings/tools',
  ADMIN_SETTINGS_ROLES: '/admin/settings/roles',
  ADMIN_SETTINGS_NOTIFICATIONS: '/admin/settings/notifications',
  ADMIN_SETTINGS_SECURITY: '/admin/settings/security',
  ADMIN_SETTINGS_SYSTEM: '/admin/settings/system',
  ADMIN_API_LOGS: '/admin/api-logs',
};
