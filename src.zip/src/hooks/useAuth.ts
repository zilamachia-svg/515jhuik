/**
 * useAuth Hook
 * Convenient hook for authentication operations
 */

import { useCallback } from 'react';
import { useUser } from '../services/UserContext';
import { authApi, LoginCredentials, RegisterData } from '../api';
import { useApi } from './useApi';

export function useAuth() {
  const { user, setUser, logout: contextLogout } = useUser();

  const loginMutation = useApi(authApi.login, {
    onSuccess: (user) => {
      setUser(user);
    },
    showSuccessToast: true,
    successMessage: 'Đăng nhập thành công!',
  });

  const registerMutation = useApi(authApi.register, {
    onSuccess: (user) => {
      setUser(user);
    },
    showSuccessToast: true,
    successMessage: 'Đăng ký thành công!',
  });

  const logoutMutation = useApi(authApi.logout, {
    onSuccess: () => {
      contextLogout();
    },
    showSuccessToast: true,
    successMessage: 'Đã đăng xuất!',
  });

  const login = useCallback(
    async (credentials: LoginCredentials) => {
      return await loginMutation.execute(credentials);
    },
    [loginMutation]
  );

  const register = useCallback(
    async (data: RegisterData) => {
      return await registerMutation.execute(data);
    },
    [registerMutation]
  );

  const logout = useCallback(async () => {
    await logoutMutation.execute();
  }, [logoutMutation]);

  return {
    user,
    isAuthenticated: !!user,
    login,
    register,
    logout,
    isLoggingIn: loginMutation.isLoading,
    isRegistering: registerMutation.isLoading,
    isLoggingOut: logoutMutation.isLoading,
  };
}
