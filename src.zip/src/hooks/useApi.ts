/**
 * useApi Hook
 * Generic hook for API calls with loading, error states
 */

import { useState, useCallback } from 'react';
import { toast } from 'sonner';
import { ApiError } from '../types';
import { formatApiErrorForToast } from '../utils';

interface UseApiOptions<T> {
  onSuccess?: (data: T) => void;
  onError?: (error: ApiError) => void;
  showErrorToast?: boolean;
  showSuccessToast?: boolean;
  successMessage?: string;
}

interface UseApiReturn<T, P extends any[]> {
  data: T | null;
  isLoading: boolean;
  error: ApiError | null;
  execute: (...params: P) => Promise<T | null>;
  reset: () => void;
}

export function useApi<T, P extends any[] = []>(
  apiFunc: (...params: P) => Promise<T>,
  options: UseApiOptions<T> = {}
): UseApiReturn<T, P> {
  const {
    onSuccess,
    onError,
    showErrorToast = true,
    showSuccessToast = false,
    successMessage,
  } = options;

  const [data, setData] = useState<T | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<ApiError | null>(null);

  const execute = useCallback(
    async (...params: P): Promise<T | null> => {
      setIsLoading(true);
      setError(null);

      try {
        const result = await apiFunc(...params);
        setData(result);

        if (showSuccessToast && successMessage) {
          toast.success(successMessage);
        }

        if (onSuccess) {
          onSuccess(result);
        }

        return result;
      } catch (err) {
        const apiError = err as ApiError;
        setError(apiError);

        if (showErrorToast) {
          toast.error(formatApiErrorForToast(apiError));
        }

        if (onError) {
          onError(apiError);
        }

        return null;
      } finally {
        setIsLoading(false);
      }
    },
    [apiFunc, onSuccess, onError, showErrorToast, showSuccessToast, successMessage]
  );

  const reset = useCallback(() => {
    setData(null);
    setError(null);
    setIsLoading(false);
  }, []);

  return { data, isLoading, error, execute, reset };
}
