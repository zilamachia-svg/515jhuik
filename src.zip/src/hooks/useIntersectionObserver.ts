import { useState, useEffect, RefObject } from 'react';

interface IntersectionObserverOptions {
    root?: Element | null;
    rootMargin?: string;
    threshold?: number | number[];
}

export const useIntersectionObserver = (
    elementRef: RefObject<Element>,
    options: IntersectionObserverOptions
): boolean => {
    const [isIntersecting, setIsIntersecting] = useState(false);

    useEffect(() => {
        const element = elementRef.current;
        if (!element) return;

        const observer = new IntersectionObserver(
            ([entry]) => {
                // Update state when observer callback fires
                setIsIntersecting(entry.isIntersecting);
            },
            options
        );

        observer.observe(element);

        // Cleanup function
        return () => {
            observer.unobserve(element);
        };
    }, [elementRef, options]); // Re-run effect if ref or options change

    return isIntersecting;
};
