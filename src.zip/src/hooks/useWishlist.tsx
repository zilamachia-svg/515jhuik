/**
 * Wishlist Hook & Management
 * Complete wishlist functionality with local storage sync
 */

import { useState, useEffect, useCallback, createContext, useContext, ReactNode } from 'react';
import { wishlistApi, WishlistItem } from '../api/features.api';
import { toast } from 'sonner';

export const useWishlist = () => {
  const [items, setItems] = useState<WishlistItem[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [count, setCount] = useState(0);

  // Load wishlist from API or localStorage
  useEffect(() => {
    const loadWishlist = async () => {
      setIsLoading(true);
      try {
        const response = await wishlistApi.getAll();
        if (response.data.success) {
          setItems(response.data.data);
          setCount(response.data.count);
        }
      } catch (error) {
        console.error('Failed to load wishlist:', error);
        // Fallback to localStorage if API fails
        const saved = localStorage.getItem('wishlist');
        if (saved) {
          const parsed = JSON.parse(saved);
          setItems(parsed);
          setCount(parsed.length);
        }
      } finally {
        setIsLoading(false);
      }
    };

    loadWishlist();
  }, []);

  // Sync to localStorage
  useEffect(() => {
    localStorage.setItem('wishlist', JSON.stringify(items));
  }, [items]);

  // Add to wishlist
  const addToWishlist = useCallback(async (productId: number, productName?: string) => {
    try {
      const response = await wishlistApi.add(productId);
      if (response.data.success) {
        setItems((prev) => [...prev, response.data.data]);
        setCount((prev) => prev + 1);
        toast.success(response.data.message || `Đã thêm ${productName || 'sản phẩm'} vào danh sách yêu thích`);
        return true;
      }
    } catch (error: unknown) {
      const err = error as { response?: { data?: { message?: string } } };
      toast.error(err.response?.data?.message || 'Không thể thêm vào danh sách yêu thích');
      return false;
    }
  }, []);

  // Remove from wishlist
  const removeFromWishlist = useCallback(async (productId: number, productName?: string) => {
    try {
      const response = await wishlistApi.remove(productId);
      if (response.data.success) {
        setItems((prev) => prev.filter((item) => item.product_id !== productId));
        setCount((prev) => prev - 1);
        toast.success(response.data.message || `Đã xóa ${productName || 'sản phẩm'} khỏi danh sách yêu thích`);
        return true;
      }
    } catch (error: unknown) {
      const err = error as { response?: { data?: { message?: string } } };
      toast.error(err.response?.data?.message || 'Không thể xóa khỏi danh sách yêu thích');
      return false;
    }
  }, []);

  // Toggle wishlist
  const toggleWishlist = useCallback(
    async (productId: number, productName?: string) => {
      const isInWishlist = items.some((item) => item.product_id === productId);
      if (isInWishlist) {
        return await removeFromWishlist(productId, productName);
      } else {
        return await addToWishlist(productId, productName);
      }
    },
    [items, addToWishlist, removeFromWishlist]
  );

  // Check if product is in wishlist
  const isInWishlist = useCallback(
    (productId: number): boolean => {
      return items.some((item) => item.product_id === productId);
    },
    [items]
  );

  // Clear all
  const clearWishlist = useCallback(() => {
    setItems([]);
    setCount(0);
    localStorage.removeItem('wishlist');
  }, []);

  return {
    items,
    count,
    isLoading,
    addToWishlist,
    removeFromWishlist,
    toggleWishlist,
    isInWishlist,
    clearWishlist,
  };
};

// Wishlist Context for global state
export type WishlistContextType = ReturnType<typeof useWishlist>;

const WishlistContext = createContext<WishlistContextType | undefined>(undefined);

export const WishlistProvider = ({ children }: { children: ReactNode }) => {
  const wishlist = useWishlist();
  return (
    <WishlistContext.Provider value={wishlist}>
      {children}
    </WishlistContext.Provider>
  );
};

export const useWishlistContext = () => {
  const context = useContext(WishlistContext);
  if (!context) {
    throw new Error('useWishlistContext must be used within WishlistProvider');
  }
  return context;
};
