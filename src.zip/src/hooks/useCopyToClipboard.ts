import { useState, useCallback } from 'react';
// FIX: Use 'sonner' for toast notifications to maintain consistency.
import { toast } from 'sonner';

export const useCopyToClipboard = (): [(text: string, successMessage?: string) => void, boolean] => {
    const [isCopied, setIsCopied] = useState(false);

    const copy = useCallback((text: string, successMessage: string = 'Đã sao chép!') => {
        if (isCopied) return;
        navigator.clipboard.writeText(text).then(() => {
            setIsCopied(true);
            toast.success(successMessage);
            setTimeout(() => {
                setIsCopied(false);
            }, 2000); // Reset after 2 seconds
        }).catch(err => {
            console.error('Failed to copy text: ', err);
            toast.error('Sao chép thất bại.');
        });
    }, [isCopied]);

    return [copy, isCopied];
};
