/**
 * Hook to use Google Maps API
 * Ensures the Google Maps script is loaded before using maps
 */

import { useState, useEffect } from 'react';

export interface GoogleMapsStatus {
  isLoaded: boolean;
  isLoading: boolean;
  error: Error | null;
}

// Avoid declaring global `google` to prevent conflicts with external type packages.
// Use (window as any).google where needed.

export const useGoogleMaps = (): GoogleMapsStatus => {
  const [status, setStatus] = useState<GoogleMapsStatus>({
    isLoaded: false,
    isLoading: true,
    error: null,
  });

  useEffect(() => {
    // Check if Google Maps is already loaded
    if ((window as any).google && (window as any).google.maps) {
      setStatus({
        isLoaded: true,
        isLoading: false,
        error: null,
      });
      return;
    }

    // Check if script is already in the document
    const existingScript = document.querySelector(
      'script[src*="maps.googleapis.com/maps/api/js"]'
    );

    if (existingScript) {
      // Script exists, wait for it to load
      const checkInterval = setInterval(() => {
        if ((window as any).google && (window as any).google.maps) {
          setStatus({
            isLoaded: true,
            isLoading: false,
            error: null,
          });
          clearInterval(checkInterval);
        }
      }, 100);

      // Timeout after 10 seconds
      setTimeout(() => {
        clearInterval(checkInterval);
        if (!(window as any).google || !(window as any).google.maps) {
          setStatus({
            isLoaded: false,
            isLoading: false,
            error: new Error('Google Maps API failed to load'),
          });
        }
      }, 10000);

      return () => clearInterval(checkInterval);
    }

    // Script doesn't exist (shouldn't happen if it's in index.html)
    setStatus({
      isLoaded: false,
      isLoading: false,
      error: new Error('Google Maps script not found'),
    });
  }, []);

  return status;
};

