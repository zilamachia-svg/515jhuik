import apiClient from './apiClient';

/**
 * In a real application, these types would be imported from a shared types file,
 * likely matching the structure defined in `backend/docs/dashboard/dashboard.model.ts`.
 */
export interface DashboardData {
    stats: {
        totalRevenue: number;
        newUsersMonthly: number;
        newOrders24h: number;
        conversionRate: number;
    };
    revenueLast7Days: { day: string; amount: number }[];
    recentActivities: { type: 'newUser' | 'newOrder'; text: string; timestamp: string, link?: string; }[];
    topProducts: { name: string; sales: number; link?: string; }[];
}

/**
 * Fetches the data for the admin dashboard from the API.
 */
export const fetchDashboardData = async (): Promise<DashboardData> => {
    try {
        const response = await apiClient.get('/admin/dashboard');
        return response.data;
    } catch (error) {
        console.error("Failed to fetch dashboard data:", error);
        // In a real app, you might want to return a default/empty state
        // or re-throw the error to be handled by the calling component.
        throw error;
    }
};