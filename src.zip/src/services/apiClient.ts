// src/services/apiClient.ts
import axios, { InternalAxiosRequestConfig, AxiosError } from "axios";
import { toast } from 'sonner';
import { setupMocks } from "./mockAdapter";
import { logRequest } from "./apiLogService";
import { API_CONFIG, APP_CONFIG } from "../config";
import { 
  classifyError, 
  formatErrorMessage, 
  logError, 
  shouldRetry, 
  calculateRetryDelay, 
  sleep,
  ErrorType 
} from "./errorHandler";

// Extend InternalAxiosRequestConfig to include retry count
interface ExtendedAxiosRequestConfig extends InternalAxiosRequestConfig {
  _retry?: boolean;
  _retry401?: boolean;
  _retryCount?: number;
}

// === CONFIGURATION ===
const apiClient = axios.create({
  baseURL: API_CONFIG.baseURL,
  withCredentials: true,
  withXSRFToken: true,  // Auto-send XSRF token
  headers: {
    Accept: API_CONFIG.headers.accept,
    "X-Requested-With": API_CONFIG.headers.requestedWith,
    "Content-Type": API_CONFIG.headers.contentType,
  },
  timeout: API_CONFIG.timeout,
});

// CSRF token cache to avoid multiple requests
let csrfTokenFetched = false;
let csrfTokenPromise: Promise<void> | null = null;

// Check if we're running on localhost (CORS issues)
const isLocalhost = (): boolean => {
  if (typeof window === 'undefined') return false;
  const hostname = window.location.hostname;
  return hostname === 'localhost' || hostname === '127.0.0.1' || hostname === '';
};

// Function to get CSRF cookie
const ensureCsrfCookie = async (): Promise<void> => {
  // Skip in dev mode with mock data
  if (APP_CONFIG.isDev && APP_CONFIG.features.mockData) {
    return;
  }

  // Skip if running on localhost connecting to production API (CORS issues)
  if (isLocalhost() && API_CONFIG.baseURL.includes('api.haidangmeta.com')) {
    return;
  }

  // If already fetching, wait for that promise
  if (csrfTokenPromise) {
    return csrfTokenPromise;
  }

  // If already fetched, skip
  if (csrfTokenFetched) {
    return;
  }

  // Create new fetch promise
  csrfTokenPromise = axios.get(`${API_CONFIG.baseURL}${API_CONFIG.csrf.cookieEndpoint}`, {
    withCredentials: true,
    timeout: 5000, // 5 second timeout
  }).then(() => {
    csrfTokenFetched = true;
    csrfTokenPromise = null;
    if (APP_CONFIG.isDev) {
      console.debug("✅ CSRF cookie obtained successfully");
    }
  }).catch((error) => {
    const err = error as { code?: string; message?: string; response?: { status?: number } };
    // Check for CORS errors, connection refused, or 404
    const isCorsError = err.code === 'ERR_NETWORK' || 
                       err.code === 'ECONNREFUSED' ||
                       err.message === 'Network Error' || 
                       err.message?.includes('Failed to fetch') ||
                       err.message?.includes('CORS') ||
                       err.message?.includes('Connection refused') ||
                       err.response?.status === 404;
    
    // If CORS error, silently skip (backend might not be running)
    if (isCorsError) {
      csrfTokenFetched = false;
      csrfTokenPromise = null;
      // Only log in dev mode
      if (APP_CONFIG.isDev) {
        console.debug("⚠️ CSRF cookie request failed (connection issue):", err.code || err.message);
      }
      return; // Don't throw, just skip CSRF
    }
    
    // Log other errors
    if (APP_CONFIG.isDev) {
      console.warn("❌ CSRF cookie pre-flight request failed:", error);
    }
    csrfTokenFetched = false; // Reset on error to retry next time
    csrfTokenPromise = null;
    throw error;
  });

  return csrfTokenPromise;
};

// === REQUEST INTERCEPTOR ===
apiClient.interceptors.request.use(
  async (config: InternalAxiosRequestConfig) => {
    const isCsrfEndpoint = config.url?.includes(API_CONFIG.csrf.cookieEndpoint);
    
    // 1. Ensure CSRF cookie exists for all requests (except CSRF endpoint itself)
    if (!isCsrfEndpoint) {
      try {
        await ensureCsrfCookie();
      } catch (error: unknown) {
        // Continue anyway - some endpoints might not need CSRF
        // Skip logging CORS errors when on localhost
        const err = error as { code?: string; message?: string };
        const isCorsError = err.code === 'ERR_NETWORK' || 
                           err.message === 'Network Error' || 
                           err.message?.includes('Failed to fetch') ||
                           err.message?.includes('CORS');
        
        if (!isCorsError && !isLocalhost()) {
          if (APP_CONFIG.isDev && APP_CONFIG.features.mockData) {
            console.debug("CSRF cookie fetch failed, continuing:", error);
          } else {
            console.debug("CSRF cookie fetch failed, continuing:", error);
          }
        }
      }
    }

    // 2. Get XSRF-TOKEN from cookies and add to headers (for non-GET/HEAD requests only)
    // For GET/HEAD requests, the session cookie is sufficient with Sanctum
    const isGetOrHead = !config.method || config.method.toLowerCase() === 'get' || config.method.toLowerCase() === 'head';
    if (!isCsrfEndpoint && !isGetOrHead) {
      const cookies = document.cookie.split(';');
      const xsrfCookie = cookies.find(cookie => cookie.trim().startsWith('XSRF-TOKEN='));
      if (xsrfCookie) {
        const token = decodeURIComponent(xsrfCookie.split('=')[1]);
        config.headers[API_CONFIG.csrf.tokenHeader] = token;
      }
    }

    // 3. Automatically add '/api/v1' prefix to all requests except the CSRF cookie endpoint.
    const isApiUrl = config.url && (config.url.startsWith(`/api/${API_CONFIG.apiVersion}`) || config.url.startsWith("http"));
    if (config.url && !isApiUrl && !isCsrfEndpoint) {
      config.url = `/api/${API_CONFIG.apiVersion}${config.url.startsWith("/") ? "" : "/"}${config.url}`;
    }

    // 4. Log the request for admin purposes
    logRequest(
      config.method?.toUpperCase() || "UNKNOWN",
      config.url || "",
      config.data
    );

    return config;
  },
  (error) => Promise.reject(error)
);

// === RESPONSE INTERCEPTOR (FOR 419 CSRF RETRY & ERROR TOASTS) ===
apiClient.interceptors.response.use(
  (response) => response,
  async (error: AxiosError & { config: ExtendedAxiosRequestConfig }) => {
    const originalRequest = error.config;
    const status = error.response?.status;

    // Handle 419 CSRF token mismatch by retrying once.
    if (status === 419 && !originalRequest._retry) {
      originalRequest._retry = true;
      console.info("CSRF token expired. Retrying request...");
      // Reset CSRF flag to fetch new token
      csrfTokenFetched = false;
      csrfTokenPromise = null;
      // Get new CSRF cookie before retry
      try {
        await ensureCsrfCookie();
        // Get new XSRF-TOKEN from cookies
        const cookies = document.cookie.split(';');
        const xsrfCookie = cookies.find(cookie => cookie.trim().startsWith('XSRF-TOKEN='));
        if (xsrfCookie) {
          const token = decodeURIComponent(xsrfCookie.split('=')[1]);
          originalRequest.headers[API_CONFIG.csrf.tokenHeader] = token;
        }
      } catch (csrfError) {
        console.warn("Failed to get CSRF cookie for retry:", csrfError);
      }
      return apiClient(originalRequest);
    }
    
    // Handle 401 Unauthorized - retry once after fetching CSRF cookie
    // This helps when CSRF cookie is missing or expired
    if (status === 401 && !originalRequest._retry401 && !originalRequest._retry) {
      const isInitialAuthCheck = originalRequest.url?.endsWith('/me') && originalRequest.method?.toUpperCase() === 'GET';
      
      // Only retry for /me endpoint (not for other endpoints that legitimately require auth)
      if (isInitialAuthCheck) {
        originalRequest._retry401 = true;
        // Only log in dev mode to reduce console noise
        if (APP_CONFIG.isDev) {
          console.debug("401 on /me endpoint. Fetching CSRF cookie and retrying...");
        }
        
        try {
          // Reset CSRF flag to fetch new token
          csrfTokenFetched = false;
          csrfTokenPromise = null;
          await ensureCsrfCookie();
          
          // Get new XSRF-TOKEN from cookies
          const cookies = document.cookie.split(';');
          const xsrfCookie = cookies.find(cookie => cookie.trim().startsWith('XSRF-TOKEN='));
          if (xsrfCookie) {
            const token = decodeURIComponent(xsrfCookie.split('=')[1]);
            originalRequest.headers[API_CONFIG.csrf.tokenHeader] = token;
          }
          
          return apiClient(originalRequest);
        } catch (csrfError) {
          console.warn("Failed to get CSRF cookie for 401 retry:", csrfError);
          // Fall through to normal error handling
        }
      }
    }
    
    // Check if the failed request was the initial 'GET /me' to fetch user data.
    const isInitialAuthCheck = originalRequest.url?.endsWith('/me') && originalRequest.method?.toUpperCase() === 'GET';
    const isNotificationEndpoint = originalRequest.url?.includes('/notifications');

    // Classify the error using the new error handler
    const classification = classifyError(error);
    
    // Skip CORS errors when on localhost (expected behavior when connecting to production API)
    const isCorsError = classification.type === ErrorType.NETWORK;
    const shouldSkipError = isLocalhost() && isCorsError;

    // Handle retryable errors with exponential backoff
    const currentRetryCount = originalRequest._retryCount || 0;
    if (classification.isRetryable && shouldRetry(error, currentRetryCount)) {
      const retryCount = currentRetryCount + 1;
      originalRequest._retryCount = retryCount;
      
      const delay = calculateRetryDelay(error, retryCount - 1);
      
      // Only show retry notification for first retry attempt
      if (retryCount === 1 && classification.shouldNotify) {
        toast.info(`Đang thử lại... (${retryCount}/${3})`, {
          duration: 2000,
        });
      }
      
      // Wait before retrying
      await sleep(delay);
      
      return apiClient(originalRequest);
    }

    // Log error (respects shouldLog flag from classification)
    if (classification.shouldLog) {
      logError(error, `API Request: ${originalRequest.method?.toUpperCase()} ${originalRequest.url}`);
    }

    // Show user-friendly error message
    // Skip:
    // - Expected 401 on initial load (/me endpoint)
    // - 401 on notification endpoints (user might not be logged in)
    // - CORS errors when on localhost
    if (classification.shouldNotify && !(status === 401 && (isInitialAuthCheck || isNotificationEndpoint)) && !shouldSkipError) {
      const errorMessage = formatErrorMessage(error);
      
      toast.error(errorMessage, {
        description: classification.recoverySuggestion || (
          status === 500 
            ? 'Vui lòng thử lại sau hoặc liên hệ hỗ trợ nếu vấn đề vẫn tiếp tục.'
            : undefined
        ),
        duration: status === 500 ? 6000 : 4000,
      });
    } else if (shouldSkipError && APP_CONFIG.isDev) {
      // Silently skip CORS errors on localhost - this is expected
      console.debug("CORS error on localhost (expected when connecting to production API):", originalRequest.url);
    } else if (status === 401 && isInitialAuthCheck) {
      // Log 401 on /me for debugging, but don't show toast (user might not be logged in)
      console.debug("401 on /me - User might not be authenticated (this is normal if not logged in)");
    }

    return Promise.reject(error);
  }
);

// === MOCK DATA FOR DEV ===
if (APP_CONFIG.features.mockData) {
  setupMocks(apiClient);
}

export default apiClient;
export { apiClient };