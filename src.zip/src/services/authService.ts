import apiClient from './apiClient';
import { User } from '../types';

// This file centralizes all authentication and user-related API calls.

export interface LoginCredentials {
    email: string;
    password: string;
    remember?: boolean;
}

export interface RegisterCredentials {
    name: string;
    email: string;
    password: string;
    password_confirmation: string;
}

/** Fetches the currently authenticated user. */
export const fetchCurrentUser = async (): Promise<User> => {
    const response = await apiClient.get('/me');
    // Handle both response.data.user and response.data (if user data is directly in data)
    return response.data?.user || response.data?.data || response.data;
};

/** Logs in a user. */
export const login = async (credentials: LoginCredentials): Promise<User> => {
    // DEBUG: Log credentials being sent
    console.log('🔐 Login attempt with:', {
        email: credentials.email,
        password: credentials.password ? `${credentials.password.length} chars` : 'empty',
        remember: credentials.remember
    });
    
    // CRITICAL: Ensure CSRF cookie is obtained before login
    // This fixes 422 validation errors when logging in from modal
    try {
        await apiClient.get('/sanctum/csrf-cookie');
        console.log('✅ CSRF cookie obtained before login');
    } catch (error) {
        console.warn('⚠️ Failed to get CSRF cookie, continuing anyway:', error);
    }
    
    const response = await apiClient.post('/login', credentials);
    console.log('✅ Login response:', response.data);
    // Handle different response formats
    return response.data?.user || response.data?.data || response.data;
};

/** Registers a new user. */
export const register = async (userData: RegisterCredentials): Promise<User> => {
    const response = await apiClient.post('/register', userData);
    // Handle different response formats
    return response.data?.user || response.data?.data || response.data;
};

/** Logs out the current user. */
export const logout = async (): Promise<void> => {
    await apiClient.post('/logout');
};

/** Sends a password reset link. */
export const forgotPassword = async (email: string): Promise<void> => {
    await apiClient.post('/forgot-password', { email });
};

/** Resets a user's password using a token. */
export const resetPassword = async (data: object): Promise<void> => {
    await apiClient.post('/reset-password', data);
};

/** Resends the verification email. */
export const resendVerification = async (): Promise<void> => {
    await apiClient.post('/email/resend-verification');
};

/** Verifies a user's email from a link. */
export const verifyFromLink = async (url: object): Promise<void> => {
    await apiClient.post('/email/verify-from-link', url);
};

/** Updates the current user's profile. Accepts partial data (name, email, avatar, etc.). */
export const updateProfile = async (data: Record<string, any>): Promise<User> => {
    const response = await apiClient.put('/me', data);
    // Handle different response formats
    return response.data?.user || response.data?.data || response.data;
};

/** Updates the current user's password. */
export const updatePassword = async (data: object): Promise<void> => {
    await apiClient.put('/me/password', data);
};

/** Sends email verification code. */
export const sendEmailVerificationCode = async (email: string): Promise<void> => {
    await apiClient.post('/me/email/send-verification-code', { email });
};

/** Verifies email with code. */
export const verifyEmailCode = async (email: string, code: string): Promise<User> => {
    const response = await apiClient.post('/me/email/verify-code', { email, code });
    return response.data?.user || response.data?.data || response.data;
};