import MockAdapter from 'axios-mock-adapter';
import { AxiosInstance, AxiosRequestConfig } from 'axios';
import * as mockData from './mockData';
import { Product, User, Faq, Post, ProductCategory, PaymentMethod, Order, Deposit, Commission, AdminApiKey } from '../types';

export const setupMocks = (apiClient: AxiosInstance) => {
    const mock = new MockAdapter(apiClient, { delayResponse: 500 });

    const API_PREFIX = '/api/v1';

    const parseJson = <T>(config: AxiosRequestConfig): T => {
        if (!config.data) {
            return {} as T;
        }
        if (typeof config.data === 'string') {
            try {
                return JSON.parse(config.data) as T;
            } catch {
                return {} as T;
            }
        }
        return config.data as T;
    };

    const toNumber = (value: unknown, fallback: number) => {
        const parsed = Number(value);
        return Number.isFinite(parsed) && parsed > 0 ? parsed : fallback;
    };

    const paginate = <T>(items: T[], pageParam: unknown, limitParam: unknown, defaultLimit = 10) => {
        const limit = toNumber(limitParam, defaultLimit);
        const totalItems = items.length;
        const totalPages = Math.max(1, Math.ceil(totalItems / limit));
        const requestedPage = toNumber(pageParam, 1);
        const currentPage = Math.min(Math.max(requestedPage, 1), totalPages);
        const startIndex = (currentPage - 1) * limit;
        const data = items.slice(startIndex, startIndex + limit);

        return {
            data,
            totalPages: totalItems === 0 ? 0 : totalPages,
            totalItems,
            currentPage: totalItems === 0 ? 1 : currentPage,
        };
    };

    const generateId = (prefix: string) => `${prefix}_${Math.random().toString(36).slice(2, 10)}`;

    const nowIso = () => new Date().toISOString();

    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    const clone = <T extends Record<string, any>>(items: T[]): T[] => items.map(item => ({ ...item }));

    const users: User[] = clone(mockData.mockUsers);
    let products: Product[] = clone(mockData.mockProducts);
    let productCategories: ProductCategory[] = clone(mockData.mockProductCategories);
    let posts: Post[] = clone(mockData.mockPosts);
    let faqs: Faq[] = clone(mockData.mockFaqs);
    let paymentMethods: PaymentMethod[] = clone(mockData.mockPaymentMethods);
    let deposits: Deposit[] = mockData.mockDeposits.map(dep => ({ ...dep }));
    const affiliateCommissions: Commission[] = mockData.mockAdminCommissions.map(c => ({ ...c }));
    let orders: Order[] = mockData.mockOrders.map(order => ({
        ...order,
        items: order.items ? order.items.map(item => ({ ...item })) : undefined,
    }));
    let apiKeys: AdminApiKey[] = mockData.mockApiKeys.map(key => ({ ...key }));

    const buildValidationError = (errors: Record<string, string[]>) => ({
        message: 'Validation failed',
        errors,
    });

    const recalcCategoryCounts = () => {
        productCategories = productCategories.map(cat => ({
            ...cat,
            product_count: products.filter(product => product.category === cat.name).length,
        }));
    };

    const findItemIndex = <T extends { id: string | number }>(collection: T[], id: string | number) =>
        collection.findIndex(item => item.id === id);

    const extractIdFromUrl = (url?: string) => url?.split('/').pop() ?? '';

    const normalizeStatus = (status: unknown) => (typeof status === 'string' ? status : '');

    // === AUTH ===
    mock.onGet(`${API_PREFIX}/me`).reply(200, { user: mockData.mockUser });

    mock.onPost(`${API_PREFIX}/login`).reply(config => {
        const { email, password } = parseJson<{ email: string; password: string }>(config);
        if (email === 'admin@haidang.com' && password === 'password') {
            return [200, { user: mockData.mockUser }];
        }
        if (email === 'user@haidang.com' && password === 'password') {
            return [200, { user: { ...mockData.mockUser, id: 2, name: 'Normal User', role: 'user', balance: 250000, emailVerified: false } }];
        }
        return [422, { message: 'Thông tin đăng nhập không chính xác.' }];
    });

    mock.onPost(`${API_PREFIX}/register`).reply(200, { user: mockData.mockUser });
    mock.onPost(`${API_PREFIX}/logout`).reply(200);
    mock.onPost(`${API_PREFIX}/forgot-password`).reply(200);
    mock.onPost(`${API_PREFIX}/reset-password`).reply(200);
    mock.onPost(`${API_PREFIX}/email/resend-verification`).reply(200);
    mock.onPut(`${API_PREFIX}/me`).reply(200, { user: mockData.mockUser });
    mock.onPut(`${API_PREFIX}/me/password`).reply(200);
    mock.onPost(`${API_PREFIX}/email/verify-from-link`).reply(200);

    // === DYNAMIC PRODUCTS MOCK ===
    mock.onGet(`${API_PREFIX}/products`).reply((config: AxiosRequestConfig) => {
        const { params = {} } = config;
        let filtered: Product[] = [...products];

        if (params.search) {
            const searchTerm = params.search.toString().toLowerCase();
            filtered = filtered.filter(p => p.name.toLowerCase().includes(searchTerm) || p.description.toLowerCase().includes(searchTerm));
        }
        if (params.category && params.category !== 'all') {
            filtered = filtered.filter(p => p.category === params.category);
        }
        if (params.country && params.country !== 'all') {
            filtered = filtered.filter(p => p.country === params.country);
        }
        if (params.price_min) {
            filtered = filtered.filter(p => p.price >= Number(params.price_min));
        }
        if (params.price_max) {
            filtered = filtered.filter(p => p.price <= Number(params.price_max));
        }
        if (params.in_stock) {
            filtered = filtered.filter(p => p.stock > 0);
        }

        if (params.sortBy) {
            switch (params.sortBy) {
                case 'price_asc':
                    filtered.sort((a, b) => a.price - b.price);
                    break;
                case 'price_desc':
                    filtered.sort((a, b) => b.price - a.price);
                    break;
                case 'stock_desc':
                    filtered.sort((a, b) => b.stock - a.stock);
                    break;
            }
        }
        
        const { data, totalPages, totalItems, currentPage } = paginate(filtered, params.page, params.limit, Number(params.limit) || 12);

        return [200, { data, totalPages, totalItems, currentPage }];
    });

    mock.onGet(`${API_PREFIX}/products/filters`).reply(() => {
        const uniqueCountries = Array.from(new Set(products.map(p => p.country))).sort();
        const uniqueCategories = Array.from(new Set(products.map(p => p.category))).sort();
        return [200, {
            uniqueCountries,
            uniqueCategories,
        }];
    });

    // === ORDERS ===
    mock.onPost(`${API_PREFIX}/orders`).reply(config => {
        const purchaseId = generateId('ord');
        const payload = parseJson<{ productId?: string; quantity?: number }>(config);
        const quantity = payload.quantity ?? 1;
        const product = payload.productId ? products.find(p => p.id === payload.productId) : null;

        if (product) {
            product.stock = Math.max(product.stock - quantity, 0);
        }

        const newOrder: Order = {
            id: purchaseId,
            productName: product?.name ?? 'Sản phẩm mẫu',
            quantity,
            totalPrice: (product?.price ?? 50000) * quantity,
            purchaseDate: nowIso(),
            status: 'Đã hoàn thành',
            userEmail: mockData.mockUser.email,
            items: [{ data: 'uid|pass|2fa' }],
        };

        orders = [newOrder, ...orders];

        return [200, {
        message: "Mua hàng thành công!",
            orderId: purchaseId,
            downloadLink: `https://haidangmeta.com/download/${purchaseId}?token=abc`,
            newBalance: mockData.mockUser.balance - newOrder.totalPrice,
        }];
    });

    mock.onGet(new RegExp(`${API_PREFIX}/orders$`)).reply(config => {
        const { params = {} } = config;
        const search = (params.search ?? '').toString().toLowerCase();
        let filtered = [...orders];
        if (search) {
            filtered = filtered.filter(order =>
                order.productName.toLowerCase().includes(search) ||
                order.userEmail?.toLowerCase().includes(search) ||
                order.id.toLowerCase().includes(search)
            );
        }
        const { data, totalPages, totalItems, currentPage } = paginate(filtered, params.page, params.limit, Number(params.limit) || 10);
        return [200, { data, totalPages, totalItems, currentPage }];
    });

    mock.onGet(new RegExp(`https://haidangmeta.com/download/ord_.*`)).reply(200, mockData.mockOrderDataString);

    // === DEPOSITS ===
    mock.onGet(`${API_PREFIX}/deposits`).reply(config => {
        const { params = {} } = config;
        const search = (params.search ?? '').toString().toLowerCase();
        let filtered = [...deposits];
        if (search) {
            filtered = filtered.filter(deposit =>
                deposit.userEmail?.toLowerCase().includes(search) ||
                deposit.transactionCode?.toLowerCase().includes(search)
            );
        }
        const { data, totalPages, totalItems, currentPage } = paginate(filtered, params.page, params.limit, Number(params.limit) || 10);
        return [200, { data, totalPages, totalItems, currentPage }];
    });

    mock.onPost(`${API_PREFIX}/deposits`).reply(config => {
        const payload = parseJson<{ amount: number; payment_method_id: string }>(config);
        const method = paymentMethods.find(m => m.id === payload.payment_method_id);
        
        if (!method) {
            return [404, { message: 'Phương thức thanh toán không tồn tại.' }];
        }

        if (payload.amount < 10000) {
            return [400, { message: 'Số tiền nạp tối thiểu là 10,000 VNĐ.' }];
        }

        if (payload.amount > 50000000) {
            return [400, { message: 'Số tiền nạp tối đa là 50,000,000 VNĐ.' }];
        }

        const newDeposit: Deposit = {
            id: generateId('dep'),
            amount: payload.amount,
            method: method.name,
            createdAt: nowIso(),
            status: 'Đang chờ',
            transactionCode: `HDM${Date.now()}${Math.random().toString(36).slice(2, 6).toUpperCase()}`,
        };

        deposits = [newDeposit, ...deposits];
        return [201, { deposit: newDeposit }];
    });

    mock.onGet(`${API_PREFIX}/payment-methods`).reply(200, { methods: paymentMethods });
    
    // === LEADERBOARD ===
    mock.onGet(`${API_PREFIX}/users/top-depositors`).reply(200, mockData.mockTopUsers);
    
    // === TOOLS ===
    mock.onPost(`${API_PREFIX}/tools/check-live-fb`).reply(config => {
        const { uids } = parseJson<{ uids: string[] }>(config);
        const results = (uids || []).map(uid => ({
            uid,
            status: Math.random() > 0.3 ? 'Live' : 'Die',
        }));
        return [200, { results }];
    });

    // === AFFILIATE ===
    mock.onGet(`${API_PREFIX}/affiliate/stats`).reply(200, mockData.mockAffiliateStats);
    mock.onGet(`${API_PREFIX}/affiliate/commissions`).reply(config => {
        const { params = {} } = config;
        const search = (params.search ?? '').toString().toLowerCase();
        let filtered = [...affiliateCommissions];
        if (search) {
            filtered = filtered.filter(c =>
                c.userEmail?.toLowerCase().includes(search) ||
                c.orderId.toLowerCase().includes(search)
            );
        }
        const { data, totalPages, totalItems, currentPage } = paginate(filtered, params.page, params.limit, Number(params.limit) || 10);
        return [200, { data, totalPages, totalItems, currentPage }];
    });
    
    // === CONTENT ===
    mock.onGet(`${API_PREFIX}/posts`).reply(() => {
        const publishedPosts = posts.filter(post => post.status === 'published');
        return [200, { posts: publishedPosts }];
    });

    mock.onGet(new RegExp(`${API_PREFIX}/posts/[^/]+$`)).reply(config => {
        const slugOrId = extractIdFromUrl(config.url);
        const post = posts.find(p => p.slug === slugOrId || p.id === slugOrId);
        if (!post) {
            return [404, { message: 'Không tìm thấy bài viết.' }];
        }
        return [200, { post }];
    });

    mock.onGet(`${API_PREFIX}/faq`).reply(() => [200, { faqs: faqs.sort((a, b) => a.order - b.order) }]);

    // === TASKS ===
    mock.onGet(`${API_PREFIX}/tasks`).reply(200, { tasks: mockData.mockTasks });
    mock.onPost(`${API_PREFIX}/tasks`).reply(config => {
        const { title, priority } = parseJson<{ title: string; priority: 'low' | 'medium' | 'high' }>(config);
        const newTask = { id: `task_${Date.now()}`, title, priority, isCompleted: false };
        return [201, { task: newTask }];
    });
    mock.onPut(new RegExp(`${API_PREFIX}/tasks/[^/]+$`)).reply(200);
    mock.onDelete(new RegExp(`${API_PREFIX}/tasks/[^/]+$`)).reply(204);

    // === ADMIN ===
    mock.onGet(`${API_PREFIX}/admin/dashboard`).reply(200, mockData.mockAdminDashboardData);

    // Users
    mock.onGet(`${API_PREFIX}/admin/users`).reply(config => {
        const { params = {} } = config;
        const search = (params.search ?? '').toString().toLowerCase();
        let filtered = [...users];
        if (search) {
            filtered = filtered.filter(user =>
                user.name.toLowerCase().includes(search) ||
                user.email.toLowerCase().includes(search)
            );
        }
        const { data, totalPages, totalItems, currentPage } = paginate(filtered, params.page, params.limit, Number(params.limit) || 10);
        return [200, { data, totalPages, totalItems, currentPage }];
    });

    mock.onPut(new RegExp(`${API_PREFIX}/admin/users/[^/]+$`)).reply(config => {
        const id = Number(extractIdFromUrl(config.url));
        const index = findItemIndex(users, id);
        if (index === -1) {
            return [404, { message: 'Người dùng không tồn tại.' }];
        }
        const payload = parseJson<Partial<User>>(config);
        const errors: Record<string, string[]> = {};
        if (!payload.name?.trim()) {
            errors.name = ['Tên không được bỏ trống.'];
        }
        if (!payload.email?.trim()) {
            errors.email = ['Email không được bỏ trống.'];
        }
        if (payload.email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(payload.email)) {
            errors.email = ['Email không hợp lệ.'];
        }
        if (payload.balance != null && payload.balance < 0) {
            errors.balance = ['Số dư không hợp lệ.'];
        }
        if (payload.role && !['user', 'admin'].includes(payload.role)) {
            errors.role = ['Quyền không hợp lệ.'];
        }
        if (Object.keys(errors).length > 0) {
            return [422, buildValidationError(errors)];
        }
        const updated: User = {
            ...users[index],
            ...payload,
        };
        users[index] = updated;
        return [200, { user: updated }];
    });

    mock.onDelete(new RegExp(`${API_PREFIX}/admin/users/[^/]+$`)).reply(config => {
        const id = Number(extractIdFromUrl(config.url));
        const index = findItemIndex(users, id);
        if (index === -1) {
            return [404, { message: 'Người dùng không tồn tại.' }];
        }
        users.splice(index, 1);
        return [204];
    });

    // Products
    mock.onGet(`${API_PREFIX}/admin/products`).reply(config => {
        const { params = {} } = config;
        const search = (params.search ?? '').toString().toLowerCase();
        let filtered = [...products];
        if (search) {
            filtered = filtered.filter(product =>
                product.name.toLowerCase().includes(search) ||
                product.category.toLowerCase().includes(search)
            );
        }
        const { data, totalPages, totalItems, currentPage } = paginate(filtered, params.page, params.limit, Number(params.limit) || 10);
        return [200, { data, totalPages, totalItems, currentPage }];
    });

    mock.onPost(`${API_PREFIX}/admin/products`).reply(config => {
        const payload = parseJson<Omit<Product, 'id'>>(config);
        const errors: Record<string, string[]> = {};
        if (!payload.name?.trim()) errors.name = ['Tên sản phẩm không được bỏ trống.'];
        if (!payload.description?.trim()) errors.description = ['Mô tả không được bỏ trống.'];
        if (payload.price == null || payload.price < 0) errors.price = ['Giá không hợp lệ.'];
        if (payload.stock == null || payload.stock < 0) errors.stock = ['Tồn kho không hợp lệ.'];
        if (!payload.category?.trim()) errors.category = ['Danh mục không được bỏ trống.'];
        if (!payload.country?.trim()) errors.country = ['Quốc gia không được bỏ trống.'];
        if (payload.category && !productCategories.some(cat => cat.name === payload.category)) {
            errors.category = ['Danh mục không tồn tại.'];
        }
        if (Object.keys(errors).length > 0) {
            return [422, buildValidationError(errors)];
        }
        const newProduct: Product = {
            id: generateId('prod'),
            name: payload.name.trim(),
            description: payload.description.trim(),
            price: Number(payload.price),
            stock: Number(payload.stock),
            country: payload.country.trim().toUpperCase(),
            category: payload.category,
            imageUrl: payload.imageUrl,
        };
        products = [newProduct, ...products];
        recalcCategoryCounts();
        return [201, { product: newProduct }];
    });

    mock.onPut(new RegExp(`${API_PREFIX}/admin/products/[^/]+$`)).reply(config => {
        const id = extractIdFromUrl(config.url);
        const index = findItemIndex(products, id);
        if (index === -1) {
            return [404, { message: 'Sản phẩm không tồn tại.' }];
        }
        const payload = parseJson<Partial<Product>>(config);
        const errors: Record<string, string[]> = {};
        if (payload.name !== undefined && !payload.name.trim()) errors.name = ['Tên sản phẩm không được bỏ trống.'];
        if (payload.description !== undefined && !payload.description.trim()) errors.description = ['Mô tả không được bỏ trống.'];
        if (payload.price != null && payload.price < 0) errors.price = ['Giá không hợp lệ.'];
        if (payload.stock != null && payload.stock < 0) errors.stock = ['Tồn kho không hợp lệ.'];
        if (payload.category && !productCategories.some(cat => cat.name === payload.category)) {
            errors.category = ['Danh mục không tồn tại.'];
        }
        if (Object.keys(errors).length > 0) {
            return [422, buildValidationError(errors)];
        }
        const existing = products[index];
        const updated: Product = {
            ...existing,
            ...payload,
            country: payload.country ? payload.country.trim().toUpperCase() : existing.country,
        };
        products[index] = updated;
        recalcCategoryCounts();
        return [200, { product: updated }];
    });

    mock.onDelete(new RegExp(`${API_PREFIX}/admin/products/[^/]+$`)).reply(config => {
        const id = extractIdFromUrl(config.url);
        const index = findItemIndex(products, id);
        if (index === -1) {
            return [404, { message: 'Sản phẩm không tồn tại.' }];
        }
        products.splice(index, 1);
        recalcCategoryCounts();
        return [204];
    });

    // Product Categories
    mock.onGet(`${API_PREFIX}/admin/product-categories`).reply(() => {
        recalcCategoryCounts();
        return [200, { categories: productCategories }];
    });

    mock.onPost(`${API_PREFIX}/admin/product-categories`).reply(config => {
        const payload = parseJson<Omit<ProductCategory, 'id' | 'product_count'>>(config);
        const errors: Record<string, string[]> = {};
        if (!payload.name?.trim()) errors.name = ['Tên danh mục không được bỏ trống.'];
        if (productCategories.some(cat => cat.name.toLowerCase() === payload.name.trim().toLowerCase())) {
            errors.name = ['Danh mục đã tồn tại.'];
        }
        if (Object.keys(errors).length > 0) {
            return [422, buildValidationError(errors)];
        }
        const newCategory: ProductCategory = {
            id: generateId('cat'),
            name: payload.name.trim(),
            description: payload.description?.trim() ?? '',
            product_count: 0,
        };
        productCategories = [newCategory, ...productCategories];
        return [201, { category: newCategory }];
    });

    mock.onPut(new RegExp(`${API_PREFIX}/admin/product-categories/[^/]+$`)).reply(config => {
        const id = extractIdFromUrl(config.url);
        const index = findItemIndex(productCategories, id);
        if (index === -1) {
            return [404, { message: 'Danh mục không tồn tại.' }];
        }
        const payload = parseJson<Partial<ProductCategory>>(config);
        const errors: Record<string, string[]> = {};
        if (payload.name !== undefined && !payload.name.trim()) errors.name = ['Tên danh mục không được bỏ trống.'];
        if (payload.name) {
            const nameToCheck = payload.name.trim().toLowerCase();
            if (productCategories.some((cat, idx) => idx !== index && cat.name.toLowerCase() === nameToCheck)) {
                errors.name = ['Danh mục đã tồn tại.'];
            }
        }
        if (Object.keys(errors).length > 0) {
            return [422, buildValidationError(errors)];
        }
        const previousName = productCategories[index].name;
        const updated: ProductCategory = {
            ...productCategories[index],
            ...payload,
            name: payload.name ? payload.name.trim() : productCategories[index].name,
            description: payload.description?.trim() ?? productCategories[index].description,
        };
        productCategories[index] = updated;
        if (payload.name && payload.name.trim() !== previousName) {
            products = products.map(product =>
                product.category === previousName ? { ...product, category: updated.name } : product
            );
        }
        recalcCategoryCounts();
        return [200, { category: updated }];
    });

    mock.onDelete(new RegExp(`${API_PREFIX}/admin/product-categories/[^/]+$`)).reply(config => {
        const id = extractIdFromUrl(config.url);
        const index = findItemIndex(productCategories, id);
        if (index === -1) {
            return [404, { message: 'Danh mục không tồn tại.' }];
        }
        const category = productCategories[index];
        const hasProducts = products.some(product => product.category === category.name);
        if (hasProducts) {
            return [422, buildValidationError({ category: ['Không thể xóa danh mục đang có sản phẩm.'] })];
        }
        productCategories.splice(index, 1);
        return [204];
    });

    // Orders (admin)
    mock.onGet(`${API_PREFIX}/admin/orders`).reply(config => {
        const { params = {} } = config;
        const search = (params.search ?? '').toString().toLowerCase();
        let filtered = [...orders];
        if (search) {
            filtered = filtered.filter(order =>
                order.productName.toLowerCase().includes(search) ||
                order.userEmail?.toLowerCase().includes(search) ||
                order.id.toLowerCase().includes(search)
            );
        }
        const { data, totalPages, totalItems, currentPage } = paginate(filtered, params.page, params.limit, Number(params.limit) || 10);
        return [200, { data, totalPages, totalItems, currentPage }];
    });

    mock.onGet(new RegExp(`${API_PREFIX}/admin/orders/[^/]+$`)).reply(config => {
        const id = extractIdFromUrl(config.url);
        const order = orders.find(o => o.id === id);
        if (!order) {
            return [404, { message: 'Đơn hàng không tồn tại.' }];
        }
        return [200, { order }];
    });

    // Deposits (admin)
    mock.onGet(`${API_PREFIX}/admin/deposits`).reply(config => {
        const { params = {} } = config;
        const search = (params.search ?? '').toString().toLowerCase();
        let filtered = [...deposits];
        if (search) {
            filtered = filtered.filter(deposit =>
                deposit.userEmail?.toLowerCase().includes(search) ||
                deposit.transactionCode?.toLowerCase().includes(search)
            );
        }
        const { data, totalPages, totalItems, currentPage } = paginate(filtered, params.page, params.limit, Number(params.limit) || 10);
        return [200, { data, totalPages, totalItems, currentPage }];
    });

    mock.onPut(new RegExp(`${API_PREFIX}/admin/deposits/[^/]+$`)).reply(config => {
        const id = extractIdFromUrl(config.url);
        const index = findItemIndex(deposits, id);
        if (index === -1) {
            return [404, { message: 'Giao dịch không tồn tại.' }];
        }
        const payload = parseJson<Partial<Deposit>>(config);
        const status = normalizeStatus(payload.status);
        if (!['Hoàn thành', 'Đang chờ', 'Thất bại'].includes(status)) {
            return [422, buildValidationError({ status: ['Trạng thái không hợp lệ.'] })];
        }
        deposits[index] = { ...deposits[index], status: status as 'Hoàn thành' | 'Đang chờ' | 'Thất bại' };
        return [200, { deposit: deposits[index] }];
    });

    // Affiliate commissions (admin)
    mock.onGet(`${API_PREFIX}/admin/affiliate/commissions`).reply(config => {
        const { params = {} } = config;
        const search = (params.search ?? '').toString().toLowerCase();
        let filtered = [...affiliateCommissions];
        if (search) {
            filtered = filtered.filter(commission =>
                commission.userEmail?.toLowerCase().includes(search) ||
                commission.orderId.toLowerCase().includes(search)
            );
        }
        const { data, totalPages, totalItems, currentPage } = paginate(filtered, params.page, params.limit, Number(params.limit) || 10);
        return [200, { data, totalPages, totalItems, currentPage }];
    });

    mock.onPut(new RegExp(`${API_PREFIX}/admin/affiliate/commissions/[^/]+$`)).reply(config => {
        const id = extractIdFromUrl(config.url);
        const index = findItemIndex(affiliateCommissions, id);
        if (index === -1) {
            return [404, { message: 'Hoa hồng không tồn tại.' }];
        }
        const payload = parseJson<Partial<Commission>>(config);
        const status = normalizeStatus(payload.status);
        if (!['approved', 'pending', 'rejected'].includes(status)) {
            return [422, buildValidationError({ status: ['Trạng thái không hợp lệ.'] })];
        }
        affiliateCommissions[index] = { ...affiliateCommissions[index], status: status as 'approved' | 'pending' | 'rejected' };
        return [200, { commission: affiliateCommissions[index] }];
    });

    // Posts (admin)
    mock.onGet(`${API_PREFIX}/admin/posts`).reply(config => {
        const { params = {} } = config;
        const search = (params.search ?? '').toString().toLowerCase();
        let filtered = [...posts];
        if (search) {
            filtered = filtered.filter(post =>
                post.title.toLowerCase().includes(search) ||
                post.slug.toLowerCase().includes(search)
            );
        }
        const { data, totalPages, totalItems, currentPage } = paginate(filtered, params.page, params.limit, Number(params.limit) || 10);
        return [200, { data, totalPages, totalItems, currentPage }];
    });

    mock.onPost(`${API_PREFIX}/admin/posts`).reply(config => {
        const payload = parseJson<Omit<Post, 'id' | 'authorName' | 'createdAt' | 'updatedAt'>>(config);
        const errors: Record<string, string[]> = {};
        if (!payload.title?.trim()) errors.title = ['Tiêu đề không được bỏ trống.'];
        if (!payload.slug?.trim()) errors.slug = ['Slug không được bỏ trống.'];
        if (!payload.content?.trim()) errors.content = ['Nội dung không được bỏ trống.'];
        if (payload.slug && posts.some(post => post.slug === payload.slug)) {
            errors.slug = ['Slug đã tồn tại.'];
        }
        if (payload.status && !['draft', 'published'].includes(payload.status)) {
            errors.status = ['Trạng thái không hợp lệ.'];
        }
        if (Object.keys(errors).length > 0) {
            return [422, buildValidationError(errors)];
        }
        const now = nowIso();
        const newPost: Post = {
            id: generateId('post'),
            title: payload.title.trim(),
            slug: payload.slug.trim(),
            content: payload.content,
            status: payload.status ?? 'draft',
            authorName: 'Admin',
            createdAt: now,
            updatedAt: now,
        };
        posts = [newPost, ...posts];
        return [201, { post: newPost }];
    });

    mock.onPut(new RegExp(`${API_PREFIX}/admin/posts/[^/]+$`)).reply(config => {
        const id = extractIdFromUrl(config.url);
        const index = findItemIndex(posts, id);
        if (index === -1) {
            return [404, { message: 'Bài viết không tồn tại.' }];
        }
        const payload = parseJson<Partial<Post>>(config);
        const errors: Record<string, string[]> = {};
        if (payload.title !== undefined && !payload.title.trim()) errors.title = ['Tiêu đề không được bỏ trống.'];
        if (payload.slug !== undefined && !payload.slug.trim()) errors.slug = ['Slug không được bỏ trống.'];
        if (payload.content !== undefined && !payload.content.trim()) errors.content = ['Nội dung không được bỏ trống.'];
        if (payload.slug && posts.some((post, idx) => idx !== index && post.slug === payload.slug)) {
            errors.slug = ['Slug đã tồn tại.'];
        }
        if (payload.status && !['draft', 'published'].includes(payload.status)) {
            errors.status = ['Trạng thái không hợp lệ.'];
        }
        if (Object.keys(errors).length > 0) {
            return [422, buildValidationError(errors)];
        }
        const updated: Post = {
            ...posts[index],
            ...payload,
            title: payload.title !== undefined ? payload.title.trim() : posts[index].title,
            slug: payload.slug !== undefined ? payload.slug.trim() : posts[index].slug,
            updatedAt: nowIso(),
        };
        posts[index] = updated;
        return [200, { post: updated }];
    });

    mock.onDelete(new RegExp(`${API_PREFIX}/admin/posts/[^/]+$`)).reply(config => {
        const id = extractIdFromUrl(config.url);
        const index = findItemIndex(posts, id);
        if (index === -1) {
            return [404, { message: 'Bài viết không tồn tại.' }];
        }
        posts.splice(index, 1);
        return [204];
    });

    // FAQ (admin)
    mock.onGet(`${API_PREFIX}/admin/faq`).reply(() => [200, { faqs: faqs.sort((a, b) => a.order - b.order) }]);

    mock.onPost(`${API_PREFIX}/admin/faq`).reply(config => {
        const payload = parseJson<Omit<Faq, 'id'>>(config);
        const errors: Record<string, string[]> = {};
        if (!payload.question?.trim()) errors.question = ['Câu hỏi không được bỏ trống.'];
        if (!payload.answer?.trim()) errors.answer = ['Câu trả lời không được bỏ trống.'];
        if (payload.order == null || payload.order < 0) errors.order = ['Thứ tự không hợp lệ.'];
        if (Object.keys(errors).length > 0) {
            return [422, buildValidationError(errors)];
        }
        const newFaq: Faq = {
            id: generateId('faq'),
            question: payload.question.trim(),
            answer: payload.answer.trim(),
            is_active: payload.is_active ?? true,
            order: Number(payload.order),
        };
        faqs = [...faqs, newFaq];
        return [201, { faq: newFaq }];
    });

    mock.onPut(new RegExp(`${API_PREFIX}/admin/faq/[^/]+$`)).reply(config => {
        const id = extractIdFromUrl(config.url);
        const index = findItemIndex(faqs, id);
        if (index === -1) {
            return [404, { message: 'FAQ không tồn tại.' }];
        }
        const payload = parseJson<Partial<Faq>>(config);
        const errors: Record<string, string[]> = {};
        if (payload.question !== undefined && !payload.question.trim()) errors.question = ['Câu hỏi không được bỏ trống.'];
        if (payload.answer !== undefined && !payload.answer.trim()) errors.answer = ['Câu trả lời không được bỏ trống.'];
        if (payload.order != null && payload.order < 0) errors.order = ['Thứ tự không hợp lệ.'];
        if (Object.keys(errors).length > 0) {
            return [422, buildValidationError(errors)];
        }
        const updated: Faq = {
            ...faqs[index],
            ...payload,
            question: payload.question !== undefined ? payload.question.trim() : faqs[index].question,
            answer: payload.answer !== undefined ? payload.answer.trim() : faqs[index].answer,
            order: payload.order != null ? Number(payload.order) : faqs[index].order,
            is_active: payload.is_active != null ? payload.is_active : faqs[index].is_active,
        };
        faqs[index] = updated;
        return [200, { faq: updated }];
    });

    mock.onDelete(new RegExp(`${API_PREFIX}/admin/faq/[^/]+$`)).reply(config => {
        const id = extractIdFromUrl(config.url);
        const index = findItemIndex(faqs, id);
        if (index === -1) {
            return [404, { message: 'FAQ không tồn tại.' }];
        }
        faqs.splice(index, 1);
        return [204];
    });

    // Payment methods (admin)
    mock.onGet(`${API_PREFIX}/admin/payment-methods`).reply(() => [200, { methods: paymentMethods }]);

    mock.onPost(`${API_PREFIX}/admin/payment-methods`).reply(config => {
        const payload = parseJson<Omit<PaymentMethod, 'id'>>(config);
        const errors: Record<string, string[]> = {};
        if (!payload.name?.trim()) errors.name = ['Tên hiển thị không được bỏ trống.'];
        if (!payload.accountName?.trim()) errors.accountName = ['Tên chủ tài khoản không được bỏ trống.'];
        if (!payload.accountNumber?.trim()) errors.accountNumber = ['Số tài khoản/SĐT không được bỏ trống.'];
        if (!payload.type || !['bank', 'momo'].includes(payload.type)) errors.type = ['Loại phương thức không hợp lệ.'];
        if (Object.keys(errors).length > 0) {
            return [422, buildValidationError(errors)];
        }
        const newMethod: PaymentMethod = {
            id: generateId('pm'),
            name: payload.name.trim(),
            type: payload.type as PaymentMethod['type'],
            accountName: payload.accountName.trim(),
            accountNumber: payload.accountNumber.trim(),
            qrCodeUrl: payload.qrCodeUrl,
            is_active: payload.is_active ?? true,
        };
        paymentMethods = [newMethod, ...paymentMethods];
        return [201, { method: newMethod }];
    });

    mock.onPut(new RegExp(`${API_PREFIX}/admin/payment-methods/[^/]+$`)).reply(config => {
        const id = extractIdFromUrl(config.url);
        const index = findItemIndex(paymentMethods, id);
        if (index === -1) {
            return [404, { message: 'Phương thức thanh toán không tồn tại.' }];
        }
        const payload = parseJson<Partial<PaymentMethod>>(config);
        const errors: Record<string, string[]> = {};
        if (payload.name !== undefined && !payload.name.trim()) errors.name = ['Tên hiển thị không được bỏ trống.'];
        if (payload.accountName !== undefined && !payload.accountName.trim()) errors.accountName = ['Tên chủ tài khoản không được bỏ trống.'];
        if (payload.accountNumber !== undefined && !payload.accountNumber.trim()) errors.accountNumber = ['Số tài khoản/SĐT không được bỏ trống.'];
        if (payload.type && !['bank', 'momo'].includes(payload.type)) errors.type = ['Loại phương thức không hợp lệ.'];
        if (Object.keys(errors).length > 0) {
            return [422, buildValidationError(errors)];
        }
        const updated: PaymentMethod = {
            ...paymentMethods[index],
            ...payload,
            name: payload.name !== undefined ? payload.name.trim() : paymentMethods[index].name,
            accountName: payload.accountName !== undefined ? payload.accountName.trim() : paymentMethods[index].accountName,
            accountNumber: payload.accountNumber !== undefined ? payload.accountNumber.trim() : paymentMethods[index].accountNumber,
        };
        paymentMethods[index] = updated;
        return [200, { method: updated }];
    });

    mock.onDelete(new RegExp(`${API_PREFIX}/admin/payment-methods/[^/]+$`)).reply(config => {
        const id = extractIdFromUrl(config.url);
        const index = findItemIndex(paymentMethods, id);
        if (index === -1) {
            return [404, { message: 'Phương thức thanh toán không tồn tại.' }];
        }
        paymentMethods.splice(index, 1);
        return [204];
    });

    // API Keys (admin)
    mock.onGet(`${API_PREFIX}/admin/api-keys`).reply(() => [200, apiKeys]);

    mock.onPost(`${API_PREFIX}/admin/api-keys`).reply(() => {
        const fullKey = `sk_${generateId('api')}${Math.random().toString(36).slice(-6)}`;
        const preview = `${fullKey.slice(0, 6)}...${fullKey.slice(-4)}`;
        const newKey: AdminApiKey = {
            id: generateId('key'),
            keyPreview: preview,
            createdAt: nowIso(),
            lastUsed: null,
            status: 'active',
        };
        apiKeys = [newKey, ...apiKeys];
        return [201, { apiKey: fullKey }];
    });

    mock.onDelete(new RegExp(`${API_PREFIX}/admin/api-keys/[^/]+$`)).reply(config => {
        const id = extractIdFromUrl(config.url);
        const index = findItemIndex(apiKeys, id);
        if (index === -1) {
            return [404, { message: 'API key không tồn tại.' }];
        }
        apiKeys[index] = { ...apiKeys[index], status: 'revoked', lastUsed: apiKeys[index].lastUsed ?? nowIso() };
        return [204];
    });

    // Settings endpoint - Mock system notification
    mock.onGet(`${API_PREFIX}/settings`).reply(() => {
        return [200, {
            systemNotification: '', // Empty by default, can be set in admin panel
            // Add other settings fields if needed
        }];
    });

    // Default pass-through for any other request
    mock.onAny().passThrough();
};