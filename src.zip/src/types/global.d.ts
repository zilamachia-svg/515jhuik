// Global ambient declarations for quick type fixes
declare var google: any;
declare interface Window {
  google?: any;
}
