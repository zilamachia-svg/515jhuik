declare module 'rfc6238' {
  /**
   * Generates a time-based one-time password (TOTP).
   * @param key The secret key, Base32 encoded.
   * @param options Configuration options.
   * @returns The generated TOTP code as a string.
   */
  export function totp(key: string, options?: any): string;

  /**
   * Generates an HMAC-based one-time password (HOTP).
   * @param key The secret key, Base32 encoded.
   * @param options Configuration options.
   * @returns The generated HOTP code as a string.
   */
  export function hotp(key: string, options?: any): string;
}