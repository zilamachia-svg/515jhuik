/**
 * Auth API Service
 * Handles all authentication-related API calls
 */

import apiClient from '../services/apiClient';
import { API_ENDPOINTS } from '../config';
import { User } from '../types';

export interface LoginCredentials {
  email: string;
  password: string;
  remember?: boolean;
}

export interface RegisterData {
  name: string;
  email: string;
  password: string;
  password_confirmation: string;
}

export interface ForgotPasswordData {
  email: string;
}

export interface ResetPasswordData {
  email: string;
  token: string;
  password: string;
  password_confirmation: string;
}

export const authApi = {
  /**
   * Get current authenticated user
   */
  async getMe(): Promise<User> {
    const response = await apiClient.get(API_ENDPOINTS.auth.me);
    return response.data;
  },

  /**
   * Login user
   */
  async login(credentials: LoginCredentials): Promise<User> {
    const response = await apiClient.post(API_ENDPOINTS.auth.login, credentials);
    return response.data;
  },

  /**
   * Register new user
   */
  async register(data: RegisterData): Promise<User> {
    const response = await apiClient.post(API_ENDPOINTS.auth.register, data);
    return response.data;
  },

  /**
   * Logout user
   */
  async logout(): Promise<void> {
    await apiClient.post(API_ENDPOINTS.auth.logout);
  },

  /**
   * Send password reset email
   */
  async forgotPassword(data: ForgotPasswordData): Promise<{ message: string }> {
    const response = await apiClient.post(API_ENDPOINTS.auth.forgotPassword, data);
    return response.data;
  },

  /**
   * Reset password with token
   */
  async resetPassword(data: ResetPasswordData): Promise<{ message: string }> {
    const response = await apiClient.post(API_ENDPOINTS.auth.resetPassword, data);
    return response.data;
  },

  /**
   * Verify email
   */
  async verifyEmail(id: string, hash: string): Promise<{ message: string }> {
    const response = await apiClient.get(`${API_ENDPOINTS.auth.verifyEmail}/${id}/${hash}`);
    return response.data;
  },

  /**
   * Resend verification email
   */
  async resendVerification(): Promise<{ message: string }> {
    const response = await apiClient.post(API_ENDPOINTS.auth.resendVerification);
    return response.data;
  },
};
