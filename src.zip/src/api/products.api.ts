/**
 * Products API Service
 * Handles all product-related API calls
 */

import apiClient from '../services/apiClient';
import { API_ENDPOINTS } from '../config';
import { Product } from '../types';

export interface ProductListParams {
  page?: number;
  limit?: number;
  search?: string;
  category?: string;
  sortBy?: string;
  order?: 'asc' | 'desc';
}

export interface ProductListResponse {
  data: Product[];
  currentPage: number;
  totalPages: number;
  totalItems: number;
}

export interface CreateProductData {
  name: string;
  description?: string;
  price: number;
  category_id: number;
  stock?: number;
  image?: string;
}

export interface UpdateProductData extends Partial<CreateProductData> {}

export const productsApi = {
  /**
   * Get products list with filters
   */
  async getProducts(params?: ProductListParams): Promise<ProductListResponse> {
    const response = await apiClient.get(API_ENDPOINTS.products.list, { params });
    return response.data;
  },

  /**
   * Get single product by ID
   */
  async getProduct(id: string | number): Promise<Product> {
    const response = await apiClient.get(API_ENDPOINTS.products.detail(id));
    return response.data;
  },

  /**
   * Create new product
   */
  async createProduct(data: CreateProductData): Promise<Product> {
    const response = await apiClient.post(API_ENDPOINTS.products.create, data);
    return response.data;
  },

  /**
   * Update product
   */
  async updateProduct(id: string | number, data: UpdateProductData): Promise<Product> {
    const response = await apiClient.put(API_ENDPOINTS.products.update(id), data);
    return response.data;
  },

  /**
   * Delete product
   */
  async deleteProduct(id: string | number): Promise<void> {
    await apiClient.delete(API_ENDPOINTS.products.delete(id));
  },

  /**
   * Upload products in bulk
   */
  async uploadProducts(file: File): Promise<{ message: string; count: number }> {
    const formData = new FormData();
    formData.append('file', file);
    
    const response = await apiClient.post(API_ENDPOINTS.products.upload, formData, {
      headers: {
        'Content-Type': 'multipart/form-data',
      },
    });
    return response.data;
  },
};
