/**
 * Admin API Service
 * Handles all admin-related API calls
 */

import apiClient from '../services/apiClient';
import { API_ENDPOINTS } from '../config';
import { User, Order, Product } from '../types';

export interface DashboardStats {
  totalRevenue: number;
  newUsersMonthly: number;
  newOrders24h: number;
  conversionRate: number;
}

export interface DashboardActivity {
  type: 'newUser' | 'newOrder';
  text: string;
  timestamp: string;
}

export interface TopProduct {
  name: string;
  sales: number;
}

export interface DashboardData {
  stats: DashboardStats;
  revenueLast7Days: { date: string; revenue: number }[];
  recentActivities: DashboardActivity[];
  topProducts: TopProduct[];
}

export interface AdminListParams {
  page?: number;
  limit?: number;
  search?: string;
}

export interface AdminListResponse<T> {
  data: T[];
  currentPage: number;
  totalPages: number;
  totalItems: number;
}

export const adminApi = {
  /**
   * Get dashboard overview data
   */
  async getDashboard(): Promise<DashboardData> {
    const response = await apiClient.get(API_ENDPOINTS.admin.dashboard);
    return response.data;
  },

  /**
   * Get users list (admin)
   */
  async getUsers(params?: AdminListParams): Promise<AdminListResponse<User>> {
    const response = await apiClient.get(API_ENDPOINTS.admin.users, { params });
    return response.data;
  },

  /**
   * Update user (admin)
   */
  async updateUser(id: string | number, data: Partial<User>): Promise<User> {
    const response = await apiClient.put(`${API_ENDPOINTS.admin.users}/${id}`, data);
    return response.data;
  },

  /**
   * Delete user (admin)
   */
  async deleteUser(id: string | number): Promise<void> {
    await apiClient.delete(`${API_ENDPOINTS.admin.users}/${id}`);
  },

  /**
   * Get orders list (admin)
   */
  async getOrders(params?: AdminListParams): Promise<AdminListResponse<Order>> {
    const response = await apiClient.get(API_ENDPOINTS.admin.orders, { params });
    return response.data;
  },

  /**
   * Get products list (admin)
   */
  async getProducts(params?: AdminListParams): Promise<AdminListResponse<Product>> {
    const response = await apiClient.get(API_ENDPOINTS.admin.products, { params });
    return response.data;
  },

  /**
   * Get settings
   */
  async getSettings(type: keyof typeof API_ENDPOINTS.settings): Promise<any> {
    const response = await apiClient.get(API_ENDPOINTS.settings[type]);
    return response.data;
  },

  /**
   * Update settings
   */
  async updateSettings(type: keyof typeof API_ENDPOINTS.settings, data: any): Promise<any> {
    const response = await apiClient.put(API_ENDPOINTS.settings[type], data);
    return response.data;
  },
};
