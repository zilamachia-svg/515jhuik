/**
 * Theme API Service
 * Handles theme settings sync with backend
 */

import apiClient from '../services/apiClient';
import { API_ENDPOINTS } from '../config';

export interface ThemeSettings {
  // Colors (HSL format)
  colors: {
    primary: string;
    secondary: string;
    accent: string;
    destructive: string;
    background: string;
    foreground: string;
    muted: string;
    border: string;
  };
  
  // Typography
  typography: {
    fontFamily: string;
    fontSize: {
      base: number;
      scale: number;
    };
  };
  
  // Spacing
  spacing: {
    unit: number; // base unit in px
  };
  
  // Border radius
  radius: {
    default: number;
  };
  
  // Dark mode
  darkMode: {
    enabled: boolean;
    colors: {
      background: string;
      foreground: string;
      // ... same structure as light colors
    };
  };
}

export const themeApi = {
  /**
   * Get current theme settings from backend
   */
  async getThemeSettings(): Promise<ThemeSettings> {
    const response = await apiClient.get(API_ENDPOINTS.settings.theme);
    return response.data;
  },

  /**
   * Update theme settings
   */
  async updateThemeSettings(settings: Partial<ThemeSettings>): Promise<ThemeSettings> {
    const response = await apiClient.put(API_ENDPOINTS.settings.theme, settings);
    return response.data;
  },

  /**
   * Apply theme to DOM
   */
  applyTheme(settings: ThemeSettings): void {
    const root = document.documentElement;

    // Apply colors
    Object.entries(settings.colors).forEach(([key, value]) => {
      root.style.setProperty(`--${key}`, value);
    });

    // Apply font
    root.style.setProperty('--font-sans', settings.typography.fontFamily);

    // Apply radius
    root.style.setProperty('--radius', `${settings.radius.default}rem`);

    // Apply dark mode colors if enabled
    if (settings.darkMode.enabled) {
      Object.entries(settings.darkMode.colors).forEach(([key, value]) => {
        root.style.setProperty(`--${key}-dark`, value);
      });
    }
  },

  /**
   * Reset to default theme
   */
  async resetTheme(): Promise<ThemeSettings> {
    const response = await apiClient.post(`${API_ENDPOINTS.settings.theme}/reset`);
    return response.data;
  },
};
