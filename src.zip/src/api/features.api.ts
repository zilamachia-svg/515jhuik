/**
 * API Services for New Features
 * Wishlist, Reviews, Notifications, Admin Logs, Batch Operations
 */

import apiClient from '../services/apiClient';

// ============================================
// WISHLIST API
// ============================================

export interface WishlistItem {
  id: number;
  user_id: number;
  product_id: number;
  product: {
    id: number;
    name: string;
    price: number;
    image?: string;
    category?: {
      name: string;
    };
  };
  created_at: string;
}

export const wishlistApi = {
  // Get all wishlist items
  getAll: () => apiClient.get<{ success: boolean; data: WishlistItem[]; count: number }>('/wishlist'),

  // Add product to wishlist
  add: (productId: number) =>
    apiClient.post<{ success: boolean; message: string; data: WishlistItem }>('/wishlist', {
      product_id: productId,
    }),

  // Remove from wishlist
  remove: (productId: number) =>
    apiClient.delete<{ success: boolean; message: string }>(`/wishlist/${productId}`),

  // Check if product is in wishlist
  check: (productId: number) =>
    apiClient.get<{ success: boolean; in_wishlist: boolean }>(`/wishlist/check/${productId}`),

  // Get wishlist count
  getCount: () => apiClient.get<{ success: boolean; count: number }>('/wishlist/count'),
};

// ============================================
// PRODUCT REVIEWS API
// ============================================

export interface ProductReview {
  id: number;
  product_id: number;
  user_id: number;
  rating: number;
  title?: string;
  comment: string;
  verified_purchase: boolean;
  is_approved: boolean;
  helpful_count: number;
  unhelpful_count: number;
  user: {
    id: number;
    name: string;
    email: string;
  };
  created_at: string;
}

export interface ReviewSummary {
  average_rating: number;
  total_reviews: number;
  rating_distribution: {
    1: number;
    2: number;
    3: number;
    4: number;
    5: number;
  };
}

export interface PaginatedResponse<T> {
  data: T[];
  current_page: number;
  last_page: number;
  per_page: number;
  total: number;
}

export const reviewsApi = {
  // Get reviews for product
  getForProduct: (productId: number, page = 1) =>
    apiClient.get<{ success: boolean; data: PaginatedResponse<ProductReview> }>(`/products/${productId}/reviews?page=${page}`),

  // Get review summary
  getSummary: (productId: number) =>
    apiClient.get<{ success: boolean; data: ReviewSummary }>(`/products/${productId}/reviews/summary`),

  // Create review
  create: (productId: number, data: { rating: number; title?: string; comment: string }) =>
    apiClient.post<{ success: boolean; message: string; data: ProductReview }>(
      `/products/${productId}/reviews`,
      data
    ),

  // Update review
  update: (reviewId: number, data: { rating: number; title?: string; comment: string }) =>
    apiClient.put<{ success: boolean; message: string; data: ProductReview }>(`/reviews/${reviewId}`, data),

  // Delete review
  delete: (reviewId: number) =>
    apiClient.delete<{ success: boolean; message: string }>(`/reviews/${reviewId}`),

  // Vote helpful
  voteHelpful: (reviewId: number) =>
    apiClient.post<{ success: boolean; data: { helpful_count: number } }>(`/reviews/${reviewId}/helpful`),

  // Vote unhelpful
  voteUnhelpful: (reviewId: number) =>
    apiClient.post<{ success: boolean; data: { unhelpful_count: number } }>(`/reviews/${reviewId}/unhelpful`),
};

// DTOs exported for consumers
export type CreateReviewDto = { rating: number; title?: string; comment: string };

// ============================================
// NOTIFICATIONS API
// ============================================

export interface Notification {
  id: number;
  user_id: number;
  title: string;
  message: string;
  type: 'info' | 'success' | 'warning' | 'error' | 'order' | 'deposit' | 'system';
  data?: Record<string, unknown>;
  read_at: string | null;
  created_at: string;
}

export const notificationsApi = {
  // Get all notifications
  getAll: (params?: { type?: string; unread_only?: boolean; page?: number; per_page?: number }) =>
    apiClient.get<{ success: boolean; data: PaginatedResponse<Notification> }>('/notifications', { params }),

  // Get unread count
  getUnreadCount: (config?: { timeout?: number }) => 
    apiClient.get<{ success: boolean; count: number }>('/notifications/unread-count', config),

  // Mark as read
  markAsRead: (id: number) =>
    apiClient.patch<{ success: boolean; message: string }>(`/notifications/${id}/read`),

  // Mark all as read
  markAllAsRead: () =>
    apiClient.post<{ success: boolean; message: string }>('/notifications/mark-all-read'),

  // Delete notification
  delete: (id: number) =>
    apiClient.delete<{ success: boolean; message: string }>(`/notifications/${id}`),

  // Delete all
  deleteAll: () => apiClient.delete<{ success: boolean; message: string }>('/notifications'),
};

// ============================================
// ADMIN - ACTIVITY LOGS API
// ============================================

export interface ActivityLog {
  id: number;
  admin_id: number;
  action: string;
  target_type: string;
  target_id: number | null;
  changes: Record<string, unknown> | null;
  ip_address: string | null;
  user_agent: string | null;
  created_at: string;
  admin: {
    id: number;
    name: string;
    email: string;
  };
}

export const adminLogsApi = {
  // Get activity logs
  getAll: (params?: {
    action?: string;
    target_type?: string;
    admin_id?: number;
    from?: string;
    to?: string;
    search?: string;
    page?: number;
    per_page?: number;
  }) => apiClient.get<{ success: boolean; data: PaginatedResponse<ActivityLog> }>('/admin/logs', { params }),

  // Export logs
  export: () => apiClient.post<{ success: boolean; data: ActivityLog[]; message: string }>('/admin/logs/export'),
};

// ============================================
// ADMIN - REVIEW MODERATION API
// ============================================

export const adminReviewsApi = {
  // Get all reviews (including pending)
  getAll: (params?: { status?: 'pending' | 'approved'; product_id?: number; page?: number; per_page?: number }) =>
    apiClient.get<{ success: boolean; data: PaginatedResponse<ProductReview> }>('/admin/reviews', { params }),

  // Approve review
  approve: (id: number) =>
    apiClient.post<{ success: boolean; message: string; data: ProductReview }>(`/admin/reviews/${id}/approve`),

  // Reject review
  reject: (id: number) =>
    apiClient.post<{ success: boolean; message: string }>(`/admin/reviews/${id}/reject`),
};

// ============================================
// ADMIN - BATCH OPERATIONS API
// ============================================

export const adminBatchApi = {
  // Batch delete products
  batchDelete: (productIds: number[]) =>
    apiClient.post<{ success: boolean; message: string }>('/admin/products/batch-delete', {
      product_ids: productIds,
    }),

  // Batch update status
  batchUpdateStatus: (productIds: number[], status: 'active' | 'inactive' | 'out_of_stock') =>
    apiClient.post<{ success: boolean; message: string }>('/admin/products/batch-status', {
      product_ids: productIds,
      status,
    }),

  // Batch adjust price
  batchAdjustPrice: (
    productIds: number[],
    adjustmentType: 'percentage' | 'fixed',
    adjustmentValue: number
  ) =>
    apiClient.post<{ success: boolean; message: string }>('/admin/products/batch-price', {
      product_ids: productIds,
      adjustment_type: adjustmentType,
      adjustment_value: adjustmentValue,
    }),

  // Export selected products
  export: (productIds: number[]) =>
    apiClient.post<{ success: boolean; data: Record<string, unknown>[]; message: string }>('/admin/products/export', {
      product_ids: productIds,
    }),
};
