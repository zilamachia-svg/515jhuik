// This manually defines the structure of `import.meta.env` to resolve errors
// like "Property 'env' does not exist on type 'ImportMeta'".
interface ImportMetaEnv {
  readonly VITE_API_BASE_URL?: string;
  readonly VITE_ENABLE_MOCK?: string;
  readonly VITE_REQUIRE_EMAIL_VERIFICATION?: string;
  readonly VITE_DISABLE_SWAGGER?: string;
  readonly VITE_APP_URL?: string;
  
  // Standard Vite env variables
  MODE: string;
  DEV: boolean;
  PROD: boolean;
  SSR: boolean;
}

interface ImportMeta {
  readonly env: ImportMetaEnv;
}
