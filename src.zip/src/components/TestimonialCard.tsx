import React from 'react';
import { Testimonial } from '../types';
// FIX: Use Card from shadcn/ui
import { Card, CardContent } from '@/components/ui/card';
import { Quote } from 'lucide-react';

type TestimonialCardProps = {
    testimonial: Testimonial;
};

export const TestimonialCard = React.memo(({ testimonial }: TestimonialCardProps) => {
    const { quote, author, position, avatar } = testimonial;
    
    return (
        <Card>
            <CardContent className="p-6 text-center">
                <Quote className="mx-auto w-8 h-8 text-muted-foreground mb-4" />
                <p className="italic text-muted-foreground">&quot;{quote}&quot;</p>
                <div className="flex items-center justify-center gap-3 mt-6">
                    {avatar && <img src={avatar} alt={author} className="w-10 h-10 rounded-full" />}
                    <div>
                        <p className="font-semibold">{author}</p>
                        <p className="text-sm text-muted-foreground">{position}</p>
                    </div>
                </div>
            </CardContent>
        </Card>
    );
});

TestimonialCard.displayName = 'TestimonialCard';