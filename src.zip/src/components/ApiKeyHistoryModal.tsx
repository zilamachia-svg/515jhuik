import { useState, useEffect } from 'react';
// FIX: Use sonner for consistent notifications
import { toast } from 'sonner';
import { AdminApiKey, ApiKeyUsage } from '../types';
// FIX: Use Dialog components from shadcn/ui
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
// FIX: Use Button from shadcn/ui
import { Button } from '@/components/ui/button';
// FIX: Use Spinner from shadcn/ui
import { Spinner } from '@/components/ui/spinner';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';

type ApiKeyHistoryModalProps = {
    apiKey: AdminApiKey;
    onClose: () => void;
};

export const ApiKeyHistoryModal = ({ apiKey, onClose }: ApiKeyHistoryModalProps) => {
    const [history, setHistory] = useState<ApiKeyUsage[]>([]);
    const [isLoading, setIsLoading] = useState(true);

    useEffect(() => {
        const fetchHistory = async () => {
            setIsLoading(true);
            try {
                // Mocking API call
                const mockHistory: ApiKeyUsage[] = [
                    { id: '1', timestamp: new Date().toISOString(), action: 'GET /products', ipAddress: '127.0.0.1' }
                ];
                setHistory(mockHistory);
            } catch (error) {
                toast.error('Không thể tải lịch sử sử dụng.');
            } finally {
                setIsLoading(false);
            }
        };
        fetchHistory();
    }, [apiKey.id]);
    
    return (
        <Dialog open={true} onOpenChange={onClose}>
            <DialogContent>
                <DialogHeader>
                    <DialogTitle>{`Lịch sử sử dụng: ${apiKey.keyPreview}`}</DialogTitle>
                </DialogHeader>
                <div className="py-4">
                    {isLoading ? <div className="flex justify-center"><Spinner /></div> : (
                        history.length > 0 ? (
                            <Table>
                                <TableHeader>
                                    <TableRow>
                                        <TableHead>Thời gian</TableHead>
                                        <TableHead>Hành động</TableHead>
                                        <TableHead>Địa chỉ IP</TableHead>
                                    </TableRow>
                                </TableHeader>
                                <TableBody>
                                    {history.map(item => (
                                        <TableRow key={item.id}>
                                            <TableCell>{new Date(item.timestamp).toLocaleString('vi-VN')}</TableCell>
                                            <TableCell>{item.action}</TableCell>
                                            <TableCell>{item.ipAddress}</TableCell>
                                        </TableRow>
                                    ))}
                                </TableBody>
                            </Table>
                        ) : (
                            <p className="text-center text-muted-foreground">Chưa có lịch sử sử dụng cho key này.</p>
                        )
                    )}
                </div>
                <DialogFooter>
                    <Button variant="secondary" onClick={onClose}>Đóng</Button>
                </DialogFooter>
            </DialogContent>
        </Dialog>
    );
};