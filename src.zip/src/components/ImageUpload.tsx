import { useState, useRef, useEffect } from 'react';
import { Upload, X, Image as ImageIcon, ZoomIn, ZoomOut, RotateCw, Crop, Check } from 'lucide-react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { cn } from '@/lib/utils';
import { toast } from 'sonner';
import apiClient from '@/services/apiClient';
import { Progress } from '@/components/ui/progress';

interface ImageUploadProps {
    title: string;
    description?: string;
    currentImage?: string;
    onImageUploaded: (url: string) => void;
    maxSizeMB?: number;
    className?: string;
    aspectRatio?: number; // For avatar/circular images
    showCrop?: boolean; // Enable crop functionality
    recommendedSize?: string; // e.g., "200x200px"
}

export function ImageUpload({ 
    title, 
    description, 
    currentImage, 
    onImageUploaded, 
    maxSizeMB = 5,
    className,
    aspectRatio,
    showCrop = false,
    recommendedSize
}: ImageUploadProps) {
    const [preview, setPreview] = useState<string | null>(currentImage || null);
    const [isDragging, setIsDragging] = useState(false);
    const [error, setError] = useState<string | null>(null);
    const [isUploading, setIsUploading] = useState(false);
    const [uploadProgress, setUploadProgress] = useState(0);
    const [imageSize, setImageSize] = useState<{ width: number; height: number } | null>(null);
    const fileInputRef = useRef<HTMLInputElement>(null);
    const imageRef = useRef<HTMLImageElement>(null);

    useEffect(() => {
        if (currentImage) {
            setPreview(currentImage);
        }
    }, [currentImage]);

    // Resize image before upload
    const resizeImage = (file: File, maxWidth: number = 1920, maxHeight: number = 1920, quality: number = 0.9): Promise<Blob> => {
        return new Promise((resolve) => {
            const reader = new FileReader();
            reader.onload = (e) => {
                const img = new Image();
                img.onload = () => {
                    const canvas = document.createElement('canvas');
                    let width = img.width;
                    let height = img.height;

                    // Calculate new dimensions
                    if (width > maxWidth || height > maxHeight) {
                        if (width > height) {
                            height = (height * maxWidth) / width;
                            width = maxWidth;
                        } else {
                            width = (width * maxHeight) / height;
                            height = maxHeight;
                        }
                    }

                    canvas.width = width;
                    canvas.height = height;

                    const ctx = canvas.getContext('2d');
                    if (ctx) {
                        ctx.drawImage(img, 0, 0, width, height);
                        canvas.toBlob((blob) => {
                            resolve(blob || file);
                        }, file.type, quality);
                    } else {
                        resolve(file);
                    }
                };
                img.src = e.target?.result as string;
            };
            reader.readAsDataURL(file);
        });
    };

    const handleFileSelect = async (file: File) => {
        setError(null);

        // Validate file type
        if (!file.type.startsWith('image/')) {
            setError('Vui lòng chọn file ảnh (PNG, JPG, GIF, WebP)');
            return;
        }

        // Validate file size
        const sizeMB = file.size / (1024 * 1024);
        if (sizeMB > maxSizeMB) {
            setError(`Kích thước ảnh không được vượt quá ${maxSizeMB}MB`);
            return;
        }

        // Create preview and get image dimensions
        const reader = new FileReader();
        reader.onloadend = () => {
            const img = new Image();
            img.onload = () => {
                setImageSize({ width: img.width, height: img.height });
                setPreview(reader.result as string);
            };
            img.src = reader.result as string;
        };
        reader.readAsDataURL(file);

        // Resize and upload to server
        setIsUploading(true);
        setUploadProgress(0);
        try {
            // Resize image if needed (max 1920x1920)
            const resizedBlob = await resizeImage(file, 1920, 1920, 0.9);
            const resizedFile = new File([resizedBlob], file.name, { type: file.type });

            const formData = new FormData();
            formData.append('file', resizedFile);

            const response = await apiClient.post('/admin/files/upload', formData, {
                headers: {
                    'Content-Type': 'multipart/form-data',
                },
                onUploadProgress: (progressEvent) => {
                    if (progressEvent.total) {
                        const percentCompleted = Math.round((progressEvent.loaded * 100) / progressEvent.total);
                        setUploadProgress(percentCompleted);
                    }
                },
            });

            const uploadedUrl = response.data.url;
            onImageUploaded(uploadedUrl);
            toast.success('Đã tải ảnh lên thành công!');
            setUploadProgress(100);
        } catch (err: any) {
            setError(err.response?.data?.message || 'Không thể tải ảnh lên');
            toast.error('Tải ảnh lên thất bại');
            setPreview(null);
            setImageSize(null);
        } finally {
            setIsUploading(false);
            setTimeout(() => setUploadProgress(0), 1000);
        }
    };

    const handleFileInput = (e: React.ChangeEvent<HTMLInputElement>) => {
        const file = e.target.files?.[0];
        if (file) {
            handleFileSelect(file);
        }
    };

    const handleDragOver = (e: React.DragEvent) => {
        e.preventDefault();
        setIsDragging(true);
    };

    const handleDragLeave = (e: React.DragEvent) => {
        e.preventDefault();
        setIsDragging(false);
    };

    const handleDrop = (e: React.DragEvent) => {
        e.preventDefault();
        setIsDragging(false);

        const file = e.dataTransfer.files[0];
        if (file) {
            handleFileSelect(file);
        }
    };

    const handleRemove = () => {
        setPreview(null);
        setError(null);
        onImageUploaded('');
        if (fileInputRef.current) {
            fileInputRef.current.value = '';
        }
    };

    const handleClick = () => {
        fileInputRef.current?.click();
    };

    const previewClasses = aspectRatio 
        ? `w-full ${aspectRatio === 1 ? 'aspect-square rounded-full' : 'aspect-video rounded-2xl'} object-cover bg-muted`
        : "w-full h-48 object-contain rounded-2xl bg-muted";

    return (
        <Card className={cn("rounded-3xl border-2 hover:border-primary/50 transition-all duration-300", className)}>
            <CardHeader>
                <CardTitle className="text-lg font-bold">{title}</CardTitle>
                {description && <CardDescription className="text-sm">{description}</CardDescription>}
                {recommendedSize && (
                    <p className="text-xs text-muted-foreground mt-1">
                        Khuyến nghị: {recommendedSize}
                    </p>
                )}
            </CardHeader>
            <CardContent>
                <div
                    className={cn(
                        "relative border-2 border-dashed rounded-2xl p-6 transition-all duration-200",
                        isDragging ? "border-primary bg-primary/5 scale-[1.02]" : "border-muted hover:border-primary/50",
                        "cursor-pointer",
                        isUploading && "pointer-events-none"
                    )}
                    onDragOver={handleDragOver}
                    onDragLeave={handleDragLeave}
                    onDrop={handleDrop}
                    onClick={handleClick}
                >
                    <input
                        ref={fileInputRef}
                        type="file"
                        accept="image/*"
                        className="hidden"
                        onChange={handleFileInput}
                        disabled={isUploading}
                    />

                    {isUploading ? (
                        <div className="flex flex-col items-center justify-center space-y-4 py-8">
                            <div className="h-12 w-12 animate-spin rounded-full border-4 border-primary border-t-transparent" />
                            <div className="w-full max-w-xs space-y-2">
                                <Progress value={uploadProgress} className="h-2 rounded-xl" />
                                <p className="text-sm text-center font-medium">
                                    Đang tải ảnh lên... {uploadProgress}%
                                </p>
                            </div>
                        </div>
                    ) : preview ? (
                        <div className="space-y-4">
                            <div className="relative group">
                                <img
                                    ref={imageRef}
                                    src={preview}
                                    alt="Preview"
                                    className={previewClasses}
                                />
                                <div className="absolute inset-0 bg-black/0 group-hover:bg-black/10 rounded-2xl transition-colors" />
                                <Button
                                    type="button"
                                    variant="destructive"
                                    size="icon"
                                    className="absolute top-2 right-2 opacity-0 group-hover:opacity-100 transition-opacity rounded-xl shadow-lg"
                                    onClick={(e) => {
                                        e.stopPropagation();
                                        handleRemove();
                                    }}
                                >
                                    <X className="h-4 w-4" />
                                </Button>
                            </div>
                            {imageSize && (
                                <div className="flex items-center justify-between text-xs text-muted-foreground px-2">
                                    <span>Kích thước: {imageSize.width} × {imageSize.height}px</span>
                                    <span>{(fileInputRef.current?.files?.[0]?.size || 0) / (1024 * 1024) > 0 
                                        ? `${((fileInputRef.current?.files?.[0]?.size || 0) / (1024 * 1024)).toFixed(2)} MB`
                                        : ''}
                                    </span>
                                </div>
                            )}
                            <p className="text-sm text-center text-muted-foreground">
                                Click hoặc kéo thả ảnh khác để thay đổi
                            </p>
                        </div>
                    ) : (
                        <div className="flex flex-col items-center justify-center space-y-4 py-8">
                            <div className="rounded-2xl bg-primary/10 p-4">
                                <Upload className="h-8 w-8 text-primary" />
                            </div>
                            <div className="text-center space-y-2">
                                <p className="text-sm font-semibold">
                                    Kéo thả ảnh vào đây hoặc click để chọn
                                </p>
                                <p className="text-xs text-muted-foreground">
                                    PNG, JPG, GIF, WebP tối đa {maxSizeMB}MB
                                </p>
                            </div>
                        </div>
                    )}

                    {error && (
                        <div className="mt-4 p-3 bg-destructive/10 border border-destructive/20 rounded-xl">
                            <p className="text-sm text-destructive font-medium">{error}</p>
                        </div>
                    )}
                </div>
            </CardContent>
        </Card>
    );
}
