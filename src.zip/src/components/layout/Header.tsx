import { Link, useLocation, useNavigate } from 'react-router-dom';
import React, { useState, useEffect, useRef } from 'react';
import { useUser } from '../../services/UserContext';
import { useFilters } from '../../contexts/FilterContext';
import { formatCurrency } from '../../utils';
import { PATHS } from '../../constants/paths';
import {
    Menu,
    User,
    LogOut,
    Wallet,
    Shield,
    Search,
    PanelLeft,
    Bell
} from 'lucide-react';
import {
    DropdownMenu,
    DropdownMenuContent,
    DropdownMenuItem,
    DropdownMenuLabel,
    DropdownMenuSeparator,
    DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { Button } from '@/components/ui/button';
import { Breadcrumbs } from '../Breadcrumbs';
import { Avatar, AvatarFallback, AvatarImage } from '../ui/avatar';
import { Input } from '../ui/input';
import { useDebounce } from '@/hooks/useDebounce';
import { NotificationBell } from '../NotificationBell';

interface HeaderProps {
    onToggleSidebar: () => void;
    isSidebarCollapsed: boolean;
}

export default function Header({ onToggleSidebar, isSidebarCollapsed }: HeaderProps) {
    const { user, logout } = useUser();
    const location = useLocation();
    const isAdminRoute = location.pathname.startsWith('/admin');
    const navigate = useNavigate();
    const { filters, dispatch } = useFilters();
    const searchInputRef = useRef<HTMLInputElement>(null);

    const [localSearch, setLocalSearch] = useState(filters.search);
    const debouncedSearch = useDebounce(localSearch, 300);

    useEffect(() => {
        setLocalSearch(filters.search);
    }, [filters.search]);

    useEffect(() => {
        dispatch({ type: 'SET_SEARCH', payload: debouncedSearch });
    }, [debouncedSearch, dispatch]);

    const handleSearchChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        setLocalSearch(e.target.value);
    };

    const handleSearchKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
        if (e.key === 'Enter' && location.pathname !== PATHS.STORE) {
            navigate(PATHS.STORE);
        }
    };

    return (
        <div className="flex flex-1 items-center justify-between gap-4">
            {/* Left: Mobile Menu & Breadcrumbs */}
            <div className="flex items-center gap-3">
                <Button
                    variant="ghost"
                    size="icon"
                    onClick={onToggleSidebar}
                    className="lg:hidden text-gray-400 hover:text-white hover:bg-gray-800 rounded-xl"
                >
                    <Menu className="h-5 w-5" />
                </Button>
                
                <div className="hidden lg:block">
                    <Breadcrumbs />
                </div>
            </div>

            {/* Center: Search Bar */}
            <div className="hidden md:flex flex-1 max-w-md mx-auto">
                <div className="relative w-full group">
                    <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-gray-500 group-focus-within:text-indigo-400 transition-colors" />
                    <Input
                        ref={searchInputRef}
                        type="search"
                        placeholder="Tìm kiếm sản phẩm, tài liệu..."
                        className="h-10 w-full rounded-xl border border-gray-700 bg-gray-800/50 pl-10 pr-4 text-sm text-gray-200 placeholder:text-gray-500 focus:border-indigo-500/50 focus:bg-gray-800 focus:ring-2 focus:ring-indigo-500/20 transition-all"
                        value={localSearch}
                        onChange={handleSearchChange}
                        onKeyDown={handleSearchKeyDown}
                    />
                </div>
            </div>

            {/* Right: Actions & User Profile */}
            <div className="flex items-center gap-3">
                {user && <NotificationBell />}

                {user ? (
                    <>
                        {/* Wallet Badge */}
                        <div className="hidden sm:flex items-center gap-2 rounded-xl bg-gray-800/80 border border-gray-700 px-3 py-1.5 text-sm font-semibold text-gray-200 shadow-sm">
                            <Wallet size={16} className="text-indigo-400" />
                            <span>{formatCurrency(user.balance)}</span>
                        </div>

                        {/* User Dropdown */}
                        <DropdownMenu>
                            <DropdownMenuTrigger asChild>
                                <Button
                                    variant="ghost"
                                    className="relative h-10 w-10 rounded-full ring-2 ring-gray-800 hover:ring-indigo-500/50 transition-all p-0 overflow-hidden"
                                >
                                    <Avatar className="h-10 w-10">
                                        <AvatarImage
                                            src={user.avatarUrl}
                                            alt={user.name}
                                        />
                                        <AvatarFallback className="bg-indigo-600 text-white font-bold">
                                            {user.name?.charAt(0) || 'U'}
                                        </AvatarFallback>
                                    </Avatar>
                                </Button>
                            </DropdownMenuTrigger>
                            <DropdownMenuContent className="w-64 rounded-xl border-gray-700 bg-gray-800 text-gray-200 p-2 shadow-xl shadow-black/50" align="end">
                                <DropdownMenuLabel className="font-normal p-2">
                                    <div className="flex flex-col space-y-1">
                                        <p className="text-sm font-semibold leading-none text-white">{user.name}</p>
                                        <p className="text-xs text-gray-400">{user.email}</p>
                                    </div>
                                </DropdownMenuLabel>
                                <DropdownMenuSeparator className="bg-gray-700" />
                                <DropdownMenuItem asChild className="rounded-lg focus:bg-gray-700 focus:text-white cursor-pointer">
                                    <Link to={PATHS.PROFILE} className="flex items-center gap-2">
                                        <User className="h-4 w-4" />
                                        <span>Trang cá nhân</span>
                                    </Link>
                                </DropdownMenuItem>
                                {user.role === 'admin' && !isAdminRoute && (
                                    <DropdownMenuItem asChild className="rounded-lg focus:bg-gray-700 focus:text-white cursor-pointer">
                                        <Link to={PATHS.ADMIN} className="flex items-center gap-2">
                                            <Shield className="h-4 w-4 text-indigo-400" />
                                            <span>Admin Panel</span>
                                        </Link>
                                    </DropdownMenuItem>
                                )}
                                <DropdownMenuSeparator className="bg-gray-700" />
                                <DropdownMenuItem
                                    onClick={logout}
                                    className="rounded-lg text-red-400 focus:bg-red-500/10 focus:text-red-400 cursor-pointer flex items-center gap-2"
                                >
                                    <LogOut className="h-4 w-4" />
                                    <span>Đăng xuất</span>
                                </DropdownMenuItem>
                            </DropdownMenuContent>
                        </DropdownMenu>
                    </>
                ) : (
                    <Button
                        asChild
                        className="rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-medium shadow-lg shadow-indigo-500/20"
                    >
                        <Link to={PATHS.LOGIN}>Đăng nhập</Link>
                    </Button>
                )}
            </div>
        </div>
    );
}