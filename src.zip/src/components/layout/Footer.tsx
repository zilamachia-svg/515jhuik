import { Link } from 'react-router-dom';
import { useLanguage } from '../../contexts/LanguageContext';
import { PATHS } from '../../constants/paths';

export default function Footer() {
    const { t } = useLanguage();
    const currentYear = new Date().getFullYear();
    const rawDomain = import.meta.env.VITE_API_BASE_URL;

    const domainUrl = rawDomain && (rawDomain.startsWith('http') ? rawDomain : `https://${rawDomain}`);
    const domainForDisplay = rawDomain && rawDomain.replace(/^https?:\/\//, '');

    return (
        <footer className="app-footer">
            <p>
                {t('footer.copyright', { year: currentYear })}
                {domainUrl && domainForDisplay && (
                     <>
                        {' - '}
                        <a href={domainUrl} target="_blank" rel="noopener noreferrer">
                            {domainForDisplay}
                        </a>
                    </>
                )}
            </p>
            <div className="footer-links">
                <Link to={PATHS.CONTACT}>{t('sidebar.contactSupport')}</Link>
                <span>|</span>
                <Link to={PATHS.API_DOCS}>API</Link>
            </div>
        </footer>
    );
}
