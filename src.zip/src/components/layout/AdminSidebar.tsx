import { NavLink } from 'react-router-dom';
import { PATHS } from '../../constants/paths';
import { useLanguage } from '../../contexts/LanguageContext';
import {
    Home, Store, Wallet, History, Trophy, FileText, Code, Link as LinkIcon, Phone, HelpCircle, Rss, Flame, Cpu
} from 'lucide-react';

type AppSidebarProps = {
    isCollapsed: boolean;
    onToggleCollapse: () => void;
};

export default function AppSidebar({ isCollapsed }: AppSidebarProps) {
    const { t } = useLanguage();
    
    const mainNav = [
        { path: PATHS.HOME, icon: <Home strokeWidth={1.7} size={20} />, label: t('sidebar.home', { defaultValue: 'Trang chủ' }) },
        { path: PATHS.STORE, icon: <Store strokeWidth={1.7} size={20} />, label: t('sidebar.buyAccounts', { defaultValue: 'Mua tài khoản' }) },
        { path: PATHS.DOCUMENTS, icon: <FileText strokeWidth={1.7} size={20} />, label: t('sidebar.buyDocuments', { defaultValue: 'Mua tài liệu' }) },
    ];

    const financialNav = [
        { path: PATHS.DEPOSIT, icon: <Wallet strokeWidth={1.7} size={20} />, label: t('sidebar.deposit', { defaultValue: 'Nạp tiền' }) },
        { path: '/history', icon: <History strokeWidth={1.7} size={20} />, label: t('sidebar.transactionHistory', { defaultValue: 'Lịch sử GD' }) },
        { path: PATHS.LEADERBOARD, icon: <Trophy strokeWidth={1.7} size={20} />, label: t('sidebar.topUpLeaderboard', { defaultValue: 'Top Nạp' }) },
        { path: PATHS.AFFILIATE, icon: <LinkIcon strokeWidth={1.7} size={20} />, label: t('sidebar.affiliate', { defaultValue: 'Tiếp thị liên kết' }) },
    ];
    
    const toolsNav = [
        { path: PATHS.TOOLS, icon: <Cpu strokeWidth={1.7} size={20} />, label: t('sidebar.toolsTitle', { defaultValue: 'Công cụ' }) },
    ];

    const infoNav = [
        { path: PATHS.API_DOCS, icon: <Code strokeWidth={1.7} size={20} />, label: t('sidebar.apiDocs', { defaultValue: 'Tài liệu API' }) },
        { path: PATHS.CONTACT, icon: <Phone strokeWidth={1.7} size={20} />, label: t('sidebar.contactSupport', { defaultValue: 'Liên hệ' }) },
        { path: PATHS.POSTS, icon: <Rss strokeWidth={1.7} size={20} />, label: t('sidebar.posts', { defaultValue: 'Bài viết' }) },
        { path: PATHS.FAQ, icon: <HelpCircle strokeWidth={1.7} size={20} />, label: t('sidebar.faq', { defaultValue: 'FAQ' }) },
    ];

    const getNavLinkClass = ({ isActive }: { isActive: boolean }) => `sidenav-link ${isActive ? 'active' : ''}`;

    return (
        <aside className={`app-sidenav ${isCollapsed ? 'collapsed' : ''}`}>
            <div className="sidenav-header">
                <div className="logo bg-primary/20 rounded-lg flex items-center justify-center">
                    <Flame className="text-primary" strokeWidth={1.7} />
                </div>
                <div className="user-info">
                    <h1 className="sidenav-link-text font-semibold">Hải Đăng Meta</h1>
                </div>
            </div>
            <nav className="sidenav-menu">
                <div className="menu-section">
                    <h3 className="menu-heading">Chính</h3>
                    {mainNav.map(item => (
                        <NavLink key={item.path} to={item.path} className={getNavLinkClass} data-tooltip={item.label} end={item.path === '/'}>
                            {item.icon}
                            <span className="sidenav-link-text">{item.label}</span>
                        </NavLink>
                    ))}
                </div>

                <div className="menu-section">
                    <h3 className="menu-heading">Tài chính</h3>
                    {financialNav.map(item => (
                         <NavLink key={item.path} to={item.path} className={getNavLinkClass} data-tooltip={item.label}>
                            {item.icon}
                            <span className="sidenav-link-text">{item.label}</span>
                        </NavLink>
                    ))}
                </div>
                 
                <div className="menu-section">
                    <h3 className="menu-heading">Công cụ</h3>
                    {toolsNav.map(item => (
                         <NavLink key={item.path} to={item.path} className={getNavLinkClass} data-tooltip={item.label}>
                            {item.icon}
                            <span className="sidenav-link-text">{item.label}</span>
                        </NavLink>
                    ))}
                </div>

                <div className="menu-section">
                    <h3 className="menu-heading">Thông tin</h3>
                    {infoNav.map(item => (
                         <NavLink key={item.path} to={item.path} className={getNavLinkClass} data-tooltip={item.label}>
                            {item.icon}
                            <span className="sidenav-link-text">{item.label}</span>
                        </NavLink>
                    ))}
                </div>
            </nav>
        </aside>
    );
}