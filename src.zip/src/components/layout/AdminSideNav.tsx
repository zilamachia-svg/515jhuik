import { useState, memo } from 'react';
import { Link, NavLink } from 'react-router-dom';
import { useLanguage } from '../../contexts/LanguageContext';
import { PATHS } from '../../constants/paths';
import { Tooltip, TooltipContent, TooltipTrigger } from '@/components/ui/tooltip';
import { ScrollArea } from '@/components/ui/scroll-area';
import { cn } from '@/lib/utils';
import {
    ArrowLeft,
    ChevronDown,
    ChevronRight,
    ChevronsLeft,
    ChevronsRight,
    X,
    LayoutDashboard, Users, ShoppingBag, CreditCard, Package, FolderOpen, UploadCloud, FileInput, Truck, FileText, HelpCircle, Folder, Key, Share2, Settings, Activity
} from 'lucide-react';
import type { DashboardShellSidebarProps } from '@/layouts/DashboardShell';

type AdminSidebarProps = DashboardShellSidebarProps;

const navSections = [
    {
        titleKey: 'sidebar.main',
        defaultExpanded: true,
        items: [
            { path: PATHS.ADMIN_DASHBOARD, labelKey: 'sidebar.admin.dashboard', icon: <LayoutDashboard size={20} /> },
            { path: PATHS.ADMIN_USERS, labelKey: 'sidebar.admin.userManagement', icon: <Users size={20} /> },
        ],
    },
    {
        titleKey: 'sidebar.admin.store',
        defaultExpanded: true,
        items: [
            { path: PATHS.ADMIN_ORDERS, labelKey: 'sidebar.admin.orderManagement', icon: <ShoppingBag size={20} /> },
            { path: PATHS.ADMIN_DEPOSITS, labelKey: 'sidebar.admin.depositManagement', icon: <CreditCard size={20} /> },
            { path: PATHS.ADMIN_PRODUCTS, labelKey: 'sidebar.admin.productManagement', icon: <Package size={20} /> },
            { path: PATHS.ADMIN_PRODUCT_CATEGORIES, labelKey: 'sidebar.admin.categories', icon: <FolderOpen size={20} /> },
            { path: PATHS.ADMIN_UPLOAD_PRODUCTS, labelKey: 'sidebar.admin.batchAdd', icon: <UploadCloud size={20} /> },
            { path: PATHS.ADMIN_ACCOUNTS_IMPORT, labelKey: 'sidebar.admin.accountsImport', icon: <FileInput size={20} /> },
            { path: PATHS.ADMIN_SUPPLIERS, labelKey: 'sidebar.admin.suppliers', icon: <Truck size={20} /> },
        ],
    },
    {
        titleKey: 'sidebar.admin.content',
        defaultExpanded: false,
        items: [
            { path: PATHS.ADMIN_POSTS, labelKey: 'sidebar.admin.postManagement', icon: <FileText size={20} /> },
            { path: PATHS.ADMIN_FAQ, labelKey: 'sidebar.admin.faqManagement', icon: <HelpCircle size={20} /> },
            { path: PATHS.ADMIN_FILES, labelKey: 'sidebar.admin.fileManagement', icon: <Folder size={20} /> },
        ],
    },
    {
        titleKey: 'sidebar.admin.marketing',
        defaultExpanded: false,
        items: [
            { path: PATHS.ADMIN_API_KEYS, labelKey: 'sidebar.admin.apiKeys', icon: <Key size={20} /> },
            { path: PATHS.ADMIN_AFFILIATE, labelKey: 'sidebar.admin.affiliateManagement', icon: <Share2 size={20} /> },
        ],
    },
    {
        titleKey: 'sidebar.admin.settings',
        defaultExpanded: false,
        items: [
            { path: PATHS.ADMIN_SETTINGS, labelKey: 'sidebar.admin.settings.system', icon: <Settings size={20} /> },
            { path: PATHS.ADMIN_API_LOGS, labelKey: 'sidebar.admin.apiLogs', icon: <Activity size={20} /> },
        ],
    },
];

const NavItem: React.FC<{
    path: string;
    icon: React.ReactNode;
    label: string;
    isCollapsed: boolean;
    onClick: () => void;
}> = memo(({ path, icon, label, isCollapsed, onClick }) => {
    return (
        <li>
            {isCollapsed ? (
                <Tooltip delayDuration={0}>
                    <TooltipTrigger asChild>
                        <NavLink
                            to={path}
                            className={({ isActive }) =>
                                cn(
                                    'flex h-10 w-10 items-center justify-center rounded-xl transition-all duration-200 mx-auto',
                                    isActive
                                        ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-500/20'
                                        : 'text-gray-400 hover:bg-gray-800 hover:text-white'
                                )
                            }
                            onClick={onClick}
                        >
                            {icon}
                        </NavLink>
                    </TooltipTrigger>
                    <TooltipContent side="right" className="bg-gray-800 text-white border-gray-700">
                        {label}
                    </TooltipContent>
                </Tooltip>
            ) : (
                <NavLink
                    to={path}
                    className={({ isActive }) =>
                        cn(
                            'group flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-medium transition-all duration-200',
                            isActive
                                ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-500/20'
                                : 'text-gray-400 hover:bg-gray-800 hover:text-white'
                        )
                    }
                    onClick={onClick}
                >
                    <span className={cn("transition-colors", "opacity-70 group-hover:opacity-100")}>
                        {icon}
                    </span>
                    <span className="truncate">{label}</span>
                </NavLink>
            )}
        </li>
    );
});

NavItem.displayName = 'NavItem';

const NavSection: React.FC<{
    title: string;
    items: Array<{ path: string; icon: React.ReactNode; label: string }>;
    isCollapsed: boolean;
    onItemClick: () => void;
    defaultExpanded?: boolean;
}> = ({ title, items, isCollapsed, onItemClick, defaultExpanded = true }) => {
    const [isExpanded, setIsExpanded] = useState(defaultExpanded);

    if (isCollapsed) {
        return (
            <div className="mb-4">
                <ul className="space-y-2">
                    {items.map(item => (
                        <NavItem key={item.path} path={item.path} icon={item.icon} label={item.label} isCollapsed onClick={onItemClick} />
                    ))}
                </ul>
            </div>
        );
    }

    return (
        <div className="mb-4 px-2">
            <button
                onClick={() => setIsExpanded(prev => !prev)}
                className="flex w-full items-center justify-between rounded-lg px-2 py-1.5 text-xs font-semibold uppercase tracking-wider text-gray-500 hover:text-gray-300 transition-colors"
            >
                <span>{title}</span>
                <ChevronDown className={cn("h-3 w-3 transition-transform duration-200", isExpanded ? "rotate-180" : "")} />
            </button>
            <div className={cn("mt-1 space-y-1 overflow-hidden transition-all duration-300", isExpanded ? "max-h-[800px] opacity-100" : "max-h-0 opacity-0")}>
                {items.map(item => (
                    <NavItem key={item.path} path={item.path} icon={item.icon} label={item.label} isCollapsed={false} onClick={onItemClick} />
                ))}
            </div>
        </div>
    );
};

const AdminSideNav: React.FC<AdminSidebarProps> = ({
    isCollapsed,
    isMobileOpen,
    onToggleCollapse,
    onCloseMobile,
}) => {
    const { t } = useLanguage();
    const translate = (key: string, fallback: string) => {
        const value = t(key);
        return value === key ? fallback : value;
    };

    return (
        <div className="flex h-full flex-col">
            <div className={cn("flex items-center h-16 px-4 border-b border-gray-800 bg-gray-900/50", isCollapsed ? "justify-center" : "justify-between")}>
                <Link to={PATHS.ADMIN} className="flex items-center gap-3 group" onClick={onCloseMobile}>
                    <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-gradient-to-br from-red-500 to-orange-600 shadow-lg shadow-red-500/20 text-white transition-transform group-hover:scale-105">
                        <span className="font-bold text-lg">A</span>
                    </div>
                    {!isCollapsed && (
                        <span className="font-bold text-gray-100 text-sm">Admin Panel</span>
                    )}
                </Link>
                {!isCollapsed && (
                    <button onClick={onCloseMobile} className="lg:hidden text-gray-400 hover:text-white">
                        <X size={20} />
                    </button>
                )}
            </div>

            <ScrollArea className="flex-1 py-4">
                <nav>
                    {navSections.map(section => {
                        const fallbackTitle = section.titleKey.split('.').pop()?.replace(/([A-Z])/g, ' $1').trim() ?? section.titleKey;
                        const title = translate(section.titleKey, fallbackTitle);
                        const preparedItems = section.items.map(item => ({
                            ...item,
                            label: translate(item.labelKey, item.labelKey),
                        }));
                        return (
                            <NavSection
                                key={section.titleKey}
                                title={title}
                                items={preparedItems}
                                isCollapsed={isCollapsed}
                                onItemClick={onCloseMobile}
                                defaultExpanded={section.defaultExpanded}
                            />
                        );
                    })}
                </nav>
            </ScrollArea>

            <div className="p-4 border-t border-gray-800 bg-gray-900/50">
                <div className="flex flex-col gap-2">
                    {!isCollapsed && (
                        <Link
                            to={PATHS.HOME}
                            className="flex w-full items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-medium text-gray-400 hover:bg-gray-800 hover:text-white transition-all"
                            onClick={onCloseMobile}
                        >
                            <ArrowLeft size={20} />
                            <span>{translate('header.backToSite', 'Quay về trang web')}</span>
                        </Link>
                    )}
                    <button
                        onClick={onToggleCollapse}
                        className={cn(
                            "hidden lg:flex items-center justify-center rounded-xl bg-gray-800/50 hover:bg-gray-800 text-gray-400 hover:text-white transition-all h-9 w-full",
                            isCollapsed && "w-9 mx-auto"
                        )}
                        title={isCollapsed ? translate('sidebar.expand', 'Expand') : translate('sidebar.collapse', 'Collapse')}
                    >
                        {isCollapsed ? <ChevronsRight size={18} /> : <ChevronsLeft size={18} />}
                    </button>
                </div>
            </div>
        </div>
    );
};

export default AdminSideNav;