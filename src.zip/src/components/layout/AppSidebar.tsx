import React, { useState } from 'react';
import { Link, NavLink } from 'react-router-dom';
import { useLanguage } from '../../contexts/LanguageContext';
import { PATHS } from '../../constants/paths';
import { Tooltip, TooltipContent, TooltipTrigger } from '@/components/ui/tooltip';
import { ScrollArea } from '@/components/ui/scroll-area';
import { cn } from '@/lib/utils';
import {
    ChevronDown,
    ChevronsLeft,
    ChevronsRight,
    X,
    Home, ShoppingCart, Wallet, History, Trophy, Link as LinkIcon, Code, Search, HelpCircle, BookOpen, FileText, Phone, Settings
} from 'lucide-react';
import type { DashboardShellSidebarProps } from '@/layouts/DashboardShell';

type AppSidebarProps = DashboardShellSidebarProps;

const mainNav = [
    { path: PATHS.HOME, labelKey: 'sidebar.home', icon: <Home size={20} /> },
    { path: PATHS.STORE, labelKey: 'sidebar.buyAccounts', icon: <ShoppingCart size={20} /> },
];

const accountNav = [
    { path: PATHS.DEPOSIT, labelKey: 'sidebar.depositMoney', icon: <Wallet size={20} /> },
    { path: PATHS.ORDERS_HISTORY, labelKey: 'sidebar.purchaseHistory', icon: <History size={20} /> },
    { path: PATHS.LEADERBOARD, labelKey: 'sidebar.topUpLeaderboard', icon: <Trophy size={20} /> },
    { path: PATHS.AFFILIATE, labelKey: 'sidebar.affiliate', icon: <LinkIcon size={20} /> },
];

const toolsNav = [
    { path: PATHS.TOOLS_GET_2FA, labelKey: 'sidebar.get2FA', icon: <Code size={20} /> },
    { path: PATHS.TOOLS_CHECK_LIVE_FB, labelKey: 'sidebar.checkLiveFB', icon: <Search size={20} /> },
];

const resourcesNav = [
    { path: PATHS.FAQ, labelKey: 'sidebar.faq', icon: <HelpCircle size={20} /> },
    { path: PATHS.GUIDE, labelKey: 'Hướng dẫn', icon: <BookOpen size={20} /> },
    { path: PATHS.POSTS, labelKey: 'sidebar.news', icon: <FileText size={20} /> },
    { path: PATHS.API_DOCS, labelKey: 'sidebar.apiDocs', icon: <Code size={20} /> },
    { path: PATHS.CONTACT, labelKey: 'sidebar.contactSupport', icon: <Phone size={20} /> },
];

const NavItem: React.FC<{
    path: string;
    icon: React.ReactNode;
    label: string;
    isCollapsed: boolean;
    end?: boolean;
    onClick?: () => void;
}> = ({ path, icon, label, isCollapsed, end, onClick }) => {
    return (
        <li>
            {isCollapsed ? (
                <Tooltip delayDuration={0}>
                    <TooltipTrigger asChild>
                        <NavLink
                            to={path}
                            end={end}
                            className={({ isActive }) =>
                                cn(
                                    'flex h-10 w-10 items-center justify-center rounded-xl transition-all duration-200 mx-auto',
                                    isActive
                                        ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-500/20'
                                        : 'text-gray-400 hover:bg-gray-800 hover:text-white'
                                )
                            }
                            onClick={onClick}
                        >
                            {icon}
                        </NavLink>
                    </TooltipTrigger>
                    <TooltipContent side="right" className="bg-gray-800 text-white border-gray-700">
                        {label}
                    </TooltipContent>
                </Tooltip>
            ) : (
                <NavLink
                    to={path}
                    end={end}
                    className={({ isActive }) =>
                        cn(
                            'group flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-medium transition-all duration-200',
                            isActive
                                ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-500/20'
                                : 'text-gray-400 hover:bg-gray-800 hover:text-white'
                        )
                    }
                    onClick={onClick}
                >
                    <span className={cn("transition-colors", "opacity-70 group-hover:opacity-100")}>
                        {icon}
                    </span>
                    <span className="truncate">{label}</span>
                </NavLink>
            )}
        </li>
    );
};

const NavSection: React.FC<{
    title: string;
    items: Array<{ path: string; icon: React.ReactNode; label: string }>;
    isCollapsed: boolean;
    onItemClick: () => void;
    defaultExpanded?: boolean;
}> = ({ title, items, isCollapsed, onItemClick, defaultExpanded = true }) => {
    const [isExpanded, setIsExpanded] = useState(defaultExpanded);

    if (isCollapsed) {
        return (
            <div className="mb-4">
                <ul className="space-y-2">
                    {items.map(item => (
                        <NavItem key={item.path} path={item.path} icon={item.icon} label={item.label} isCollapsed end={item.path === PATHS.HOME} onClick={onItemClick} />
                    ))}
                </ul>
            </div>
        );
    }

    return (
        <div className="mb-4 px-2">
            <button
                onClick={() => setIsExpanded(prev => !prev)}
                className={cn(
                    "flex w-full items-center justify-between rounded-lg px-2 py-1.5 text-xs font-semibold uppercase tracking-wider text-gray-500 hover:text-gray-300 transition-colors",
                )}
            >
                <span>{title}</span>
                <ChevronDown
                    className={cn(
                        "h-3 w-3 transition-transform duration-200",
                        isExpanded ? "rotate-180" : "",
                    )}
                />
            </button>
            <div className={cn(
                "mt-1 space-y-1 overflow-hidden transition-all duration-300",
                isExpanded ? "max-h-[500px] opacity-100" : "max-h-0 opacity-0"
            )}>
                {items.map(item => (
                    <NavItem key={item.path} path={item.path} icon={item.icon} label={item.label} isCollapsed={false} end={item.path === PATHS.HOME} onClick={onItemClick} />
                ))}
            </div>
        </div>
    );
};

const AppSidebar: React.FC<AppSidebarProps> = ({
    isCollapsed,
    isMobileOpen,
    onToggleCollapse,
    onCloseMobile,
}) => {
    const { t } = useLanguage();
    const translate = (key: string, fallback: string) => {
        const value = t(key);
        return value === key ? fallback : value;
    };

    return (
        <div className="flex h-full flex-col">
            {/* Header Sidebar */}
            <div className={cn("flex items-center h-16 px-4 border-b border-gray-800", isCollapsed ? "justify-center" : "justify-between")}>
                <Link to="/" className="flex items-center gap-3 group" onClick={onCloseMobile}>
                    <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-gradient-to-br from-indigo-500 to-purple-600 shadow-lg shadow-indigo-500/30 text-white transition-transform group-hover:scale-105">
                       <span className="font-bold text-lg">H</span>
                    </div>
                    {!isCollapsed && (
                        <div className="flex flex-col">
                            <span className="font-bold text-gray-100 text-sm leading-none">Hải Đăng Meta</span>
                            <span className="text-[10px] text-indigo-400 font-medium mt-1">Creative Suite</span>
                        </div>
                    )}
                </Link>
                
                {!isCollapsed && (
                    <button
                        onClick={onCloseMobile}
                        className="lg:hidden text-gray-400 hover:text-white transition-colors"
                    >
                        <X size={20} />
                    </button>
                )}
            </div>

            {/* Content Scroll */}
            <ScrollArea className="flex-1 py-4">
                <nav>
                    {[
                        { titleKey: 'sidebar.main', items: mainNav, defaultExpanded: true },
                        { titleKey: 'sidebar.account', items: accountNav, defaultExpanded: true },
                        { titleKey: 'sidebar.toolsTitle', items: toolsNav, defaultExpanded: true },
                        { titleKey: 'sidebar.resources', items: resourcesNav, defaultExpanded: true },
                    ].map(section => (
                        <NavSection
                            key={section.titleKey}
                            title={translate(section.titleKey, section.titleKey)}
                            items={section.items.map(item => ({
                                ...item,
                                label: translate(item.labelKey, item.labelKey),
                            }))}
                            isCollapsed={isCollapsed}
                            onItemClick={onCloseMobile}
                            defaultExpanded={section.defaultExpanded}
                        />
                    ))}
                </nav>
            </ScrollArea>

            {/* Footer Sidebar / Collapse Button */}
            <div className="p-4 border-t border-gray-800 bg-gray-900/50">
                <div className="flex flex-col gap-2">
                    {!isCollapsed && (
                        <Link
                            to={PATHS.SETTINGS}
                            className="flex w-full items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-medium text-gray-400 hover:bg-gray-800 hover:text-white transition-all"
                            onClick={onCloseMobile}
                        >
                            <Settings size={20} />
                            <span>{translate('sidebar.accountSettings', 'Settings')}</span>
                        </Link>
                    )}
                    
                    <button
                        onClick={onToggleCollapse}
                        className={cn(
                            "hidden lg:flex items-center justify-center rounded-xl bg-gray-800/50 hover:bg-gray-800 text-gray-400 hover:text-white transition-all h-9 w-full",
                            isCollapsed && "w-9 mx-auto"
                        )}
                        title={isCollapsed ? translate('sidebar.expand', 'Expand') : translate('sidebar.collapse', 'Collapse')}
                    >
                        {isCollapsed ? <ChevronsRight size={18} /> : <ChevronsLeft size={18} />}
                    </button>
                </div>
            </div>
        </div>
    );
};
export default AppSidebar;