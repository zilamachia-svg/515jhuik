import { useRef } from 'react';
import { Bold, Italic, List, Code } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';

type RichTextEditorProps = {
    value: string;
    onChange: (value: string) => void;
};

const RichTextEditor = ({ value, onChange }: RichTextEditorProps) => {
    const textareaRef = useRef<HTMLTextAreaElement>(null);

    const insertText = (before: string, after: string = '') => {
        const textarea = textareaRef.current;
        if (!textarea) return;

        const start = textarea.selectionStart;
        const end = textarea.selectionEnd;
        const selectedText = value.substring(start, end);
        const newText = `${value.substring(0, start)}${before}${selectedText}${after}${value.substring(end)}`;

        onChange(newText);

        // Restore focus and selection
        textarea.focus();
        setTimeout(() => {
            textarea.setSelectionRange(start + before.length, start + before.length + selectedText.length);
        }, 0);
    };

    return (
        <div className="border border-input rounded-lg">
            <div className="flex items-center gap-1 p-2 border-b border-input">
                <Button type="button" variant="ghost" size="icon" className="h-8 w-8" onClick={() => insertText('**', '**')} title="Bold">
                    <Bold size={16} />
                </Button>
                <Button type="button" variant="ghost" size="icon" className="h-8 w-8" onClick={() => insertText('*', '*')} title="Italic">
                    <Italic size={16} />
                </Button>
                <Button type="button" variant="ghost" size="icon" className="h-8 w-8" onClick={() => insertText('\n- ', '')} title="List">
                    <List size={16} />
                </Button>
                 <Button type="button" variant="ghost" size="icon" className="h-8 w-8" onClick={() => insertText('`', '`')} title="Code">
                    <Code size={16} />
                </Button>
            </div>
            <Textarea
                ref={textareaRef}
                value={value}
                onChange={(e) => onChange(e.target.value)}
                placeholder="Nội dung bài viết..."
                className="border-0 focus-visible:ring-0 focus-visible:ring-offset-0 min-h-[200px] resize-y"
            />
        </div>
    );
};

export default RichTextEditor;
