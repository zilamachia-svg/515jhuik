import React, { useMemo } from 'react';
import { PaymentMethod, User } from '../types';
import { useCopyToClipboard } from '../hooks/useCopyToClipboard';
import { formatCurrency } from '../utils';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogDescription } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Copy, Check, AlertTriangle } from 'lucide-react';
import { Alert, AlertDescription } from './ui/alert';

type PaymentInstructionsModalProps = {
    method: PaymentMethod;
    user: User;
    amount?: number;
    onClose: () => void;
};

export const PaymentInstructionsModal = ({ method, user, amount = 100000, onClose }: PaymentInstructionsModalProps) => {
    const [copyContent, isContentCopied] = useCopyToClipboard();
    const [copyAccNum, isAccNumCopied] = useCopyToClipboard();

    // Generate a unique part of the transfer content based on user ID
    const transferSyntax = useMemo(() => `HDM ${user.id}`, [user.id]);

    const formattedAmount = new Intl.NumberFormat('vi-VN').format(amount);

    const qrCodeUrl = useMemo(() => {
        if (!method.accountNumber || !method.accountName) return method.qrCodeUrl || '';
        // Using VietQR API standard
        // Note: Momo doesn't have a standard public QR generation API like this. We'll use the static QR if provided.
        if (method.type === 'bank') {
            const params = new URLSearchParams({
                accountName: method.accountName,
                amount: amount.toString(),
                addInfo: transferSyntax,
            });
            // A simple heuristic to get bank code, not exhaustive.
            const bankCode = method.name.toUpperCase().replace('BANK', '').trim();
            return `https://img.vietqr.io/image/${bankCode}-${method.accountNumber}-print.png?${params.toString()}`;
        }
        return method.qrCodeUrl || '';
    }, [method, amount, transferSyntax]);

    return (
        <Dialog open={true} onOpenChange={onClose}>
            <DialogContent className="max-w-md">
                <DialogHeader>
                    <DialogTitle>Nạp tiền qua {method.name}</DialogTitle>
                    <DialogDescription>Thực hiện chuyển khoản theo thông tin dưới đây</DialogDescription>
                </DialogHeader>
                <div className="space-y-4 py-4">
                     <Alert variant="destructive">
                        <AlertTriangle className="h-4 w-4" />
                        <AlertDescription className="font-semibold">
                            Chuyển khoản chính xác nội dung để được cộng tiền tự động.
                        </AlertDescription>
                    </Alert>
                    
                    <div className="p-3 bg-muted rounded-lg">
                        <div className="flex justify-between items-center">
                            <span className="text-sm text-muted-foreground">Số tiền cần nạp:</span>
                            <span className="text-lg font-bold text-primary">{formatCurrency(amount)}</span>
                        </div>
                    </div>

                    <div className="flex flex-col items-center gap-4">
                        {qrCodeUrl && (
                             <div className="p-2 border rounded-lg">
                                <img src={qrCodeUrl} alt="QR Code" width="250" height="250" />
                            </div>
                        )}
                        <p className="text-sm text-center">Quét mã QR để chuyển khoản nhanh</p>
                    </div>
                    
                    <div className="space-y-3 text-sm">
                        <div className="flex justify-between items-center">
                            <span>Tên chủ tài khoản:</span>
                            <span className="font-semibold">{method.accountName}</span>
                        </div>
                        <div className="flex justify-between items-center">
                            <span>Số tài khoản/SĐT:</span>
                             <div className="flex items-center gap-2">
                                <span className="font-semibold">{method.accountNumber}</span>
                                <Button variant="ghost" size="icon" className="h-7 w-7" onClick={() => copyAccNum(method.accountNumber, 'Đã sao chép số tài khoản!')}>
                                    {isAccNumCopied ? <Check size={14} /> : <Copy size={14} />}
                                </Button>
                            </div>
                        </div>
                        <div className="flex justify-between items-center">
                            <span>Nội dung chuyển khoản:</span>
                            <div className="flex items-center gap-2">
                                <span className="font-semibold text-primary">{transferSyntax}</span>
                                <Button variant="ghost" size="icon" className="h-7 w-7" onClick={() => copyContent(transferSyntax, 'Đã sao chép nội dung!')}>
                                    {isContentCopied ? <Check size={14} /> : <Copy size={14} />}
                                </Button>
                            </div>
                        </div>
                         <div className="flex justify-between items-center">
                            <span>Số tiền:</span>
                            <span className="font-semibold text-primary">{formatCurrency(amount)}</span>
                        </div>
                    </div>
                </div>
                <DialogFooter>
                    <Button onClick={onClose} className="w-full">Đã hiểu</Button>
                </DialogFooter>
            </DialogContent>
        </Dialog>
    );
};
