import { Button } from './ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { TriangleAlert, RefreshCw, Home, AlertCircle } from 'lucide-react';
import { Link } from 'react-router-dom';
import { useState } from 'react';

interface ErrorFallbackProps {
    error?: Error | null;
    errorInfo?: React.ErrorInfo | null;
    onReset?: () => void;
}

export const ErrorFallback = ({ error, errorInfo, onReset }: ErrorFallbackProps) => {
    const [showDetails, setShowDetails] = useState(false);
    const isDev = import.meta.env.DEV;

    return (
        <div className="min-h-screen flex items-center justify-center bg-background p-4">
            <Card className="text-center max-w-2xl w-full">
                <CardHeader>
                    <TriangleAlert className="mx-auto h-16 w-16 text-destructive mb-4" />
                    <CardTitle className="text-2xl">Đã có lỗi xảy ra</CardTitle>
                    <CardDescription className="mt-2">
                        Rất tiếc, đã có sự cố ngoài ý muốn. Vui lòng thử một trong các cách sau:
                    </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                    <div className="flex flex-col sm:flex-row gap-3 justify-center">
                        {onReset && (
                            <Button
                                onClick={onReset}
                                variant="default"
                                className="rounded-xl"
                            >
                                <RefreshCw className="mr-2 h-4 w-4" />
                                Thử lại
                            </Button>
                        )}
                        <Button
                            onClick={() => window.location.reload()}
                            variant="outline"
                            className="rounded-xl"
                        >
                            <RefreshCw className="mr-2 h-4 w-4" />
                            Tải lại trang
                        </Button>
                        <Button
                            asChild
                            variant="outline"
                            className="rounded-xl"
                        >
                            <Link to="/">
                                <Home className="mr-2 h-4 w-4" />
                                Về trang chủ
                            </Link>
                        </Button>
                    </div>

                    {isDev && error && (
                        <div className="mt-6 text-left">
                            <Button
                                variant="ghost"
                                size="sm"
                                onClick={() => setShowDetails(!showDetails)}
                                className="w-full justify-between rounded-xl"
                            >
                                <span className="flex items-center gap-2">
                                    <AlertCircle className="h-4 w-4" />
                                    {showDetails ? 'Ẩn' : 'Hiển thị'} chi tiết lỗi
                                </span>
                            </Button>
                            
                            {showDetails && (
                                <div className="mt-3 p-4 bg-muted rounded-xl space-y-3 text-sm">
                                    <div>
                                        <strong className="text-destructive">Lỗi:</strong>
                                        <pre className="mt-1 p-2 bg-background rounded text-xs overflow-auto">
                                            {error.message}
                                        </pre>
                                    </div>
                                    {error.stack && (
                                        <div>
                                            <strong>Stack Trace:</strong>
                                            <pre className="mt-1 p-2 bg-background rounded text-xs overflow-auto max-h-40">
                                                {error.stack}
                                            </pre>
                                        </div>
                                    )}
                                    {errorInfo && errorInfo.componentStack && (
                                        <div>
                                            <strong>Component Stack:</strong>
                                            <pre className="mt-1 p-2 bg-background rounded text-xs overflow-auto max-h-40">
                                                {errorInfo.componentStack}
                                            </pre>
                                        </div>
                                    )}
                                </div>
                            )}
                        </div>
                    )}

                    <div className="mt-6 p-4 bg-muted/50 rounded-xl">
                        <p className="text-sm text-muted-foreground">
                            Nếu vấn đề vẫn tiếp tục, vui lòng{' '}
                            <Link to="/lien-he" className="text-primary hover:underline">
                                liên hệ hỗ trợ
                            </Link>
                            {' '}hoặc báo cáo lỗi.
                        </p>
                    </div>
                </CardContent>
            </Card>
        </div>
    );
};