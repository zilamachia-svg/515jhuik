import { useState, useMemo } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Product } from '../types';
import { ProductItem } from './ProductItem';
import { Button } from '@/components/ui/button';
import { Spinner } from '@/components/ui/spinner';

interface ProductGridProps {
    products: Product[];
    onBuy: (product: Product, quantity?: number) => void;
    onViewDetails: (product: Product) => void;
    itemsPerRow?: {
        mobile: number;
        tablet: number;
        desktop: number;
        large: number;
    };
    maxRows?: number; // Giới hạn số hàng hiển thị ban đầu
}

const DEFAULT_ITEMS_PER_ROW = {
    mobile: 1,      // 1 sản phẩm/hàng trên mobile
    tablet: 2,      // 2 sản phẩm/hàng trên tablet
    desktop: 3,     // 3 sản phẩm/hàng trên desktop
    large: 4,       // 4 sản phẩm/hàng trên large screen
};

const DEFAULT_MAX_ROWS = 3; // Hiển thị tối đa 3 hàng ban đầu

// Optimize: Move animation variants outside component to avoid recreating on every render
const itemVariants = {
    initial: { opacity: 0, y: 20 },
    animate: { opacity: 1, y: 0 },
    exit: { opacity: 0, y: -20 }
};

export const ProductGrid = ({ 
    products, 
    onBuy, 
    onViewDetails,
    itemsPerRow = DEFAULT_ITEMS_PER_ROW,
    maxRows = DEFAULT_MAX_ROWS
}: ProductGridProps) => {
    const [showAll, setShowAll] = useState(false);
    
    // Optimize: Memoize calculated values
    const { displayedProducts, hasMore, remainingCount } = useMemo(() => {
        const initialItemsCount = itemsPerRow.desktop * maxRows;
        return {
            displayedProducts: showAll ? products : products.slice(0, initialItemsCount),
            hasMore: products.length > initialItemsCount,
            remainingCount: products.length - initialItemsCount
        };
    }, [products, showAll, itemsPerRow.desktop, maxRows]);

    return (
        <div className="space-y-4">
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-3 sm:gap-4 pt-4 pb-2">
                <AnimatePresence mode="wait">
                    {displayedProducts.map((product, index) => (
                        <motion.div
                            key={product.id}
                            variants={itemVariants}
                            initial="initial"
                            animate="animate"
                            exit="exit"
                            transition={{ 
                                duration: 0.3, 
                                // Optimize: Cap animation delay for better performance with many items
                                delay: Math.min(index * 0.05, 0.5) 
                            }}
                            whileHover={{ scale: 1.02, y: -5 }}
                            whileTap={{ scale: 0.98 }}
                        >
                            <ProductItem
                                product={product}
                                onBuy={onBuy}
                                onViewDetails={onViewDetails}
                            />
                        </motion.div>
                    ))}
                </AnimatePresence>
            </div>
            
            {hasMore && !showAll && (
                <div className="flex justify-center pt-2">
                    <Button
                        variant="outline"
                        onClick={() => setShowAll(true)}
                        className="rounded-full"
                    >
                        Xem thêm {remainingCount} sản phẩm
                    </Button>
                </div>
            )}
            
            {showAll && hasMore && (
                <div className="flex justify-center pt-2">
                    <Button
                        variant="ghost"
                        onClick={() => setShowAll(false)}
                        className="rounded-full"
                    >
                        Thu gọn
                    </Button>
                </div>
            )}
        </div>
    );
};

