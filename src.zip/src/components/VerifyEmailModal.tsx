import { useState } from 'react';
import { toast } from 'sonner';
import { formatApiErrorForToast } from '../utils';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { ApiError } from '../types';
import { MailWarning } from 'lucide-react';
import { Spinner } from './ui/spinner';
import { resendVerification } from '../services/authService';

type VerifyEmailModalProps = {
    onClose: () => void;
};

export const VerifyEmailModal = ({ onClose }: VerifyEmailModalProps) => {
    const [isLoading, setIsLoading] = useState(false);

    const handleResend = async () => {
        setIsLoading(true);
        try {
            await resendVerification();
            toast.success('Email xác thực đã được gửi lại. Vui lòng kiểm tra hộp thư của bạn.');
            onClose();
        } catch (error) {
            toast.error(formatApiErrorForToast(error as ApiError, 'Gửi lại email thất bại.'));
        } finally {
            setIsLoading(false);
        }
    };

    return (
        <Dialog open={true} onOpenChange={onClose}>
            <DialogContent>
                <DialogHeader>
                    <DialogTitle>Xác thực địa chỉ Email</DialogTitle>
                </DialogHeader>
                <div className="py-4 text-center space-y-4">
                    <MailWarning className="mx-auto h-12 w-12 text-yellow-500" />
                    <h4 className="font-semibold">Vui lòng xác thực email của bạn</h4>
                    <p className="text-sm text-muted-foreground">
                        Một liên kết xác thực đã được gửi đến địa chỉ email của bạn khi đăng ký.
                        Vui lòng kiểm tra hộp thư (cả mục spam) và nhấp vào liên kết để kích hoạt đầy đủ chức năng của tài khoản.
                    </p>
                    <p className="text-sm text-muted-foreground">
                        Nếu bạn không nhận được email, hãy nhấp vào nút bên dưới để gửi lại.
                    </p>
                </div>
                <DialogFooter>
                    <Button variant="outline" onClick={onClose} disabled={isLoading}>
                        Để sau
                    </Button>
                    <Button onClick={handleResend} disabled={isLoading}>
                        {isLoading && <Spinner className="mr-2 h-4 w-4 animate-spin" />}
                        Gửi lại Email
                    </Button>
                </DialogFooter>
            </DialogContent>
        </Dialog>
    );
};