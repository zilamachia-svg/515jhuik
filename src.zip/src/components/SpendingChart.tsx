import React from 'react';
import { Bar, BarChart, CartesianGrid, ResponsiveContainer, Tooltip, XAxis, YAxis } from 'recharts';
import { formatCurrency } from '../utils';

type SpendingData = {
    day: string;
    amount: number;
};

type SpendingChartProps = {
    data: SpendingData[];
};

const CustomTooltip = ({ active, payload, label }: any) => {
    if (active && payload && payload.length) {
      return (
        <div className="p-2 text-sm bg-background/90 border border-border rounded-lg shadow-lg">
          <p className="font-bold text-white">{label}</p>
          <p className="text-primary font-semibold">{`Doanh thu: ${formatCurrency(payload[0].value)}`}</p>
        </div>
      );
    }
    return null;
};

export const SpendingChart = React.memo(({ data }: SpendingChartProps) => {
    if (!data || data.length === 0) {
        return <div className="flex items-center justify-center h-64 text-muted-foreground">Không có dữ liệu chi tiêu.</div>;
    }

    return (
        <ResponsiveContainer width="100%" height={300}>
            <BarChart data={data} margin={{ top: 5, right: 20, left: 10, bottom: 5 }}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} />
                <XAxis 
                    dataKey="day" 
                    tickLine={false} 
                    axisLine={false}
                    stroke="hsl(0 0% 95%)"
                    fontSize={14}
                    fontWeight={600}
                />
                <YAxis 
                    tickFormatter={(value) => new Intl.NumberFormat('vi-VN', { notation: 'compact' }).format(value as number)} 
                    tickLine={false} 
                    axisLine={false} 
                    width={60}
                    stroke="hsl(0 0% 95%)"
                    fontSize={14}
                    fontWeight={600}
                />
                <Tooltip
                    cursor={{ fill: 'hsl(var(--accent))' }}
                    content={<CustomTooltip />}
                />
                <Bar dataKey="amount" fill="hsl(var(--primary))" radius={[4, 4, 0, 0]} />
            </BarChart>
        </ResponsiveContainer>
    );
});

SpendingChart.displayName = 'SpendingChart';
