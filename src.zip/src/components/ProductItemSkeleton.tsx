import { Card, CardContent, CardFooter } from "./ui/card";
import { Skeleton } from "./ui/skeleton";

export const ProductItemSkeleton = () => {
    return (
        <Card className="flex flex-col h-full overflow-hidden">
            <div className="relative aspect-video w-full flex flex-col items-center justify-center p-4">
                <Skeleton className="h-10 w-10 mb-2 rounded-full" />
                <Skeleton className="h-5 w-3/4" />
            </div>
            
            <CardContent className="p-4 flex-1">
                <Skeleton className="h-4 w-full" />
                <Skeleton className="h-4 w-2/3 mt-2" />
                <div className="flex justify-between items-center mt-4">
                    <Skeleton className="h-6 w-16 rounded-full" />
                    <Skeleton className="h-7 w-24" />
                </div>
            </CardContent>
            <CardFooter className="p-4 pt-0 grid grid-cols-2 gap-2">
                <Skeleton className="h-10 w-full" />
                <Skeleton className="h-10 w-full" />
            </CardFooter>
        </Card>
    );
};
