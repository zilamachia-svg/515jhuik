import React, { useState, useEffect } from 'react';
import { toast } from 'sonner';
import { Product } from '../types';
import { useUser } from '../services/UserContext';
import { formatCurrency } from '../utils';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { useLanguage } from '../contexts/LanguageContext';
// FIX: Import the consistent Spinner component from the UI library.
import { Spinner } from '@/components/ui/spinner';

type PurchaseModalProps = {
    product: Product;
    initialQuantity?: number;
    onClose: () => void;
    onConfirm: (quantity: number) => void;
    isProcessing: boolean;
};

export const PurchaseModal = ({ product, initialQuantity = 1, onClose, onConfirm, isProcessing }: PurchaseModalProps) => {
    const { t } = useLanguage();
    const { user } = useUser();
    const [quantity, setQuantity] = useState(initialQuantity);
    const totalPrice = product.price * quantity;
    const balanceIsSufficient = user ? user.balance >= totalPrice : false;

    useEffect(() => {
        if (product.stock > 0) {
            setQuantity(Math.min(initialQuantity, product.stock));
        } else {
            setQuantity(0);
        }
    }, [product.id, product.stock, initialQuantity]);

    const handleQuantityChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        let value = parseInt(e.target.value, 10);
        if (isNaN(value) || value < 1) {
            value = 1;
        }
        if (value > product.stock) {
            value = product.stock;
            toast.warning(t('purchase.errors.notEnoughStock', { stock: product.stock.toLocaleString('vi-VN') }));
        }
        setQuantity(value);
    };
    
    const handleConfirm = () => {
        if (quantity <= 0) {
            toast.error(t('purchase.errors.invalidQuantity'));
            return;
        }
        if (!balanceIsSufficient) {
            toast.error(t('purchase.errors.insufficientFunds'));
            return;
        }
        if (quantity > product.stock) {
            toast.error(t('purchase.errors.notEnoughStock', { stock: product.stock.toLocaleString('vi-VN') }));
            return;
        }
        onConfirm(quantity);
    };

    return (
        <Dialog open={true} onOpenChange={onClose}>
            <DialogContent>
                <DialogHeader>
                    <DialogTitle>{t('purchase.title', {defaultValue: 'Xác nhận mua hàng'})}</DialogTitle>
                </DialogHeader>
                <div className="space-y-4 py-4">
                    <div className="p-4 bg-muted rounded-lg">
                        <h4 className="font-semibold">{product.name}</h4>
                        <p>{t('purchase.price', {defaultValue: 'Đơn giá'})}: <span className="font-medium text-primary">{formatCurrency(product.price)}</span></p>
                        <p>{t('purchase.stock', {defaultValue: 'Tồn kho'})}: {product.stock.toLocaleString('vi-VN')}</p>
                    </div>
                    <div className="space-y-2">
                        <Label htmlFor="quantity">{t('purchase.quantity', {defaultValue: 'Số lượng'})}</Label>
                        <Input
                            id="quantity"
                            type="number"
                            value={quantity}
                            onChange={handleQuantityChange}
                            min="1"
                            max={product.stock}
                            disabled={isProcessing || product.stock === 0}
                        />
                    </div>
                    <div className="space-y-2 text-sm">
                        <p className="flex justify-between">{t('purchase.totalPrice', {defaultValue: 'Tổng cộng'})}: <strong className="text-lg text-primary">{formatCurrency(totalPrice)}</strong></p>
                        <p className="flex justify-between">
                            {t('purchase.yourBalance', {defaultValue: 'Số dư của bạn'})}: 
                            <span className={balanceIsSufficient ? 'text-green-500' : 'text-destructive'}>
                                {formatCurrency(user?.balance ?? 0)}
                            </span>
                        </p>
                        {!balanceIsSufficient && <p className="text-destructive text-right">{t('purchase.errors.insufficientFunds', {defaultValue: 'Số dư không đủ.'})}</p>}
                    </div>
                </div>
                <DialogFooter>
                    <Button variant="outline" onClick={onClose} disabled={isProcessing}>
                        {t('common.cancel')}
                    </Button>
                    <Button
                        onClick={handleConfirm}
                        disabled={!balanceIsSufficient || product.stock === 0 || quantity <= 0 || isProcessing}
                    >
                        {isProcessing && <Spinner className="mr-2 h-4 w-4 animate-spin" />}
                        {t('purchase.confirmPurchase')}
                    </Button>
                </DialogFooter>
            </DialogContent>
        </Dialog>
    );
};
