import React from 'react';
import { Document } from '../types';
import { formatCurrency } from '../utils';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardFooter, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { FileText } from 'lucide-react';

type DocumentItemProps = {
    document: Document;
    onBuy: (document: Document) => void;
};

export const DocumentItem: React.FC<DocumentItemProps> = ({ document, onBuy }) => {
    return (
        <Card className="flex flex-col">
            <CardHeader>
                <div className="flex justify-center mb-4">
                    <FileText className="w-12 h-12 text-primary" />
                </div>
                <CardTitle>{document.name}</CardTitle>
                <CardDescription className="line-clamp-3 h-[60px]">{document.description}</CardDescription>
            </CardHeader>
            <CardContent className="flex-grow">
                <div className="text-sm text-muted-foreground">
                    <p>Phiên bản: {document.version}</p>
                    <p>Cập nhật: {new Date(document.releaseDate).toLocaleDateString('vi-VN')}</p>
                </div>
            </CardContent>
            <CardFooter className="flex-col items-stretch gap-4">
                 <div className="text-2xl font-bold text-center text-primary">
                    {formatCurrency(document.price)}
                </div>
                <Button onClick={() => onBuy(document)}>
                    Mua ngay
                </Button>
            </CardFooter>
        </Card>
    );
};
