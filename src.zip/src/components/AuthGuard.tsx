import React from 'react';
import { Navigate, useLocation, Outlet } from 'react-router-dom';
import { useUser } from '../services/UserContext';
import { Spinner } from './ui/spinner';
import { PATHS } from '../constants/paths';

/**
 * AuthGuard - Protects routes that require authentication
 * 
 * This component:
 * 1. Shows a loading spinner while checking authentication status
 * 2. Redirects to login page if user is not authenticated
 * 3. Only renders protected routes when user is authenticated
 * 
 * All routes wrapped by this guard require authentication to access.
 */
export const AuthGuard = () => {
    const { user, isLoading } = useUser();
    const location = useLocation();

    // Show loading spinner while checking authentication
    // This prevents any protected content from rendering during auth check
    if (isLoading) {
        return (
            <div className="fixed inset-0 z-50 flex items-center justify-center bg-background">
                <div className="flex flex-col items-center gap-4">
                    <Spinner className="h-10 w-10" />
                    <p className="text-sm text-muted-foreground">Đang kiểm tra xác thực...</p>
                </div>
            </div>
        );
    }

    // If user is not authenticated, immediately redirect to login
    // This prevents any protected content from being rendered or accessed
    if (!user) {
        // Redirect unauthenticated users to login page
        // Pass the current location so we can redirect back after login.
        // Using 'replace' to prevent back button from going to protected route
        return <Navigate to={PATHS.LOGIN} state={{ from: location }} replace />;
    }

    // User is authenticated - render protected routes
    return <Outlet />;
};