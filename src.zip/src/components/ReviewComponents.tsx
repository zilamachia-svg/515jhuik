/**
 * Review Components
 * Star Rating, Review Form, Review List, Rating Summary
 */

import { useState } from 'react';
import { Star, ThumbsUp, ThumbsDown, CheckCircle, AlertCircle } from 'lucide-react';
import { toast } from 'sonner';
import { reviewsApi, ProductReview, CreateReviewDto } from '../api/features.api';
import { useApi } from '../hooks/useApi';
import { useAuth } from '../hooks/useAuth';
import { Button } from '../components/ui/button';
import { Textarea } from '../components/ui/textarea';
import { Input } from '../components/ui/input';
import { Card, CardContent, CardHeader, CardTitle } from '../components/ui/card';
import { cn } from '../lib/utils';

// ============================================
// STAR RATING COMPONENT
// ============================================

interface StarRatingProps {
  value: number;
  onChange?: (rating: number) => void;
  readonly?: boolean;
  size?: 'sm' | 'md' | 'lg';
  showValue?: boolean;
}

export const StarRating = ({ 
  value, 
  onChange, 
  readonly = false, 
  size = 'md',
  showValue = false 
}: StarRatingProps) => {
  const [hoverRating, setHoverRating] = useState(0);
  
  const sizeClasses = {
    sm: 'w-4 h-4',
    md: 'w-5 h-5',
    lg: 'w-6 h-6'
  };

  const displayRating = hoverRating || value;

  return (
    <div className="flex items-center gap-1">
      {[1, 2, 3, 4, 5].map((star) => (
        <Star
          key={star}
          className={cn(
            sizeClasses[size],
            'transition-colors',
            star <= displayRating ? 'fill-yellow-400 text-yellow-400' : 'text-gray-300',
            !readonly && 'cursor-pointer hover:scale-110'
          )}
          onClick={() => !readonly && onChange?.(star)}
          onMouseEnter={() => !readonly && setHoverRating(star)}
          onMouseLeave={() => !readonly && setHoverRating(0)}
        />
      ))}
      {showValue && (
        <span className="ml-2 text-sm font-medium">{value.toFixed(1)}</span>
      )}
    </div>
  );
};

// ============================================
// REVIEW FORM COMPONENT
// ============================================

interface ReviewFormProps {
  productId: number;
  onSuccess?: () => void;
}

export const ReviewForm = ({ productId, onSuccess }: ReviewFormProps) => {
  const { user } = useAuth();
  const [rating, setRating] = useState(5);
  const [title, setTitle] = useState('');
  const [comment, setComment] = useState('');

  const { execute: submitReview, isLoading } = useApi(reviewsApi.create);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!user) {
      toast.error('Vui lòng đăng nhập để đánh giá');
      return;
    }

    if (comment.trim().length < 10) {
      toast.error('Nội dung đánh giá phải có ít nhất 10 ký tự');
      return;
    }

    try {
      const data: CreateReviewDto = {
        rating,
        title: title.trim() || undefined,
        comment: comment.trim(),
      };

      await submitReview(productId, data);
      toast.success('Đánh giá của bạn đã được gửi và đang chờ duyệt');
      
      // Reset form
      setRating(5);
      setTitle('');
      setComment('');
      
      onSuccess?.();
    } catch (error) {
      toast.error('Không thể gửi đánh giá. Vui lòng thử lại');
    }
  };

  if (!user) {
    return (
      <Card>
        <CardContent className="p-6 text-center">
          <AlertCircle className="w-12 h-12 text-gray-400 mx-auto mb-3" />
          <p className="text-gray-600 dark:text-gray-400 mb-4">
            Vui lòng đăng nhập để đánh giá sản phẩm
          </p>
          <Button>Đăng nhập</Button>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Viết đánh giá của bạn</CardTitle>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-sm font-medium mb-2">
              Đánh giá của bạn
            </label>
            <StarRating value={rating} onChange={setRating} size="lg" />
          </div>

          <div>
            <label className="block text-sm font-medium mb-2">
              Tiêu đề (tùy chọn)
            </label>
            <Input
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="Tóm tắt đánh giá của bạn"
              maxLength={100}
            />
          </div>

          <div>
            <label className="block text-sm font-medium mb-2">
              Nội dung đánh giá <span className="text-red-500">*</span>
            </label>
            <Textarea
              value={comment}
              onChange={(e) => setComment(e.target.value)}
              placeholder="Chia sẻ trải nghiệm của bạn về sản phẩm này..."
              rows={5}
              required
              minLength={10}
            />
            <p className="text-xs text-gray-500 mt-1">
              Tối thiểu 10 ký tự ({comment.length}/10)
            </p>
          </div>

          <Button type="submit" disabled={isLoading || comment.trim().length < 10}>
            {isLoading ? 'Đang gửi...' : 'Gửi đánh giá'}
          </Button>
        </form>
      </CardContent>
    </Card>
  );
};

// ============================================
// REVIEW ITEM COMPONENT
// ============================================

interface ReviewItemProps {
  review: ProductReview;
  onVote?: () => void;
}

export const ReviewItem = ({ review, onVote }: ReviewItemProps) => {
  const { user } = useAuth();
  const { execute: voteHelpful } = useApi(reviewsApi.voteHelpful);
  const { execute: voteUnhelpful } = useApi(reviewsApi.voteUnhelpful);

  const handleVoteHelpful = async () => {
    if (!user) {
      toast.error('Vui lòng đăng nhập để vote');
      return;
    }
    try {
      await voteHelpful(review.id);
      toast.success('Cảm ơn phản hồi của bạn!');
      onVote?.();
    } catch (error) {
      toast.error('Không thể vote');
    }
  };

  const handleVoteUnhelpful = async () => {
    if (!user) {
      toast.error('Vui lòng đăng nhập để vote');
      return;
    }
    try {
      await voteUnhelpful(review.id);
      toast.success('Cảm ơn phản hồi của bạn!');
      onVote?.();
    } catch (error) {
      toast.error('Không thể vote');
    }
  };

  return (
    <div className="border-b border-gray-200 dark:border-gray-700 py-4 last:border-b-0">
      <div className="flex items-start gap-3">
        <div className="flex-shrink-0">
          <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center">
            <span className="text-sm font-semibold text-primary">
              {review.user?.name?.charAt(0).toUpperCase() || 'U'}
            </span>
          </div>
        </div>

        <div className="flex-1">
          <div className="flex items-center gap-2 mb-1">
            <span className="font-semibold">{review.user?.name || 'Người dùng'}</span>
            {review.verified_purchase && (
              <span className="inline-flex items-center gap-1 text-xs bg-green-100 dark:bg-green-900/30 text-green-700 dark:text-green-400 px-2 py-0.5 rounded">
                <CheckCircle className="w-3 h-3" />
                Đã mua
              </span>
            )}
          </div>

          <div className="flex items-center gap-2 mb-2">
            <StarRating value={review.rating} readonly size="sm" />
            <span className="text-xs text-gray-500">
              {new Date(review.created_at).toLocaleDateString('vi-VN')}
            </span>
          </div>

          {review.title && (
            <h4 className="font-semibold mb-1">{review.title}</h4>
          )}

          <p className="text-gray-700 dark:text-gray-300 mb-3">
            {review.comment}
          </p>

          {!review.is_approved && (
            <p className="text-xs text-yellow-600 dark:text-yellow-500 mb-2">
              ⏳ Đánh giá đang chờ duyệt
            </p>
          )}

          <div className="flex items-center gap-4 text-sm">
            <button
              onClick={handleVoteHelpful}
              className="flex items-center gap-1 text-gray-600 dark:text-gray-400 hover:text-green-600 dark:hover:text-green-400 transition-colors"
            >
              <ThumbsUp className="w-4 h-4" />
              <span>Hữu ích ({review.helpful_count})</span>
            </button>
            <button
              onClick={handleVoteUnhelpful}
              className="flex items-center gap-1 text-gray-600 dark:text-gray-400 hover:text-red-600 dark:hover:text-red-400 transition-colors"
            >
              <ThumbsDown className="w-4 h-4" />
              <span>({review.unhelpful_count})</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

// ============================================
// REVIEW LIST COMPONENT
// ============================================

interface ReviewListProps {
  productId: number;
  reviews: ProductReview[];
  isLoading?: boolean;
  onReload?: () => void;
}

export const ReviewList = ({ reviews, isLoading, onReload }: ReviewListProps) => {
  if (isLoading) {
    return (
      <div className="space-y-4">
        {[...Array(3)].map((_, i) => (
          <div key={i} className="animate-pulse">
            <div className="flex gap-3">
              <div className="w-10 h-10 bg-gray-200 dark:bg-gray-700 rounded-full"></div>
              <div className="flex-1">
                <div className="h-4 bg-gray-200 dark:bg-gray-700 rounded w-1/4 mb-2"></div>
                <div className="h-3 bg-gray-200 dark:bg-gray-700 rounded w-full mb-2"></div>
                <div className="h-3 bg-gray-200 dark:bg-gray-700 rounded w-3/4"></div>
              </div>
            </div>
          </div>
        ))}
      </div>
    );
  }

  if (reviews.length === 0) {
    return (
      <div className="text-center py-12">
        <AlertCircle className="w-12 h-12 text-gray-300 dark:text-gray-600 mx-auto mb-3" />
        <p className="text-gray-600 dark:text-gray-400">
          Chưa có đánh giá nào cho sản phẩm này
        </p>
        <p className="text-sm text-gray-500 dark:text-gray-500 mt-1">
          Hãy là người đầu tiên đánh giá!
        </p>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      {reviews.map((review) => (
        <ReviewItem key={review.id} review={review} onVote={onReload} />
      ))}
    </div>
  );
};

// ============================================
// RATING SUMMARY COMPONENT
// ============================================

interface RatingSummaryProps {
  averageRating: number;
  totalReviews: number;
  ratingDistribution?: { [key: string]: number };
}

export const RatingSummary = ({ 
  averageRating, 
  totalReviews, 
  ratingDistribution = {} 
}: RatingSummaryProps) => {
  const getPercentage = (count: number) => {
    if (totalReviews === 0) return 0;
    return (count / totalReviews) * 100;
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle>Đánh giá sản phẩm</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="flex items-center gap-6 mb-6">
          <div className="text-center">
            <div className="text-4xl font-bold mb-2">{averageRating.toFixed(1)}</div>
            <StarRating value={averageRating} readonly />
            <div className="text-sm text-gray-500 mt-1">
              {totalReviews} đánh giá
            </div>
          </div>

          <div className="flex-1 space-y-2">
            {[5, 4, 3, 2, 1].map((star) => {
              const count = ratingDistribution[star] || 0;
              const percentage = getPercentage(count);

              return (
                <div key={star} className="flex items-center gap-2">
                  <span className="text-sm w-8">{star} ⭐</span>
                  <div className="flex-1 h-2 bg-gray-200 dark:bg-gray-700 rounded-full overflow-hidden">
                    <div
                      className="h-full bg-yellow-400 transition-all"
                      style={{ width: `${percentage}%` }}
                    />
                  </div>
                  <span className="text-sm text-gray-500 w-12 text-right">
                    {count}
                  </span>
                </div>
              );
            })}
          </div>
        </div>
      </CardContent>
    </Card>
  );
};
