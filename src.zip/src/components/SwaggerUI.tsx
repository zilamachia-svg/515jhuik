import { useEffect, useRef } from 'react';

const disableSwagger = import.meta.env.VITE_DISABLE_SWAGGER === 'true';

interface SwaggerUIProps {
  spec: object | string;
  url?: string;
}

export const SwaggerUI: React.FC<SwaggerUIProps> = ({ spec, url }) => {
  const swaggerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (disableSwagger) return;
    if (!swaggerRef.current) return;

    // Dynamically import Swagger only when enabled. This import will fail
    // if the package is not installed — we avoid it while disabled.
    let isMounted = true;
    let SwaggerUIBundle: any = null;

    (async () => {
      try {
        // Use computed paths to avoid Vite's static import analysis when the
        // package is intentionally removed during development.
        const bundlePath = 'swagger-ui-dist/swagger-ui-bundle.js';
        const cssPath = 'swagger-ui-dist/swagger-ui.css';

        const mod = await import(/* @vite-ignore */ bundlePath);
        SwaggerUIBundle = (mod as any).default || mod;
        await import(/* @vite-ignore */ cssPath);

        if (!isMounted || !swaggerRef.current) return;

        // Clear previous instance
        swaggerRef.current.innerHTML = '';

        const containerId = 'swagger-ui-container-' + Date.now();
        swaggerRef.current.id = containerId;

        SwaggerUIBundle({
          spec: spec,
          url: url,
          dom_id: '#' + containerId,
          deepLinking: true,
          presets: [
            SwaggerUIBundle.presets.apis,
            SwaggerUIBundle.presets.standalone,
          ],
          plugins: [
            SwaggerUIBundle.plugins.DownloadUrl,
          ],
          layout: 'BaseLayout',
          validatorUrl: null,
          tryItOutEnabled: true,
          supportedSubmitMethods: ['get', 'post', 'put', 'delete', 'patch'],
          docExpansion: 'list',
          filter: true,
          showExtensions: true,
          showCommonExtensions: true,
          requestInterceptor: (request: any) => {
            const apiKey = localStorage.getItem('api_key');
            if (apiKey && request.headers) {
              request.headers['Authorization'] = `Bearer ${apiKey}`;
            }
            return request;
          },
        });
      } catch (err) {
        // If import fails, leave the container empty and log for debugging.
        // In development we intentionally remove the package to avoid vulnerabilities.
        // eslint-disable-next-line no-console
        console.warn('Swagger UI not available:', err);
      }
    })();

    return () => {
      isMounted = false;
      if (swaggerRef.current) {
        swaggerRef.current.innerHTML = '';
      }
    };
  }, [spec, url]);

  if (disableSwagger) {
    return (
      <div className="swagger-ui-wrapper">
        <div className="p-6 text-center text-muted-foreground">API Docs temporarily disabled</div>
      </div>
    );
  }

  return (
    <div className="swagger-ui-wrapper">
      <div ref={swaggerRef} className="swagger-ui-container" />
      <style>{`
        .swagger-ui-wrapper {
          width: 100%;
        }
        .swagger-ui-container {
          width: 100%;
        }
        .swagger-ui .topbar {
          display: none;
        }
        .swagger-ui .info {
          margin: 20px 0;
        }
        .swagger-ui .scheme-container {
          background: hsl(var(--background));
          padding: 10px;
          border-radius: 4px;
        }
        .swagger-ui .btn.authorize {
          background-color: hsl(var(--primary));
          border-color: hsl(var(--primary));
        }
        .swagger-ui .btn.authorize:hover {
          background-color: hsl(var(--primary) / 0.9);
        }
      `}</style>
    </div>
  );
};

