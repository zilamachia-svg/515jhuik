/**
 * Notification Bell Component
 * Display notifications with badge and dropdown
 */

import { useState, useEffect, useRef } from 'react';
import { Bell, Check, Trash2, X } from 'lucide-react';
import { toast } from 'sonner';
import { notificationsApi, Notification } from '../api/features.api';
import { useAuth } from '../hooks/useAuth';
import { Button } from '../components/ui/button';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuTrigger,
} from '../components/ui/dropdown-menu';
import { cn } from '../lib/utils';

export const NotificationBell = () => {
  const { user, isAuthenticated } = useAuth();
  const [notifications, setNotifications] = useState<Notification[]>([]);
  const [unreadCount, setUnreadCount] = useState(0);
  const [isOpen, setIsOpen] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const loadingRef = useRef(false);
  // FIX: Use ReturnType<typeof setInterval> instead of NodeJS.Timeout to allow running in environments without Node types
  const intervalRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const isMountedRef = useRef(true);

  // IMPORTANT: All hooks must be called before any conditional returns
  // This ensures React's Rules of Hooks are followed

  useEffect(() => {
    // Double-check: Don't run if user is not authenticated
    if (!isAuthenticated) {
      // Reset state when user logs out
      setNotifications([]);
      setUnreadCount(0);
      // Clear any existing intervals
      if (intervalRef.current) {
        clearInterval(intervalRef.current);
        intervalRef.current = null;
      }
      return;
    }

    isMountedRef.current = true;

    // Load notifications function - defined inside useEffect to access latest user state
    const loadNotifications = async () => {
      // Don't make request if user is not authenticated
      if (!user || !isAuthenticated || !isMountedRef.current) {
        return;
      }
      
      setIsLoading(true);
      try {
        const response = await notificationsApi.getAll({ per_page: 10 });
        // Handle response: backend returns { success: true, data: PaginatedResponse<Notification> }
        // where PaginatedResponse has { data: Notification[], current_page, last_page, per_page, total }
        if (response.data?.data) {
          const paginatedData = response.data.data;
          // Check if it's a paginated response with nested data array
          if (paginatedData && typeof paginatedData === 'object' && 'data' in paginatedData && Array.isArray(paginatedData.data)) {
            if (isMountedRef.current) setNotifications(paginatedData.data);
          } 
          // Check if it's directly an array (non-paginated)
          else if (Array.isArray(paginatedData)) {
            if (isMountedRef.current) setNotifications(paginatedData);
          } 
          // Fallback: empty array
          else {
            if (isMountedRef.current) setNotifications([]);
          }
        } else {
          if (isMountedRef.current) setNotifications([]);
        }
      } catch (error: any) {
        // Silently fail for 401 (not logged in) - expected behavior
        const status = error.response?.status;
        if (status === 401) {
          // User is not authenticated - silently fail and reset state
          if (isMountedRef.current) {
            setNotifications([]);
            setUnreadCount(0);
          }
          return;
        }
        // Only log other errors
        if (isMountedRef.current) {
          console.error('Failed to load notifications:', error);
        }
      } finally {
        if (isMountedRef.current) {
          setIsLoading(false);
        }
      }
    };

    // Load unread count function - defined inside useEffect to access latest user state
    const loadUnreadCount = async () => {
      // Don't make request if user is not authenticated or already loading
      if (!user || !isAuthenticated || loadingRef.current || !isMountedRef.current) {
        return;
      }
      
      loadingRef.current = true;
      try {
        // Use shorter timeout for unread count (5 seconds)
        const response = await notificationsApi.getUnreadCount({
          timeout: 5000, // 5 second timeout
        });
        if (isMountedRef.current) {
          setUnreadCount(response.data.count || 0);
        }
      } catch (error: any) {
        // Silently fail for expected errors (don't spam console)
        const status = error.response?.status;
        const isUnauthorized = status === 401;
        const isTimeout = error.code === 'ECONNABORTED';
        const isNetworkError = error.code === 'ERR_NETWORK';
        
        // Silently handle: 401 (not logged in), timeout, network errors
        if (isUnauthorized || isTimeout || isNetworkError) {
          // These are expected - user might not be logged in or network issues
          // Reset count on 401
          if (isUnauthorized && isMountedRef.current) {
            setUnreadCount(0);
          }
          return;
        }
        
        // Only log unexpected errors
        if (isMountedRef.current) {
          console.error('Failed to load unread count:', error);
        }
      } finally {
        loadingRef.current = false;
      }
    };

    // Load initial data only if user is authenticated
    const loadInitialData = async () => {
      // Triple-check before making requests
      // Wait a bit to ensure user state is stable
      await new Promise(resolve => setTimeout(resolve, 100));
      
      if (!isMountedRef.current || !user || !isAuthenticated) {
        return;
      }
      
      try {
        await Promise.all([
          loadNotifications(),
          loadUnreadCount()
        ]);
      } catch (error) {
        // Errors are handled in individual functions
        // Just ensure we don't crash the component
      }
    };

    // Only load data if user is authenticated
    if (user && isAuthenticated) {
      loadInitialData();
    }

    // Poll for new notifications every 60 seconds (reduced frequency)
    // Only poll when tab is visible and user is authenticated
    const startPolling = () => {
      // Clear any existing interval first
      if (intervalRef.current) {
        clearInterval(intervalRef.current);
        intervalRef.current = null;
      }
      
      if (document.visibilityState === 'visible' && isMountedRef.current && user && isAuthenticated) {
        intervalRef.current = setInterval(() => {
          if (document.visibilityState === 'visible' && isMountedRef.current && user && isAuthenticated) {
            loadUnreadCount();
          } else {
            // Stop polling if user is no longer authenticated
            if (intervalRef.current) {
              clearInterval(intervalRef.current);
              intervalRef.current = null;
            }
          }
        }, 60000); // 60 seconds
      }
    };

    // Start polling
    startPolling();

    // Reload when tab becomes visible
    const handleVisibilityChange = () => {
      if (document.visibilityState === 'visible' && isMountedRef.current && user && isAuthenticated) {
        loadUnreadCount();
        // Restart polling
        startPolling();
      } else {
        // Stop polling if user is no longer authenticated
        if (intervalRef.current) {
          clearInterval(intervalRef.current);
          intervalRef.current = null;
        }
      }
    };

    document.addEventListener('visibilitychange', handleVisibilityChange);

    return () => {
      isMountedRef.current = false;
      if (intervalRef.current) {
        clearInterval(intervalRef.current);
        intervalRef.current = null;
      }
      document.removeEventListener('visibilitychange', handleVisibilityChange);
      loadingRef.current = false; // Reset loading ref on cleanup
    };
  }, [user, isAuthenticated]);

  const handleMarkAsRead = async (id: number) => {
    try {
      await notificationsApi.markAsRead(id);
      setNotifications(prev => 
        prev.map(n => n.id === id ? { ...n, read_at: new Date().toISOString() } : n)
      );
      setUnreadCount(prev => Math.max(0, prev - 1));
    } catch (error) {
      toast.error('Không thể đánh dấu đã đọc');
    }
  };

  const handleMarkAllAsRead = async () => {
    try {
      await notificationsApi.markAllAsRead();
      setNotifications(prev => 
        prev.map(n => ({ ...n, read_at: new Date().toISOString() }))
      );
      setUnreadCount(0);
      toast.success('Đã đánh dấu tất cả là đã đọc');
    } catch (error) {
      toast.error('Không thể đánh dấu tất cả');
    }
  };

  const handleDelete = async (id: number) => {
    try {
      await notificationsApi.delete(id);
      setNotifications(prev => prev.filter(n => n.id !== id));
      if (notifications.find(n => n.id === id && !n.read_at)) {
        setUnreadCount(prev => Math.max(0, prev - 1));
      }
      toast.success('Đã xóa thông báo');
    } catch (error) {
      toast.error('Không thể xóa thông báo');
    }
  };

  const getNotificationIcon = (type: string) => {
    switch (type) {
      case 'order':
        return '🛒';
      case 'deposit':
        return '💰';
      case 'system':
        return '⚙️';
      default:
        return 'ℹ️';
    }
  };

  // Don't render if user is not authenticated
  // IMPORTANT: This check must be AFTER all hooks are called
  // to follow React's Rules of Hooks
  if (!isAuthenticated) {
    return null;
  }

  return (
    <DropdownMenu open={isOpen} onOpenChange={setIsOpen}>
      <DropdownMenuTrigger asChild>
        <Button 
          variant="ghost" 
          size="icon" 
          className="relative rounded-2xl hover:bg-muted/50 transition-all duration-200"
        >
          <Bell className="h-5 w-5" />
          {unreadCount > 0 && (
            <span className="absolute -right-1 -top-1 flex h-5 w-5 items-center justify-center rounded-full bg-red-500 text-xs font-semibold text-white shadow-lg ring-2 ring-background">
              {unreadCount > 99 ? '99+' : unreadCount}
            </span>
          )}
        </Button>
      </DropdownMenuTrigger>

      <DropdownMenuContent
        align="end"
        className="w-80 max-h-[500px] overflow-hidden rounded-2xl border border-border/50 bg-background/95 backdrop-blur-xl shadow-2xl p-0"
        {...({ onOpenAutoFocus: (e: any) => e.preventDefault() } as any)}
      >
        <div className="sticky top-0 z-10 bg-background/95 backdrop-blur-sm border-b border-border/50 px-4 py-3 flex items-center justify-between rounded-t-2xl">
          <h3 className="font-semibold text-foreground">Thông báo</h3>
          {unreadCount > 0 && (
            <Button
              variant="ghost"
              size="sm"
              onClick={handleMarkAllAsRead}
              className="text-xs h-7 rounded-xl hover:bg-muted"
            >
              Đánh dấu tất cả
            </Button>
          )}
        </div>

        <div className="overflow-y-auto max-h-[400px]">
          {isLoading ? (
            <div className="p-4 space-y-3">
              {[...Array(3)].map((_, i) => (
                <div key={i} className="animate-pulse">
                  <div className="h-4 bg-muted rounded mb-2"></div>
                  <div className="h-3 bg-muted rounded w-2/3"></div>
                </div>
              ))}
            </div>
          ) : notifications.length === 0 ? (
            <div className="p-8 text-center text-muted-foreground">
              <Bell className="w-12 h-12 mx-auto mb-2 opacity-30" />
              <p className="text-sm">Không có thông báo mới</p>
            </div>
          ) : (
            <div className="divide-y divide-border/50">
              {notifications.map((notification) => (
                <div
                  key={notification.id}
                  className={cn(
                    'p-4 hover:bg-muted/50 transition-colors cursor-pointer',
                    !notification.read_at && 'bg-primary/5 dark:bg-primary/10'
                  )}
                >
                <div className="flex gap-3">
                  <div className="flex-shrink-0 text-2xl">
                    {getNotificationIcon(notification.type)}
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-start justify-between gap-2">
                      <h4 className="font-semibold text-sm">{notification.title}</h4>
                      <div className="flex gap-1">
                        {!notification.read_at && (
                          <button
                            onClick={() => handleMarkAsRead(notification.id)}
                            className="text-blue-600 hover:text-blue-700 p-1"
                            title="Đánh dấu đã đọc"
                          >
                            <Check className="w-4 h-4" />
                          </button>
                        )}
                        <button
                          onClick={() => handleDelete(notification.id)}
                          className="text-red-600 hover:text-red-700 p-1"
                          title="Xóa"
                        >
                          <X className="w-4 h-4" />
                        </button>
                      </div>
                    </div>
                    <p className="text-sm text-muted-foreground mt-1 line-clamp-2">
                      {notification.message}
                    </p>
                    <p className="text-xs text-muted-foreground/70 mt-1.5">
                      {new Date(notification.created_at).toLocaleString('vi-VN')}
                    </p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}

        </div>

        {notifications.length > 0 && (
          <div className="sticky bottom-0 border-t border-border/50 bg-background/95 backdrop-blur-sm p-2 rounded-b-2xl">
            <Button variant="ghost" size="sm" className="w-full text-xs rounded-xl hover:bg-muted">
              Xem tất cả thông báo
            </Button>
          </div>
        )}
      </DropdownMenuContent>
    </DropdownMenu>
  );
};

export default NotificationBell;
