import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { toast } from 'sonner';
import { formatApiErrorForToast, getApiValidationErrors } from '../utils';
import { ApiError, User } from '../types';
import * as authService from '../services/authService';

import { Button } from './ui/button';
import { Dialog, DialogContent, DialogTitle } from '@/components/ui/dialog';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Spinner } from './ui/spinner';
import { VisuallyHidden } from '@radix-ui/react-visually-hidden';
import { AuthForm } from './auth/AuthForm';
import { cn } from '@/lib/utils';
import { PATHS } from '../constants/paths';

export type AuthMode = 'login' | 'register' | 'forgot-password';

type AuthModalProps = {
    initialMode?: AuthMode;
    onClose: () => void;
    onLoginSuccess: (user: User) => void;
    onLoginFailure: (email: string, reason: string) => void;
};

export const AuthModal = ({ initialMode = 'login', onClose, onLoginSuccess, onLoginFailure }: AuthModalProps) => {
    const navigate = useNavigate();
    const [mode, setMode] = useState<AuthMode>(initialMode);
    const [isLoading, setIsLoading] = useState(false);
    
    // Form state is managed here and passed down
    const [email, setEmail] = useState('');
    const [name, setName] = useState('');
    const [password, setPassword] = useState('');
    const [rememberMe, setRememberMe] = useState(false);
    const [errors, setErrors] = useState<Record<string, string>>({});
    
    const resetForm = () => {
        setName('');
        setPassword('');
        setRememberMe(false);
        setErrors({});
        setIsLoading(false);
    };

    const switchMode = (newMode: AuthMode) => {
        resetForm();
        setMode(newMode);
    };
    
    const handleLogin = async (e: React.FormEvent) => {
        e.preventDefault();
        
        // Validate inputs
        if (!email.trim()) {
            toast.error('Vui lòng nhập email');
            setErrors({ email: 'Email không được để trống' });
            return;
        }
        if (!password) {
            toast.error('Vui lòng nhập mật khẩu');
            setErrors({ password: 'Mật khẩu không được để trống' });
            return;
        }
        
        setIsLoading(true);
        setErrors({});
        
        try {
            // Trim email and password before sending to avoid validation errors
            const user = await authService.login({ 
                email: email.trim(), 
                password: password.trim(), 
                remember: rememberMe 
            });
            onLoginSuccess(user);
            toast.success('Đăng nhập thành công!');
        } catch (error) {
            const apiError = error as ApiError;
            
            // Lấy validation errors từ response
            const validationErrors = getApiValidationErrors(apiError);
            if (validationErrors) {
                setErrors(validationErrors);
                
                // Hiển thị toast với message lỗi đầu tiên
                const firstError = Object.values(validationErrors)[0];
                if (firstError) {
                    toast.error(firstError, {
                        duration: 5000,
                        description: 'Vui lòng kiểm tra lại thông tin đăng nhập.',
                    });
                }
            } else {
                // Nếu không có validation errors, hiển thị message từ API
                const message = formatApiErrorForToast(apiError, 'Đăng nhập thất bại. Vui lòng thử lại.');
                toast.error(message, {
                    duration: 5000,
                    description: 'Vui lòng kiểm tra lại email và mật khẩu.',
                });
            }
            
            // Track login failure
            onLoginFailure(email, formatApiErrorForToast(apiError));
        } finally {
            setIsLoading(false);
        }
    };
    
    const handleRegister = async (e: React.FormEvent) => {
        e.preventDefault();
        
        // Validate inputs
        if (!name.trim()) {
            toast.error("Vui lòng nhập tên đầy đủ");
            setErrors({ name: 'Tên không được để trống' });
            return;
        }
        if (!email.trim()) {
            toast.error("Vui lòng nhập email");
            setErrors({ email: 'Email không được để trống' });
            return;
        }
        if (password.length < 8) {
            toast.error("Mật khẩu phải ít nhất 8 ký tự");
            setErrors({ password: 'Mật khẩu phải ít nhất 8 ký tự' });
            return;
        }
        
        setIsLoading(true);
        setErrors({});
        try {
            const user = await authService.register({ name, email, password, password_confirmation: password });
            onLoginSuccess(user);
            toast.success('Đăng ký thành công!');
        } catch (error) {
            const validationErrors = getApiValidationErrors(error as ApiError);
            if (validationErrors) {
                setErrors(validationErrors);
                
                // Hiển thị toast với message lỗi đầu tiên
                const firstError = Object.values(validationErrors)[0];
                if (firstError) {
                    toast.error(firstError, {
                        duration: 5000,
                        description: 'Vui lòng kiểm tra lại thông tin bạn đã nhập.',
                    });
                }
            } else {
                const message = formatApiErrorForToast(error as ApiError, 'Đăng ký thất bại. Vui lòng thử lại.');
                toast.error(message);
            }
        } finally {
            setIsLoading(false);
        }
    };
    
    const handleForgotPassword = () => {
        // Đơn giản hóa: Không hỗ trợ quên mật khẩu nữa
        toast.info('Tính năng quên mật khẩu không khả dụng. Vui lòng liên hệ hỗ trợ nếu bạn quên mật khẩu.');
    };


    const renderContent = () => {
        return (
            <AuthForm
                initialTab={mode === 'register' ? 'signup' : 'signin'}
                isLoading={isLoading}
                email={email}
                setEmail={setEmail}
                name={name}
                setName={setName}
                password={password}
                setPassword={setPassword}
                rememberMe={rememberMe}
                setRememberMe={setRememberMe}
                errors={errors}
                onSignIn={handleLogin}
                onSignUp={handleRegister}
                onForgotPassword={handleForgotPassword}
            />
        );
    };
    
    return (
        <Dialog open={true} onOpenChange={onClose}>
            <DialogContent className="bg-transparent border-none shadow-none p-0 max-w-md w-full">
                <VisuallyHidden>
                    <DialogTitle>
                        {mode === 'login' ? 'Đăng nhập' : mode === 'register' ? 'Đăng ký' : 'Xác thực / Quên mật khẩu'}
                    </DialogTitle>
                </VisuallyHidden>
                <div className="bg-card border border-border/50 rounded-2xl shadow-2xl overflow-hidden">
                    {renderContent()}
                </div>
            </DialogContent>
        </Dialog>
    );
};