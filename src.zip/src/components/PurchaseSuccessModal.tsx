import React, { useState, useEffect, useCallback } from 'react';
import { toast } from 'sonner';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { useCopyToClipboard } from '../hooks/useCopyToClipboard';
import { Check, Copy, Download, RefreshCw, AlertTriangle } from 'lucide-react';
import { Textarea } from '@/components/ui/textarea';
import { Spinner } from './ui/spinner';
import apiClient from '../services/apiClient';
import { ApiError } from '../types';
import { formatApiErrorForToast } from '../utils';

type PurchaseSuccessModalProps = {
    orderId: string;
    downloadLink: string;
    onClose: () => void;
};

export const PurchaseSuccessModal = ({ orderId, downloadLink, onClose }: PurchaseSuccessModalProps) => {
    const [copy, isCopied] = useCopyToClipboard();
    const [isLoading, setIsLoading] = useState(true);
    const [error, setError] = useState<string | null>(null);
    const [orderData, setOrderData] = useState<string>('');

    const fetchOrderData = useCallback(async () => {
        setIsLoading(true);
        setError(null);

        try {
            // Use the authenticated apiClient to fetch the order data.
            // The mock adapter will handle this in DEV environments.
            // This ensures the request is secure in a real environment.
            const response = await apiClient.get(downloadLink);

            // The backend should return plain text for this endpoint.
            // Axios places it in response.data.
            const data = typeof response.data === 'string'
                ? response.data
                : JSON.stringify(response.data, null, 2); // Fallback for non-string data
            
            setOrderData(data);
        } catch (e: any) {
            setError(formatApiErrorForToast(e as ApiError, 'Không thể tải dữ liệu đơn hàng. Vui lòng thử lại.'));
        } finally {
            setIsLoading(false);
        }
    }, [downloadLink]);

    useEffect(() => {
        fetchOrderData();
    }, [fetchOrderData]);

    const handleDownloadTxt = () => {
        if (!orderData) return;
        const blob = new Blob([orderData], { type: 'text/plain;charset=utf-8' });
        const url = URL.createObjectURL(blob);
        const link = document.createElement('a');
        link.href = url;
        link.setAttribute('download', `don-hang-${orderId}.txt`);
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
        URL.revokeObjectURL(url);
        toast.success('Đã bắt đầu tải xuống!');
    };
    
    const renderContent = () => {
        if (isLoading) {
            return (
                <div className="flex flex-col items-center justify-center space-y-4 h-48">
                    <Spinner className="h-10 w-10" />
                    <p className="text-muted-foreground">Đang tải dữ liệu đơn hàng...</p>
                </div>
            );
        }

        if (error) {
            return (
                 <div className="flex flex-col items-center justify-center space-y-4 text-center p-4 bg-muted/50 rounded-lg">
                    <AlertTriangle className="h-12 w-12 text-destructive" />
                    <h4 className="font-semibold">Tải dữ liệu thất bại</h4>
                    <p className="text-sm text-muted-foreground">{error}</p>
                    <div className="flex gap-2 pt-2">
                        <Button variant="outline" onClick={fetchOrderData}>
                            <RefreshCw size={16} className="mr-2"/>
                            Thử lại
                        </Button>
                    </div>
                </div>
            );
        }

        return (
            <div className="space-y-4">
                <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
                    <div className="space-y-1">
                        <h4 className="font-semibold">Dữ liệu đơn hàng của bạn</h4>
                        <p className="text-sm text-muted-foreground">Mã đơn hàng: #{orderId}</p>
                    </div>
                    <div className="flex items-center gap-2 flex-shrink-0">
                         <Button variant="outline" size="sm" onClick={() => copy(orderData, 'Đã sao chép toàn bộ dữ liệu!')}>
                            {isCopied ? <Check size={16} className="mr-2" /> : <Copy size={16} className="mr-2" />}
                            Sao chép
                        </Button>
                         <Button variant="default" size="sm" onClick={handleDownloadTxt}>
                            <Download size={16} className="mr-2" />
                            Tải file .txt
                        </Button>
                    </div>
                </div>
                 <Textarea
                    readOnly
                    value={orderData}
                    rows={10}
                    className="font-mono text-xs bg-muted/50 resize-y"
                    placeholder="Không có dữ liệu..."
                 />
            </div>
        );
    };

    return (
        <Dialog open={true} onOpenChange={onClose}>
            <DialogContent className="max-w-2xl">
                <DialogHeader>
                    <DialogTitle>Giao dịch thành công!</DialogTitle>
                </DialogHeader>
                <div className="py-4">
                    {renderContent()}
                </div>
                <DialogFooter>
                    <Button onClick={onClose} className="w-full sm:w-auto">
                        Đóng
                    </Button>
                </DialogFooter>
            </DialogContent>
        </Dialog>
    );
};