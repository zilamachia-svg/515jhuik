import React, { useState, useEffect } from 'react';
import { toast } from 'sonner';
import { Post, ApiError } from '../../types';
import apiClient from '../../services/apiClient';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { formatApiErrorForToast, getApiValidationErrors, slugify } from '../../utils';
import RichTextEditor from '../RichTextEditor';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Spinner } from '@/components/ui/spinner';

type EditPostModalProps = {
    post: Post | 'new';
    onClose: () => void;
    onSave: () => void;
};

// Based on the Post type, but excluding server-generated fields for a creation payload
const emptyPost: Omit<Post, 'id' | 'authorName' | 'createdAt' | 'updatedAt'> = {
    title: '',
    slug: '',
    content: '',
    status: 'draft',
};

export const EditPostModal = ({ post, onClose, onSave }: EditPostModalProps) => {
    const isNew = post === 'new';
    const [formData, setFormData] = useState(() => isNew ? emptyPost : { title: post.title, slug: post.slug, content: post.content, status: post.status });
    const [isLoading, setIsLoading] = useState(false);
    const [errors, setErrors] = useState<Record<string, string>>({});
    const [isSlugManuallyEdited, setIsSlugManuallyEdited] = useState(!isNew);
    
    // Reset form when switching between new/edit
    useEffect(() => {
        if (isNew) {
            setFormData(emptyPost);
            setIsSlugManuallyEdited(false);
            setErrors({});
        } else {
            setFormData({ title: post.title, slug: post.slug, content: post.content, status: post.status });
            setIsSlugManuallyEdited(true);
        }
    }, [post, isNew]);

    useEffect(() => {
        if (!isSlugManuallyEdited) {
            setFormData(prev => ({ ...prev, slug: slugify(prev.title) }));
        }
    }, [formData.title, isSlugManuallyEdited]);


    const handleFormChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        const { name, value } = e.target;
        setFormData(prev => ({ ...prev, [name]: value }));
    };
    
    const handleSlugChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        setIsSlugManuallyEdited(true);
        // Slugify the input as the user types to ensure it's always URL-friendly
        setFormData(prev => ({ ...prev, slug: slugify(e.target.value) }));
    };

    const handleSelectChange = (value: 'published' | 'draft') => {
        setFormData(prev => ({ ...prev, status: value }));
    };

    const handleContentChange = (content: string) => {
        setFormData(prev => ({ ...prev, content }));
    };

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        setIsLoading(true);
        setErrors({});
        try {
            if (isNew) {
                await apiClient.post('/admin/posts', formData);
                toast.success('Thêm bài viết thành công!');
            } else {
                await apiClient.put(`/admin/posts/${(post as Post).id}`, formData);
                toast.success('Cập nhật bài viết thành công!');
            }
            onSave();
            // Reset form after successful save if it was a new post
            if (isNew) {
                setFormData(emptyPost);
                setIsSlugManuallyEdited(false);
                setErrors({});
            }
        } catch (error: any) {
            const validationErrors = getApiValidationErrors(error as ApiError);
            if (validationErrors) {
                setErrors(validationErrors);
            } else {
                toast.error(formatApiErrorForToast(error, 'Thao tác thất bại.'));
            }
        } finally {
            setIsLoading(false);
        }
    };

    return (
        <Dialog open={true} onOpenChange={onClose}>
            <DialogContent className="max-w-3xl">
                <DialogHeader>
                    <DialogTitle>{isNew ? 'Viết bài mới' : `Sửa bài viết: ${post.title}`}</DialogTitle>
                </DialogHeader>
                <form id="post-form" onSubmit={handleSubmit} className="space-y-4 py-4">
                    <div className="space-y-2">
                        <Label htmlFor="title">Tiêu đề</Label>
                        <Input id="title" name="title" type="text" value={formData.title} onChange={handleFormChange} required aria-invalid={!!errors.title} />
                        {errors.title && <small className="text-destructive text-sm">{errors.title}</small>}
                    </div>
                     <div className="space-y-2">
                        <Label htmlFor="slug">Đường dẫn (slug)</Label>
                        <Input id="slug" name="slug" type="text" value={formData.slug} onChange={handleSlugChange} required aria-invalid={!!errors.slug} />
                        <p className="text-sm text-muted-foreground">URL thân thiện cho bài viết. Sẽ được tự động tạo từ tiêu đề.</p>
                        {errors.slug && <small className="text-destructive text-sm">{errors.slug}</small>}
                    </div>
                    <div className="space-y-2">
                        <Label htmlFor="content">Nội dung (hỗ trợ Markdown)</Label>
                        <RichTextEditor
                            value={formData.content}
                            onChange={handleContentChange}
                        />
                        {errors.content && <small className="text-destructive text-sm">{errors.content}</small>}
                    </div>
                    <div className="space-y-2">
                        <Label htmlFor="status">Trạng thái</Label>
                        <Select name="status" value={formData.status} onValueChange={handleSelectChange} required>
                            <SelectTrigger id="status">
                                <SelectValue placeholder="Chọn trạng thái" />
                            </SelectTrigger>
                            <SelectContent>
                                <SelectItem value="draft">Bản nháp</SelectItem>
                                <SelectItem value="published">Xuất bản</SelectItem>
                            </SelectContent>
                        </Select>
                    </div>
                </form>
                <DialogFooter>
                    <Button variant="outline" onClick={onClose} disabled={isLoading}>Hủy</Button>
                    <Button type="submit" form="post-form" disabled={isLoading}>
                        {isLoading && <Spinner className="mr-2 h-4 w-4 animate-spin" />}
                        Lưu
                    </Button>
                </DialogFooter>
            </DialogContent>
        </Dialog>
    );
};