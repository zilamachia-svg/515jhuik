import { useState, useEffect } from 'react';
import { toast } from 'sonner';
import { Order, ApiError } from '../../types';
import apiClient from '../../services/apiClient';
import { formatCurrency, formatApiErrorForToast } from '../../utils';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogDescription } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Spinner } from '@/components/ui/spinner';
import { Textarea } from '@/components/ui/textarea';

type OrderDetailModalProps = {
    order: Order;
    onClose: () => void;
};

export const OrderDetailModal = ({ order, onClose }: OrderDetailModalProps) => {
    const [details, setDetails] = useState<Order | null>(null);
    const [isLoading, setIsLoading] = useState(true);

    useEffect(() => {
        const fetchDetails = async () => {
            setIsLoading(true);
            try {
                const response = await apiClient.get(`/admin/orders/${order.id}`);
                setDetails(response.data.order);
            } catch (error) {
                toast.error(formatApiErrorForToast(error as ApiError, 'Không thể tải chi tiết đơn hàng.'));
            } finally {
                setIsLoading(false);
            }
        };
        fetchDetails();
    }, [order.id]);

    const purchasedItemsText = details?.items?.map(item => item.data).join('\n') || '';

    return (
        <Dialog open={true} onOpenChange={onClose}>
            <DialogContent className="max-w-lg">
                <DialogHeader>
                    <DialogTitle>Chi tiết đơn hàng #{order.id}</DialogTitle>
                    <DialogDescription>
                        {order.productName} - {order.userEmail}
                    </DialogDescription>
                </DialogHeader>
                {isLoading ? (
                    <div className="flex justify-center py-8"><Spinner /></div>
                ) : details ? (
                    <div className="space-y-4 py-4">
                        <div className="grid grid-cols-2 gap-2 text-sm">
                            <p><strong>Số lượng:</strong> {details.quantity}</p>
                            <p><strong>Tổng tiền:</strong> {formatCurrency(details.totalPrice)}</p>
                            <p><strong>Ngày mua:</strong> {new Date(details.purchaseDate).toLocaleString('vi-VN')}</p>
                            <p><strong>Trạng thái:</strong> {details.status}</p>
                        </div>
                        <div>
                             <h4 className="font-semibold mb-2">Dữ liệu đã mua</h4>
                             <Textarea
                                readOnly
                                value={purchasedItemsText}
                                rows={10}
                                className="font-mono text-xs"
                             />
                        </div>
                    </div>
                ) : (
                    <p>Không có dữ liệu chi tiết.</p>
                )}
                <DialogFooter>
                    <Button variant="outline" onClick={onClose}>Đóng</Button>
                </DialogFooter>
            </DialogContent>
        </Dialog>
    );
};