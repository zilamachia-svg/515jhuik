import React, { useState, useEffect } from 'react';
import { toast } from 'sonner';
import { Faq, ApiError } from '../../types';
import apiClient from '../../services/apiClient';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { formatApiErrorForToast, getApiValidationErrors } from '../../utils';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Spinner } from '@/components/ui/spinner';

type EditFaqModalProps = {
    faq: Faq | 'new';
    onClose: () => void;
    onSave: () => void;
};

const emptyFaq: Omit<Faq, 'id'> = {
    question: '',
    answer: '',
    is_active: true,
    order: 0,
};

export const EditFaqModal = ({ faq, onClose, onSave }: EditFaqModalProps) => {
    const isNew = faq === 'new';
    const [formData, setFormData] = useState(() => isNew ? emptyFaq : { ...faq });
    const [isLoading, setIsLoading] = useState(false);
    const [errors, setErrors] = useState<Record<string, string>>({});
    
    // Reset form when switching between new/edit
    useEffect(() => {
        if (isNew) {
            setFormData(emptyFaq);
            setErrors({});
        } else {
            setFormData({ ...faq });
        }
    }, [faq, isNew]);

    const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
        const { name, value } = e.target;
        setFormData(prev => ({ ...prev, [name]: name === 'order' ? parseInt(value, 10) : value }));
    };
    
    const handleToggle = (checked: boolean) => {
        setFormData(prev => ({ ...prev, is_active: checked }));
    };

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        setIsLoading(true);
        setErrors({});
        try {
            if (isNew) {
                await apiClient.post('/admin/faq', formData);
                toast.success('Thêm FAQ thành công!');
            } else {
                await apiClient.put(`/admin/faq/${faq.id}`, formData);
                toast.success('Cập nhật FAQ thành công!');
            }
            onSave();
            // Reset form after successful save if it was a new FAQ
            if (isNew) {
                setFormData(emptyFaq);
                setErrors({});
            }
        } catch (error) {
            const validationErrors = getApiValidationErrors(error as ApiError);
            if (validationErrors) {
                setErrors(validationErrors);
            } else {
                toast.error(formatApiErrorForToast(error as ApiError, 'Lưu FAQ thất bại.'));
            }
        } finally {
            setIsLoading(false);
        }
    };
    
    return (
        <Dialog open={true} onOpenChange={onClose}>
            <DialogContent>
                <DialogHeader>
                    <DialogTitle>{isNew ? 'Thêm FAQ mới' : 'Sửa FAQ'}</DialogTitle>
                </DialogHeader>
                <form id="faq-form" onSubmit={handleSubmit} className="space-y-4 py-4">
                    <div className="space-y-2">
                        <Label htmlFor="question">Câu hỏi</Label>
                        <Input id="question" name="question" type="text" value={formData.question} onChange={handleChange} required aria-invalid={!!errors.question} />
                        {errors.question && <small className="text-destructive text-sm">{errors.question}</small>}
                    </div>
                    <div className="space-y-2">
                        <Label htmlFor="answer">Câu trả lời</Label>
                        <Textarea id="answer" name="answer" value={formData.answer} onChange={handleChange} rows={5} required aria-invalid={!!errors.answer} />
                        {errors.answer && <small className="text-destructive text-sm">{errors.answer}</small>}
                    </div>
                    <div className="space-y-2">
                        <Label htmlFor="order">Thứ tự</Label>
                        <Input id="order" name="order" type="number" value={formData.order} onChange={handleChange} required min="0" aria-invalid={!!errors.order} />
                        {errors.order && <small className="text-destructive text-sm">{errors.order}</small>}
                    </div>
                    <div className="flex items-center space-x-2">
                        <Switch id="is_active" checked={formData.is_active} onCheckedChange={handleToggle} />
                        <Label htmlFor="is_active">{formData.is_active ? 'Công khai' : 'Ẩn'}</Label>
                    </div>
                </form>
                 <DialogFooter>
                    <Button variant="outline" onClick={onClose} disabled={isLoading}>Hủy</Button>
                    <Button type="submit" form="faq-form" disabled={isLoading}>
                        {isLoading && <Spinner className="mr-2 h-4 w-4 animate-spin" />}
                        Lưu
                    </Button>
                </DialogFooter>
            </DialogContent>
        </Dialog>
    );
};