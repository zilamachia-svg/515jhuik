import React, { useState } from 'react';
import { toast } from 'sonner';
import { User, ApiError } from '../../types';
import apiClient from '../../services/apiClient';
import { formatApiErrorForToast, getApiValidationErrors } from '../../utils';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogDescription } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';

type EditUserModalProps = {
    user: User;
    onClose: () => void;
    onSave: () => void;
};

export const EditUserModal = ({ user, onClose, onSave }: EditUserModalProps) => {
    const [formData, setFormData] = useState({
        name: user.name,
        email: user.email,
        balance: user.balance,
        role: user.role,
    });
    const [isLoading, setIsLoading] = useState(false);
    const [errors, setErrors] = useState<Record<string, string>>({});

    const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        const { name, value } = e.target;
        setFormData(prev => ({ ...prev, [name]: name === 'balance' ? Number(value) : value }));
    };

    const handleSelectChange = (name: 'role') => (value: string) => {
         setFormData(prev => ({ ...prev, [name]: value as 'user' | 'admin' }));
    }
    
    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        setIsLoading(true);
        setErrors({});
        try {
            await apiClient.put(`/admin/users/${user.id}`, formData);
            toast.success('Cập nhật người dùng thành công!');
            onSave();
        } catch (error) {
            const validationErrors = getApiValidationErrors(error as ApiError);
            if (validationErrors) {
                setErrors(validationErrors);
            } else {
                toast.error(formatApiErrorForToast(error as ApiError, 'Cập nhật thất bại.'));
            }
        } finally {
            setIsLoading(false);
        }
    };

    return (
        <Dialog open={true} onOpenChange={onClose}>
            <DialogContent>
                <DialogHeader>
                    <DialogTitle>Chỉnh sửa người dùng</DialogTitle>
                    <DialogDescription>{user.name}</DialogDescription>
                </DialogHeader>
                 <form id="edit-user-form" onSubmit={handleSubmit} className="space-y-4 py-4">
                    <div className="space-y-2">
                        <Label htmlFor="name">Tên</Label>
                        <Input id="name" name="name" value={formData.name} onChange={handleChange} required aria-invalid={!!errors.name} />
                        {errors.name && <small className="text-destructive text-sm">{errors.name}</small>}
                    </div>
                    <div className="space-y-2">
                        <Label htmlFor="email">Email</Label>
                        <Input id="email" name="email" type="email" value={formData.email} onChange={handleChange} required aria-invalid={!!errors.email} />
                        {errors.email && <small className="text-destructive text-sm">{errors.email}</small>}
                    </div>
                    <div className="space-y-2">
                        <Label htmlFor="balance">Số dư</Label>
                        <Input id="balance" name="balance" type="number" value={formData.balance} onChange={handleChange} required aria-invalid={!!errors.balance} />
                        {errors.balance && <small className="text-destructive text-sm">{errors.balance}</small>}
                    </div>
                    <div className="space-y-2">
                        <Label htmlFor="role">Quyền</Label>
                        <Select name="role" value={formData.role} onValueChange={handleSelectChange('role')}>
                            <SelectTrigger id="role" aria-invalid={!!errors.role}>
                                <SelectValue placeholder="Chọn quyền" />
                            </SelectTrigger>
                            <SelectContent>
                                <SelectItem value="user">User</SelectItem>
                                <SelectItem value="admin">Admin</SelectItem>
                            </SelectContent>
                        </Select>
                        {errors.role && <small className="text-destructive text-sm">{errors.role}</small>}
                    </div>
                </form>
                <DialogFooter>
                    <Button variant="outline" onClick={onClose} disabled={isLoading}>Hủy</Button>
                    <Button type="submit" form="edit-user-form" disabled={isLoading}>
                        Lưu thay đổi
                    </Button>
                </DialogFooter>
            </DialogContent>
        </Dialog>
    );
};