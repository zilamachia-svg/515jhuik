import React, { useState, useEffect } from 'react';
import { toast } from 'sonner';
import { Product, ProductCategory, ApiError } from '../../types';
import apiClient from '../../services/apiClient';
import { formatApiErrorForToast, getApiValidationErrors } from '../../utils';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Spinner } from '@/components/ui/spinner';
import { Checkbox } from '@/components/ui/checkbox';
import RichTextEditor from '../RichTextEditor';
import { ImageUpload } from '../ImageUpload';

type EditProductModalProps = {
    product: Product | 'new';
    onClose: () => void;
    onSave: () => void;
};

const emptyProduct: Omit<Product, 'id' | 'imageUrl'> = {
    name: '',
    description: '',
    price: 0,
    stock: 0,
    country: 'US',
    category: '',
};

interface FormData {
    name: string;
    description: string;
    price: number;
    stock: number;
    country: string;
    category: string;
    imageUrl?: string;
    status?: string;
    usePromotionalMoney?: boolean;
}

export const EditProductModal = ({ product, onClose, onSave }: EditProductModalProps) => {
    const isNew = product === 'new';
    const initialData: FormData = isNew ? {
        ...emptyProduct,
        status: 'Hiện',
        usePromotionalMoney: false,
    } : {
        name: product.name,
        description: product.description || '',
        price: product.price,
        stock: product.stock,
        country: product.country || 'US',
        category: product.category,
        imageUrl: product.imageUrl,
        status: 'Hiện',
        usePromotionalMoney: false,
    };
    const [formData, setFormData] = useState<FormData>(initialData);
    const [logoUrl, setLogoUrl] = useState<string>(product !== 'new' && product.imageUrl ? product.imageUrl : '');
    
    // Reset form when switching between new/edit
    useEffect(() => {
        if (isNew) {
            setFormData({
                ...emptyProduct,
                status: 'Hiện',
                usePromotionalMoney: false,
            });
            setLogoUrl('');
        } else {
            setFormData({
                name: product.name,
                description: product.description || '',
                price: product.price,
                stock: product.stock,
                country: product.country || 'US',
                category: product.category,
                imageUrl: product.imageUrl,
                status: 'Hiện',
                usePromotionalMoney: false,
            });
            setLogoUrl(product.imageUrl || '');
        }
    }, [product, isNew]);
    const [categories, setCategories] = useState<ProductCategory[]>([]);
    const [isLoading, setIsLoading] = useState(false);
    const [errors, setErrors] = useState<Record<string, string>>({});

    useEffect(() => {
        // Fetch categories for the dropdown
        apiClient.get('/admin/product-categories')
            .then(res => {
                const fetchedCategories = res.data.categories;
                setCategories(fetchedCategories);
                if (isNew && fetchedCategories.length > 0) {
                    // Set default category for new products
                    setFormData(prev => ({ ...prev, category: fetchedCategories[0].name }));
                } else if (!isNew) {
                    // Ensure the existing product's category is set
                    setFormData(prev => ({ ...prev, category: product.category }));
                }
            })
            .catch(() => toast.error('Could not load product categories.'));
    }, [isNew, product]);

    const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
        const { name, value, type } = e.target;
        if (type === 'checkbox') {
            const checked = (e.target as HTMLInputElement).checked;
            setFormData(prev => ({ ...prev, [name]: checked }));
        } else {
            setFormData(prev => ({ ...prev, [name]: name === 'price' || name === 'stock' ? Number(value) : value }));
        }
    };

    const handleDescriptionChange = (value: string) => {
        setFormData(prev => ({ ...prev, description: value }));
    };

    const handleSelectChange = (value: string) => {
        setFormData(prev => ({ ...prev, category: value }));
    };

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        setIsLoading(true);
        setErrors({});
        try {
            // Validate required fields
            if (!formData.name.trim()) {
                setErrors({ name: 'Tên tài khoản là bắt buộc' });
                setIsLoading(false);
                return;
            }
            if (!formData.category) {
                setErrors({ category: 'Danh mục là bắt buộc' });
                setIsLoading(false);
                return;
            }
            
            const submitData = {
                name: formData.name.trim(),
                description: formData.description.trim(),
                price: Number(formData.price) || 0,
                stock: Number(formData.stock) || 0,
                country: formData.country || 'US',
                category: formData.category,
                imageUrl: logoUrl || formData.imageUrl || '',
            };
            
            if (isNew) {
                await apiClient.post('/admin/products', submitData);
                toast.success('Thêm sản phẩm thành công!');
            } else {
                await apiClient.put(`/admin/products/${product.id}`, submitData);
                toast.success('Cập nhật sản phẩm thành công!');
            }
            onSave();
            onClose();
            // Reset form after successful save if it was a new product
            if (isNew) {
                setFormData({
                    ...emptyProduct,
                    status: 'Hiện',
                    usePromotionalMoney: false,
                });
                setLogoUrl('');
                setErrors({});
            }
        } catch (error) {
            const validationErrors = getApiValidationErrors(error as ApiError);
            if (validationErrors) {
                setErrors(validationErrors);
            } else {
                toast.error(formatApiErrorForToast(error as ApiError, 'Lưu sản phẩm thất bại.'));
            }
        } finally {
            setIsLoading(false);
        }
    };

    return (
        <Dialog open={true} onOpenChange={onClose}>
            <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
                <DialogHeader>
                    <DialogTitle>{isNew ? 'Thêm tài khoản' : 'Sửa tài liệu'}</DialogTitle>
                </DialogHeader>
                <form id="product-form" onSubmit={handleSubmit} className="space-y-6 py-4">
                    <div className="grid grid-cols-2 gap-6">
                        {/* Left Column */}
                        <div className="space-y-4">
                            <div className="space-y-2">
                                <Label htmlFor="name">Tên tài khoản*</Label>
                                <Input 
                                    id="name" 
                                    name="name" 
                                    type="text" 
                                    value={formData.name} 
                                    onChange={handleChange} 
                                    placeholder="Tên tài khoản"
                                    required 
                                    aria-invalid={!!errors.name} 
                                />
                                {errors.name && <small className="text-destructive text-sm">{errors.name}</small>}
                            </div>
                            
                            <div className="space-y-2">
                                <Label htmlFor="category">Danh mục*</Label>
                                <Select name="category" value={formData.category} onValueChange={handleSelectChange} required>
                                    <SelectTrigger id="category" aria-invalid={!!errors.category}>
                                        <SelectValue placeholder="-- Chọn danh mục --" />
                                    </SelectTrigger>
                                    <SelectContent>
                                        {categories.map(cat => <SelectItem key={cat.id} value={cat.name}>{cat.name}</SelectItem>)}
                                    </SelectContent>
                                </Select>
                                {errors.category && <small className="text-destructive text-sm">{errors.category}</small>}
                            </div>

                            <div className="space-y-2">
                                <Label htmlFor="price">Giá</Label>
                                <Input 
                                    id="price" 
                                    name="price" 
                                    type="number" 
                                    value={formData.price || 0} 
                                    onChange={handleChange} 
                                    min="0" 
                                    step="1000"
                                    aria-invalid={!!errors.price} 
                                />
                                <p className="text-xs text-muted-foreground">Vui lòng nhập giá VNĐ</p>
                                {errors.price && <small className="text-destructive text-sm">{errors.price}</small>}
                            </div>
                            
                            <div className="space-y-2">
                                <Label htmlFor="stock">Số lượng (Tồn kho)</Label>
                                <Input 
                                    id="stock" 
                                    name="stock" 
                                    type="number" 
                                    value={formData.stock || 0} 
                                    onChange={handleChange} 
                                    min="0" 
                                    aria-invalid={!!errors.stock} 
                                />
                                {errors.stock && <small className="text-destructive text-sm">{errors.stock}</small>}
                            </div>

                            <div className="flex items-center space-x-2">
                                <Checkbox
                                    id="autoCheckLive"
                                    name="autoCheckLive"
                                />
                                <Label htmlFor="autoCheckLive" className="text-sm font-normal cursor-pointer">
                                    Tự động check live tài khoản facebook
                                </Label>
                            </div>

                            <div className="space-y-2">
                                <Label>Logo</Label>
                                <ImageUpload
                                    title=""
                                    description=""
                                    currentImage={logoUrl}
                                    onImageUploaded={(url) => {
                                        setLogoUrl(url);
                                        setFormData(prev => ({ ...prev, imageUrl: url }));
                                    }}
                                    maxSizeMB={2}
                                />
                            </div>
                        </div>

                        {/* Right Column */}
                        <div className="space-y-4">
                            <div className="space-y-2">
                                <Label htmlFor="status">Trạng thái</Label>
                                <Input 
                                    id="status" 
                                    name="status" 
                                    type="text" 
                                    value={formData.status || 'Hiện'} 
                                    onChange={handleChange}
                                />
                            </div>

                            <div className="space-y-2">
                                <Label htmlFor="numerical">Numerical*</Label>
                                <Select name="numerical" value="0" onValueChange={() => {}}>
                                    <SelectTrigger id="numerical">
                                        <SelectValue placeholder="-- Select numerical --" />
                                    </SelectTrigger>
                                    <SelectContent>
                                        <SelectItem value="0">0</SelectItem>
                                        <SelectItem value="1">1</SelectItem>
                                    </SelectContent>
                                </Select>
                            </div>

                            <div className="space-y-2">
                                <Label htmlFor="country">Quốc gia</Label>
                                <Select name="country" value={formData.country} onValueChange={(value) => setFormData(prev => ({ ...prev, country: value }))}>
                                    <SelectTrigger id="country">
                                        <SelectValue placeholder="-- Chọn quốc gia --" />
                                    </SelectTrigger>
                                    <SelectContent>
                                        <SelectItem value="US">United States</SelectItem>
                                        <SelectItem value="VN">Vietnam</SelectItem>
                                        <SelectItem value="PH">Philippines</SelectItem>
                                        <SelectItem value="WW">World Wide</SelectItem>
                                    </SelectContent>
                                </Select>
                            </div>

                            <div className="flex items-center space-x-2">
                                <Checkbox
                                    id="usePromotionalMoney"
                                    name="usePromotionalMoney"
                                    checked={formData.usePromotionalMoney || false}
                                    onCheckedChange={(checked) => setFormData(prev => ({ ...prev, usePromotionalMoney: !!checked }))}
                                />
                                <Label htmlFor="usePromotionalMoney" className="text-sm font-normal cursor-pointer">
                                    Sử dụng tiền khuyến mãi
                                </Label>
                            </div>
                        </div>
                    </div>

                    {/* Description - Full Width */}
                    <div className="space-y-2">
                        <Label htmlFor="description">Mô tả</Label>
                        <RichTextEditor 
                            value={formData.description} 
                            onChange={handleDescriptionChange}
                        />
                        {errors.description && <small className="text-destructive text-sm">{errors.description}</small>}
                    </div>
                </form>
                <DialogFooter>
                    <Button variant="outline" onClick={onClose} disabled={isLoading}>Hủy</Button>
                    <Button type="submit" form="product-form" disabled={isLoading}>
                        {isLoading && <Spinner className="mr-2 h-4 w-4 animate-spin" />}
                        Lưu
                    </Button>
                </DialogFooter>
            </DialogContent>
        </Dialog>
    );
};