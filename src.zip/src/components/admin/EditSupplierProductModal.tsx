import React, { useState } from 'react';
// FIX: Use sonner for consistent notifications
import { toast } from 'sonner';
import { SupplierProduct } from '../../types';
// FIX: Use Dialog components from shadcn/ui
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
// FIX: Use Button from shadcn/ui
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { Spinner } from '@/components/ui/spinner';

type EditSupplierProductModalProps = {
    product: SupplierProduct | 'new';
    supplierId: string;
    onClose: () => void;
    onSave: () => void;
};

const emptyProduct: Omit<SupplierProduct, 'id'> = {
    name: '',
    cost: 0,
    stock: 0,
};

export const EditSupplierProductModal = ({ product, supplierId, onClose, onSave }: EditSupplierProductModalProps) => {
    const isNew = product === 'new';
    const [formData, setFormData] = useState(() => isNew ? emptyProduct : { ...product });
    const [isLoading, setIsLoading] = useState(false);

    const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        const { name, value } = e.target;
        setFormData(prev => ({ ...prev, [name]: name === 'name' ? value : Number(value) }));
    };

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        setIsLoading(true);
        const payload = { ...formData, supplierId };
        try {
            if (isNew) {
                // await apiClient.post('/admin/supplier-products', payload);
                console.log("Mock creating product with payload:", payload);
                toast.success('(Mock) Thêm sản phẩm thành công!');
            } else {
                // await apiClient.put(`/admin/supplier-products/${(product as SupplierProduct).id}`, payload);
                console.log("Mock updating product with payload:", payload);
                toast.success('(Mock) Cập nhật sản phẩm thành công!');
            }
            onSave();
        } catch (error: any) {
            toast.error(error.response?.data?.message || 'Thao tác thất bại.');
        } finally {
            setIsLoading(false);
        }
    };

    return (
        <Dialog open={true} onOpenChange={onClose}>
            <DialogContent>
                <DialogHeader>
                    <DialogTitle>{isNew ? 'Thêm sản phẩm NCC' : 'Sửa sản phẩm NCC'}</DialogTitle>
                </DialogHeader>
                <form id="supplier-product-form" onSubmit={handleSubmit} className="space-y-4 py-4">
                    <div className="space-y-2">
                        <Label htmlFor="name">Tên sản phẩm</Label>
                        <Input id="name" name="name" type="text" value={formData.name} onChange={handleChange} required />
                    </div>
                    <div className="space-y-2">
                        <Label htmlFor="cost">Giá nhập</Label>
                        <Input id="cost" name="cost" type="number" value={formData.cost} onChange={handleChange} required min="0" />
                    </div>
                    <div className="space-y-2">
                        <Label htmlFor="stock">Tồn kho</Label>
                        <Input id="stock" name="stock" type="number" value={formData.stock} onChange={handleChange} required min="0" />
                    </div>
                </form>
                <DialogFooter>
                    <Button variant="outline" onClick={onClose} disabled={isLoading}>Hủy</Button>
                    <Button type="submit" form="supplier-product-form" disabled={isLoading}>
                        {isLoading && <Spinner className="mr-2 h-4 w-4 animate-spin" />}
                        Lưu
                    </Button>
                </DialogFooter>
            </DialogContent>
        </Dialog>
    );
};