import React, { useState } from 'react';
import { toast } from 'sonner';
import { ProductCategory, ApiError } from '../../types';
import apiClient from '../../services/apiClient';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { formatApiErrorForToast, getApiValidationErrors } from '../../utils';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Spinner } from '@/components/ui/spinner';

type EditProductCategoryModalProps = {
    category: ProductCategory | 'new';
    onClose: () => void;
    onSave: () => void;
};

const emptyCategory: Omit<ProductCategory, 'id' | 'product_count'> = {
    name: '',
    description: '',
};

export const EditProductCategoryModal = ({ category, onClose, onSave }: EditProductCategoryModalProps) => {
    const isNew = category === 'new';
    const [formData, setFormData] = useState(() => isNew ? emptyCategory : { name: category.name, description: category.description });
    const [isLoading, setIsLoading] = useState(false);
    const [errors, setErrors] = useState<Record<string, string>>({});

    const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
        const { name, value } = e.target;
        setFormData(prev => ({ ...prev, [name]: value }));
    };

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        setIsLoading(true);
        setErrors({});
        try {
            if (isNew) {
                await apiClient.post('/admin/product-categories', formData);
                toast.success('Thêm danh mục thành công!');
            } else {
                await apiClient.put(`/admin/product-categories/${(category as ProductCategory).id}`, formData);
                toast.success('Cập nhật danh mục thành công!');
            }
            onSave();
        } catch (error: any) {
            const validationErrors = getApiValidationErrors(error as ApiError);
            if (validationErrors) {
                setErrors(validationErrors);
            } else {
                toast.error(formatApiErrorForToast(error, 'Thao tác thất bại.'));
            }
        } finally {
            setIsLoading(false);
        }
    };

    return (
        <Dialog open={true} onOpenChange={onClose}>
            <DialogContent>
                <DialogHeader>
                    <DialogTitle>{isNew ? 'Thêm danh mục mới' : `Sửa danh mục: ${category.name}`}</DialogTitle>
                </DialogHeader>
                <form id="category-form" onSubmit={handleSubmit} className="space-y-4 py-4">
                    <div className="space-y-2">
                        <Label htmlFor="name">Tên danh mục</Label>
                        <Input id="name" name="name" type="text" value={formData.name} onChange={handleChange} required aria-invalid={!!errors.name} />
                        {errors.name && <small className="text-destructive text-sm">{errors.name}</small>}
                    </div>
                    <div className="space-y-2">
                        <Label htmlFor="description">Mô tả</Label>
                        <Textarea id="description" name="description" value={formData.description} onChange={handleChange} rows={3} aria-invalid={!!errors.description} />
                        {errors.description && <small className="text-destructive text-sm">{errors.description}</small>}
                    </div>
                </form>
                <DialogFooter>
                    <Button variant="outline" onClick={onClose} disabled={isLoading}>Hủy</Button>
                    <Button type="submit" form="category-form" disabled={isLoading}>
                        {isLoading && <Spinner className="mr-2 h-4 w-4 animate-spin" />}
                        Lưu
                    </Button>
                </DialogFooter>
            </DialogContent>
        </Dialog>
    );
};