import React, { useState } from 'react';
import { toast } from 'sonner';
import { PaymentMethod, ApiError } from '../../types';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { formatApiErrorForToast, getApiValidationErrors } from '../../utils';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Spinner } from '@/components/ui/spinner';

type EditPaymentMethodModalProps = {
    method: PaymentMethod | 'new';
    onClose: () => void;
    onSave: (methodData: Omit<PaymentMethod, 'id'> | PaymentMethod) => Promise<void>;
};

const emptyMethod: Omit<PaymentMethod, 'id'> = {
    type: 'bank',
    name: '',
    accountName: '',
    accountNumber: '',
    qrCodeUrl: '',
    is_active: true,
};

export const EditPaymentMethodModal = ({ method, onClose, onSave }: EditPaymentMethodModalProps) => {
    const isNew = method === 'new';
    const [formData, setFormData] = useState(() => isNew ? emptyMethod : { ...method });
    const [isLoading, setIsLoading] = useState(false);
    const [errors, setErrors] = useState<Record<string, string>>({});

    const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        const { name, value } = e.target;
        setFormData(prev => ({ ...prev, [name]: value }));
    };

    const handleSelectChange = (value: 'bank' | 'momo') => {
        setFormData(prev => ({ ...prev, type: value }));
    };

    const handleToggle = (checked: boolean) => {
        setFormData(prev => ({ ...prev, is_active: checked }));
    };

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        setIsLoading(true);
        setErrors({});
        try {
            await onSave(formData);
        } catch (error) {
             const validationErrors = getApiValidationErrors(error as ApiError);
            if (validationErrors) {
                setErrors(validationErrors);
            } else {
                toast.error(formatApiErrorForToast(error as ApiError, 'Lưu thất bại.'));
            }
            // re-throw to be handled by parent if needed
            throw error;
        } finally {
            setIsLoading(false);
        }
    };

    return (
        <Dialog open={true} onOpenChange={onClose}>
            <DialogContent>
                <DialogHeader>
                    <DialogTitle>{isNew ? 'Thêm phương thức' : 'Sửa phương thức'}</DialogTitle>
                </DialogHeader>
                <form id="payment-method-form" onSubmit={handleSubmit} className="space-y-4 py-4">
                    <div className="space-y-2">
                        <Label htmlFor="name">Tên hiển thị</Label>
                        <Input id="name" name="name" type="text" value={formData.name} onChange={handleChange} required placeholder="Ví dụ: Vietcombank" aria-invalid={!!errors.name} />
                        {errors.name && <small className="text-destructive text-sm">{errors.name}</small>}
                    </div>
                    <div className="space-y-2">
                        <Label htmlFor="type">Loại</Label>
                        <Select value={formData.type} onValueChange={handleSelectChange}>
                            <SelectTrigger id="type" aria-invalid={!!errors.type}>
                                <SelectValue placeholder="Chọn loại" />
                            </SelectTrigger>
                            <SelectContent>
                                <SelectItem value="bank">Ngân hàng</SelectItem>
                                <SelectItem value="momo">Ví Momo</SelectItem>
                            </SelectContent>
                        </Select>
                        {errors.type && <small className="text-destructive text-sm">{errors.type}</small>}
                    </div>
                    <div className="space-y-2">
                        <Label htmlFor="accountName">Tên chủ tài khoản</Label>
                        <Input id="accountName" name="accountName" type="text" value={formData.accountName} onChange={handleChange} required aria-invalid={!!errors.accountName} />
                        {errors.accountName && <small className="text-destructive text-sm">{errors.accountName}</small>}
                    </div>
                    <div className="space-y-2">
                        <Label htmlFor="accountNumber">Số tài khoản / SĐT</Label>
                        <Input id="accountNumber" name="accountNumber" type="text" value={formData.accountNumber} onChange={handleChange} required aria-invalid={!!errors.accountNumber} />
                        {errors.accountNumber && <small className="text-destructive text-sm">{errors.accountNumber}</small>}
                    </div>
                    <div className="space-y-2">
                        <Label htmlFor="qrCodeUrl">URL ảnh QR Code (tùy chọn)</Label>
                        <Input id="qrCodeUrl" name="qrCodeUrl" type="text" value={formData.qrCodeUrl || ''} onChange={handleChange} aria-invalid={!!errors.qrCodeUrl} />
                        {errors.qrCodeUrl && <small className="text-destructive text-sm">{errors.qrCodeUrl}</small>}
                    </div>
                    <div className="flex items-center space-x-2">
                        <Switch id="is_active" checked={formData.is_active} onCheckedChange={handleToggle} />
                        <Label htmlFor="is_active">{formData.is_active ? 'Đang hoạt động' : 'Tắt'}</Label>
                    </div>
                </form>
                <DialogFooter>
                    <Button variant="outline" onClick={onClose} disabled={isLoading}>Hủy</Button>
                    <Button type="submit" form="payment-method-form" disabled={isLoading}>
                        {isLoading && <Spinner className="mr-2 h-4 w-4 animate-spin" />}
                        Lưu
                    </Button>
                </DialogFooter>
            </DialogContent>
        </Dialog>
    );
};