import { useState } from 'react';
import { toast } from 'sonner';
import apiClient from '../services/apiClient';
import { useUser } from '../services/UserContext';
import { formatApiErrorForToast } from '../utils';
import { ApiError } from '../types';
import { Alert, AlertDescription } from './ui/alert';
import { Button } from './ui/button';
import { TriangleAlert } from 'lucide-react';

export const EmailVerificationBanner = () => {
    const { user } = useUser();
    const [isLoading, setIsLoading] = useState(false);
    const [isSent, setIsSent] = useState(false);

    // Feature flag from Vite env (defaults to false)
    const requireEmailVerification = import.meta.env.VITE_REQUIRE_EMAIL_VERIFICATION === 'true' || false;

    // If the flag is disabled, do not render the banner
    if (!requireEmailVerification) return null;

    if (!user || user.emailVerified) {
        return null;
    }

    const handleResend = async () => {
        setIsLoading(true);
        try {
            await apiClient.post('/email/resend-verification');
            toast.success('Email xác thực đã được gửi lại!');
            setIsSent(true);
        } catch (error) {
            toast.error(formatApiErrorForToast(error as ApiError, 'Gửi lại email thất bại.'));
        } finally {
            setIsLoading(false);
        }
    };

    return (
        <Alert variant="destructive" className="m-0 rounded-none border-x-0 border-t-0 border-b border-white/60 bg-red-500/10 backdrop-blur-sm dark:border-slate-800/60 dark:bg-red-500/20">
            <TriangleAlert className="h-4 w-4" />
            <div className="flex flex-wrap items-center justify-between w-full gap-2">
                <AlertDescription className="text-sm font-medium">
                    Tài khoản của bạn chưa được xác thực. Vui lòng kiểm tra email để kích hoạt.
                </AlertDescription>
                <Button
                    onClick={handleResend}
                    disabled={isLoading || isSent}
                    variant="destructive"
                    size="sm"
                    className="h-8"
                >
                    {isLoading ? 'Đang gửi...' : (isSent ? 'Đã gửi' : 'Gửi lại link')}
                </Button>
            </div>
        </Alert>
    );
};