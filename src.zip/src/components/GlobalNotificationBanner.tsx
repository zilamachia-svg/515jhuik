import { useState, useEffect } from 'react';
import { X, AlertCircle, Info, CheckCircle2, AlertTriangle } from 'lucide-react';
import { Alert, AlertDescription } from './ui/alert';
import { Button } from './ui/button';
import { cn } from '@/lib/utils';
import apiClient from '../services/apiClient';

type NotificationType = 'info' | 'success' | 'warning' | 'error';

interface SystemNotification {
    message: string;
    type: NotificationType;
    isActive: boolean;
}

export const GlobalNotificationBanner = () => {
    const [notification, setNotification] = useState<SystemNotification | null>(null);
    const [isDismissed, setIsDismissed] = useState(false);

    useEffect(() => {
        const fetchNotification = async () => {
            try {
                // Sử dụng endpoint đúng: /api/v1/settings hoặc /admin/settings
                const response = await apiClient.get('/api/v1/settings');
                const systemNotification = response.data?.systemNotification || response.data?.settings?.systemNotification;
                
                if (systemNotification && systemNotification.trim()) {
                    setNotification({
                        message: systemNotification,
                        type: 'info',
                        isActive: true,
                    });
                    setIsDismissed(false);
                } else {
                    setNotification(null);
                }
            } catch (error: any) {
                // Suppress network errors trong dev mode (backend có thể chưa chạy)
                const isNetworkError = error?.code === 'ERR_NETWORK' || 
                                      error?.message === 'Network Error' || 
                                      error?.message?.includes('Failed to fetch') ||
                                      (!error?.response && error?.request);
                
                if (import.meta.env.DEV) {
                    // Chỉ log nếu không phải network error
                    if (!isNetworkError) {
                        console.debug('Could not fetch system notification:', error);
                    }
                    // Hoàn toàn im lặng với network errors trong dev mode
                } else {
                    // Trong production, log tất cả errors (trừ network errors nếu cần)
                    if (!isNetworkError) {
                        console.debug('Could not fetch system notification:', error);
                    }
                }
            }
        };

        fetchNotification();
        
        // Chỉ set interval nếu không phải dev mode hoặc có backend
        const interval = setInterval(fetchNotification, 5 * 60 * 1000);
        return () => clearInterval(interval);
    }, []);

    if (!notification || !notification.isActive || isDismissed) {
        return null;
    }

    const getIcon = () => {
        switch (notification.type) {
            case 'success':
                return <CheckCircle2 className="h-4 w-4" />;
            case 'warning':
                return <AlertTriangle className="h-4 w-4" />;
            case 'error':
                return <AlertCircle className="h-4 w-4" />;
            default:
                return <Info className="h-4 w-4" />;
        }
    };

    const getVariant = (): 'default' | 'destructive' => {
        return notification.type === 'error' ? 'destructive' : 'default';
    };

    return (
        <Alert
            variant={getVariant()}
            className={cn(
                'm-0 rounded-none border-x-0 border-t-0 border-b border-white/60 bg-gradient-to-r from-primary/5 via-primary/10 to-primary/5 shadow-sm backdrop-blur-sm dark:border-slate-800/60 dark:from-primary/10 dark:via-primary/15 dark:to-primary/10',
                notification.type === 'error' && 'from-red-500/10 via-red-500/15 to-red-500/10 dark:from-red-500/20 dark:via-red-500/25 dark:to-red-500/20',
                notification.type === 'warning' && 'from-yellow-500/10 via-yellow-500/15 to-yellow-500/10 dark:from-yellow-500/20 dark:via-yellow-500/25 dark:to-yellow-500/20',
                notification.type === 'success' && 'from-green-500/10 via-green-500/15 to-green-500/10 dark:from-green-500/20 dark:via-green-500/25 dark:to-green-500/20'
            )}
        >
            <div className="mx-auto flex w-full max-w-[1600px] items-center gap-3 px-2 sm:px-4 lg:px-6">
                <div className="flex-shrink-0 text-primary dark:text-primary/90">
                    {getIcon()}
                </div>
                <AlertDescription className="flex-1 text-sm font-medium text-slate-700 dark:text-slate-100">
                    {notification.message}
                </AlertDescription>
                <Button
                    variant="ghost"
                    size="icon"
                    className="h-6 w-6 flex-shrink-0 rounded-lg hover:bg-white/60 dark:hover:bg-slate-800/60"
                    onClick={() => setIsDismissed(true)}
                    aria-label="Đóng thông báo"
                >
                    <X className="h-3.5 w-3.5" />
                </Button>
            </div>
        </Alert>
    );
};