import { CheckCircle, XCircle } from "lucide-react"

interface PasswordStrengthProps {
  password: string;
}

const getPasswordStrength = (password: string) => {
    let strength = 0;
    const checks = {
      length: password.length >= 8,
      uppercase: /[A-Z]/.test(password),
      lowercase: /[a-z]/.test(password),
      number: /\d/.test(password),
      special: /[!@#$%^&*(),.?":{}|<>]/.test(password),
    }

    strength = Object.values(checks).filter(Boolean).length;

    return {
      score: strength,
      checks,
      label: strength < 2 ? "Yếu" : strength < 4 ? "Trung bình" : "Mạnh",
      color: strength < 2 ? "text-destructive" : strength < 4 ? "text-yellow-500" : "text-green-500",
    }
}

export function PasswordStrengthIndicator({ password }: PasswordStrengthProps) {
  const passwordStrength = getPasswordStrength(password);

  if (!password) return null;

  return (
    <div className="space-y-2 pt-2">
      <div className="flex items-center justify-between">
        <span className="text-xs text-muted-foreground">Độ mạnh mật khẩu:</span>
        <span className={`text-xs font-medium ${passwordStrength.color}`}>{passwordStrength.label}</span>
      </div>
      <div className="grid grid-cols-5 gap-1">
        {[...Array(5)].map((_, i) => (
          <div
            key={i}
            className={`h-1 rounded-full transition-all duration-200 ${
              i < passwordStrength.score
                ? passwordStrength.score < 2
                  ? "bg-destructive"
                  : passwordStrength.score < 4
                    ? "bg-yellow-500"
                    : "bg-green-500"
                : "bg-muted"
            }`}
          />
        ))}
      </div>
      <div className="space-y-1 pt-1">
        {Object.entries(passwordStrength.checks).map(([key, passed]) => (
          <div key={key} className="flex items-center gap-2 text-xs">
            {passed ? (
              <CheckCircle className="w-3 h-3 text-green-500" />
            ) : (
              <XCircle className="w-3 h-3 text-muted-foreground" />
            )}
            <span className={passed ? "text-green-500" : "text-muted-foreground"}>
              {key === "length" && "Ít nhất 8 ký tự"}
              {key === "uppercase" && "Một chữ hoa"}
              {key === "lowercase" && "Một chữ thường"}
              {key === "number" && "Một chữ số"}
              {key === "special" && "Một ký tự đặc biệt"}
            </span>
          </div>
        ))}
      </div>
    </div>
  )
}
