import { Moon, Sun } from "lucide-react";
import { useTheme } from "../contexts/ThemeContext";
import { Switch } from "@/components/ui/switch";

export function ThemeToggle() {
  const { isDarkMode, toggleTheme } = useTheme();

  return (
    <div className="flex items-center space-x-2">
      <Sun
        className={`h-[1.2rem] w-[1.2rem] transition-all duration-500 ease-in-out ${
          !isDarkMode
            ? "text-foreground scale-100 rotate-0"
            : "text-muted-foreground scale-75 -rotate-90"
        }`}
      />
      <Switch
        checked={isDarkMode}
        onCheckedChange={toggleTheme}
        aria-label="Toggle theme"
        className="transition-all duration-300 ease-in-out hover:scale-110"
      />
      <Moon
        className={`h-[1.2rem] w-[1.2rem] transition-all duration-500 ease-in-out ${
          isDarkMode
            ? "text-foreground scale-100 rotate-0"
            : "text-muted-foreground scale-75 rotate-90"
        }`}
      />
    </div>
  );
}
