import React from 'react';
import { Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { PATHS } from '../constants/paths';
import { Wand2 } from 'lucide-react';

interface PlaceholderContentProps {
    icon?: React.ReactNode;
    title: string;
    message: string;
    showCta?: boolean;
    ctaLink?: string;
    ctaText?: string;
}

export function PlaceholderContent({
    icon = <Wand2 className="w-12 h-12" />,
    title,
    message,
    showCta = false,
    ctaLink = PATHS.HOME,
    ctaText = 'Về trang chủ'
}: PlaceholderContentProps) {
    return (
        <div className="flex flex-col items-center justify-center text-center p-12 text-muted-foreground">
            <div className="text-5xl opacity-40 mb-4">{icon}</div>
            <h2 className="text-xl font-semibold text-foreground mb-2">{title}</h2>
            <p className="max-w-md">{message}</p>
            {showCta && (
                <Button asChild className="mt-6">
                    <Link to={ctaLink}>{ctaText}</Link>
                </Button>
            )}
        </div>
    );
}
