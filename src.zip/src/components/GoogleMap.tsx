/**
 * Google Maps Component
 * Wrapper component for Google Maps integration
 */

import { useEffect, useRef, useState } from 'react';
import { useGoogleMaps } from '../hooks/useGoogleMaps';

interface GoogleMapProps {
  center?: { lat: number; lng: number };
  zoom?: number;
  markers?: Array<{ lat: number; lng: number; title?: string }>;
  onMapClick?: (lat: number, lng: number) => void;
  className?: string;
  style?: React.CSSProperties;
}

export const GoogleMap: React.FC<GoogleMapProps> = ({
  center = { lat: 10.8231, lng: 106.6297 }, // Ho Chi Minh City default
  zoom = 13,
  markers = [],
  onMapClick,
  className = '',
  style = {},
}) => {
  const mapRef = useRef<HTMLDivElement>(null);
  const mapInstanceRef = useRef<any | null>(null);
  const markersRef = useRef<any[]>([]);
  const { isLoaded, isLoading, error } = useGoogleMaps();
  const [mapError, setMapError] = useState<string | null>(null);

  useEffect(() => {
    if (!isLoaded || !mapRef.current) return;

    try {
      // Initialize map
      const map = new (window.google as any).maps.Map(mapRef.current, {
        center,
        zoom,
        mapTypeControl: true,
        streetViewControl: true,
        fullscreenControl: true,
      });

      mapInstanceRef.current = map;

      // Add click listener
      if (onMapClick) {
        (map as any).addListener('click', (e: any) => {
          if (e.latLng) {
            onMapClick(e.latLng.lat(), e.latLng.lng());
          }
        });
      }
    } catch (err) {
      console.error('Error initializing Google Map:', err);
      setMapError('Failed to initialize map');
    }
  }, [isLoaded, center, zoom, onMapClick]);

  // Update markers when they change
  useEffect(() => {
    if (!isLoaded || !mapInstanceRef.current) return;

    // Clear existing markers
    markersRef.current.forEach(marker => marker.setMap(null));
    markersRef.current = [];

    // Add new markers
    markers.forEach(markerData => {
      const marker = new (window.google as any).maps.Marker({
        position: { lat: markerData.lat, lng: markerData.lng },
        map: mapInstanceRef.current,
        title: markerData.title,
      });

      markersRef.current.push(marker);
    });
  }, [isLoaded, markers]);

  // Update map center when it changes
  useEffect(() => {
    if (mapInstanceRef.current) {
      mapInstanceRef.current.setCenter(center);
    }
  }, [center]);

  // Update map zoom when it changes
  useEffect(() => {
    if (mapInstanceRef.current) {
      mapInstanceRef.current.setZoom(zoom);
    }
  }, [zoom]);

  if (isLoading) {
    return (
      <div className={`flex items-center justify-center h-64 bg-gray-100 ${className}`} style={style}>
        <div className="text-gray-500">Đang tải bản đồ...</div>
      </div>
    );
  }

  if (error || mapError) {
    return (
      <div className={`flex items-center justify-center h-64 bg-gray-100 ${className}`} style={style}>
        <div className="text-red-500">
          {error?.message || mapError || 'Không thể tải bản đồ'}
        </div>
      </div>
    );
  }

  return (
    <div
      ref={mapRef}
      className={`w-full h-full ${className}`}
      style={{ minHeight: '300px', ...style }}
    />
  );
};

