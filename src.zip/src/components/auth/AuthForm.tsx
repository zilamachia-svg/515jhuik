import type React from "react"
import { useState, useMemo } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Checkbox } from "@/components/ui/checkbox"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Eye, EyeOff, Loader2, Lock, User, CheckCircle2, AlertCircle, ShieldCheck } from "lucide-react"
import { cn } from "@/lib/utils"

interface AuthFormProps {
  initialTab: 'signin' | 'signup';
  isLoading: boolean;
  email: string;
  setEmail: (email: string) => void;
  name: string;
  setName: (name: string) => void;
  password: string;
  setPassword: (password: string) => void;
  rememberMe: boolean;
  setRememberMe: (remember: boolean) => void;
  errors: Record<string, string>;
  onSignIn: (e: React.FormEvent) => void;
  onSignUp: (e: React.FormEvent) => void;
  onForgotPassword: () => void;
}

// Password strength calculator
const getPasswordStrength = (password: string): { score: number; label: string; color: string } => {
  if (!password) return { score: 0, label: '', color: '' };
  
  let score = 0;
  if (password.length >= 8) score++;
  if (password.length >= 12) score++;
  if (/[a-z]/.test(password) && /[A-Z]/.test(password)) score++;
  if (/\d/.test(password)) score++;
  if (/[^a-zA-Z\d]/.test(password)) score++;
  
  if (score <= 1) return { score: 1, label: 'Yếu', color: 'bg-destructive' };
  if (score <= 2) return { score: 2, label: 'Trung bình', color: 'bg-yellow-500' };
  if (score <= 3) return { score: 3, label: 'Khá', color: 'bg-blue-500' };
  return { score: 4, label: 'Mạnh', color: 'bg-green-500' };
};

export function AuthForm({
  initialTab,
  isLoading,
  email,
  setEmail,
  name,
  setName,
  password,
  setPassword,
  rememberMe,
  setRememberMe,
  errors,
  onSignIn,
  onSignUp,
  onForgotPassword,
}: AuthFormProps) {
  const [showPassword, setShowPassword] = useState(false);
  const [activeTab, setActiveTab] = useState(initialTab);
  const [nameBlurred, setNameBlurred] = useState(false);
  const [passwordBlurred, setPasswordBlurred] = useState(false);
  
  const passwordStrength = useMemo(() => getPasswordStrength(password), [password]);
  const isNameValid = name.trim().length >= 3 && !errors.name;
  const isPasswordValid = password.length >= 6 && !errors.password;

  return (
    <Tabs defaultValue={initialTab} className="w-full" onValueChange={(tab) => {
      setActiveTab(tab as 'signin' | 'signup');
      setNameBlurred(false);
      setPasswordBlurred(false);
    }}>
      <div className="relative bg-gradient-to-r from-primary/10 via-transparent to-primary/10 p-8 pb-4">
        {/* Decorative background elements */}
        <div className="absolute inset-0 overflow-hidden">
          <div className="absolute -top-20 -right-20 h-40 w-40 rounded-full bg-primary/5 blur-3xl"></div>
          <div className="absolute -bottom-20 -left-20 h-40 w-40 rounded-full bg-primary/5 blur-3xl"></div>
        </div>
        
        <div className="relative">
          <h1 className="text-2xl font-bold text-foreground mb-6 text-center">
            {activeTab === 'signin' ? '🔐 Đăng Nhập' : '✨ Tạo Tài Khoản'}
          </h1>
          
          <TabsList className="grid w-full grid-cols-2 bg-muted/30 backdrop-blur-sm border border-border/20 rounded-lg">
            <TabsTrigger
              value="signin"
              className="data-[state=active]:bg-gradient-to-r data-[state=active]:from-primary/90 data-[state=active]:to-primary/70 data-[state=active]:text-primary-foreground data-[state=active]:shadow-lg text-muted-foreground transition-all duration-200"
            >
              Đăng nhập
            </TabsTrigger>
            <TabsTrigger
              value="signup"
              className="data-[state=active]:bg-gradient-to-r data-[state=active]:from-primary/90 data-[state=active]:to-primary/70 data-[state=active]:text-primary-foreground data-[state=active]:shadow-lg text-muted-foreground transition-all duration-200"
            >
              Đăng ký
            </TabsTrigger>
          </TabsList>
        </div>
      </div>

      <TabsContent value="signin" className="space-y-4 px-8 py-6 pb-8">
        <form onSubmit={onSignIn} className="space-y-5">
          <div className="space-y-2">
            <Label htmlFor="signin-email" className="text-foreground/90 font-semibold">
              Email
            </Label>
            <div className="relative group">
              <User className="absolute left-3 top-3 h-4 w-4 text-muted-foreground group-focus-within:text-primary transition-colors" />
              <Input
                id="signin-email"
                type="email"
                placeholder="Nhập email của bạn"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                onBlur={() => setNameBlurred(true)}
                autoComplete="off"
                className={cn(
                  "pl-10 bg-muted/50 border-border/80 text-foreground placeholder:text-muted-foreground focus:border-primary backdrop-blur-sm transition-all duration-200",
                  errors.email && "border-destructive focus-visible:ring-destructive bg-destructive/5"
                )}
                aria-invalid={!!errors.email}
                required
              />
              {nameBlurred && email && !errors.email && (
                <CheckCircle2 className="absolute right-3 top-3 h-4 w-4 text-green-500 animate-in" />
              )}
            </div>
            {errors.email && (
              <p className="text-sm text-destructive mt-1 flex items-center gap-1">
                <AlertCircle className="h-3 w-3" /> {errors.email}
              </p>
            )}
          </div>

          <div className="space-y-2">
            <Label htmlFor="signin-password" className="text-foreground/90 font-semibold">
              Mật khẩu
            </Label>
            <div className="relative group">
              <Lock className="absolute left-3 top-3 h-4 w-4 text-muted-foreground group-focus-within:text-primary transition-colors" />
              <Input
                id="signin-password"
                type={showPassword ? "text" : "password"}
                placeholder="Nhập mật khẩu của bạn"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                onBlur={() => setPasswordBlurred(true)}
                autoComplete="off"
                className={cn(
                  "pl-10 pr-10 bg-muted/50 border-border/80 text-foreground placeholder:text-muted-foreground focus:border-primary backdrop-blur-sm transition-all duration-200",
                  errors.password && "border-destructive focus-visible:ring-destructive bg-destructive/5"
                )}
                aria-invalid={!!errors.password}
                required
              />
              <button
                type="button"
                onClick={() => setShowPassword(!showPassword)}
                className="absolute right-3 top-3 text-muted-foreground hover:text-foreground transition-colors"
                aria-label={showPassword ? "Ẩn mật khẩu" : "Hiển thị mật khẩu"}
              >
                {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
              </button>
            </div>
            {errors.password && (
              <p className="text-sm text-destructive mt-1 flex items-center gap-1">
                <AlertCircle className="h-3 w-3" /> {errors.password}
              </p>
            )}
          </div>

          <div className="flex items-center justify-between pt-2">
            <div className="flex items-center space-x-2">
              <Checkbox
                id="remember"
                checked={rememberMe}
                onCheckedChange={(checked) => setRememberMe(!!checked)}
                className="border-border/80 data-[state=checked]:bg-primary transition-all"
              />
              <Label htmlFor="remember" className="text-sm text-muted-foreground cursor-pointer">
                Ghi nhớ tôi
              </Label>
            </div>
            <button
              type="button"
              onClick={onForgotPassword}
              className="text-sm text-primary/80 hover:text-primary underline underline-offset-2 transition-colors font-medium"
            >
              Quên mật khẩu?
            </button>
          </div>

          <Button
            type="submit"
            className="w-full bg-gradient-to-r from-primary to-primary/90 hover:from-primary/90 hover:to-primary text-primary-foreground border-0 shadow-lg hover:shadow-xl transition-all duration-200 py-2 h-auto font-semibold"
            disabled={isLoading}
          >
            {isLoading ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Đang đăng nhập...
              </>
            ) : (
              "Đăng nhập"
            )}
          </Button>
        </form>
      </TabsContent>

      <TabsContent value="signup" className="space-y-4 px-8 py-6 pb-8">
        <form onSubmit={onSignUp} className="space-y-5">
          <div className="space-y-2">
            <Label htmlFor="signup-name" className="text-foreground/90 font-semibold">
              Tên đầy đủ
            </Label>
            <div className="relative group">
              <User className="absolute left-3 top-3 h-4 w-4 text-muted-foreground group-focus-within:text-primary transition-colors" />
              <Input
                id="signup-name"
                type="text"
                placeholder="Nhập tên đầy đủ của bạn"
                value={name}
                onChange={(e) => setName(e.target.value)}
                onBlur={() => setNameBlurred(true)}
                autoComplete="name"
                className={cn(
                  "pl-10 bg-muted/50 border-border/80 text-foreground placeholder:text-muted-foreground focus:border-primary backdrop-blur-sm transition-all duration-200",
                  errors.name && "border-destructive focus-visible:ring-destructive bg-destructive/5",
                  nameBlurred && isNameValid && "border-green-500/50 bg-green-500/5"
                )}
                aria-invalid={!!errors.name}
                required
                minLength={3}
              />
              {nameBlurred && isNameValid && (
                <CheckCircle2 className="absolute right-3 top-3 h-4 w-4 text-green-500 animate-in" />
              )}
            </div>
            {errors.name && (
              <p className="text-sm text-destructive mt-1 flex items-center gap-1">
                <AlertCircle className="h-3 w-3" /> {errors.name}
              </p>
            )}
          </div>

          <div className="space-y-2">
            <Label htmlFor="signup-email" className="text-foreground/90 font-semibold">
              Email
            </Label>
            <div className="relative group">
              <User className="absolute left-3 top-3 h-4 w-4 text-muted-foreground group-focus-within:text-primary transition-colors" />
              <Input
                id="signup-email"
                type="email"
                placeholder="Nhập email của bạn"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                onBlur={() => setNameBlurred(true)}
                autoComplete="email"
                className={cn(
                  "pl-10 bg-muted/50 border-border/80 text-foreground placeholder:text-muted-foreground focus:border-primary backdrop-blur-sm transition-all duration-200",
                  errors.email && "border-destructive focus-visible:ring-destructive bg-destructive/5",
                  nameBlurred && email && !errors.email && "border-green-500/50 bg-green-500/5"
                )}
                aria-invalid={!!errors.email}
                required
              />
              {nameBlurred && email && !errors.email && (
                <CheckCircle2 className="absolute right-3 top-3 h-4 w-4 text-green-500 animate-in" />
              )}
            </div>
            {errors.email && (
              <p className="text-sm text-destructive mt-1 flex items-center gap-1">
                <AlertCircle className="h-3 w-3" /> {errors.email}
              </p>
            )}
          </div>

          <div className="space-y-2">
            <Label htmlFor="signup-password" className="text-foreground/90 font-semibold">
              Mật khẩu
            </Label>
            <div className="relative group">
              <Lock className="absolute left-3 top-3 h-4 w-4 text-muted-foreground group-focus-within:text-primary transition-colors" />
              <Input
                id="signup-password"
                type={showPassword ? "text" : "password"}
                placeholder="Tạo mật khẩu mạnh (tối thiểu 6 ký tự)"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                onBlur={() => setPasswordBlurred(true)}
                autoComplete="new-password"
                className={cn(
                  "pl-10 pr-10 bg-muted/50 border-border/80 text-foreground placeholder:text-muted-foreground focus:border-primary backdrop-blur-sm transition-all duration-200",
                  errors.password && "border-destructive focus-visible:ring-destructive bg-destructive/5",
                  passwordBlurred && isPasswordValid && "border-green-500/50 bg-green-500/5"
                )}
                aria-invalid={!!errors.password}
                required
                minLength={6}
              />
              <button
                type="button"
                onClick={() => setShowPassword(!showPassword)}
                className="absolute right-3 top-3 text-muted-foreground hover:text-foreground transition-colors"
                aria-label={showPassword ? "Ẩn mật khẩu" : "Hiển thị mật khẩu"}
              >
                {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
              </button>
            </div>

            {/* Password strength indicator */}
            {password && (
              <div className="space-y-2 mt-2">
                <div className="flex items-center gap-2">
                  <div className="flex-1 h-2 bg-muted rounded-full overflow-hidden">
                    <div
                      className={`h-full ${passwordStrength.color} transition-all duration-300 ${
                        passwordStrength.score === 1 ? 'w-1/4' :
                        passwordStrength.score === 2 ? 'w-1/2' :
                        passwordStrength.score === 3 ? 'w-3/4' :
                        'w-full'
                      }`}
                    />
                  </div>
                  <span className={cn(
                    "text-xs font-semibold",
                    passwordStrength.score <= 1 && "text-destructive",
                    passwordStrength.score === 2 && "text-yellow-600 dark:text-yellow-500",
                    passwordStrength.score === 3 && "text-blue-600 dark:text-blue-500",
                    passwordStrength.score >= 4 && "text-green-600 dark:text-green-500"
                  )}>
                    {passwordStrength.label}
                  </span>
                </div>
              </div>
            )}

            {errors.password && (
              <p className="text-sm text-destructive mt-1 flex items-center gap-1">
                <AlertCircle className="h-3 w-3" /> {errors.password}
              </p>
            )}
            
            {password && password.length > 0 && password.length < 6 && !errors.password && (
              <p className="text-xs text-muted-foreground mt-1 flex items-center gap-1">
                <AlertCircle className="h-3 w-3" /> Mật khẩu phải có ít nhất 6 ký tự
              </p>
            )}
          </div>

          <div className="bg-muted/30 rounded-lg p-3 space-y-2 border border-border/20">
            <p className="text-xs font-semibold text-foreground/80 flex items-center gap-1">
              <ShieldCheck className="h-3 w-3 text-primary" /> Mật khẩu tốt nên có:
            </p>
            <ul className="text-xs text-muted-foreground space-y-1 ml-4">
              <li className={cn("flex items-center gap-2", password.length >= 8 && "text-green-600 dark:text-green-500")}>
                ✓ Ít nhất 8 ký tự
              </li>
              <li className={cn("flex items-center gap-2", /[a-z]/.test(password) && /[A-Z]/.test(password) && "text-green-600 dark:text-green-500")}>
                ✓ Kết hợp chữ hoa và chữ thường
              </li>
              <li className={cn("flex items-center gap-2", /\d/.test(password) && "text-green-600 dark:text-green-500")}>
                ✓ Chứa chữ số
              </li>
              <li className={cn("flex items-center gap-2", /[^a-zA-Z\d]/.test(password) && "text-green-600 dark:text-green-500")}>
                ✓ Chứa ký tự đặc biệt
              </li>
            </ul>
          </div>

          <Button
            type="submit"
            className="w-full bg-gradient-to-r from-primary to-primary/90 hover:from-primary/90 hover:to-primary text-primary-foreground border-0 shadow-lg hover:shadow-xl transition-all duration-200 py-2 h-auto font-semibold disabled:opacity-50 disabled:cursor-not-allowed"
            disabled={isLoading || !name.trim() || password.length < 6 || !isNameValid}
          >
            {isLoading ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Đang tạo tài khoản...
              </>
            ) : (
              <>
                <ShieldCheck className="mr-2 h-4 w-4" />
                Tạo tài khoản
              </>
            )}
          </Button>

          <p className="text-xs text-center text-muted-foreground">
            Bằng cách tạo tài khoản, bạn đồng ý với<br />
            <a href="#" className="text-primary/80 hover:text-primary underline transition-colors">Điều khoản sử dụng</a> và{' '}
            <a href="#" className="text-primary/80 hover:text-primary underline transition-colors">Chính sách bảo mật</a>
          </p>
        </form>
      </TabsContent>
    </Tabs>
  );
}
