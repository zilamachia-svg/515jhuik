import { useState, useEffect } from 'react';
// FIX: Use Card from shadcn/ui
import { Card, CardContent } from '@/components/ui/card';
import { ShoppingCart, UserPlus } from 'lucide-react';

type Activity = {
    type: 'purchase' | 'signup';
    text: string;
    time: string;
};

const mockActivities: Activity[] = [
    { type: 'purchase', text: 'Thành viên ***123 vừa mua VIA US Cổ', time: 'vài giây trước' },
    { type: 'signup', text: 'Thành viên ***456 vừa đăng ký', time: '1 phút trước' },
    { type: 'purchase', text: 'Thành viên ***789 vừa mua Clone Philippines', time: '3 phút trước' },
];

export const LiveActivityFeed = () => {
    const [activities, setActivities] = useState<Activity[]>(mockActivities);
    
    // Simulate new activities
    useEffect(() => {
        const interval = setInterval(() => {
            const newActivity: Activity = Math.random() > 0.5
                ? { type: 'purchase', text: 'Thành viên ***abc vừa mua BM5 kháng', time: 'vừa xong' }
                : { type: 'signup', text: 'Thành viên ***xyz vừa đăng ký', time: 'vừa xong' };
            
            setActivities(prev => [newActivity, ...prev.slice(0, 4)]);
        }, 8000); // Add a new activity every 8 seconds
        
        return () => clearInterval(interval);
    }, []);

    const getIcon = (type: 'purchase' | 'signup') => {
        return type === 'purchase'
            ? <ShoppingCart className="h-4 w-4" />
            : <UserPlus className="h-4 w-4" />;
    };
    
    return (
        <Card>
            <CardContent className="p-0">
                <ul className="divide-y divide-border">
                    {activities.map((activity, index) => (
                        <li key={index} className="flex items-center gap-3 p-3">
                            <div className={`flex items-center justify-center w-8 h-8 rounded-full ${activity.type === 'purchase' ? 'bg-blue-100 dark:bg-blue-900 text-blue-600 dark:text-blue-300' : 'bg-green-100 dark:bg-green-900 text-green-600 dark:text-green-300'}`}>
                                {getIcon(activity.type)}
                            </div>
                            <div className="flex-1 text-sm">
                                <p>{activity.text}</p>
                                <p className="text-xs text-muted-foreground">{activity.time}</p>
                            </div>
                        </li>
                    ))}
                </ul>
            </CardContent>
        </Card>
    );
};