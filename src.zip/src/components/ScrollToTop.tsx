import { useEffect } from 'react';
import { useLocation } from 'react-router-dom';

/**
 * A component that scrolls the window to the top whenever the route changes.
 * This is a common requirement for Single Page Applications (SPAs) to mimic
 * the behavior of traditional websites.
 * 
 * Improved version with smooth scrolling and better behavior.
 */
export const ScrollToTop = () => {
  const { pathname } = useLocation();

  useEffect(() => {
    // Smooth scroll to top when route changes
    window.scrollTo({
      top: 0,
      left: 0,
      behavior: 'smooth'
    });

    // Also scroll main content area if it exists (for dashboard layout)
    const mainContent = document.querySelector('main');
    if (mainContent) {
      mainContent.scrollTo({
        top: 0,
        left: 0,
        behavior: 'smooth'
      });
    }

    // Fallback for browsers that don't support smooth scroll
    // Use setTimeout to ensure smooth scroll works
    const timeoutId = setTimeout(() => {
      window.scrollTo(0, 0);
      if (mainContent) {
        mainContent.scrollTo(0, 0);
      }
    }, 100);

    return () => clearTimeout(timeoutId);
  }, [pathname]); // Effect runs every time the pathname changes

  return null; // This component does not render anything
};
