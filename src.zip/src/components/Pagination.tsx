import { usePagination, DOTS } from '../hooks/usePagination';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { ChevronLeft, ChevronRight, ChevronsLeft, ChevronsRight } from 'lucide-react';

type PaginationProps = {
    currentPage: number;
    totalPages: number;
    totalItems: number;
    itemsPerPage: number;
    onPageChange: (page: number) => void;
    onItemsPerPageChange?: (limit: number) => void;
    itemsPerPageOptions?: number[];
};

export const Pagination = ({
    currentPage,
    totalItems,
    itemsPerPage,
    totalPages,
    onPageChange,
    onItemsPerPageChange,
    itemsPerPageOptions = [10, 20, 50],
}: PaginationProps) => {
    
    const paginationRange = usePagination({
        currentPage,
        totalCount: totalItems,
        pageSize: itemsPerPage,
        siblingCount: 1,
    });
    
    if (currentPage === 0 || totalItems <= itemsPerPage) {
        return null;
    }

    const onNext = () => {
        if (currentPage < totalPages) {
            onPageChange(currentPage + 1);
        }
    };

    const onPrevious = () => {
        if (currentPage > 1) {
            onPageChange(currentPage - 1);
        }
    };
    
    const onFirst = () => {
        onPageChange(1);
    };
    
    const onLast = () => {
        onPageChange(totalPages);
    };

    const startItem = (currentPage - 1) * itemsPerPage + 1;
    const endItem = Math.min(currentPage * itemsPerPage, totalItems);

    return (
        <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between rounded-2xl border-2 bg-card p-4">
            <div className="flex flex-col gap-2 sm:flex-row sm:items-center sm:gap-4">
                <div className="text-sm font-medium text-muted-foreground">
                    Hiển thị <span className="font-semibold text-foreground">{startItem}-{endItem}</span> trên <span className="font-semibold text-foreground">{totalItems}</span>
                </div>
                {onItemsPerPageChange && (
                    <div className="flex items-center gap-2">
                        <span className="text-sm text-muted-foreground">Số mục:</span>
                        <Select
                            value={`${itemsPerPage}`}
                            onValueChange={(value) => onItemsPerPageChange(Number(value))}
                        >
                            <SelectTrigger className="h-8 w-20 rounded-xl">
                                <SelectValue placeholder={itemsPerPage} />
                            </SelectTrigger>
                            <SelectContent className="rounded-2xl">
                                {itemsPerPageOptions.map(option => (
                                    <SelectItem key={option} value={`${option}`} className="rounded-xl">
                                        {option}
                                    </SelectItem>
                                ))}
                            </SelectContent>
                        </Select>
                    </div>
                )}
            </div>
            
            <div className="flex items-center gap-1 sm:gap-2">
                <Button
                    variant="outline"
                    size="icon"
                    onClick={onFirst}
                    disabled={currentPage === 1}
                    className="h-9 w-9 rounded-xl"
                    title="Trang đầu"
                >
                    <ChevronsLeft className="h-4 w-4" />
                </Button>
                <Button
                    variant="outline"
                    size="icon"
                    onClick={onPrevious}
                    disabled={currentPage === 1}
                    className="h-9 w-9 rounded-xl"
                    title="Trang trước"
                >
                    <ChevronLeft className="h-4 w-4" />
                </Button>

                <div className="flex items-center gap-1">
                    {paginationRange?.map((pageNumber, index) => {
                        if (pageNumber === DOTS) {
                            return (
                                <span key={`dots-${index}`} className="px-2 py-1 text-muted-foreground">
                                    &#8230;
                                </span>
                            );
                        }

                        return (
                            <Button
                                key={pageNumber}
                                variant={pageNumber === currentPage ? 'default' : 'outline'}
                                size="icon"
                                onClick={() => onPageChange(pageNumber as number)}
                                className="h-9 w-9 rounded-xl font-medium"
                            >
                                {pageNumber}
                            </Button>
                        );
                    })}
                </div>

                <Button
                    variant="outline"
                    size="icon"
                    onClick={onNext}
                    disabled={currentPage === totalPages}
                    className="h-9 w-9 rounded-xl"
                    title="Trang sau"
                >
                    <ChevronRight className="h-4 w-4" />
                </Button>
                <Button
                    variant="outline"
                    size="icon"
                    onClick={onLast}
                    disabled={currentPage === totalPages}
                    className="h-9 w-9 rounded-xl"
                    title="Trang cuối"
                >
                    <ChevronsRight className="h-4 w-4" />
                </Button>
            </div>
        </div>
    );
};