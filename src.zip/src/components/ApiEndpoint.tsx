import { CodeBlock } from './CodeBlock';
import { Card, CardHeader, CardTitle, CardContent, CardDescription } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';

type ApiEndpointProps = {
    method: 'GET' | 'POST' | 'PUT' | 'DELETE';
    path: string;
    description: string;
    requestBody?: object;
    responseBody?: object;
};

const getMethodVariant = (method: string): 'default' | 'secondary' | 'destructive' | 'outline' => {
    switch (method.toUpperCase()) {
        case 'GET': return 'default';
        case 'POST': return 'secondary';
        case 'PUT': return 'outline';
        case 'DELETE': return 'destructive';
        default: return 'default';
    }
};

export const ApiEndpoint = ({ method, path, description, requestBody, responseBody }: ApiEndpointProps) => {
    return (
        <Card>
            <CardHeader>
                <div className="flex items-center gap-4">
                     <Badge variant={getMethodVariant(method)} className="text-sm font-bold">{method}</Badge>
                    <code className="text-sm font-semibold bg-muted px-2 py-1 rounded">{path}</code>
                </div>
                <CardDescription>{description}</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
                 {requestBody && (
                    <div className="space-y-2">
                        <h4 className="font-semibold">Request Body</h4>
                        <CodeBlock language="json" code={JSON.stringify(requestBody, null, 2)} />
                    </div>
                )}

                {responseBody && (
                    <div className="space-y-2">
                        <h4 className="font-semibold">Example Response</h4>
                        <CodeBlock language="json" code={JSON.stringify(responseBody, null, 2)} />
                    </div>
                )}
            </CardContent>
        </Card>
    );
};
