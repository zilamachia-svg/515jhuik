import { useEffect } from 'react';

interface SEOProps {
    title?: string;
    description?: string;
    keywords?: string;
    image?: string;
    url?: string;
    type?: 'website' | 'article' | 'product';
    structuredData?: object | object[];
    noindex?: boolean;
}

const defaultTitle = 'HẢI ĐĂNG META - Nền tảng dịch vụ meta hàng đầu Việt Nam';
const defaultDescription = 'Nền tảng dịch vụ meta hàng đầu Việt Nam. Mua bán tài khoản, nạp tiền, quản lý đơn hàng và nhiều tính năng khác.';
const defaultImage = '/logo.png';
const siteUrl = import.meta.env.VITE_APP_URL || 'https://haidangmeta.com';

export function SEO({
    title,
    description = defaultDescription,
    keywords = 'hải đăng meta, dịch vụ meta, tài khoản facebook, tài khoản instagram, nạp tiền online',
    image = defaultImage,
    url,
    type = 'website',
    structuredData,
    noindex = false,
}: SEOProps) {
    const fullTitle = title ? `${title} | ${defaultTitle}` : defaultTitle;
    const fullUrl = url ? `${siteUrl}${url}` : siteUrl;
    const fullImage = image.startsWith('http') ? image : `${siteUrl}${image}`;

    useEffect(() => {
        // Update document title
        document.title = fullTitle;

        // Helper function to update or create meta tag
        const updateMetaTag = (property: string, content: string, isProperty = false) => {
            const attribute = isProperty ? 'property' : 'name';
            let element = document.querySelector(`meta[${attribute}="${property}"]`) as HTMLMetaElement;
            
            if (!element) {
                element = document.createElement('meta');
                element.setAttribute(attribute, property);
                document.head.appendChild(element);
            }
            
            element.setAttribute('content', content);
        };

        // Primary Meta Tags
        updateMetaTag('title', fullTitle);
        updateMetaTag('description', description);
        updateMetaTag('keywords', keywords);
        
        if (noindex) {
            updateMetaTag('robots', 'noindex, nofollow');
        } else {
            updateMetaTag('robots', 'index, follow');
        }

        // Canonical URL
        let canonical = document.querySelector('link[rel="canonical"]') as HTMLLinkElement;
        if (!canonical) {
            canonical = document.createElement('link');
            canonical.setAttribute('rel', 'canonical');
            document.head.appendChild(canonical);
        }
        canonical.setAttribute('href', fullUrl);

        // Open Graph / Facebook
        updateMetaTag('og:type', type, true);
        updateMetaTag('og:url', fullUrl, true);
        updateMetaTag('og:title', fullTitle, true);
        updateMetaTag('og:description', description, true);
        updateMetaTag('og:image', fullImage, true);
        updateMetaTag('og:site_name', 'Hải Đăng Meta', true);
        updateMetaTag('og:locale', 'vi_VN', true);

        // Twitter
        updateMetaTag('twitter:card', 'summary_large_image');
        updateMetaTag('twitter:url', fullUrl);
        updateMetaTag('twitter:title', fullTitle);
        updateMetaTag('twitter:description', description);
        updateMetaTag('twitter:image', fullImage);

        // Structured Data (JSON-LD)
        // Remove existing structured data scripts
        const existingScripts = document.querySelectorAll('script[type="application/ld+json"]');
        existingScripts.forEach(script => script.remove());

        // Add new structured data
        if (structuredData) {
            const dataArray = Array.isArray(structuredData) ? structuredData : [structuredData];
            
            dataArray.forEach((data) => {
                const script = document.createElement('script');
                script.type = 'application/ld+json';
                script.text = JSON.stringify(data);
                document.head.appendChild(script);
            });
        }

        // Cleanup function
        return () => {
            // Reset to defaults on unmount (optional)
            document.title = defaultTitle;
        };
    }, [title, description, keywords, image, url, type, structuredData, noindex, fullTitle, fullUrl, fullImage]);

    // This component doesn't render anything
    return null;
}

// Helper function to generate Organization structured data
export function generateOrganizationSchema() {
    return {
        '@context': 'https://schema.org',
        '@type': 'Organization',
        name: 'Hải Đăng Meta',
        url: siteUrl,
        logo: `${siteUrl}/logo.png`,
        description: defaultDescription,
        sameAs: [
            // Add social media links here
            // 'https://www.facebook.com/haidangmeta',
            // 'https://twitter.com/haidangmeta',
        ],
    };
}

// Helper function to generate Product structured data
export function generateProductSchema(product: {
    name: string;
    description: string;
    price: number;
    image?: string;
    url?: string;
}) {
    return {
        '@context': 'https://schema.org',
        '@type': 'Product',
        name: product.name,
        description: product.description,
        image: product.image ? `${siteUrl}${product.image}` : defaultImage,
        offers: {
            '@type': 'Offer',
            price: product.price,
            priceCurrency: 'VND',
            availability: 'https://schema.org/InStock',
        },
        url: product.url ? `${siteUrl}${product.url}` : siteUrl,
    };
}

// Helper function to generate Article structured data
export function generateArticleSchema(article: {
    title: string;
    description: string;
    image?: string;
    publishedTime?: string;
    modifiedTime?: string;
    author?: string;
    url?: string;
}) {
    return {
        '@context': 'https://schema.org',
        '@type': 'Article',
        headline: article.title,
        description: article.description,
        image: article.image ? `${siteUrl}${article.image}` : defaultImage,
        datePublished: article.publishedTime,
        dateModified: article.modifiedTime || article.publishedTime,
        author: {
            '@type': 'Organization',
            name: article.author || 'Hải Đăng Meta',
        },
        publisher: {
            '@type': 'Organization',
            name: 'Hải Đăng Meta',
            logo: {
                '@type': 'ImageObject',
                url: `${siteUrl}/logo.png`,
            },
        },
        url: article.url ? `${siteUrl}${article.url}` : siteUrl,
    };
}

// Helper function to generate BreadcrumbList structured data
export function generateBreadcrumbSchema(items: Array<{ name: string; url: string }>) {
    return {
        '@context': 'https://schema.org',
        '@type': 'BreadcrumbList',
        itemListElement: items.map((item, index) => ({
            '@type': 'ListItem',
            position: index + 1,
            name: item.name,
            item: `${siteUrl}${item.url}`,
        })),
    };
}
