import { useCopyToClipboard } from '../hooks/useCopyToClipboard';
import { Copy, Check } from 'lucide-react';
import { Button } from '@/components/ui/button';

type CodeBlockProps = {
    code: string;
    language?: string;
};

export const CodeBlock = ({ code, language }: CodeBlockProps) => {
    const [copy, isCopied] = useCopyToClipboard();

    return (
        <div className="relative my-4 rounded-lg bg-slate-900 text-white">
            <div className="flex justify-between items-center px-4 py-2 bg-slate-800 text-slate-300 text-xs rounded-t-lg">
                <span>{language}</span>
                <Button 
                    variant="ghost"
                    size="icon"
                    className="h-7 w-7 text-slate-300 hover:bg-slate-700 hover:text-white" 
                    onClick={() => copy(code, 'Đã sao chép code!')}
                    aria-label="Sao chép code"
                >
                    {isCopied ? <Check size={16} /> : <Copy size={16} />}
                </Button>
            </div>
            <pre className="p-4 text-sm rounded-b-lg overflow-x-auto">
                <code className={`language-${language}`}>
                    {code.trim()}
                </code>
            </pre>
        </div>
    );
};
