import React from 'react';
import { cn } from '../lib/utils';

type TimelineItemProps = {
    icon: React.ReactNode;
    title: string;
    timestamp: string;
    isLast: boolean;
};

const TimelineItem: React.FC<TimelineItemProps> = ({ icon, title, timestamp, isLast }) => {
    return (
        <li className="relative flex gap-4">
            <div className={cn(
                "absolute left-0 top-0 h-full w-0.5 bg-border -translate-x-1/2",
                isLast && "hidden"
            )}></div>
            <div className="relative z-10 flex h-7 w-7 items-center justify-center rounded-full bg-background border">
                {icon}
            </div>
            <div className="flex-1 space-y-1 pb-4">
                <p className="text-base font-semibold text-white">{title}</p>
                <p className="text-sm font-medium text-white/90">{timestamp}</p>
            </div>
        </li>
    );
};

type TimelineProps = {
    items: {
        icon: React.ReactNode;
        title: string;
        timestamp: string;
    }[];
};

export const Timeline: React.FC<TimelineProps> = ({ items }) => {
    if (!items || items.length === 0) {
        return <p className="text-muted-foreground text-sm">No recent activities.</p>;
    }

    return (
        <ul>
            {items.map((item, index) => (
                <TimelineItem
                    key={index}
                    icon={item.icon}
                    title={item.title}
                    timestamp={item.timestamp}
                    isLast={index === items.length - 1}
                />
            ))}
        </ul>
    );
};
