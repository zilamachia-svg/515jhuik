import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { ArrowRight, FileText, HelpCircle, Shield, BookOpen, MessageSquare, Newspaper, Info } from 'lucide-react';
import { PATHS } from '../constants/paths';

interface Article {
    id: string;
    title: string;
    description: string;
    category: 'policy' | 'terms' | 'warranty' | 'faq' | 'guide' | 'announcement';
    path: string;
    icon: React.ReactNode;
    badge?: string;
}

const articles: Article[] = [
    {
        id: 'terms',
        title: 'Điều khoản sử dụng',
        description: 'Quy định và điều khoản khi sử dụng dịch vụ của chúng tôi',
        category: 'terms',
        path: PATHS.TERMS,
        icon: <FileText className="h-5 w-5" />,
        badge: 'Quan trọng',
    },
    {
        id: 'policy',
        title: 'Chính sách bảo mật',
        description: 'Cam kết bảo vệ thông tin cá nhân và dữ liệu của khách hàng',
        category: 'policy',
        path: PATHS.PRIVACY_POLICY,
        icon: <Shield className="h-5 w-5" />,
    },
    {
        id: 'warranty',
        title: 'Chính sách bảo hành',
        description: 'Quy định về bảo hành và đổi trả sản phẩm',
        category: 'warranty',
        path: PATHS.WARRANTY,
        icon: <Shield className="h-5 w-5" />,
    },
    {
        id: 'conditions',
        title: 'Điều kiện giao dịch',
        description: 'Các điều kiện và quy trình thực hiện giao dịch',
        category: 'terms',
        path: PATHS.CONDITIONS,
        icon: <BookOpen className="h-5 w-5" />,
    },
    {
        id: 'faq',
        title: 'Câu hỏi thường gặp',
        description: 'Giải đáp các thắc mắc phổ biến của khách hàng',
        category: 'faq',
        path: PATHS.FAQ,
        icon: <HelpCircle className="h-5 w-5" />,
    },
    {
        id: 'guide',
        title: 'Hướng dẫn sử dụng',
        description: 'Hướng dẫn chi tiết cách sử dụng các tính năng',
        category: 'guide',
        path: PATHS.GUIDE,
        icon: <BookOpen className="h-5 w-5" />,
    },
];

const categoryColors = {
    policy: 'bg-blue-500/10 text-blue-600 border-blue-500/20',
    terms: 'bg-purple-500/10 text-purple-600 border-purple-500/20',
    warranty: 'bg-green-500/10 text-green-600 border-green-500/20',
    faq: 'bg-orange-500/10 text-orange-600 border-orange-500/20',
    guide: 'bg-indigo-500/10 text-indigo-600 border-indigo-500/20',
    announcement: 'bg-red-500/10 text-red-600 border-red-500/20',
};

export function BannerContent() {
    return (
        <div className="mt-6 grid grid-cols-1 gap-3 md:grid-cols-2 lg:grid-cols-3">
            {articles.map((article, index) => (
                <motion.div
                    key={article.id}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.3, delay: index * 0.1 }}
                    whileHover={{ scale: 1.02, y: -5 }}
                >
                    <Card className="group h-full overflow-hidden rounded-2xl border-2 transition-all duration-300 hover:border-primary/50 hover:shadow-lg">
                        <CardContent className="p-4">
                            <div className="flex items-start gap-3">
                                <div className={`flex h-10 w-10 items-center justify-center rounded-xl ${categoryColors[article.category]}`}>
                                    {article.icon}
                                </div>
                                <div className="flex-1 space-y-2">
                                    <div className="flex items-center gap-2">
                                        <h3 className="font-semibold text-sm leading-tight">{article.title}</h3>
                                        {article.badge && (
                                            <Badge variant="outline" className="rounded-full text-xs">
                                                {article.badge}
                                            </Badge>
                                        )}
                                    </div>
                                    <p className="text-xs text-muted-foreground line-clamp-2">{article.description}</p>
                                    <Button
                                        variant="ghost"
                                        size="sm"
                                        className="h-7 rounded-xl text-xs"
                                        asChild
                                    >
                                        <Link to={article.path}>
                                            Xem chi tiết <ArrowRight className="ml-1 h-3 w-3" />
                                        </Link>
                                    </Button>
                                </div>
                            </div>
                        </CardContent>
                    </Card>
                </motion.div>
            ))}
        </div>
    );
}

