import React from 'react';

type PageHeaderProps = {
    title: string;
};

// Simplified to just an h3 to fit inside panels
export const PageHeader = React.memo(({ title }: PageHeaderProps) => {
    return (
        <h3>{title}</h3>
    );
});

PageHeader.displayName = 'PageHeader';