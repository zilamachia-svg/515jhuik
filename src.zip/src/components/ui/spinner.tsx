import React from 'react';
import { Loader2 } from 'lucide-react';
import { cn } from '@/lib/utils';

// FIX: Changed interface to a type alias to fix prop type issues, consistent with other UI components.
type SpinnerProps = React.SVGAttributes<SVGSVGElement>;

export const Spinner = ({ className, ...props }: SpinnerProps) => {
    return (
        <Loader2 className={cn('animate-spin', className)} {...props} />
    );
};