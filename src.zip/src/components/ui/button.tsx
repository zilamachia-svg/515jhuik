import * as React from "react"
import { Slot } from "@radix-ui/react-slot"
import { cva, type VariantProps } from "class-variance-authority"

import { cn } from "@/lib/utils"

const buttonVariants = cva(
  "inline-flex items-center justify-center whitespace-nowrap rounded-2xl text-sm font-semibold ring-offset-background transition-all duration-200 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50",
  {
    variants: {
      variant: {
        default: "bg-gradient-to-r from-blue-500/90 to-blue-400/90 text-white shadow-lg shadow-blue-500/20 hover:-translate-y-0.5 hover:shadow-xl hover:shadow-blue-500/30 active:translate-y-0 dark:from-primary dark:to-blue-500/90 dark:shadow-primary/20 dark:hover:shadow-primary/30",
        destructive:
          "bg-gradient-to-r from-red-500/90 to-red-400/90 text-white shadow-lg shadow-red-500/20 hover:-translate-y-0.5 hover:shadow-xl hover:shadow-red-500/30 active:translate-y-0",
        outline:
          "border-2 border-white/60 bg-white/50 text-foreground shadow-sm backdrop-blur-sm hover:-translate-y-0.5 hover:border-white/80 hover:bg-white/70 hover:shadow-lg dark:border-slate-700/60 dark:bg-slate-800/50 dark:text-foreground dark:hover:bg-slate-800/70",
        secondary:
          "bg-gradient-to-r from-slate-100/90 to-slate-200/90 text-slate-800 shadow-sm hover:-translate-y-0.5 hover:shadow-md dark:from-slate-700/80 dark:to-slate-600/80 dark:text-slate-100",
        ghost: "hover:bg-white/60 hover:text-foreground hover:shadow-sm dark:hover:bg-slate-800/60",
        link: "text-primary underline-offset-4 hover:underline",
      },
      size: {
        default: "h-10 px-4 py-2",
        sm: "h-9 rounded-xl px-3 text-xs",
        lg: "h-12 rounded-2xl px-8 text-base",
        icon: "h-10 w-10",
      },
    },
    defaultVariants: {
      variant: "default",
      size: "default",
    },
  }
)

// FIX: Changed interface to type to fix issue where VariantProps were not being correctly applied.
export type ButtonProps = React.ButtonHTMLAttributes<HTMLButtonElement> &
  VariantProps<typeof buttonVariants> & {
    asChild?: boolean
  }

const Button = React.forwardRef<HTMLButtonElement, ButtonProps>(
  ({ className, variant, size, asChild = false, ...props }, ref) => {
    const Comp = asChild ? Slot : "button"
    return (
      <Comp
        className={cn(buttonVariants({ variant, size, className }))}
        ref={ref}
        {...props}
      />
    )
  }
)
Button.displayName = "Button"

export { Button, buttonVariants }