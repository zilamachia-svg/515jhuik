import * as React from "react"
import { cva, type VariantProps } from "class-variance-authority"

import { cn } from "@/lib/utils"

const badgeVariants = cva(
  "inline-flex items-center rounded-full border px-3 py-1 text-xs font-semibold shadow-sm transition-all duration-200 focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2",
  {
    variants: {
      variant: {
        default:
          "border-transparent bg-gradient-to-r from-primary to-purple-600 text-white shadow-primary/30 hover:shadow-primary/40",
        secondary:
          "border-transparent bg-gradient-to-r from-slate-100 to-slate-200 text-slate-900 hover:shadow-md dark:from-slate-800 dark:to-slate-700 dark:text-slate-100",
        destructive:
          "border-transparent bg-gradient-to-r from-red-600 to-red-700 text-white shadow-red-500/30 hover:shadow-red-500/40",
        outline: "border-white/70 bg-white/60 text-foreground backdrop-blur-sm dark:border-slate-800/70 dark:bg-slate-800/60",
      },
    },
    defaultVariants: {
      variant: "default",
    },
  }
)

// FIX: Changed interface to type to fix issue where VariantProps were not being correctly applied.
export type BadgeProps = React.HTMLAttributes<HTMLDivElement> &
  VariantProps<typeof badgeVariants>

function Badge({ className, variant, ...props }: BadgeProps) {
  return (
    <div className={cn(badgeVariants({ variant }), className)} {...props} />
  )
}

export { Badge, badgeVariants }