import React, { useState } from 'react';
import { Product } from '../types';
import { formatCurrency } from '../utils';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';

type ProductDetailModalProps = {
    product: Product;
    onClose: () => void;
    onBuy: (product: Product, quantity: number) => void;
};

export const ProductDetailModal = ({ product, onClose, onBuy }: ProductDetailModalProps) => {
    const [quantity, setQuantity] = useState(1);

    const handleBuyClick = () => {
        onBuy(product, quantity);
        onClose(); // Close details modal after clicking buy
    };
    
    const handleQuantityChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        let value = parseInt(e.target.value, 10);
        if (isNaN(value) || value < 1) {
            value = 1;
        }
        if (value > product.stock) {
            value = product.stock;
        }
        setQuantity(value);
    };

    const totalPrice = product.price * quantity;

    return (
        <Dialog open={true} onOpenChange={onClose}>
            <DialogContent className="sm:max-w-2xl">
                <DialogHeader>
                    <DialogTitle>{product.name}</DialogTitle>
                </DialogHeader>
                 <div className="grid grid-cols-1 md:grid-cols-2 gap-6 py-4">
                    <div className="flex flex-col items-center justify-center bg-accent/20 p-6 rounded-lg text-center">
                        <img 
                            src={`https://flagcdn.com/w80/${product.country.toLowerCase()}.png`} 
                            alt={product.country} 
                            className="mb-4"
                        />
                        <h3 className="text-lg font-semibold">{product.name}</h3>
                        <p className="text-sm text-muted-foreground">{product.category}</p>
                    </div>
                    <div className="space-y-4">
                        <div>
                            <h4 className="font-semibold mb-1">Mô tả</h4>
                            <p className="text-sm text-muted-foreground">{product.description}</p>
                        </div>
                        <div className="grid grid-cols-2 gap-2 text-sm pt-4 border-t">
                            <div>
                                <p className="text-muted-foreground">Quốc gia</p>
                                <p className="font-semibold">{product.country}</p>
                            </div>
                             <div>
                                <p className="text-muted-foreground">Tồn kho</p>
                                <p className="font-semibold">{product.stock > 0 ? product.stock.toLocaleString('vi-VN') : 'Hết hàng'}</p>
                            </div>
                        </div>
                        <div className="pt-4 border-t">
                             <h4 className="font-semibold mb-2">Mua nhanh</h4>
                             <div className="grid grid-cols-2 gap-4 items-end">
                                <div>
                                    <Label htmlFor="quantity-modal">Số lượng</Label>
                                    <Input
                                        id="quantity-modal"
                                        type="number"
                                        value={quantity}
                                        onChange={handleQuantityChange}
                                        min="1"
                                        max={product.stock}
                                        disabled={product.stock === 0}
                                    />
                                </div>
                                <div className="text-right">
                                     <p className="text-sm text-muted-foreground">Tổng cộng</p>
                                     <p className="text-2xl font-bold text-primary">{formatCurrency(totalPrice)}</p>
                                </div>
                             </div>
                        </div>
                    </div>
                </div>
                <DialogFooter>
                     <Button variant="outline" onClick={onClose}>
                        Đóng
                    </Button>
                    <Button
                        onClick={handleBuyClick}
                        disabled={product.stock === 0 || quantity <= 0}
                    >
                        {product.stock > 0 ? 'Mua ngay' : 'Hết hàng'}
                    </Button>
                </DialogFooter>
            </DialogContent>
        </Dialog>
    );
};