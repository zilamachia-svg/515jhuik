import React from 'react';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog"
import { Button } from "@/components/ui/button";

type ConfirmationModalProps = {
    title: string;
    message: string;
    confirmText?: string;
    cancelText?: string;
    onConfirm: () => void;
    onCancel?: () => void;
    isDestructive?: boolean;
    showCancel?: boolean;
    children?: React.ReactNode;
    isConfirming?: boolean;
};

export const ConfirmationModal = ({
    title,
    message,
    confirmText = 'Confirm',
    cancelText = 'Cancel',
    onConfirm,
    onCancel,
    isDestructive = false,
    showCancel = true,
    children,
    isConfirming = false,
}: ConfirmationModalProps) => {

    const handleCancel = () => {
        if (!isConfirming && onCancel) {
            onCancel();
        }
    };

    return (
        <AlertDialog open={true} onOpenChange={handleCancel}>
            <AlertDialogContent>
                <AlertDialogHeader>
                    <AlertDialogTitle>{title}</AlertDialogTitle>
                    <AlertDialogDescription>
                        {message}
                    </AlertDialogDescription>
                </AlertDialogHeader>
                {children && <div className="py-4">{children}</div>}
                <AlertDialogFooter>
                    {showCancel && <AlertDialogCancel disabled={isConfirming}>{cancelText}</AlertDialogCancel>}
                    <AlertDialogAction asChild>
                        <Button 
                            variant={isDestructive ? 'destructive' : 'default'}
                            onClick={onConfirm}
                            disabled={isConfirming}
                        >
                            {confirmText}
                        </Button>
                    </AlertDialogAction>
                </AlertDialogFooter>
            </AlertDialogContent>
        </AlertDialog>
    );
};
