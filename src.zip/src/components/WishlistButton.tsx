/**
 * Wishlist Button Component
 * Heart icon button to add/remove products from wishlist
 */

import { Heart } from 'lucide-react';
import { Button } from './ui/button';
import { cn } from '../lib/utils';
import { useWishlist } from '../hooks/useWishlist';

interface WishlistButtonProps {
  productId: number;
  productName?: string;
  variant?: 'default' | 'icon' | 'ghost';
  size?: 'sm' | 'md' | 'lg' | 'icon';
  className?: string;
  showLabel?: boolean;
}

export const WishlistButton = ({
  productId,
  productName,
  variant = 'ghost',
  size = 'icon',
  className,
  showLabel = false,
}: WishlistButtonProps) => {
  const { isInWishlist, toggleWishlist, isLoading } = useWishlist();
  const inWishlist = isInWishlist(productId);

  const handleClick = async (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    await toggleWishlist(productId, productName);
  };

  return (
    <Button
      variant={variant as any}
      size={size as any}
      onClick={handleClick}
      disabled={isLoading}
      className={cn(
        'transition-all duration-200',
        inWishlist && 'text-red-500 hover:text-red-600',
        className
      )}
      title={inWishlist ? 'Xóa khỏi yêu thích' : 'Thêm vào yêu thích'}
    >
      <Heart
        className={cn(
          'h-5 w-5 transition-all',
          inWishlist && 'fill-red-500'
        )}
      />
      {showLabel && (
        <span className="ml-2">
          {inWishlist ? 'Đã lưu' : 'Lưu'}
        </span>
      )}
    </Button>
  );
};

// Wishlist Badge - shows count
export const WishlistBadge = ({ className }: { className?: string }) => {
  const { count } = useWishlist();

  if (count === 0) return null;

  return (
    <span className={cn(
      'absolute -top-1 -right-1 bg-red-500 text-white text-xs rounded-full h-5 w-5 flex items-center justify-center',
      className
    )}>
      {count > 9 ? '9+' : count}
    </span>
  );
};
