import { useState, useEffect } from 'react';
import { toast } from 'sonner';
import { Order, ApiError } from '../types';
import apiClient from '../services/apiClient';
import { formatCurrency, formatApiErrorForToast } from '../utils';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogDescription } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Spinner } from '@/components/ui/spinner';
import { Textarea } from '@/components/ui/textarea';
import { Download, Copy, Check } from 'lucide-react';
import { useCopyToClipboard } from '../hooks/useCopyToClipboard';

type UserOrderDetailModalProps = {
    order: Order;
    onClose: () => void;
};

export const UserOrderDetailModal = ({ order, onClose }: UserOrderDetailModalProps) => {
    const [details, setDetails] = useState<Order | null>(null);
    const [isLoading, setIsLoading] = useState(true);
    const [orderData, setOrderData] = useState<string>('');
    const [copy, isCopied] = useCopyToClipboard();

    useEffect(() => {
        const fetchDetails = async () => {
            setIsLoading(true);
            try {
                const response = await apiClient.get(`/orders/${order.id}`);
                const orderDetails = response.data.order || response.data;
                setDetails(orderDetails);
                
                // Fetch order data for download
                if (orderDetails.items && orderDetails.items.length > 0) {
                    const dataText = orderDetails.items.map((item: { data: string }) => item.data).join('\n');
                    setOrderData(dataText);
                } else {
                    // Try to fetch from download endpoint
                    try {
                        const downloadResponse = await apiClient.get(`/orders/${order.id}/download`, {
                            responseType: 'text',
                        });
                        setOrderData(typeof downloadResponse.data === 'string' ? downloadResponse.data : '');
                    } catch (e) {
                        // If download endpoint doesn't exist, use order info
                        setOrderData(`Đơn hàng #${order.id}\nSản phẩm: ${order.productName}\nSố lượng: ${order.quantity}\nTổng tiền: ${formatCurrency(order.totalPrice)}\nNgày mua: ${new Date(order.purchaseDate).toLocaleString('vi-VN')}`);
                    }
                }
            } catch (error) {
                toast.error(formatApiErrorForToast(error as ApiError, 'Không thể tải chi tiết đơn hàng.'));
            } finally {
                setIsLoading(false);
            }
        };
        fetchDetails();
    }, [order.id, order.productName, order.quantity, order.totalPrice, order.purchaseDate]);

    const handleDownload = () => {
        if (!orderData) {
            toast.error('Không có dữ liệu để tải xuống');
            return;
        }
        
        const blob = new Blob([orderData], { type: 'text/plain;charset=utf-8' });
        const url = URL.createObjectURL(blob);
        const link = document.createElement('a');
        link.href = url;
        link.setAttribute('download', `don-hang-${order.id}.txt`);
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
        URL.revokeObjectURL(url);
        toast.success('Đã bắt đầu tải xuống!');
    };

    const handleCopy = () => {
        if (!orderData) {
            toast.error('Không có dữ liệu để sao chép');
            return;
        }
        copy(orderData, 'Đã sao chép dữ liệu đơn hàng!');
    };

    const purchasedItemsText = details?.items?.map(item => item.data).join('\n') || orderData;

    return (
        <Dialog open={true} onOpenChange={onClose}>
            <DialogContent className="max-w-2xl">
                <DialogHeader>
                    <DialogTitle>Chi tiết đơn hàng #{order.id}</DialogTitle>
                    <DialogDescription>
                        {order.productName}
                    </DialogDescription>
                </DialogHeader>
                {isLoading ? (
                    <div className="flex justify-center py-8"><Spinner /></div>
                ) : details ? (
                    <div className="space-y-4 py-4">
                        <div className="grid grid-cols-2 gap-4 text-sm">
                            <div>
                                <p className="text-muted-foreground">Số lượng</p>
                                <p className="font-semibold">{details.quantity}</p>
                            </div>
                            <div>
                                <p className="text-muted-foreground">Tổng tiền</p>
                                <p className="font-semibold text-primary">{formatCurrency(details.totalPrice)}</p>
                            </div>
                            <div>
                                <p className="text-muted-foreground">Ngày mua</p>
                                <p className="font-semibold">{new Date(details.purchaseDate).toLocaleString('vi-VN')}</p>
                            </div>
                            <div>
                                <p className="text-muted-foreground">Trạng thái</p>
                                <p className="font-semibold">{details.status}</p>
                            </div>
                        </div>
                        <div className="space-y-3">
                            <div className="flex items-center justify-between">
                                <h4 className="font-semibold">Dữ liệu đã mua</h4>
                                <div className="flex gap-2">
                                    <Button variant="outline" size="sm" onClick={handleCopy} className="rounded-xl">
                                        {isCopied ? <Check className="h-4 w-4 mr-2" /> : <Copy className="h-4 w-4 mr-2" />}
                                        Sao chép
                                    </Button>
                                    <Button variant="default" size="sm" onClick={handleDownload} className="rounded-xl">
                                        <Download className="h-4 w-4 mr-2" />
                                        Tải về
                                    </Button>
                                </div>
                            </div>
                            <Textarea
                                readOnly
                                value={purchasedItemsText}
                                rows={12}
                                className="font-mono text-xs rounded-xl"
                            />
                        </div>
                    </div>
                ) : (
                    <p>Không có dữ liệu chi tiết.</p>
                )}
                <DialogFooter>
                    <Button variant="outline" onClick={onClose} className="rounded-xl">Đóng</Button>
                </DialogFooter>
            </DialogContent>
        </Dialog>
    );
};

