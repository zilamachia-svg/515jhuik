import { useState, useEffect } from 'react';
import { useFilters, MAX_PRICE } from '../contexts/FilterContext';
import { fetchProductFilterOptions } from '../services/productService';
import { useLanguage } from '../contexts/LanguageContext';
import { useDebounce } from '../hooks/useDebounce';
import { formatCurrency } from '../utils';

import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Switch } from '@/components/ui/switch';
import { Button } from '@/components/ui/button';
import { Slider } from '@/components/ui/slider';
import { FilterCardSkeleton } from './skeletons/FilterCardSkeleton';

export const FilterSidebar = () => {
    const { t } = useLanguage();
    const { filters, dispatch } = useFilters();
    const [filterOptions, setFilterOptions] = useState<{ countries: string[], categories: string[] }>({ countries: [], categories: [] });
    const [isLoading, setIsLoading] = useState(true);
    
    // Local state for the slider to provide a smooth UX
    const [priceRange, setPriceRange] = useState([filters.priceMin, filters.priceMax]);
    const debouncedPriceRange = useDebounce(priceRange, 500);

    // Effect to fetch filter options on mount
    useEffect(() => {
        const loadOptions = async () => {
            setIsLoading(true);
            try {
                const { uniqueCountries, uniqueCategories } = await fetchProductFilterOptions();
                setFilterOptions({ countries: uniqueCountries, categories: uniqueCategories });
            } catch (error) {
                console.error("Failed to load filter options", error);
            } finally {
                setIsLoading(false);
            }
        };
        loadOptions();
    }, []);

    // Effect to update the global state when the debounced price range changes
    useEffect(() => {
        dispatch({ type: 'SET_PRICE_RANGE', payload: { min: debouncedPriceRange[0], max: debouncedPriceRange[1] } });
    }, [debouncedPriceRange, dispatch]);
    
    // Effect to sync the local slider state if the global filters are reset
    useEffect(() => {
        setPriceRange([filters.priceMin, filters.priceMax]);
    }, [filters.priceMin, filters.priceMax]);

    const handleReset = () => {
        dispatch({ type: 'RESET_FILTERS' });
    };

    if (isLoading) {
        return <Card><CardContent className="pt-6"><FilterCardSkeleton /></CardContent></Card>;
    }

    return (
        <Card>
            <CardHeader>
                <CardTitle>{t('storePage.filtersTitle')}</CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
                <div className="space-y-2">
                    <Label htmlFor="category-select">{t('storePage.category')}</Label>
                    <Select value={filters.category} onValueChange={(value) => dispatch({ type: 'SET_CATEGORY', payload: value })}>
                        <SelectTrigger id="category-select"><SelectValue /></SelectTrigger>
                        <SelectContent>
                            <SelectItem value="all">{t('common.all')}</SelectItem>
                            {filterOptions.categories.map(cat => <SelectItem key={cat} value={cat}>{cat}</SelectItem>)}
                        </SelectContent>
                    </Select>
                </div>
                 <div className="space-y-2">
                    <Label htmlFor="country-select">{t('storePage.country')}</Label>
                    <Select value={filters.country} onValueChange={(value) => dispatch({ type: 'SET_COUNTRY', payload: value })}>
                        <SelectTrigger id="country-select"><SelectValue /></SelectTrigger>
                        <SelectContent>
                            <SelectItem value="all">{t('common.all')}</SelectItem>
                            {filterOptions.countries.map(c => <SelectItem key={c} value={c}>{c}</SelectItem>)}
                        </SelectContent>
                    </Select>
                </div>
                <div className="space-y-4">
                    <Label>{t('filter.priceRange')}</Label>
                    <Slider
                        value={priceRange}
                        onValueChange={setPriceRange}
                        max={MAX_PRICE}
                        step={10000}
                        minStepsBetweenThumbs={1}
                    />
                    <div className="flex justify-between text-sm text-muted-foreground">
                        <span>{formatCurrency(priceRange[0])}</span>
                        <span>{formatCurrency(priceRange[1] === MAX_PRICE ? MAX_PRICE : priceRange[1])}</span>
                    </div>
                </div>
                <div className="space-y-2">
                    <Label htmlFor="sortby-select">{t('storePage.sortBy')}</Label>
                    <Select value={filters.sortBy} onValueChange={(value) => dispatch({ type: 'SET_SORT_BY', payload: value })}>
                        <SelectTrigger id="sortby-select"><SelectValue /></SelectTrigger>
                        <SelectContent>
                            <SelectItem value="default">{t('storePage.sort.default')}</SelectItem>
                            <SelectItem value="price_asc">{t('storePage.sort.priceAsc')}</SelectItem>
                            <SelectItem value="price_desc">{t('storePage.sort.priceDesc')}</SelectItem>
                            <SelectItem value="stock_desc">{t('storePage.sort.stockDesc')}</SelectItem>
                        </SelectContent>
                    </Select>
                </div>
                <div className="flex items-center space-x-2">
                    <Switch
                        id="in-stock-only"
                        checked={filters.inStockOnly}
                        onCheckedChange={() => dispatch({ type: 'TOGGLE_IN_STOCK' })}
                    />
                    <Label htmlFor="in-stock-only">{t('storePage.inStockOnly')}</Label>
                </div>
                 <Button variant="outline" className="w-full" onClick={handleReset}>
                    {t('common.resetFilters')}
                </Button>
            </CardContent>
        </Card>
    );
};