import React from 'react';

const CircularProgress = () => {
    return null;
};

export default CircularProgress;
