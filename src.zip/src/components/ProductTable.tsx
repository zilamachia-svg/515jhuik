import React from 'react';
import { Product } from '../types';
import { formatCurrency } from '../utils';
import { Button } from '@/components/ui/button';
// import { Badge } from '@/components/ui/badge'; // Unused
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { ShoppingCart, Eye } from 'lucide-react';
import { cn } from '@/lib/utils';

interface ProductTableProps {
    products: Product[];
    onBuy: (product: Product, quantity?: number) => void;
    onViewDetails: (product: Product) => void;
}

// ✅ Memoize component to prevent unnecessary re-renders
export const ProductTable = React.memo(({ products, onBuy }: ProductTableProps) => {
    return (
        <div className="w-full overflow-x-auto">
            <Table>
                <TableHeader>
                    <TableRow>
                        <TableHead className="w-[40%]">Tên dịch vụ</TableHead>
                        <TableHead className="w-[15%]">Quốc gia</TableHead>
                        <TableHead className="w-[15%]">Số lượng</TableHead>
                        <TableHead className="w-[15%]">Số tiền</TableHead>
                        <TableHead className="w-[15%]">Thao tác</TableHead>
                    </TableRow>
                </TableHeader>
                <TableBody>
                    {products.length === 0 ? (
                        <TableRow>
                            <TableCell colSpan={5} className="text-center py-8 text-muted-foreground">
                                Không có sản phẩm nào
                            </TableCell>
                        </TableRow>
                    ) : (
                        products.map((product) => (
                            <TableRow key={product.id} className="hover:bg-muted/50">
                            <TableCell>
                                <div className="space-y-1">
                                    <div className="flex items-center gap-2">
                                        {/* Logo/Icon based on category */}
                                        {product.category?.toLowerCase().includes('gmail') && (
                                            <div className="flex items-center justify-center w-8 h-8 rounded bg-gradient-to-br from-red-500 to-blue-500 text-white font-bold text-xs">
                                                M
                                            </div>
                                        )}
                                        {product.category?.toLowerCase().includes('hotmail') && (
                                            <div className="flex items-center justify-center w-8 h-8 rounded bg-blue-500 text-white">
                                                <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 20 20">
                                                    <path d="M2.003 5.884L10 9.882l7.997-3.998A2 2 0 0016 4H4a2 2 0 00-1.997 1.884z" />
                                                    <path d="M18 8.118l-8 4-8-4V14a2 2 0 002 2h12a2 2 0 002-2V8.118z" />
                                                </svg>
                                            </div>
                                        )}
                                        {product.category?.toLowerCase().includes('facebook') && (
                                            <div className="flex items-center justify-center w-8 h-8 rounded bg-blue-600 text-white font-bold">
                                                f
                                            </div>
                                        )}
                                        <div className="flex-1 min-w-0">
                                            <p className="font-semibold text-sm truncate" title={product.name}>
                                                {product.name}
                                            </p>
                                        </div>
                                    </div>
                                    {/* 2 dòng mô tả */}
                                    <p className="text-xs text-muted-foreground line-clamp-2" title={product.description}>
                                        {product.description || `${product.name} - Chưa Qua Dịch Vụ`}
                                    </p>
                                </div>
                            </TableCell>
                            <TableCell>
                                <div className="flex items-center gap-2">
                                    <img 
                                        src={`https://flagcdn.com/w20/${product.country?.toLowerCase() || 'us'}.png`} 
                                        alt={product.country || 'US'} 
                                        className="w-5 h-4 object-cover rounded"
                                        onError={(e) => {
                                            e.currentTarget.style.display = 'none';
                                        }}
                                    />
                                    <span className="text-sm">{product.country || 'US'}</span>
                                </div>
                            </TableCell>
                            <TableCell>
                                <div className="flex items-center gap-2">
                                    <ShoppingCart className="w-4 h-4 text-muted-foreground" />
                                    <span className={cn(
                                        "text-sm font-medium",
                                        product.stock === 0 ? "text-destructive" : "text-foreground"
                                    )}>
                                        {product.stock}
                                    </span>
                                </div>
                            </TableCell>
                            <TableCell>
                                <div className="flex items-center gap-2">
                                    <Eye className="w-4 h-4 text-muted-foreground" />
                                    <span className="text-sm font-bold text-green-600 dark:text-green-400">
                                        {formatCurrency(product.price)}
                                    </span>
                                </div>
                            </TableCell>
                            <TableCell>
                                {product.stock > 0 ? (
                                    <Button
                                        size="sm"
                                        onClick={() => onBuy(product)}
                                        className="rounded-full"
                                    >
                                        <ShoppingCart className="w-4 h-4 mr-1" />
                                        Mua ngay
                                    </Button>
                                ) : (
                                    <Button
                                        size="sm"
                                        variant="outline"
                                        disabled
                                        className="rounded-full"
                                    >
                                        <span className="mr-1">😢</span>
                                        Hết hàng
                                    </Button>
                                )}
                            </TableCell>
                        </TableRow>
                        ))
                    )}
                </TableBody>
            </Table>
        </div>
    );
}, (prevProps, nextProps) => {
    // Custom comparison function for React.memo
    // Only re-render if products array changes or callbacks change
    if (prevProps.products.length !== nextProps.products.length) {
        return false; // Re-render
    }
    
    // Check if any product changed
    for (let i = 0; i < prevProps.products.length; i++) {
        if (prevProps.products[i].id !== nextProps.products[i].id ||
            prevProps.products[i].stock !== nextProps.products[i].stock ||
            prevProps.products[i].price !== nextProps.products[i].price) {
            return false; // Re-render
        }
    }
    
    return true; // Skip re-render
});

ProductTable.displayName = 'ProductTable';

