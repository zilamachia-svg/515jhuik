
export const FilterCardSkeleton = () => {
    return (
        <div className="space-y-6 animate-pulse">
            <div className="form-group">
                <div className="h-4 bg-slate-700 rounded w-1/3 mb-2"></div>
                <div className="h-10 bg-slate-700 rounded-lg w-full"></div>
            </div>
            <div className="form-group">
                <div className="h-4 bg-slate-700 rounded w-1/3 mb-2"></div>
                <div className="h-10 bg-slate-700 rounded-lg w-full"></div>
            </div>
            <div className="form-group">
                <div className="h-4 bg-slate-700 rounded w-1/3 mb-2"></div>
                <div className="h-10 bg-slate-700 rounded-lg w-full"></div>
            </div>
        </div>
    );
};