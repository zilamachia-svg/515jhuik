import React from 'react';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Skeleton } from '@/components/ui/skeleton';

type TableSkeletonProps = {
    headers: string[];
    rows?: number;
};

export const TableSkeleton = ({ headers, rows = 5 }: TableSkeletonProps) => {
    return (
        <Table>
            <TableHeader>
                <TableRow>
                    {headers.map((_, index) => (
                        <TableHead key={index}><Skeleton className="h-5 w-24" /></TableHead>
                    ))}
                </TableRow>
            </TableHeader>
            <TableBody>
                {Array.from({ length: rows }).map((_, rowIndex) => (
                    <TableRow key={rowIndex}>
                        {headers.map((_, colIndex) => (
                            <TableCell key={colIndex}><Skeleton className="h-5 w-full" /></TableCell>
                        ))}
                    </TableRow>
                ))}
            </TableBody>
        </Table>
    );
};
