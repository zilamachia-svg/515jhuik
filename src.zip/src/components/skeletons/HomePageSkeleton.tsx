import { ProductItemSkeleton } from './ProductItemSkeleton';

export const HomePageSkeleton = () => {
    return (
        <div className="homepage-container skeleton">
            <section className="hero-section">
                <div className="skeleton-element" style={{ height: '48px', width: '60%', margin: '0 auto 1rem' }}></div>
                <div className="skeleton-element" style={{ height: '20px', width: '80%', margin: '0 auto 1.5rem' }}></div>
                <div className="skeleton-element skeleton-button" style={{ height: '48px', width: '180px', margin: '0 auto' }}></div>
            </section>

            <section className="featured-products-section">
                <div className="skeleton-element" style={{ height: '36px', width: '300px', marginBottom: '2rem' }}></div>
                <div className="featured-products-grid">
                    {Array.from({ length: 4 }).map((_, index) => (
                        <ProductItemSkeleton key={index} />
                    ))}
                </div>
            </section>
            
            <div className="homepage-grid">
                <section>
                    <div className="skeleton-element" style={{ height: '32px', width: '250px', marginBottom: '1.5rem' }}></div>
                    <div className="testimonials-grid">
                         <div className="card skeleton-element" style={{ height: '200px' }}></div>
                         <div className="card skeleton-element" style={{ height: '200px' }}></div>
                    </div>
                </section>
                <section>
                    <div className="skeleton-element" style={{ height: '32px', width: '200px', marginBottom: '1.5rem' }}></div>
                    <div className="card skeleton-element" style={{ height: '300px' }}></div>
                </section>
            </div>
        </div>
    );
};