import React from 'react';
import { Navigate, Outlet } from 'react-router-dom';
import { useUser } from '../services/UserContext';
import { Spinner } from './ui/spinner';
import { PATHS } from '../constants/paths';

/**
 * PublicRoute - Only allows access to auth pages when user is NOT authenticated
 * Redirects authenticated users away from auth pages (login, register, etc.)
 */
export const PublicRoute = () => {
    const { user, isLoading } = useUser();

    if (isLoading) {
        return <div className="fixed inset-0 flex items-center justify-center bg-background"><Spinner className="h-10 w-10"/></div>;
    }

    // If user is already authenticated, redirect to home
    if (user) {
        return <Navigate to={PATHS.HOME} replace />;
    }

    return <Outlet />;
};

