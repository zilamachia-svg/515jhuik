import React from 'react';
import { Product } from '../types';
import { formatCurrency } from '../utils';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardFooter } from '@/components/ui/card';
import { useLanguage } from '../contexts/LanguageContext';
import { Badge } from '@/components/ui/badge';

type ProductItemProps = {
    product: Product;
    onViewDetails: (product: Product) => void;
    onBuy: (product: Product) => void;
};

const StockBadge = ({ stock }: { stock: number }) => {
    const { t } = useLanguage();

    if (stock === 0) {
        return <Badge variant="destructive">{t('common.outOfStock')}</Badge>;
    }
    if (stock <= 10) {
        return <Badge className="bg-yellow-500 text-yellow-50 hover:bg-yellow-500/80 border-transparent">{t('stock.lowStock', { defaultValue: 'Sắp hết' })}</Badge>;
    }
    return <Badge className="bg-green-600 text-green-50 hover:bg-green-600/80 border-transparent">{t('stock.inStock', { defaultValue: 'Còn hàng' })}</Badge>;
};

export const ProductItem = React.memo(({ product, onViewDetails, onBuy }: ProductItemProps) => {
    const { t } = useLanguage();

    const handleBuyClick = (e: React.MouseEvent) => {
        e.stopPropagation();
        onBuy(product);
    };

    return (
        <Card 
            className="group flex flex-col h-full overflow-hidden rounded-3xl border-2 transition-all duration-300 hover:-translate-y-1 hover:border-primary/50 hover:shadow-xl cursor-pointer"
            onClick={() => onViewDetails(product)}
        >
            <div 
                className="relative aspect-video w-full flex flex-col items-center justify-center bg-gradient-to-br from-muted/50 to-muted/30 p-4 text-center rounded-t-3xl"
            >
                <img 
                    src={`https://flagcdn.com/w40/${product.country.toLowerCase()}.png`} 
                    alt={product.country} 
                    title={product.country}
                    className="mb-2"
                />
                <h3 className="text-base font-semibold leading-tight" title={product.name}>{product.name}</h3>
                
                {product.stock === 0 && (
                    <div className="absolute inset-0 bg-card/80 backdrop-blur-sm flex items-center justify-center rounded-t-3xl">
                        <span className="text-foreground font-bold">{t('common.outOfStock')}</span>
                    </div>
                )}
            </div>
            
            <CardContent className="p-4 flex-1">
                <p className="text-sm text-muted-foreground line-clamp-2 mb-3">{product.description}</p>
                <div className="flex justify-between items-center">
                    <StockBadge stock={product.stock} />
                    <span className="font-bold text-lg text-primary">{formatCurrency(product.price)}</span>
                </div>
            </CardContent>
            <CardFooter className="p-4 pt-0">
                <Button
                    className="w-full rounded-2xl"
                    onClick={handleBuyClick}
                    disabled={product.stock === 0}
                >
                    {product.stock > 0 ? t('common.buy') : t('common.outOfStock')}
                </Button>
            </CardFooter>
        </Card>
    );
});

ProductItem.displayName = 'ProductItem';