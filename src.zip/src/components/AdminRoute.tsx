import React from 'react';
import { Navigate, useLocation, Outlet } from 'react-router-dom';
import { useUser } from '../services/UserContext';
import { Spinner } from './ui/spinner';
import { PATHS } from '../constants/paths';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { ShieldAlert } from 'lucide-react';

export default function AdminRoute() {
    const { user, isLoading } = useUser();
    const location = useLocation();

    if (isLoading) {
        return <div className="fixed inset-0 flex items-center justify-center"><Spinner className="h-10 w-10" /></div>;
    }

    if (!user) {
        return <Navigate to={PATHS.HOME} state={{ from: location }} replace />;
    }

    if (user.role !== 'admin') {
        return (
             <div className="flex items-center justify-center h-full p-8">
                <Card className="max-w-md w-full text-center">
                    <CardHeader>
                        <ShieldAlert className="w-16 h-16 mx-auto text-destructive" />
                        <CardTitle>Truy cập bị từ chối</CardTitle>
                    </CardHeader>
                    <CardContent>
                        <p>Bạn không có quyền truy cập vào trang này.</p>
                    </CardContent>
                </Card>
            </div>
        );
    }

    return <Outlet />;
}