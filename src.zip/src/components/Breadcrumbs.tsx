import { Fragment } from 'react';
import { NavLink, useLocation } from 'react-router-dom';
import { useLanguage } from '../contexts/LanguageContext';

// This mapping translates URL path segments into human-readable names or translation keys.
const pathFriendlyNames: Record<string, string> = {
    'store': 'storePage.title',
    'deposit': 'pageTitles.deposit',
    'history': 'pageTitles.purchaseHistory',
    'orders': 'pageTitles.purchaseHistory',
    'leaderboard': 'sidebar.topUpLeaderboard',
    'cong-cu': 'sidebar.toolsTitle',
    'get-2fa': 'sidebar.get2FA',
    'check-live-fb': 'sidebar.checkLiveFB',
    'documents': 'sidebar.buyDocuments',
    'api-docs': 'sidebar.apiDocs',
    'affiliate': 'sidebar.affiliate',
    'contact': 'sidebar.contactSupport',
    'posts': 'sidebar.posts',
    'faq': 'sidebar.faq',
    'tasks': 'tasksPage.title',
    'settings': 'sidebar.accountSettings',
    'profile': 'settings.profile.title',
    'preferences': 'settings.preferences.title',
    'admin': 'header.adminPage',
    'dashboard': 'sidebar.admin.dashboard',
    'users': 'sidebar.admin.userManagement',
    'products': 'sidebar.admin.productManagement',
    'product-categories': 'sidebar.admin.categories',
    'upload': 'sidebar.admin.batchAdd',
};

export const Breadcrumbs = () => {
    const location = useLocation();
    const { t } = useLanguage();
    // Split path into segments, filtering out empty strings from leading/trailing slashes
    const pathnames = location.pathname.split('/').filter((x) => x);

    // If on the homepage, no breadcrumbs are needed.
    if (pathnames.length === 0) {
        return null;
    }

    return (
        <nav aria-label="breadcrumb" className="text-xs font-medium text-muted-foreground">
            <ol className="flex items-center space-x-1">
                <li>
                    <NavLink to="/" className="hover:text-primary transition-colors px-1 py-0.5 rounded hover:bg-muted/50">
                        {t('pageTitles.home', { defaultValue: 'Trang chủ' })}
                    </NavLink>
                </li>
                {pathnames.map((segment, index) => {
                    const routeTo = `/${pathnames.slice(0, index + 1).join('/')}`;
                    const isLast = index === pathnames.length - 1;
                    const key = pathFriendlyNames[segment] || segment;
                    const name = t(key, { defaultValue: segment.charAt(0).toUpperCase() + segment.slice(1) });

                    return (
                        <Fragment key={routeTo}>
                            <li>
                                <span className="mx-0.5 text-muted-foreground/60">›</span>
                            </li>
                            <li aria-current={isLast ? 'page' : undefined}>
                                {isLast ? (
                                    <span className="font-semibold text-foreground px-1">{name}</span>
                                ) : (
                                    <NavLink to={routeTo} className="hover:text-primary transition-colors px-1 py-0.5 rounded hover:bg-muted/50">
                                        {name}
                                    </NavLink>
                                )}
                            </li>
                        </Fragment>
                    );
                })}
            </ol>
        </nav>
    );
};