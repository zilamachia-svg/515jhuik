import { motion } from 'framer-motion';
import { usePageTitle } from '../contexts/PageTitleContext';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { FileText } from 'lucide-react';
import { BannerContent } from '@/components/BannerContent';

export default function TermsPage() {
    usePageTitle('Điều khoản sử dụng - Hải Đăng Meta');

    return (
        <div className="space-y-8">
            {/* Banner với nội dung */}
            <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5 }}
                className="overflow-hidden rounded-3xl bg-gradient-to-r from-purple-400/85 via-indigo-400/85 to-blue-400/85 p-8 text-white"
            >
                <div className="flex flex-col gap-6 md:flex-row md:items-center md:justify-between">
                    <div className="space-y-4">
                        <div className="flex items-center gap-3">
                            <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-white/20 backdrop-blur-md">
                                <FileText className="h-6 w-6" />
                            </div>
                            <div>
                                <h1 className="text-3xl font-bold">Điều khoản sử dụng</h1>
                                <p className="text-white/80">Quy định và điều khoản khi sử dụng dịch vụ</p>
                            </div>
                        </div>
                    </div>
                </div>
                <BannerContent />
            </motion.div>

            {/* Nội dung chính */}
            <Card className="rounded-3xl">
                <CardHeader>
                    <CardTitle>Điều khoản sử dụng dịch vụ</CardTitle>
                </CardHeader>
                <CardContent className="prose prose-slate max-w-none space-y-6">
                    <section>
                        <h2 className="text-2xl font-bold mb-4">1. Giới thiệu</h2>
                        <p className="text-muted-foreground leading-relaxed">
                            Chào mừng bạn đến với <strong>Hải Đăng Meta</strong> - nền tảng dịch vụ meta hàng đầu Việt Nam. 
                            Bằng việc truy cập và sử dụng website của chúng tôi, bạn đồng ý tuân thủ các điều khoản và điều kiện 
                            được quy định trong tài liệu này. Vui lòng đọc kỹ các điều khoản trước khi sử dụng dịch vụ.
                        </p>
                    </section>

                    <section>
                        <h2 className="text-2xl font-bold mb-4">2. Định nghĩa</h2>
                        <ul className="list-disc pl-6 space-y-2 text-muted-foreground">
                            <li><strong>&quot;Dịch vụ&quot;</strong> - Các sản phẩm và dịch vụ được cung cấp bởi Hải Đăng Meta bao gồm tài khoản, công cụ và các dịch vụ liên quan.</li>
                            <li><strong>&quot;Người dùng&quot;</strong> - Bất kỳ cá nhân hoặc tổ chức nào truy cập và sử dụng dịch vụ của chúng tôi.</li>
                            <li><strong>&quot;Tài khoản&quot;</strong> - Tài khoản người dùng được tạo trên hệ thống Hải Đăng Meta.</li>
                            <li><strong>&quot;Sản phẩm&quot;</strong> - Các tài khoản, dịch vụ hoặc công cụ được bán trên nền tảng.</li>
                        </ul>
                    </section>

                    <section>
                        <h2 className="text-2xl font-bold mb-4">3. Điều kiện sử dụng</h2>
                        <div className="space-y-4">
                            <div>
                                <h3 className="text-xl font-semibold mb-2">3.1. Độ tuổi</h3>
                                <p className="text-muted-foreground">
                                    Bạn phải đủ 18 tuổi trở lên hoặc có sự đồng ý của người giám hộ hợp pháp để sử dụng dịch vụ. 
                                    Chúng tôi có quyền yêu cầu xác minh độ tuổi bất cứ lúc nào.
                                </p>
                            </div>
                            <div>
                                <h3 className="text-xl font-semibold mb-2">3.2. Tài khoản người dùng</h3>
                                <p className="text-muted-foreground">
                                    Bạn chịu trách nhiệm bảo mật thông tin đăng nhập của mình. Mọi hoạt động diễn ra trên tài khoản 
                                    của bạn sẽ được coi là do bạn thực hiện. Bạn phải thông báo ngay cho chúng tôi nếu phát hiện 
                                    tài khoản bị xâm nhập trái phép.
                                </p>
                            </div>
                            <div>
                                <h3 className="text-xl font-semibold mb-2">3.3. Thông tin chính xác</h3>
                                <p className="text-muted-foreground">
                                    Bạn cam kết cung cấp thông tin chính xác, đầy đủ và cập nhật khi đăng ký và sử dụng dịch vụ. 
                                    Việc cung cấp thông tin sai lệch có thể dẫn đến việc tài khoản bị khóa hoặc chấm dứt dịch vụ.
                                </p>
                            </div>
                        </div>
                    </section>

                    <section>
                        <h2 className="text-2xl font-bold mb-4">4. Quy tắc sử dụng</h2>
                        <div className="space-y-4">
                            <div>
                                <h3 className="text-xl font-semibold mb-2">4.1. Sử dụng hợp pháp</h3>
                                <p className="text-muted-foreground">
                                    Bạn chỉ được sử dụng dịch vụ cho mục đích hợp pháp. Nghiêm cấm sử dụng dịch vụ để:
                                </p>
                                <ul className="list-disc pl-6 mt-2 space-y-1 text-muted-foreground">
                                    <li>Thực hiện các hoạt động vi phạm pháp luật</li>
                                    <li>Lừa đảo, gian lận hoặc gây hại cho người khác</li>
                                    <li>Spam, quấy rối hoặc đe dọa người dùng khác</li>
                                    <li>Phát tán nội dung bất hợp pháp, vi phạm bản quyền</li>
                                </ul>
                            </div>
                            <div>
                                <h3 className="text-xl font-semibold mb-2">4.2. Cấm hành vi</h3>
                                <p className="text-muted-foreground">
                                    Bạn không được phép:
                                </p>
                                <ul className="list-disc pl-6 mt-2 space-y-1 text-muted-foreground">
                                    <li>Chia sẻ, bán lại hoặc chuyển nhượng tài khoản cho người khác</li>
                                    <li>Sử dụng công cụ tự động hoặc bot để truy cập hệ thống</li>
                                    <li>Cố gắng hack, xâm nhập hoặc làm gián đoạn hệ thống</li>
                                    <li>Khai thác lỗ hổng bảo mật hoặc lỗi hệ thống</li>
                                </ul>
                            </div>
                        </div>
                    </section>

                    <section>
                        <h2 className="text-2xl font-bold mb-4">5. Giao dịch và thanh toán</h2>
                        <div className="space-y-4">
                            <div>
                                <h3 className="text-xl font-semibold mb-2">5.1. Giá cả</h3>
                                <p className="text-muted-foreground">
                                    Tất cả giá cả được hiển thị bằng VNĐ và có thể thay đổi mà không cần thông báo trước. 
                                    Giá cuối cùng sẽ được xác nhận tại thời điểm thanh toán.
                                </p>
                            </div>
                            <div>
                                <h3 className="text-xl font-semibold mb-2">5.2. Thanh toán</h3>
                                <p className="text-muted-foreground">
                                    Chúng tôi chấp nhận thanh toán qua các phương thức: Chuyển khoản ngân hàng, Ví điện tử MoMo. 
                                    Giao dịch phải được hoàn tất trong vòng 24 giờ sau khi đặt hàng.
                                </p>
                            </div>
                            <div>
                                <h3 className="text-xl font-semibold mb-2">5.3. Hoàn tiền</h3>
                                <p className="text-muted-foreground">
                                    Chính sách hoàn tiền được áp dụng theo quy định tại <a href="/warranty" className="text-primary hover:underline">Chính sách bảo hành</a>. 
                                    Việc hoàn tiền sẽ được xử lý trong vòng 5-7 ngày làm việc sau khi được chấp thuận.
                                </p>
                            </div>
                        </div>
                    </section>

                    <section>
                        <h2 className="text-2xl font-bold mb-4">6. Quyền sở hữu trí tuệ</h2>
                        <p className="text-muted-foreground">
                            Tất cả nội dung trên website bao gồm logo, văn bản, hình ảnh, thiết kế đều thuộc quyền sở hữu của 
                            <strong> Hải Đăng Meta</strong>. Bạn không được phép sao chép, phân phối hoặc sử dụng nội dung này 
                            mà không có sự cho phép bằng văn bản của chúng tôi.
                        </p>
                    </section>

                    <section>
                        <h2 className="text-2xl font-bold mb-4">7. Miễn trừ trách nhiệm</h2>
                        <p className="text-muted-foreground">
                            Chúng tôi không chịu trách nhiệm về bất kỳ thiệt hại nào phát sinh từ việc sử dụng dịch vụ, bao gồm 
                            nhưng không giới hạn: mất dữ liệu, gián đoạn dịch vụ, hoặc các vấn đề kỹ thuật. Chúng tôi cung cấp 
                            dịch vụ &quot;như hiện tại&quot; và không đảm bảo dịch vụ sẽ hoạt động liên tục hoặc không có lỗi.
                        </p>
                    </section>

                    <section>
                        <h2 className="text-2xl font-bold mb-4">8. Chấm dứt dịch vụ</h2>
                        <p className="text-muted-foreground">
                            Chúng tôi có quyền chấm dứt hoặc tạm ngưng tài khoản của bạn bất cứ lúc nào nếu bạn vi phạm các điều 
                            khoản này. Trong trường hợp đó, bạn sẽ không được hoàn lại bất kỳ khoản phí nào đã thanh toán.
                        </p>
                    </section>

                    <section>
                        <h2 className="text-2xl font-bold mb-4">9. Thay đổi điều khoản</h2>
                        <p className="text-muted-foreground">
                            Chúng tôi có quyền thay đổi các điều khoản này bất cứ lúc nào. Các thay đổi sẽ có hiệu lực ngay sau 
                            khi được đăng tải trên website. Việc bạn tiếp tục sử dụng dịch vụ sau khi có thay đổi được coi là 
                            bạn đã chấp nhận các điều khoản mới.
                        </p>
                    </section>

                    <section>
                        <h2 className="text-2xl font-bold mb-4">10. Liên hệ</h2>
                        <p className="text-muted-foreground">
                            Nếu bạn có bất kỳ câu hỏi nào về các điều khoản này, vui lòng liên hệ với chúng tôi qua:
                        </p>
                        <ul className="list-disc pl-6 mt-2 space-y-1 text-muted-foreground">
                            <li>Email: support@haidangmeta.com</li>
                            <li>Hotline: 1900-xxxx</li>
                            <li>Thời gian hỗ trợ: 8:00 - 22:00 hàng ngày</li>
                        </ul>
                    </section>

                    <div className="mt-8 p-4 bg-muted rounded-2xl">
                        <p className="text-sm text-muted-foreground">
                            <strong>Lần cập nhật cuối:</strong> {new Date().toLocaleDateString('vi-VN')}
                        </p>
                    </div>
                </CardContent>
            </Card>
        </div>
    );
}

