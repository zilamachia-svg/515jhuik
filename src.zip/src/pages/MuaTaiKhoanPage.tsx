import { useState, useEffect, useCallback, useMemo } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { toast } from 'sonner';
import { Product, ApiError } from '../types';
import { fetchProducts, fetchProductFilterOptions } from '../services/productService';
import { formatApiErrorForToast } from '../utils';
import { usePageTitle } from '../contexts/PageTitleContext';
import { useLanguage } from '../contexts/LanguageContext';
import { useUser } from '../services/UserContext';
import apiClient from '../services/apiClient';
import { useFilters } from '../contexts/FilterContext';
import { useDebounce } from '../hooks/useDebounce';
import { Search, Download, Store, Plus, Minus, Info, Mail, Sun, Moon } from 'lucide-react';
import { Link } from 'react-router-dom';
import { PATHS } from '../constants/paths';
import { Alert, AlertDescription } from '../components/ui/alert';
import { BannerContent } from '../components/BannerContent';

// Components
import { ProductTable } from '../components/ProductTable';
import { PurchaseModal } from '../components/PurchaseModal';
import { ProductDetailModal } from '../components/ProductDetailModal';
import { PurchaseSuccessModal } from '../components/PurchaseSuccessModal';
import { Card, CardContent } from '../components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from '@/components/ui/accordion';
import { TableSkeleton } from '../components/skeletons/TableSkeleton';

const ITEMS_PER_PAGE = 12;

type ProductTab = 'via' | 'bm' | 'page' | 'clone';

export default function MuaTaiKhoanPage() {
    const { t } = useLanguage();
    usePageTitle(t('storePage.title'));

    const { user, setUser, openAuthModal } = useUser();
    const { filters, dispatch } = useFilters();
    const debouncedSearch = useDebounce(filters.search, 500);
    const [activeTab, setActiveTab] = useState<ProductTab>('via');

    const [products, setProducts] = useState<Product[]>([]);
    const [isLoading, setIsLoading] = useState(true);
    const [isLoadingMore, setIsLoadingMore] = useState(false);
    const [totalPages, setTotalPages] = useState(1);

    const [productToBuy, setProductToBuy] = useState<Product | null>(null);
    const [initialQuantity, setInitialQuantity] = useState(1);
    const [productToView, setProductToView] = useState<Product | null>(null);
    const [purchaseSuccessInfo, setPurchaseSuccessInfo] = useState<{ orderId: string, downloadLink: string } | null>(null);
    const [isProcessingPurchase, setIsProcessingPurchase] = useState(false);
    const [availableCategories, setAvailableCategories] = useState<string[]>([]);

    // Create a stable key from filters, excluding 'page', to detect when to reset the product list
    const filtersKey = useMemo(() => {
        const { page, ...otherFilters } = filters;
        return JSON.stringify(otherFilters);
    }, [filters]);

    // Fetch available categories
    useEffect(() => {
        const loadCategories = async () => {
            try {
                const options = await fetchProductFilterOptions();
                setAvailableCategories(options.uniqueCategories);
            } catch (error) {
                console.error('Failed to load categories:', error);
            }
        };
        loadCategories();
    }, []);

    // Effect for initial load and when filters (like category, sort, etc.) change
    useEffect(() => {
        const loadInitialProducts = async () => {
            setIsLoading(true);
            try {
                // ✅ Use proper pagination instead of loading all products
                const data = await fetchProducts({
                    ...filters,
                    search: debouncedSearch,
                    page: 1, 
                    limit: ITEMS_PER_PAGE, // Use pagination (12 items per page)
                });
                setProducts(data.data);
                setTotalPages(data.totalPages);
                // Ensure the page in context is reset to 1
                dispatch({ type: 'SET_PAGE', payload: 1 });
            } catch (error) {
                toast.error(formatApiErrorForToast(error as ApiError, t('storePage.errors.fetchProducts')));
            } finally {
                setIsLoading(false);
            }
        };
        
        loadInitialProducts();
    // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [filtersKey, debouncedSearch, dispatch, t]);

    const handleLoadMore = async () => {
        const nextPage = filters.page + 1;
        if (nextPage > totalPages || isLoadingMore) return;

        setIsLoadingMore(true);
        try {
            const data = await fetchProducts({
                ...filters,
                search: debouncedSearch,
                page: nextPage,
                limit: ITEMS_PER_PAGE,
            });
            setProducts(prev => [...prev, ...data.data]);
            dispatch({ type: 'SET_PAGE', payload: nextPage });
        } catch (error) {
            toast.error(formatApiErrorForToast(error as ApiError, t('storePage.errors.fetchProducts')));
        } finally {
            setIsLoadingMore(false);
        }
    };

    const handleBuy = (product: Product, quantity: number = 1) => {
        if (!user) {
            openAuthModal();
            return;
        }
        
        // Email verification gating is controlled by feature flag
        const requireEmailVerification = (import.meta.env.VITE_REQUIRE_EMAIL_VERIFICATION === 'true') || false;
        if (requireEmailVerification) {
            const isEmailVerified = user?.email_verified_at || (user as any)?.emailVerified;
            if (!isEmailVerified) {
                toast.error('Vui lòng xác thực email trước khi mua hàng', {
                    duration: 5000,
                    description: 'Vào Cài đặt > Xác thực Email để xác thực email của bạn.',
                });
                return;
            }
        }
        
        setInitialQuantity(quantity);
        setProductToBuy(product);
    };

    const handleViewDetails = (product: Product) => {
        setProductToView(product);
    };

    const handleConfirmPurchase = async (quantity: number) => {
        if (!productToBuy || !user) return;
        setIsProcessingPurchase(true);
        try {
            const response = await apiClient.post('/orders', {
                product_id: productToBuy.id,
                quantity: quantity,
            });
            
            setUser({ ...user, balance: response.data.new_balance });
            setPurchaseSuccessInfo({
                orderId: response.data.order_id,
                downloadLink: response.data.download_link,
            });
            setProductToBuy(null);
            toast.success(response.data.message || t('purchase.successMessage'));
            
            // Update stock locally instead of reloading the entire list
            setProducts(prev => prev.map(p => 
                p.id === productToBuy.id ? { ...p, stock: p.stock - quantity } : p
            ));

        } catch (error) {
            const apiError = error as ApiError;
            console.error("Purchase failed:", apiError);
            // Do not block purchases due to email verification — show generic error
            toast.error(formatApiErrorForToast(apiError, 'Không thể mua hàng. Vui lòng thử lại.'));
        } finally {
            setIsProcessingPurchase(false);
        }
    };

    // Group products by category
    const groupedProducts = useMemo(() => {
        return products.reduce((acc, product) => {
            const category = product.category || 'Khác';
            if (!acc[category]) {
                acc[category] = [];
            }
            acc[category].push(product);
            return acc;
        }, {} as Record<string, Product[]>);
    }, [products]);

    // Filter products by tab
    const getFilteredProducts = () => {
        const tabFilters: Record<ProductTab, string[]> = {
            via: ['Via', 'VIA', 'via', 'Via Việt Nam', 'Via Random', 'Via Nuôi', 'Via Indo', 'Via Phi', 'Via Châu Âu', 'Via Châu Á', 'Via Châu Mỹ', 'Via Châu Phi'],
            bm: ['BM', 'Business Manager', 'Business'],
            page: ['Page', 'Facebook Page'],
            clone: ['Clone', 'Clone Philippines'],
        };

        const filterCategories = tabFilters[activeTab] || [];
        return Object.entries(groupedProducts).filter(([category]) => 
            filterCategories.some(filter => category.toLowerCase().includes(filter.toLowerCase())) ||
            (activeTab === 'via' && !['BM', 'Business Manager', 'Business', 'Page', 'Facebook Page', 'Clone', 'Clone Philippines'].some(f => category.toLowerCase().includes(f.toLowerCase())))
        );
    };

    const filteredGroupedProducts = getFilteredProducts();
    const [theme, setTheme] = useState<'light' | 'dark'>(() => {
        try {
            const stored = localStorage.getItem('theme');
            if (stored === 'dark' || stored === 'light') return stored;
        } catch { /* ignore */ }
        // Respect system preference if available
        if (typeof window !== 'undefined' && window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches) {
            return 'dark';
        }
        return 'light';
    });
    // Email verification requirement is controlled via Vite env flag
    const requireEmailVerification = (import.meta.env.VITE_REQUIRE_EMAIL_VERIFICATION === 'true') || false;

    useEffect(() => {
        // Apply theme class on root element
        const root = document.documentElement;
        if (theme === 'dark') {
            root.classList.add('dark');
        } else {
            root.classList.remove('dark');
        }
        try { localStorage.setItem('theme', theme); } catch {}
    }, [theme]);

    const toggleTheme = () => setTheme(prev => prev === 'dark' ? 'light' : 'dark');

    return (
        <>
            <div className="space-y-6 sm:space-y-8">
                {/* Email verification banner (controlled by feature flag) */}
                {user && requireEmailVerification && !((user as any)?.email_verified_at || (user as any)?.emailVerified) && (
                    <Alert className="border-yellow-200 bg-yellow-50 dark:bg-yellow-950/20 dark:border-yellow-800 rounded-2xl">
                        <Mail className="h-5 w-5 text-yellow-600 dark:text-yellow-400" />
                        <AlertDescription className="text-yellow-900 dark:text-yellow-100">
                            <div className="flex flex-col gap-2">
                                <p className="font-semibold">Vui lòng xác thực email trước khi mua hàng</p>
                                <p className="text-sm">Để mua hàng, bạn cần xác thực email của mình. Vui lòng vào <Link to={PATHS.PROFILE} className="underline font-semibold">Cài đặt &gt; Xác thực Email</Link> để thực hiện xác thực.</p>
                            </div>
                        </AlertDescription>
                    </Alert>
                )}
                
                {/* Banner Section */}
                <motion.div
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.5 }}
                    className="overflow-hidden rounded-2xl sm:rounded-3xl bg-gradient-to-r from-pink-400/85 via-red-400/85 to-orange-400/85 p-4 sm:p-8 text-white"
                >
                    <div className="flex flex-col gap-4 sm:gap-6 md:flex-row md:items-center md:justify-between">
                        <div className="space-y-2">
                            <h2 className="text-2xl sm:text-3xl font-bold flex items-center gap-2 sm:gap-3">
                                <span className="text-2xl sm:text-3xl">🛒</span>
                                Cửa hàng Tài khoản
                            </h2>
                            <p className="max-w-[600px] text-sm sm:text-base text-white/80">
                                Khám phá bộ sưu tập tài khoản chất lượng cao và dịch vụ chuyên nghiệp của chúng tôi.
                            </p>
                        </div>
                        <div className="flex items-center gap-2">
                            <Button className="hidden sm:inline-flex w-full sm:w-fit rounded-2xl bg-white text-red-700 hover:bg-white/90" asChild>
                                <a href="#products">
                                    <Download className="mr-2 h-4 w-4" />
                                    Xem sản phẩm
                                </a>
                            </Button>
                            <Button
                                onClick={toggleTheme}
                                variant="ghost"
                                className="p-2 rounded-xl bg-white/90 dark:bg-black/60 shadow-sm"
                                aria-label="Toggle color theme"
                            >
                                {theme === 'dark' ? <Sun className="h-4 w-4 text-yellow-300" /> : <Moon className="h-4 w-4 text-gray-700" />}
                            </Button>
                        </div>
                    </div>
                    <BannerContent />
                </motion.div>

                {/* Search and Filter Bar */}
                <div className="flex flex-col gap-3">
                    <div className="relative">
                        <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 sm:h-5 sm:w-5 text-muted-foreground pointer-events-none" />
                        <Input
                            type="search"
                            placeholder="Tìm kiếm theo tên"
                            className="w-full rounded-2xl pl-9 sm:pl-11 pr-4 h-10 sm:h-11 text-sm focus-visible:ring-2 focus-visible:ring-primary/20"
                            value={filters.search}
                            onChange={(e) => dispatch({ type: 'SET_SEARCH', payload: e.target.value })}
                        />
                    </div>
                    {/* Filter Buttons - Scrollable */}
                    <div className="flex items-center gap-2 overflow-x-auto pb-2 scrollbar-hide -mx-1 px-1">
                        {['Bao đổi pass', 'Chạy quảng cáo', 'Via XMDT - 902', 'Ít Hold', 'Lách Thuế', 'Limit cao', 'Via Có 2FA', 'Nuôi Profile'].map((filter) => (
                            <Button
                                key={filter}
                                variant="outline"
                                size="sm"
                                className="whitespace-nowrap rounded-full text-xs sm:text-sm border-blue-200 hover:border-blue-400 hover:bg-blue-50 dark:border-blue-800 dark:hover:border-blue-600 dark:hover:bg-blue-950"
                            >
                                {filter}
                            </Button>
                        ))}
                    </div>
                </div>

                {/* Main Content with Tabs and Accordion */}
                <div id="products" className="space-y-4">
                    <Tabs value={activeTab} onValueChange={(value) => setActiveTab(value as ProductTab)}>
                        <TabsList className="grid w-full grid-cols-2 sm:grid-cols-4 h-auto bg-muted/50">
                            <TabsTrigger value="via" className="text-xs sm:text-sm py-2 sm:py-3 data-[state=active]:bg-background">
                                Via
                            </TabsTrigger>
                            <TabsTrigger value="bm" className="text-xs sm:text-sm py-2 sm:py-3 data-[state=active]:bg-background">
                                BM
                            </TabsTrigger>
                            <TabsTrigger value="page" className="text-xs sm:text-sm py-2 sm:py-3 data-[state=active]:bg-background">
                                Page
                            </TabsTrigger>
                            <TabsTrigger value="clone" className="text-xs sm:text-sm py-2 sm:py-3 data-[state=active]:bg-background">
                                Clone
                            </TabsTrigger>
                        </TabsList>

                        <TabsContent value={activeTab} className="mt-4 sm:mt-6">
                            {isLoading ? (
                                <div className="space-y-4">
                                    <TableSkeleton headers={['Tên dịch vụ', 'Quốc gia', 'Số lượng', 'Số tiền', 'Thao tác']} />
                                </div>
                            ) : filteredGroupedProducts.length > 0 ? (
                                <Accordion type="multiple" defaultValue={filteredGroupedProducts.map(([c, items]) => items && items.length > 0 ? c : '') .filter(Boolean)} className="w-full space-y-2 sm:space-y-3">
                                    {filteredGroupedProducts.map(([category, categoryProducts]) => (
                                        <AccordionItem 
                                            key={category} 
                                            value={category}
                                            className="border-2 rounded-xl sm:rounded-2xl px-3 sm:px-4 bg-card hover:bg-muted/30 transition-all duration-200"
                                        >
                                            <AccordionTrigger className="hover:no-underline py-3 sm:py-4">
                                                <div className="flex items-center justify-between w-full pr-2 sm:pr-4">
                                                    <span className="font-semibold text-sm sm:text-base md:text-lg text-left">
                                                        {category}
                                                    </span>
                                                    <Badge variant="secondary" className="ml-2 text-xs sm:text-sm">
                                                        {categoryProducts.length}
                                                    </Badge>
                                                </div>
                                            </AccordionTrigger>
                                            <AccordionContent>
                                                <div className="pt-4">
                                                    {categoryProducts.length > 0 ? (
                                                        <ProductTable 
                                                            products={categoryProducts}
                                                            onBuy={handleBuy}
                                                            onViewDetails={handleViewDetails}
                                                        />
                                                    ) : (
                                                        <p className="text-center py-8 text-muted-foreground">Không có sản phẩm nào trong danh mục này</p>
                                                    )}
                                                </div>
                                            </AccordionContent>
                                        </AccordionItem>
                                    ))}
                                </Accordion>
                            ) : (
                                <Card className="rounded-2xl sm:rounded-3xl">
                                    <CardContent>
                                        <div className="text-center p-8 sm:p-12">
                                            <p className="text-sm sm:text-base text-muted-foreground">
                                                {t('storePage.noProductsFound')}
                                            </p>
                                        </div>
                                    </CardContent>
                                </Card>
                            )}
                        </TabsContent>
                    </Tabs>
                </div>
            </div>

            {productToView && (
                <ProductDetailModal
                    product={productToView}
                    onClose={() => setProductToView(null)}
                    onBuy={handleBuy}
                />
            )}

            {productToBuy && (
                <PurchaseModal
                    product={productToBuy}
                    initialQuantity={initialQuantity}
                    onClose={() => setProductToBuy(null)}
                    onConfirm={handleConfirmPurchase}
                    isProcessing={isProcessingPurchase}
                />
            )}
            
            {purchaseSuccessInfo && (
                <PurchaseSuccessModal
                    orderId={purchaseSuccessInfo.orderId}
                    downloadLink={purchaseSuccessInfo.downloadLink}
                    onClose={() => setPurchaseSuccessInfo(null)}
                />
            )}
        </>
    );
}
