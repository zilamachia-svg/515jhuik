import { useState, useEffect } from 'react';
import { toast } from 'sonner';
import { AffiliateStats, Commission, ApiError } from '../types';
import apiClient from '../services/apiClient';
import { useUser } from '../services/UserContext';
import { usePageTitle } from '../contexts/PageTitleContext';
import { formatCurrency, formatApiErrorForToast } from '../utils';
import { useCopyToClipboard } from '../hooks/useCopyToClipboard';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Button } from '@/components/ui/button';
import { Spinner } from '@/components/ui/spinner';
import { Copy, Check, Percent, Users, DollarSign, HandCoins } from 'lucide-react';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';

export default function AffiliatePage() {
    usePageTitle("Tiếp thị liên kết");
    const { user } = useUser();
    const [stats, setStats] = useState<AffiliateStats | null>(null);
    const [commissions, setCommissions] = useState<Commission[]>([]);
    const [isLoading, setIsLoading] = useState(true);
    const [copy, isCopied] = useCopyToClipboard();

    useEffect(() => {
        const fetchData = async () => {
            setIsLoading(true);
            try {
                const [statsRes, commissionsRes] = await Promise.all([
                    apiClient.get('/affiliate/stats'),
                    apiClient.get('/affiliate/commissions')
                ]);
                setStats(statsRes.data);
                setCommissions(commissionsRes.data.data);
            } catch (error) {
                toast.error(formatApiErrorForToast(error as ApiError, 'Không thể tải dữ liệu affiliate.'));
            } finally {
                setIsLoading(false);
            }
        };
        fetchData();
    }, []);

    if (isLoading) {
        return <div className="flex justify-center p-8"><Spinner className="h-10 w-10" /></div>;
    }

    if (!stats) {
        return <p>Không có dữ liệu.</p>;
    }
    
    const statCards = [
        { icon: <DollarSign className="h-4 w-4 text-muted-foreground" />, label: 'Tổng hoa hồng', value: formatCurrency(stats.totalCommission) },
        { icon: <HandCoins className="h-4 w-4 text-muted-foreground" />, label: 'Hoa hồng chờ duyệt', value: formatCurrency(stats.pendingCommission) },
        { icon: <Users className="h-4 w-4 text-muted-foreground" />, label: 'Số người giới thiệu', value: stats.referrals },
        { icon: <Percent className="h-4 w-4 text-muted-foreground" />, label: 'Tỉ lệ chuyển đổi', value: `${stats.conversionRate.toFixed(2)}%` },
    ];

    return (
        <div className="space-y-6">
            <div className="flex items-center gap-2 mb-4">
                <span className="text-2xl">🤝</span>
                <h1 className="text-2xl font-bold">Tiếp thị liên kết</h1>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
                 {statCards.map((card, index) => (
                    <Card key={index}>
                        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                            <CardTitle className="text-sm font-medium">{card.label}</CardTitle>
                            {card.icon}
                        </CardHeader>
                        <CardContent>
                            <div className="text-2xl font-bold">{card.value}</div>
                        </CardContent>
                    </Card>
                ))}
            </div>

            <Card>
                <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                        <span className="text-xl">🔗</span>
                        Link giới thiệu của bạn
                    </CardTitle>
                </CardHeader>
                <CardContent>
                    <Label htmlFor="ref-link">Chia sẻ link này để nhận hoa hồng</Label>
                    <div className="flex items-center gap-2">
                        <Input id="ref-link" readOnly value={user?.referralLink || ''} />
                        <Button variant="outline" size="icon" onClick={() => copy(user?.referralLink || '', 'Đã sao chép link!')}>
                            {isCopied ? <Check size={16} /> : <Copy size={16} />}
                        </Button>
                    </div>
                </CardContent>
            </Card>

            <Card>
                <CardHeader>
                    <CardTitle>Lịch sử hoa hồng</CardTitle>
                </CardHeader>
                <CardContent>
                    <div className="w-full overflow-auto">
                        <Table>
                            <TableHeader>
                                <TableRow>
                                    <TableHead>Đơn hàng</TableHead>
                                    <TableHead>Người được giới thiệu</TableHead>
                                    <TableHead>Tổng đơn</TableHead>
                                    <TableHead>Hoa hồng</TableHead>
                                    <TableHead>Ngày</TableHead>
                                    <TableHead>Trạng thái</TableHead>
                                </TableRow>
                            </TableHeader>
                            <TableBody>
                                {commissions.map(c => (
                                    <TableRow key={c.id}>
                                        <TableCell>{c.orderId}</TableCell>
                                        <TableCell>{c.referredUser}</TableCell>
                                        <TableCell>{formatCurrency(c.orderTotal)}</TableCell>
                                        <TableCell className="text-green-500 font-semibold">{formatCurrency(c.commissionAmount)}</TableCell>
                                        <TableCell>{new Date(c.date).toLocaleDateString('vi-VN')}</TableCell>
                                        <TableCell>{c.status}</TableCell>
                                    </TableRow>
                                ))}
                            </TableBody>
                        </Table>
                    </div>
                </CardContent>
            </Card>
        </div>
    );
}