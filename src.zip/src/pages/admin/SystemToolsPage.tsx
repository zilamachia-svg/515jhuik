// FIX: Use sonner for consistent notifications
import { toast } from 'sonner';
import { usePageTitle } from '../../contexts/PageTitleContext';
// FIX: Use Card components from shadcn/ui
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
// FIX: Use Button from shadcn/ui
import { Button } from '@/components/ui/button';

export default function SystemToolsPage() {
    usePageTitle("Công cụ Hệ thống");

    const handleAction = (actionName: string) => {
        toast.info(`(Mock) Đang thực hiện: ${actionName}...`);
        setTimeout(() => {
            toast.success(`(Mock) ${actionName} đã hoàn tất!`);
        }, 1500);
    };

    return (
        <div className="space-y-6">
            <Card>
                <CardHeader><CardTitle>Cache</CardTitle></CardHeader>
                <CardContent>
                    <p className="text-muted-foreground">Xóa cache ứng dụng, cấu hình, và route để áp dụng các thay đổi mới nhất.</p>
                    <div className="mt-4">
                        <Button variant="outline" onClick={() => handleAction('Xóa Cache')}>Xóa Cache hệ thống</Button>
                    </div>
                </CardContent>
            </Card>
             <Card>
                <CardHeader><CardTitle>Logs</CardTitle></CardHeader>
                <CardContent>
                    <p className="text-muted-foreground">Xem hoặc xóa file log của hệ thống.</p>
                    <div className="mt-4 flex gap-2">
                        <Button variant="outline" onClick={() => handleAction('Xem Log')}>Xem Log</Button>
                        <Button variant="destructive" onClick={() => handleAction('Xóa Log')}>Xóa Log</Button>
                    </div>
                </CardContent>
            </Card>
        </div>
    );
}