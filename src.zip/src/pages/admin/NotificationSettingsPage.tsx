import React, { useState } from 'react';
// FIX: Use sonner for consistent notifications
import { toast } from 'sonner';
import { NotificationSettings } from '../../types';
import { usePageTitle } from '../../contexts/PageTitleContext';
// FIX: Use Card components from shadcn/ui
import { Card, CardContent, CardHeader, CardTitle, CardFooter } from '@/components/ui/card';
// FIX: Use Button from shadcn/ui
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Spinner } from '@/components/ui/spinner';

const mockSettings: NotificationSettings = {
    smtpHost: 'smtp.mailgun.org',
    smtpPort: 587,
    smtpUser: 'postmaster@mg.example.com',
    smtpPass: 'password123',
    smtpEncryption: 'tls',
    fromEmail: 'noreply@example.com',
    fromName: 'Hải Đăng Meta',
    telegramWebhookUrl: '',
    discordWebhookUrl: '',
};

export default function NotificationSettingsPage() {
    usePageTitle("Cài đặt Thông báo");
    const [settings, setSettings] = useState<NotificationSettings>(mockSettings);
    const [isLoading, setIsLoading] = useState(false);

    const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        setSettings(prev => ({...prev, [e.target.name]: e.target.value}));
    };

    const handleSelectChange = (value: 'none' | 'tls' | 'ssl') => {
        setSettings(prev => ({ ...prev, smtpEncryption: value }));
    };

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        setIsLoading(true);
        setTimeout(() => {
            toast.success("Đã lưu cài đặt thông báo!");
            setIsLoading(false);
        }, 1000);
    };

    return (
        <form onSubmit={handleSubmit} className="space-y-6">
            <Card>
                <CardHeader><CardTitle>Cấu hình SMTP</CardTitle></CardHeader>
                <CardContent className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div className="space-y-2"><Label htmlFor="smtpHost">Host</Label><Input id="smtpHost" name="smtpHost" value={settings.smtpHost} onChange={handleChange} /></div>
                    <div className="space-y-2"><Label htmlFor="smtpPort">Port</Label><Input id="smtpPort" type="number" name="smtpPort" value={settings.smtpPort} onChange={handleChange} /></div>
                    <div className="space-y-2"><Label htmlFor="smtpUser">Username</Label><Input id="smtpUser" name="smtpUser" value={settings.smtpUser} onChange={handleChange} /></div>
                    <div className="space-y-2"><Label htmlFor="smtpPass">Password</Label><Input id="smtpPass" type="password" name="smtpPass" value={settings.smtpPass} onChange={handleChange} /></div>
                    <div className="space-y-2"><Label htmlFor="smtpEncryption">Mã hóa</Label>
                        <Select value={settings.smtpEncryption} onValueChange={handleSelectChange}>
                            <SelectTrigger id="smtpEncryption"><SelectValue placeholder="Chọn mã hóa" /></SelectTrigger>
                            <SelectContent>
                                <SelectItem value="none">None</SelectItem>
                                <SelectItem value="tls">TLS</SelectItem>
                                <SelectItem value="ssl">SSL</SelectItem>
                            </SelectContent>
                        </Select>
                    </div>
                    <div className="space-y-2"><Label htmlFor="fromEmail">Email gửi</Label><Input id="fromEmail" name="fromEmail" value={settings.fromEmail} onChange={handleChange} /></div>
                    <div className="space-y-2"><Label htmlFor="fromName">Tên người gửi</Label><Input id="fromName" name="fromName" value={settings.fromName} onChange={handleChange} /></div>
                </CardContent>
            </Card>

             <Card>
                <CardHeader><CardTitle>Cấu hình Webhook</CardTitle></CardHeader>
                <CardContent className="space-y-4">
                    <div className="space-y-2">
                        <Label htmlFor="telegramWebhookUrl">Telegram Webhook URL</Label>
                        <Input id="telegramWebhookUrl" name="telegramWebhookUrl" value={settings.telegramWebhookUrl} onChange={handleChange} />
                    </div>
                    <div className="space-y-2">
                        <Label htmlFor="discordWebhookUrl">Discord Webhook URL</Label>
                        <Input id="discordWebhookUrl" name="discordWebhookUrl" value={settings.discordWebhookUrl} onChange={handleChange} />
                    </div>
                </CardContent>
            </Card>

            <div className="flex justify-end">
                <Button type="submit" disabled={isLoading}>
                    {isLoading && <Spinner className="mr-2 h-4 w-4 animate-spin" />}
                    Lưu thay đổi
                </Button>
            </div>
        </form>
    );
}