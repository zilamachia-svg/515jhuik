import { useState, useEffect, useCallback } from 'react';
import { toast } from 'sonner';
import { PaymentMethod, ApiError } from '../../types';
import apiClient from '../../services/apiClient';
import { formatApiErrorForToast } from '../../utils';
import { usePageTitle } from '../../contexts/PageTitleContext';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Plus, Edit, Trash2, RefreshCw } from 'lucide-react';
import { EditPaymentMethodModal } from '../../components/admin/EditPaymentMethodModal';
import { ConfirmationModal } from '../../components/ConfirmationModal';
import { TableSkeleton } from '../../components/skeletons/TableSkeleton';
import { cn } from '@/lib/utils';

export default function PaymentSettingsPage() {
    usePageTitle("Cài đặt Thanh toán");

    const [methods, setMethods] = useState<PaymentMethod[]>([]);
    const [isLoading, setIsLoading] = useState(true);
    const [methodToEdit, setMethodToEdit] = useState<PaymentMethod | 'new' | null>(null);
    const [methodToDelete, setMethodToDelete] = useState<PaymentMethod | null>(null);

    const fetchMethods = useCallback(async () => {
        setIsLoading(true);
        try {
            const response = await apiClient.get('/admin/payment-methods');
            setMethods(response.data.methods);
        } catch (error) {
            toast.error(formatApiErrorForToast(error as ApiError, 'Không thể tải phương thức thanh toán.'));
        } finally {
            setIsLoading(false);
        }
    }, []);

    useEffect(() => {
        fetchMethods();
    }, [fetchMethods]);

    const handleSave = async (methodData: Omit<PaymentMethod, 'id'> | PaymentMethod) => {
        if ('id' in methodData) {
            await apiClient.put(`/admin/payment-methods/${methodData.id}`, methodData);
            toast.success('Đã cập nhật phương thức thanh toán.');
        } else {
            await apiClient.post('/admin/payment-methods', methodData);
            toast.success('Đã thêm phương thức thanh toán mới.');
        }
        setMethodToEdit(null);
        fetchMethods();
    };
    
    const handleDelete = async () => {
        if (!methodToDelete) return;
        try {
            await apiClient.delete(`/admin/payment-methods/${methodToDelete.id}`);
            toast.success('Đã xóa phương thức thanh toán.');
            setMethodToDelete(null);
            fetchMethods();
        } catch (error) {
            toast.error(formatApiErrorForToast(error as ApiError, 'Xóa thất bại.'));
        }
    };

    return (
        <>
            <Card className="rounded-2xl shadow-xl hover:shadow-2xl transition-shadow duration-300">
                <CardHeader className="flex-row items-center justify-between">
                    <div className="space-y-1">
                        <CardTitle className="text-xl font-bold">Phương thức thanh toán</CardTitle>
                        <p className="text-sm text-muted-foreground font-medium">
                            Quản lý các tài khoản ngân hàng, ví điện tử
                        </p>
                    </div>
                    <div className="flex items-center gap-2">
                        <Button variant="outline" onClick={fetchMethods} disabled={isLoading} className="shadow-md font-semibold rounded-lg">
                            <RefreshCw size={16} className={cn("mr-2", isLoading && "animate-spin")} />
                            Làm mới
                        </Button>
                        <Button onClick={() => setMethodToEdit('new')} size="lg" className="shadow-lg font-bold">
                            <Plus size={18} className="mr-2" /> 
                            Thêm mới
                        </Button>
                    </div>
                </CardHeader>
                <CardContent>
                     {isLoading ? (
                        <TableSkeleton headers={['Tên', 'Loại', 'Chủ TK', 'Số TK/SĐT', 'Trạng thái', 'Hành động']} />
                     ) : (
                        <div className="w-full overflow-auto">
                            <Table>
                                <TableHeader>
                                    <TableRow>
                                        <TableHead>Tên</TableHead>
                                        <TableHead>Loại</TableHead>
                                        <TableHead>Chủ TK</TableHead>
                                        <TableHead>Số TK/SĐT</TableHead>
                                        <TableHead>Trạng thái</TableHead>
                                        <TableHead>Hành động</TableHead>
                                    </TableRow>
                                </TableHeader>
                                <TableBody>
                                    {methods.map(method => (
                                        <TableRow key={method.id}>
                                            <TableCell>{method.name}</TableCell>
                                            <TableCell>{method.type}</TableCell>
                                            <TableCell>{method.accountName}</TableCell>
                                            <TableCell>{method.accountNumber}</TableCell>
                                            <TableCell>{method.is_active ? 'Hoạt động' : 'Tắt'}</TableCell>
                                            <TableCell>
                                                <div className="flex gap-2">
                                                    <Button variant="ghost" size="icon" onClick={() => setMethodToEdit(method)}><Edit size={14} /></Button>
                                                    <Button variant="ghost" size="icon" className="text-destructive" onClick={() => setMethodToDelete(method)}><Trash2 size={14} /></Button>
                                                </div>
                                            </TableCell>
                                        </TableRow>
                                    ))}
                                </TableBody>
                            </Table>
                        </div>
                     )}
                </CardContent>
            </Card>

            {methodToEdit && (
                <EditPaymentMethodModal
                    method={methodToEdit}
                    onClose={() => setMethodToEdit(null)}
                    onSave={handleSave}
                />
            )}
            
            {methodToDelete && (
                <ConfirmationModal
                    title="Xác nhận xóa"
                    message={`Bạn có chắc muốn xóa phương thức "${methodToDelete.name}"?`}
                    isDestructive
                    onConfirm={handleDelete}
                    onCancel={() => setMethodToDelete(null)}
                />
            )}
        </>
    );
}