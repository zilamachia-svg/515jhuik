import { useState, useEffect, useCallback } from 'react';
import { motion } from 'framer-motion';
import { toast } from 'sonner';
import { User, ApiError } from '../../types';
import apiClient from '../../services/apiClient';
import { formatCurrency, formatApiErrorForToast } from '../../utils';
import { usePageTitle } from '../../contexts/PageTitleContext';
import { useDebounce } from '../../hooks/useDebounce';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Pagination } from '@/components/Pagination';
import { Edit, Trash2, Users, Search, UserPlus } from 'lucide-react';
import { EditUserModal } from '../../components/admin/EditUserModal';
import { ConfirmationModal } from '../../components/ConfirmationModal';
import { TableSkeleton } from '../../components/skeletons/TableSkeleton';

const ITEMS_PER_PAGE = 10;

export default function UserManagementPage() {
    usePageTitle("Quản lý Người dùng");

    const [users, setUsers] = useState<User[]>([]);
    const [isLoading, setIsLoading] = useState(true);
    const [currentPage, setCurrentPage] = useState(1);
    const [totalPages, setTotalPages] = useState(1);
    const [totalItems, setTotalItems] = useState(0);
    const [searchTerm, setSearchTerm] = useState('');
    const debouncedSearch = useDebounce(searchTerm, 500);

    const [userToEdit, setUserToEdit] = useState<User | null>(null);
    const [userToDelete, setUserToDelete] = useState<User | null>(null);

    const fetchUsers = useCallback(async (page: number, search: string) => {
        setIsLoading(true);
        try {
            const response = await apiClient.get('/admin/users', {
                params: { page, limit: ITEMS_PER_PAGE, search: search || undefined },
            });
            setUsers(response.data.data);
            setTotalPages(response.data.totalPages);
            setTotalItems(response.data.totalItems);
            setCurrentPage(response.data.currentPage);
        } catch (error) {
            toast.error(formatApiErrorForToast(error as ApiError, 'Không thể tải danh sách người dùng.'));
        } finally {
            setIsLoading(false);
        }
    }, []);

    useEffect(() => {
        fetchUsers(currentPage, debouncedSearch);
    }, [fetchUsers, currentPage, debouncedSearch]);

    const handlePageChange = (page: number) => {
        setCurrentPage(page);
    };

    const handleDeleteUser = async () => {
        if (!userToDelete) return;
        try {
            await apiClient.delete(`/admin/users/${userToDelete.id}`);
            toast.success(`Đã xóa người dùng ${userToDelete.name}.`);
            setUserToDelete(null);
            fetchUsers(currentPage, debouncedSearch); // Refresh data
        } catch (error) {
            toast.error(formatApiErrorForToast(error as ApiError, 'Xóa người dùng thất bại.'));
            setUserToDelete(null);
        }
    };

    return (
        <>
            <div className="space-y-8">
                {/* Banner Section */}
                <motion.div
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.5 }}
                    className="overflow-hidden rounded-3xl bg-gradient-to-r from-blue-400/85 via-cyan-400/85 to-teal-400/85 p-8 text-white"
                >
                    <div className="flex flex-col gap-6 md:flex-row md:items-center md:justify-between">
                        <div className="space-y-2">
                            <h2 className="text-3xl font-bold flex items-center gap-2">
                                <span className="text-3xl">👥</span>
                                Quản lý Người dùng
                            </h2>
                            <p className="max-w-[600px] text-white/80">
                                Quản lý tất cả người dùng trong hệ thống, xem thông tin và chỉnh sửa quyền truy cập.
                            </p>
                        </div>
                        <div className="flex items-center gap-3">
                            <div className="flex h-16 w-16 items-center justify-center rounded-2xl bg-white/20 backdrop-blur-md">
                                <Users className="h-8 w-8" />
                            </div>
                        </div>
                    </div>
                </motion.div>

                {/* Search Bar */}
                <div className="flex items-center gap-3">
                    <div className="relative flex-1">
                        <Search className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                        <Input
                            type="search"
                            placeholder="Tìm kiếm email hoặc tên..."
                            value={searchTerm}
                            onChange={(e) => setSearchTerm(e.target.value)}
                            className="w-full rounded-2xl pl-9"
                        />
                    </div>
                    <Button 
                        className="rounded-2xl"
                        onClick={() => toast.info('Tính năng thêm người dùng đang được phát triển')}
                    >
                        <UserPlus className="mr-2 h-4 w-4" />
                        Thêm người dùng
                    </Button>
                </div>

                {/* Users Table */}
                <Card className="rounded-3xl">
                    <CardHeader>
                        <CardTitle>Danh sách Người dùng</CardTitle>
                    </CardHeader>
                    <CardContent>
                        {isLoading && !users.length ? (
                             <TableSkeleton headers={['Tên', 'Email', 'Số dư', 'Quyền', 'Ngày tham gia', 'Hành động']} />
                        ) : (
                            <div className="w-full overflow-auto rounded-2xl border">
                                <Table>
                                    <TableHeader>
                                        <TableRow>
                                            <TableHead>Tên</TableHead>
                                            <TableHead>Email</TableHead>
                                            <TableHead>Số dư</TableHead>
                                            <TableHead>Quyền</TableHead>
                                            <TableHead>Ngày tham gia</TableHead>
                                            <TableHead>Hành động</TableHead>
                                        </TableRow>
                                    </TableHeader>
                                    <TableBody>
                                        {users.map(user => (
                                            <TableRow key={user.id} className="hover:bg-muted/50 transition-colors">
                                                <TableCell className="font-medium">{user.name}</TableCell>
                                                <TableCell>{user.email}</TableCell>
                                                <TableCell className="font-semibold">{formatCurrency(user.balance)}</TableCell>
                                                <TableCell>
                                                    <Badge variant={user.role === 'admin' ? 'default' : 'secondary'} className="rounded-xl">
                                                        {user.role}
                                                    </Badge>
                                                </TableCell>
                                                <TableCell>{user.createdAt ? new Date(user.createdAt).toLocaleDateString('vi-VN') : 'N/A'}</TableCell>
                                                <TableCell>
                                                    <div className="flex items-center gap-2">
                                                        <Button variant="ghost" size="icon" className="rounded-xl" onClick={() => setUserToEdit(user)}>
                                                            <Edit size={14} />
                                                        </Button>
                                                        <Button variant="ghost" size="icon" className="rounded-xl text-destructive hover:text-destructive" onClick={() => setUserToDelete(user)}>
                                                            <Trash2 size={14} />
                                                        </Button>
                                                    </div>
                                                </TableCell>
                                            </TableRow>
                                        ))}
                                    </TableBody>
                                </Table>
                            </div>
                        )}

                        {!isLoading && users.length === 0 && (
                            <div className="text-center p-12">
                                <Users className="mx-auto h-12 w-12 text-muted-foreground mb-4" />
                                <p className="text-muted-foreground">Không tìm thấy người dùng nào.</p>
                            </div>
                        )}

                        {totalPages > 1 && (
                            <div className="mt-6">
                                <Pagination
                                    currentPage={currentPage}
                                    totalPages={totalPages}
                                    totalItems={totalItems}
                                    itemsPerPage={ITEMS_PER_PAGE}
                                    onPageChange={handlePageChange}
                                />
                            </div>
                        )}
                    </CardContent>
                </Card>
            </div>

            {userToEdit && (
                <EditUserModal
                    user={userToEdit}
                    onClose={() => setUserToEdit(null)}
                    onSave={() => {
                        setUserToEdit(null);
                        fetchUsers(currentPage, debouncedSearch); // Refresh data
                    }}
                />
            )}
            
            {userToDelete && (
                <ConfirmationModal
                    title="Xác nhận xóa người dùng"
                    message={`Bạn có chắc muốn xóa vĩnh viễn người dùng "${userToDelete.name}"? Hành động này không thể hoàn tác.`}
                    isDestructive
                    onConfirm={handleDeleteUser}
                    onCancel={() => setUserToDelete(null)}
                />
            )}
        </>
    );
}