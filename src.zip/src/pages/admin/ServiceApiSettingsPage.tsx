import React, { useState } from 'react';
// FIX: Use sonner for consistent notifications
import { toast } from 'sonner';
import { ServiceApiSettings } from '../../types';
import { usePageTitle } from '../../contexts/PageTitleContext';
// FIX: Use Card components from shadcn/ui
import { Card, CardContent, CardHeader, CardTitle, CardFooter } from '@/components/ui/card';
// FIX: Use Button from shadcn/ui
import { Button } from '@/components/ui/button';
// FIX: Use Switch from shadcn/ui
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { Spinner } from '@/components/ui/spinner';

const mockSettings: ServiceApiSettings = {
    externalApiKey: 'key_1234567890abcdef',
    webhookEndpoint: 'https://myservice.com/webhook',
    retryOnError: true,
};

export default function ServiceApiSettingsPage() {
    usePageTitle("Cài đặt Service API");
    const [settings, setSettings] = useState<ServiceApiSettings>(mockSettings);
    const [isLoading, setIsLoading] = useState(false);

    const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        setSettings(prev => ({...prev, [e.target.name]: e.target.value}));
    };
    
    const handleToggle = (checked: boolean) => {
        setSettings(prev => ({ ...prev, retryOnError: checked }));
    };

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        setIsLoading(true);
        setTimeout(() => {
            toast.success("Đã lưu cài đặt Service API!");
            setIsLoading(false);
        }, 1000);
    };

    return (
        <Card>
            <CardHeader>
                <CardTitle>Cài đặt API Dịch vụ Ngoài</CardTitle>
            </CardHeader>
            <form onSubmit={handleSubmit}>
                <CardContent className="space-y-4">
                    <div className="space-y-2">
                        <Label htmlFor="externalApiKey">API Key dịch vụ</Label>
                        <Input type="password" id="externalApiKey" name="externalApiKey" value={settings.externalApiKey} onChange={handleChange} />
                    </div>
                    <div className="space-y-2">
                        <Label htmlFor="webhookEndpoint">Webhook Endpoint</Label>
                        <Input type="url" id="webhookEndpoint" name="webhookEndpoint" value={settings.webhookEndpoint} onChange={handleChange} />
                    </div>
                    <div className="flex items-center space-x-2">
                        <Switch id="retryOnError" checked={settings.retryOnError} onCheckedChange={handleToggle} />
                        <Label htmlFor="retryOnError">Tự động thử lại khi lỗi ({settings.retryOnError ? 'Đang bật' : 'Đang tắt'})</Label>
                    </div>
                </CardContent>
                <CardFooter className="flex justify-end">
                    <Button type="submit" disabled={isLoading}>
                        {isLoading && <Spinner className="mr-2 h-4 w-4 animate-spin" />}
                        Lưu thay đổi
                    </Button>
                </CardFooter>
            </form>
        </Card>
    );
}