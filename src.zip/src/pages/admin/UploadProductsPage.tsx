import React, { useState, useEffect } from 'react';
import { toast } from 'sonner';
import { ProductCategory, ApiError } from '../../types';
import apiClient from '../../services/apiClient';
import { formatApiErrorForToast } from '../../utils';
import { usePageTitle } from '../../contexts/PageTitleContext';
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Upload } from 'lucide-react';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import { Spinner } from '@/components/ui/spinner';

export default function UploadProductsPage() {
    usePageTitle("Thêm sản phẩm hàng loạt");

    const [categories, setCategories] = useState<ProductCategory[]>([]);
    const [selectedCategory, setSelectedCategory] = useState('');
    const [productData, setProductData] = useState('');
    const [isLoading, setIsLoading] = useState(false);

    useEffect(() => {
        apiClient.get('/admin/product-categories')
            .then(res => {
                setCategories(res.data.categories);
                if (res.data.categories.length > 0) {
                    setSelectedCategory(res.data.categories[0].name);
                }
            })
            .catch(() => toast.error('Không thể tải danh mục sản phẩm.'));
    }, []);

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        const items = productData.split('\n').map(line => line.trim()).filter(Boolean);

        if (!selectedCategory || items.length === 0) {
            toast.warning('Vui lòng chọn danh mục và nhập dữ liệu sản phẩm.');
            return;
        }

        setIsLoading(true);
        try {
            const response = await apiClient.post('/admin/products/upload', {
                category: selectedCategory,
                items: items,
            });
            toast.success(`Đã thêm thành công ${response.data.count} mục vào danh mục ${selectedCategory}.`);
            setProductData(''); // Clear textarea on success
        } catch (error) {
            toast.error(formatApiErrorForToast(error as ApiError, 'Tải lên thất bại.'));
        } finally {
            setIsLoading(false);
        }
    };

    return (
        <Card>
            <CardHeader>
                <CardTitle>Thêm dữ liệu sản phẩm</CardTitle>
            </CardHeader>
            <form onSubmit={handleSubmit}>
                <CardContent className="space-y-4">
                    <div className="space-y-2">
                        <Label htmlFor="category-select">Chọn danh mục sản phẩm</Label>
                        <Select
                            value={selectedCategory}
                            onValueChange={setSelectedCategory}
                            required
                            disabled={categories.length === 0}
                        >
                            <SelectTrigger id="category-select">
                                <SelectValue placeholder="Chọn danh mục..." />
                            </SelectTrigger>
                            <SelectContent>
                                {categories.map(cat => (
                                    <SelectItem key={cat.id} value={cat.name}>{cat.name}</SelectItem>
                                ))}
                            </SelectContent>
                        </Select>
                    </div>

                    <div className="space-y-2">
                        <Label htmlFor="product-data">Dữ liệu sản phẩm</Label>
                        <Textarea
                            id="product-data"
                            rows={15}
                            value={productData}
                            onChange={(e) => setProductData(e.target.value)}
                            placeholder="Mỗi dòng là một sản phẩm (ví dụ: uid|pass|2fa|...)"
                            required
                        />
                        <p className="text-sm text-muted-foreground">Hệ thống sẽ tự động cập nhật số lượng tồn kho cho danh mục đã chọn.</p>
                    </div>
                </CardContent>
                <CardFooter className="flex justify-end">
                    <Button type="submit" disabled={isLoading}>
                        {isLoading ? <Spinner className="mr-2 h-4 w-4 animate-spin" /> : <Upload size={16} className="mr-2" />}
                        Tải lên
                    </Button>
                </CardFooter>
            </form>
        </Card>
    );
}