import React, { useState } from 'react';
// FIX: Use sonner for consistent notifications
import { toast } from 'sonner';
import { ToolsSettings } from '../../types';
import { usePageTitle } from '../../contexts/PageTitleContext';
// FIX: Use Card from shadcn/ui
import { Card, CardContent, CardHeader, CardTitle, CardFooter } from '@/components/ui/card';
// FIX: Use Button from shadcn/ui
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Spinner } from '@/components/ui/spinner';

const mockSettings: ToolsSettings = {
    checkLiveEngine: 'internal',
    checkLiveApiKey: 'key_abcdef123456',
    requestLimitPerUser: 100,
    cacheDurationMinutes: 15,
};

export default function ToolsSettingsPage() {
    usePageTitle("Cài đặt Công cụ");
    const [settings, setSettings] = useState<ToolsSettings>(mockSettings);
    const [isLoading, setIsLoading] = useState(false);

    const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        setSettings(prev => ({...prev, [e.target.name]: e.target.value}));
    };
    
    const handleSelectChange = (value: 'internal' | 'external') => {
        setSettings(prev => ({ ...prev, checkLiveEngine: value }));
    };

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        setIsLoading(true);
        setTimeout(() => {
            toast.success("Đã lưu cài đặt công cụ!");
            setIsLoading(false);
        }, 1000);
    };

    return (
        <Card>
            <CardHeader><CardTitle>Cài đặt Công cụ</CardTitle></CardHeader>
            <form onSubmit={handleSubmit}>
                <CardContent className="space-y-4">
                    <div className="space-y-2">
                        <Label htmlFor="checkLiveEngine">Engine Check Live</Label>
                        <Select value={settings.checkLiveEngine} onValueChange={handleSelectChange}>
                            <SelectTrigger id="checkLiveEngine">
                                <SelectValue placeholder="Chọn engine" />
                            </SelectTrigger>
                            <SelectContent>
                                <SelectItem value="internal">Hệ thống</SelectItem>
                                <SelectItem value="external">Dịch vụ ngoài</SelectItem>
                            </SelectContent>
                        </Select>
                    </div>
                    <div className="space-y-2">
                        <Label htmlFor="checkLiveApiKey">API Key Check Live (nếu dùng dịch vụ ngoài)</Label>
                        <Input type="password" id="checkLiveApiKey" name="checkLiveApiKey" value={settings.checkLiveApiKey} onChange={handleChange} />
                    </div>
                    <div className="space-y-2">
                        <Label htmlFor="requestLimitPerUser">Giới hạn request / người dùng / ngày</Label>
                        <Input type="number" id="requestLimitPerUser" name="requestLimitPerUser" value={settings.requestLimitPerUser} onChange={handleChange} />
                    </div>
                    <div className="space-y-2">
                        <Label htmlFor="cacheDurationMinutes">Thời gian cache kết quả (phút)</Label>
                        <Input type="number" id="cacheDurationMinutes" name="cacheDurationMinutes" value={settings.cacheDurationMinutes} onChange={handleChange} />
                    </div>
                </CardContent>
                <CardFooter className="flex justify-end">
                    <Button type="submit" disabled={isLoading}>
                        {isLoading && <Spinner className="mr-2 h-4 w-4 animate-spin" />}
                        Lưu thay đổi
                    </Button>
                </CardFooter>
            </form>
        </Card>
    );
}