import { useState, useEffect, useCallback } from 'react';
import { motion } from 'framer-motion';
import { toast } from 'sonner';
import { Deposit, ApiError } from '../../types';
import apiClient from '../../services/apiClient';
import { formatCurrency, formatApiErrorForToast } from '../../utils';
import { usePageTitle } from '../../contexts/PageTitleContext';
import { useDebounce } from '../../hooks/useDebounce';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Pagination } from '@/components/Pagination';
import { Check, X, Wallet, Search } from 'lucide-react';
import { ConfirmationModal } from '../../components/ConfirmationModal';
import { TableSkeleton } from '../../components/skeletons/TableSkeleton';

const ITEMS_PER_PAGE = 10;

type ActionType = 'approve' | 'reject';

export default function DepositManagementPage() {
    usePageTitle("Quản lý Nạp tiền");

    const [deposits, setDeposits] = useState<Deposit[]>([]);
    const [isLoading, setIsLoading] = useState(true);
    const [currentPage, setCurrentPage] = useState(1);
    const [totalPages, setTotalPages] = useState(1);
    const [totalItems, setTotalItems] = useState(0);
    const [searchTerm, setSearchTerm] = useState('');
    const debouncedSearch = useDebounce(searchTerm, 500);

    const [depositToConfirm, setDepositToConfirm] = useState<{ deposit: Deposit, action: ActionType } | null>(null);

    const fetchDeposits = useCallback(async (page: number, search: string) => {
        setIsLoading(true);
        try {
            const response = await apiClient.get('/admin/deposits', {
                params: { page, limit: ITEMS_PER_PAGE, search: search || undefined },
            });
            setDeposits(response.data.data);
            setTotalPages(response.data.totalPages);
            setTotalItems(response.data.totalItems);
            setCurrentPage(response.data.currentPage);
        } catch (error) {
            toast.error(formatApiErrorForToast(error as ApiError, 'Không thể tải danh sách giao dịch.'));
        } finally {
            setIsLoading(false);
        }
    }, []);

    useEffect(() => {
        fetchDeposits(currentPage, debouncedSearch);
    }, [fetchDeposits, currentPage, debouncedSearch]);

    const handlePageChange = (page: number) => {
        setCurrentPage(page);
    };

    const handleUpdateStatus = async () => {
        if (!depositToConfirm) return;
        
        const { deposit, action } = depositToConfirm;
        const newStatus = action === 'approve' ? 'Hoàn thành' : 'Thất bại';

        try {
            await apiClient.put(`/admin/deposits/${deposit.id}`, { status: newStatus });
            toast.success(`Đã ${action === 'approve' ? 'duyệt' : 'từ chối'} giao dịch.`);
            setDepositToConfirm(null);
            fetchDeposits(currentPage, debouncedSearch);
        } catch (error) {
            toast.error(formatApiErrorForToast(error as ApiError, 'Cập nhật thất bại.'));
            setDepositToConfirm(null);
        }
    };

    return (
        <>
            <div className="space-y-8">
                {/* Banner Section */}
                <motion.div
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.5 }}
                    className="overflow-hidden rounded-3xl bg-gradient-to-r from-yellow-400/85 via-amber-400/85 to-orange-400/85 p-8 text-white"
                >
                    <div className="flex flex-col gap-6 md:flex-row md:items-center md:justify-between">
                        <div className="space-y-2">
                            <h2 className="text-3xl font-bold flex items-center gap-2">
                                <span className="text-3xl">💳</span>
                                Quản lý Nạp tiền
                            </h2>
                            <p className="max-w-[600px] text-white/80">
                                Xem và quản lý tất cả giao dịch nạp tiền, duyệt hoặc từ chối các yêu cầu nạp tiền.
                            </p>
                        </div>
                        <div className="flex items-center gap-3">
                            <div className="flex h-16 w-16 items-center justify-center rounded-2xl bg-white/20 backdrop-blur-md">
                                <Wallet className="h-8 w-8" />
                            </div>
                        </div>
                    </div>
                </motion.div>

                {/* Search Bar */}
                <div className="flex items-center gap-3">
                    <div className="relative flex-1">
                        <Search className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                        <Input
                            type="search"
                            placeholder="Tìm kiếm email, mã GD..."
                            value={searchTerm}
                            onChange={(e) => setSearchTerm(e.target.value)}
                            className="w-full rounded-2xl pl-9"
                        />
                    </div>
                </div>

            <Card className="rounded-3xl">
                <CardHeader>
                    <CardTitle>Danh sách giao dịch</CardTitle>
                </CardHeader>
                <CardContent>
                     {isLoading && !deposits.length ? (
                        <TableSkeleton headers={['Email', 'Số tiền', 'Phương thức', 'Ngày tạo', 'Trạng thái', 'Hành động']} />
                     ) : (
                        <div className="w-full overflow-auto">
                            <Table>
                                <TableHeader>
                                    <TableRow>
                                        <TableHead>Email</TableHead>
                                        <TableHead>Số tiền</TableHead>
                                        <TableHead>Phương thức</TableHead>
                                        <TableHead>Ngày tạo</TableHead>
                                        <TableHead>Trạng thái</TableHead>
                                        <TableHead>Hành động</TableHead>
                                    </TableRow>
                                </TableHeader>
                                <TableBody>
                                    {deposits.map(d => (
                                        <TableRow key={d.id}>
                                            <TableCell>{d.userEmail}</TableCell>
                                            <TableCell>{formatCurrency(d.amount)}</TableCell>
                                            <TableCell>{d.method}</TableCell>
                                            <TableCell>{new Date(d.createdAt).toLocaleString('vi-VN')}</TableCell>
                                            <TableCell>{d.status}</TableCell>
                                            <TableCell>
                                                {d.status === 'Đang chờ' && (
                                                    <div className="flex gap-2">
                                                        <Button 
                                                            variant="outline" 
                                                            size="sm" 
                                                            onClick={() => setDepositToConfirm({ deposit: d, action: 'approve' })}
                                                            className="rounded-xl"
                                                        >
                                                            <Check size={14} className="mr-2" /> Duyệt
                                                        </Button>
                                                        <Button 
                                                            variant="destructive" 
                                                            size="sm" 
                                                            onClick={() => setDepositToConfirm({ deposit: d, action: 'reject' })}
                                                            className="rounded-xl"
                                                        >
                                                            <X size={14} className="mr-2" /> Hủy
                                                        </Button>
                                                    </div>
                                                )}
                                            </TableCell>
                                        </TableRow>
                                    ))}
                                </TableBody>
                            </Table>
                        </div>
                     )}
                     {!isLoading && deposits.length === 0 && (
                        <p className="text-center p-8 text-muted-foreground">Không có giao dịch nào.</p>
                     )}
                     {totalPages > 1 && (
                        <div className="mt-6">
                            <Pagination
                                currentPage={currentPage}
                                totalPages={totalPages}
                                totalItems={totalItems}
                                itemsPerPage={ITEMS_PER_PAGE}
                                onPageChange={handlePageChange}
                            />
                        </div>
                     )}
                </CardContent>
            </Card>
            </div>

            {depositToConfirm && (
                <ConfirmationModal
                    title={`Xác nhận ${depositToConfirm.action === 'approve' ? 'duyệt' : 'hủy'}`}
                    message={`Bạn có chắc muốn ${depositToConfirm.action === 'approve' ? 'duyệt' : 'hủy'} giao dịch ${formatCurrency(depositToConfirm.deposit.amount)} của ${depositToConfirm.deposit.userEmail}?`}
                    isDestructive={depositToConfirm.action === 'reject'}
                    onConfirm={handleUpdateStatus}
                    onCancel={() => setDepositToConfirm(null)}
                />
            )}
        </>
    );
}