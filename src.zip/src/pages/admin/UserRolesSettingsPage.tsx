import React, { useState } from 'react';
// FIX: Use sonner for consistent notifications
import { toast } from 'sonner';
import { UserRolesSettings } from '../../types';
import { usePageTitle } from '../../contexts/PageTitleContext';
// FIX: Use Card components from shadcn/ui
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
// FIX: Use Button from shadcn/ui
import { Button } from '@/components/ui/button';
// FIX: Use Switch from shadcn/ui
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { Spinner } from '@/components/ui/spinner';
import { Plus, Trash2, Crown, Gift } from 'lucide-react';

const initialSettings: UserRolesSettings = {
    vipTiers: [
        { id: 1, name: 'VIP 1', minDeposit: 5000000, discountPercent: 2 },
        { id: 2, name: 'VIP 2', minDeposit: 15000000, discountPercent: 5 },
    ],
    kycRequired: false,
    depositBonuses: [
        { id: 1, depositAmount: 500000, bonusPercent: 3 },
        { id: 2, depositAmount: 1000000, bonusPercent: 5 },
    ]
};

export default function UserRolesSettingsPage() {
    usePageTitle("Cài đặt Phân quyền");
    const [settings, setSettings] = useState<UserRolesSettings>(initialSettings);
    const [isLoading, setIsLoading] = useState(false);

    const handleVipTierChange = (id: number, field: 'name' | 'minDeposit' | 'discountPercent', value: string | number) => {
        setSettings(prev => ({
            ...prev,
            vipTiers: prev.vipTiers.map(tier => 
                tier.id === id ? { ...tier, [field]: value } : tier
            )
        }));
    };

    const handleAddVipTier = () => {
        const newId = Math.max(...settings.vipTiers.map(t => t.id), 0) + 1;
        setSettings(prev => ({
            ...prev,
            vipTiers: [...prev.vipTiers, { id: newId, name: `VIP ${newId}`, minDeposit: 0, discountPercent: 0 }]
        }));
    };

    const handleRemoveVipTier = (id: number) => {
        setSettings(prev => ({
            ...prev,
            vipTiers: prev.vipTiers.filter(tier => tier.id !== id)
        }));
    };

    const handleBonusChange = (id: number, field: 'depositAmount' | 'bonusPercent', value: number) => {
        setSettings(prev => ({
            ...prev,
            depositBonuses: prev.depositBonuses.map(bonus => 
                bonus.id === id ? { ...bonus, [field]: value } : bonus
            )
        }));
    };

    const handleAddBonus = () => {
        const newId = Math.max(...settings.depositBonuses.map(b => b.id), 0) + 1;
        setSettings(prev => ({
            ...prev,
            depositBonuses: [...prev.depositBonuses, { id: newId, depositAmount: 0, bonusPercent: 0 }]
        }));
    };

    const handleRemoveBonus = (id: number) => {
        setSettings(prev => ({
            ...prev,
            depositBonuses: prev.depositBonuses.filter(bonus => bonus.id !== id)
        }));
    };

    const handleToggleKyc = (checked: boolean) => {
        setSettings(prev => ({ ...prev, kycRequired: checked }));
    };

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        setIsLoading(true);
        setTimeout(() => {
            toast.success("Đã lưu cài đặt phân quyền!");
            setIsLoading(false);
        }, 1000);
    };

    const formatCurrency = (amount: number) => {
        return new Intl.NumberFormat('vi-VN', { style: 'currency', currency: 'VND' }).format(amount);
    };

    return (
        <form onSubmit={handleSubmit} className="space-y-6">
            <Card className="rounded-2xl shadow-xl hover:shadow-2xl transition-shadow duration-300">
                <CardHeader className="flex-row items-center justify-between">
                    <div className="space-y-1">
                        <CardTitle className="text-xl font-bold flex items-center gap-2">
                            <Crown className="h-5 w-5 text-yellow-500" />
                            Cấp VIP
                        </CardTitle>
                        <p className="text-sm text-muted-foreground font-medium">
                            Thiết lập các cấp độ VIP dựa trên tổng nạp
                        </p>
                    </div>
                    <Button type="button" variant="outline" size="sm" onClick={handleAddVipTier} className="shadow-md font-semibold rounded-lg">
                        <Plus size={16} className="mr-2" />
                        Thêm cấp VIP
                    </Button>
                </CardHeader>
                <CardContent className="space-y-4">
                    {settings.vipTiers.map((tier, index) => (
                        <div key={tier.id} className="grid grid-cols-1 md:grid-cols-[2fr_3fr_2fr_auto] gap-4 p-4 bg-gradient-to-r from-yellow-50 to-orange-50 border-2 border-yellow-200 rounded-xl">
                            <div className="space-y-1">
                                <Label className="text-xs font-semibold text-muted-foreground">Tên cấp</Label>
                                <Input 
                                    type="text" 
                                    value={tier.name} 
                                    onChange={(e) => handleVipTierChange(tier.id, 'name', e.target.value)}
                                    placeholder="VIP 1"
                                    className="rounded-lg shadow-sm font-semibold"
                                />
                            </div>
                            <div className="space-y-1">
                                <Label className="text-xs font-semibold text-muted-foreground">Tổng nạp tối thiểu (VND)</Label>
                                <Input 
                                    type="number" 
                                    value={tier.minDeposit} 
                                    onChange={(e) => handleVipTierChange(tier.id, 'minDeposit', Number(e.target.value))}
                                    placeholder="5000000"
                                    className="rounded-lg shadow-sm font-medium"
                                />
                                <p className="text-xs text-muted-foreground font-medium">{formatCurrency(tier.minDeposit)}</p>
                            </div>
                            <div className="space-y-1">
                                <Label className="text-xs font-semibold text-muted-foreground">% Giảm giá</Label>
                                <Input 
                                    type="number" 
                                    value={tier.discountPercent} 
                                    onChange={(e) => handleVipTierChange(tier.id, 'discountPercent', Number(e.target.value))}
                                    placeholder="5"
                                    min="0"
                                    max="100"
                                    className="rounded-lg shadow-sm font-bold text-green-600"
                                />
                            </div>
                            <div className="flex items-end">
                                <Button 
                                    type="button" 
                                    variant="ghost" 
                                    size="icon" 
                                    onClick={() => handleRemoveVipTier(tier.id)}
                                    className="text-destructive hover:bg-destructive/10"
                                    disabled={settings.vipTiers.length === 1}
                                >
                                    <Trash2 size={16} />
                                </Button>
                            </div>
                        </div>
                    ))}
                </CardContent>
            </Card>

            <Card className="rounded-2xl shadow-xl hover:shadow-2xl transition-shadow duration-300">
                <CardHeader className="flex-row items-center justify-between">
                    <div className="space-y-1">
                        <CardTitle className="text-xl font-bold flex items-center gap-2">
                            <Gift className="h-5 w-5 text-pink-500" />
                            Thưởng Nạp
                        </CardTitle>
                        <p className="text-sm text-muted-foreground font-medium">
                            Cấu hình các mốc thưởng khi nạp tiền
                        </p>
                    </div>
                    <Button type="button" variant="outline" size="sm" onClick={handleAddBonus} className="shadow-md font-semibold rounded-lg">
                        <Plus size={16} className="mr-2" />
                        Thêm mốc thưởng
                    </Button>
                </CardHeader>
                <CardContent className="space-y-4">
                    {settings.depositBonuses.map((bonus) => (
                        <div key={bonus.id} className="grid grid-cols-1 md:grid-cols-[1fr_1fr_auto] gap-4 p-4 bg-gradient-to-r from-pink-50 to-purple-50 border-2 border-pink-200 rounded-xl">
                            <div className="space-y-1">
                                <Label className="text-xs font-semibold text-muted-foreground">Mức nạp (VND)</Label>
                                <Input 
                                    type="number" 
                                    value={bonus.depositAmount} 
                                    onChange={(e) => handleBonusChange(bonus.id, 'depositAmount', Number(e.target.value))}
                                    placeholder="500000"
                                    className="rounded-lg shadow-sm font-medium"
                                />
                                <p className="text-xs text-muted-foreground font-medium">{formatCurrency(bonus.depositAmount)}</p>
                            </div>
                            <div className="space-y-1">
                                <Label className="text-xs font-semibold text-muted-foreground">% Thưởng</Label>
                                <Input 
                                    type="number" 
                                    value={bonus.bonusPercent} 
                                    onChange={(e) => handleBonusChange(bonus.id, 'bonusPercent', Number(e.target.value))}
                                    placeholder="5"
                                    min="0"
                                    max="100"
                                    className="rounded-lg shadow-sm font-bold text-pink-600"
                                />
                            </div>
                            <div className="flex items-end">
                                <Button 
                                    type="button" 
                                    variant="ghost" 
                                    size="icon" 
                                    onClick={() => handleRemoveBonus(bonus.id)}
                                    className="text-destructive hover:bg-destructive/10"
                                    disabled={settings.depositBonuses.length === 1}
                                >
                                    <Trash2 size={16} />
                                </Button>
                            </div>
                        </div>
                    ))}
                </CardContent>
            </Card>

            <Card className="rounded-2xl shadow-xl hover:shadow-2xl transition-shadow duration-300">
                <CardHeader>
                    <CardTitle className="text-xl font-bold">Yêu cầu khác</CardTitle>
                </CardHeader>
                <CardContent>
                    <div className="flex items-center space-x-3 p-4 bg-blue-50 border-2 border-blue-200 rounded-xl">
                        <Switch id="kycRequired" checked={settings.kycRequired} onCheckedChange={handleToggleKyc} />
                        <Label htmlFor="kycRequired" className="font-semibold cursor-pointer">
                            Yêu cầu KYC để giao dịch 
                            <span className={`ml-2 text-sm ${settings.kycRequired ? 'text-green-600' : 'text-gray-500'}`}>
                                ({settings.kycRequired ? 'Đang bật' : 'Đang tắt'})
                            </span>
                        </Label>
                    </div>
                </CardContent>
            </Card>
            
            <div className="sticky bottom-6 flex justify-end">
                <Button type="submit" disabled={isLoading} size="lg" className="shadow-xl hover:shadow-2xl transition-all duration-300 rounded-xl font-bold text-base px-8">
                    {isLoading && <Spinner className="mr-2 h-5 w-5 animate-spin" />}
                    Lưu tất cả thay đổi
                </Button>
            </div>
        </form>
    );
}