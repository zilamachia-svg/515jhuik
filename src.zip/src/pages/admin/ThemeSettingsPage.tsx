import React from 'react';
import { useTheme } from '../../contexts/ThemeContext';
import { usePageTitle } from '../../contexts/PageTitleContext';
import { Button } from '@/components/ui/button';
import { toast } from 'sonner';
import { Card, CardContent, CardHeader, CardTitle, CardFooter } from '@/components/ui/card';
import { Label } from '@/components/ui/label';

export default function ThemeSettingsPage() {
    usePageTitle("Cài đặt Giao diện");
    const { settings, setSettings, isDarkMode } = useTheme();

    const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        setSettings({ ...settings, [e.target.name]: e.target.value });
    };
    
    const handleSave = (e: React.FormEvent) => {
        e.preventDefault();
        // The context already saves to localStorage on change, so this is just for user feedback
        toast.success('Đã lưu cài đặt giao diện!');
    }

    return (
        <Card className="rounded-2xl shadow-xl hover:shadow-2xl transition-shadow duration-300">
            <CardHeader>
                <CardTitle className="text-xl font-bold">{`Tùy chỉnh Giao diện (${isDarkMode ? 'Dark' : 'Light'} Mode)`}</CardTitle>
                <p className="text-sm text-muted-foreground font-medium mt-2">
                    Thay đổi màu sắc chủ đạo của giao diện
                </p>
            </CardHeader>
            <form onSubmit={handleSave}>
                <CardContent>
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                        <div className="space-y-2">
                            <Label htmlFor="primaryColor" className="text-sm font-semibold">Màu chính (Primary)</Label>
                            <div className="flex items-center gap-3">
                                <input type="color" id="primaryColor" name="primaryColor" value={settings.primaryColor} onChange={handleChange} className="w-16 h-16 p-1 bg-card border-2 border-input rounded-xl shadow-md cursor-pointer hover:scale-105 transition-transform" />
                                <div className="flex-1 space-y-1">
                                    <p className="text-xs text-muted-foreground font-medium">Màu nút, liên kết</p>
                                    <code className="text-xs bg-gray-100 px-2 py-1 rounded font-mono">{settings.primaryColor}</code>
                                </div>
                            </div>
                        </div>
                         <div className="space-y-2">
                            <Label htmlFor="secondaryColor" className="text-sm font-semibold">Màu phụ (Secondary)</Label>
                            <div className="flex items-center gap-3">
                                <input type="color" id="secondaryColor" name="secondaryColor" value={settings.secondaryColor} onChange={handleChange} className="w-16 h-16 p-1 bg-card border-2 border-input rounded-xl shadow-md cursor-pointer hover:scale-105 transition-transform" />
                                <div className="flex-1 space-y-1">
                                    <p className="text-xs text-muted-foreground font-medium">Màu phụ trợ</p>
                                    <code className="text-xs bg-gray-100 px-2 py-1 rounded font-mono">{settings.secondaryColor}</code>
                                </div>
                            </div>
                        </div>
                         <div className="space-y-2">
                            <Label htmlFor="accentColor" className="text-sm font-semibold">Màu nhấn (Accent)</Label>
                            <div className="flex items-center gap-3">
                                <input type="color" id="accentColor" name="accentColor" value={settings.accentColor} onChange={handleChange} className="w-16 h-16 p-1 bg-card border-2 border-input rounded-xl shadow-md cursor-pointer hover:scale-105 transition-transform" />
                                <div className="flex-1 space-y-1">
                                    <p className="text-xs text-muted-foreground font-medium">Màu nhấn mạnh</p>
                                    <code className="text-xs bg-gray-100 px-2 py-1 rounded font-mono">{settings.accentColor}</code>
                                </div>
                            </div>
                        </div>
                        <div className="space-y-2">
                            <Label htmlFor="textColor" className="text-sm font-semibold">Màu chữ</Label>
                            <div className="flex items-center gap-3">
                                <input type="color" id="textColor" name="textColor" value={settings.textColor} onChange={handleChange} className="w-16 h-16 p-1 bg-card border-2 border-input rounded-xl shadow-md cursor-pointer hover:scale-105 transition-transform" />
                                <div className="flex-1 space-y-1">
                                    <p className="text-xs text-muted-foreground font-medium">Màu văn bản chính</p>
                                    <code className="text-xs bg-gray-100 px-2 py-1 rounded font-mono">{settings.textColor}</code>
                                </div>
                            </div>
                        </div>
                        <div className="space-y-2">
                            <Label htmlFor="cardColor" className="text-sm font-semibold">Màu thẻ</Label>
                            <div className="flex items-center gap-3">
                                <input type="color" id="cardColor" name="cardColor" value={settings.cardColor} onChange={handleChange} className="w-16 h-16 p-1 bg-card border-2 border-input rounded-xl shadow-md cursor-pointer hover:scale-105 transition-transform" />
                                <div className="flex-1 space-y-1">
                                    <p className="text-xs text-muted-foreground font-medium">Nền card, modal</p>
                                    <code className="text-xs bg-gray-100 px-2 py-1 rounded font-mono">{settings.cardColor}</code>
                                </div>
                            </div>
                        </div>
                        <div className="space-y-2">
                            <Label htmlFor="headerColor" className="text-sm font-semibold">Màu Header</Label>
                            <div className="flex items-center gap-3">
                                <input type="color" id="headerColor" name="headerColor" value={settings.headerColor} onChange={handleChange} className="w-16 h-16 p-1 bg-card border-2 border-input rounded-xl shadow-md cursor-pointer hover:scale-105 transition-transform" />
                                <div className="flex-1 space-y-1">
                                    <p className="text-xs text-muted-foreground font-medium">Nền thanh header</p>
                                    <code className="text-xs bg-gray-100 px-2 py-1 rounded font-mono">{settings.headerColor}</code>
                                </div>
                            </div>
                        </div>
                    </div>
                </CardContent>
                <CardFooter className="flex justify-end border-t pt-6">
                    <Button type="submit" size="lg" className="shadow-xl hover:shadow-2xl transition-all duration-300 rounded-xl font-bold text-base px-8">Lưu thay đổi</Button>
                </CardFooter>
            </form>
        </Card>
    );
}