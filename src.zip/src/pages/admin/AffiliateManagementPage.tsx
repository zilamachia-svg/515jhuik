import { useState, useEffect, useCallback } from 'react';
import { motion } from 'framer-motion';
import { toast } from 'sonner';
import { Commission, ApiError } from '../../types';
import apiClient from '../../services/apiClient';
import { formatCurrency, formatApiErrorForToast } from '../../utils';
import { usePageTitle } from '../../contexts/PageTitleContext';
import { useDebounce } from '../../hooks/useDebounce';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Pagination } from '@/components/Pagination';
import { Check, X, Share2, Search } from 'lucide-react';
import { ConfirmationModal } from '../../components/ConfirmationModal';
import { TableSkeleton } from '../../components/skeletons/TableSkeleton';
import { Badge } from '@/components/ui/badge';

const ITEMS_PER_PAGE = 10;
type ActionType = 'approve' | 'reject';

export default function AffiliateManagementPage() {
    usePageTitle("Quản lý Tiếp thị");

    const [commissions, setCommissions] = useState<Commission[]>([]);
    const [isLoading, setIsLoading] = useState(true);
    const [currentPage, setCurrentPage] = useState(1);
    const [totalPages, setTotalPages] = useState(1);
    const [totalItems, setTotalItems] = useState(0);
    const [searchTerm, setSearchTerm] = useState('');
    const debouncedSearch = useDebounce(searchTerm, 500);

    const [commissionToConfirm, setCommissionToConfirm] = useState<{ commission: Commission, action: ActionType } | null>(null);

    const fetchCommissions = useCallback(async (page: number, search: string) => {
        setIsLoading(true);
        try {
            const response = await apiClient.get('/admin/affiliate/commissions', {
                params: { page, limit: ITEMS_PER_PAGE, search: search || undefined },
            });
            setCommissions(response.data.data);
            setTotalPages(response.data.totalPages);
            setTotalItems(response.data.totalItems);
            setCurrentPage(response.data.currentPage);
        } catch (error) {
            toast.error(formatApiErrorForToast(error as ApiError, 'Không thể tải danh sách hoa hồng.'));
        } finally {
            setIsLoading(false);
        }
    }, []);

    useEffect(() => {
        fetchCommissions(currentPage, debouncedSearch);
    }, [fetchCommissions, currentPage, debouncedSearch]);

    const handlePageChange = (page: number) => {
        setCurrentPage(page);
    };

    const handleUpdateStatus = async () => {
        if (!commissionToConfirm) return;
        
        const { commission, action } = commissionToConfirm;
        const newStatus = action === 'approve' ? 'approved' : 'rejected';

        try {
            await apiClient.put(`/admin/affiliate/commissions/${commission.id}`, { status: newStatus });
            toast.success(`Đã ${action === 'approve' ? 'duyệt' : 'từ chối'} hoa hồng.`);
            setCommissionToConfirm(null);
            fetchCommissions(currentPage, debouncedSearch);
        } catch (error) {
            toast.error(formatApiErrorForToast(error as ApiError, 'Cập nhật thất bại.'));
            setCommissionToConfirm(null);
        }
    };
    
    const getStatusVariant = (status: 'approved' | 'pending' | 'rejected'): 'default' | 'secondary' | 'destructive' => {
        switch (status) {
            case 'approved': return 'default';
            case 'pending': return 'secondary';
            case 'rejected': return 'destructive';
            default: return 'secondary';
        }
    }

    return (
        <>
            <div className="space-y-8">
                {/* Banner Section */}
                <motion.div
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.5 }}
                    className="overflow-hidden rounded-3xl bg-gradient-to-r from-purple-400/85 via-pink-400/85 to-rose-400/85 p-8 text-white"
                >
                    <div className="flex flex-col gap-6 md:flex-row md:items-center md:justify-between">
                        <div className="space-y-2">
                            <h2 className="text-3xl font-bold flex items-center gap-2">
                                <span className="text-3xl">🤝</span>
                                Quản lý Tiếp thị
                            </h2>
                            <p className="max-w-[600px] text-white/80">
                                Xem và quản lý hoa hồng tiếp thị, duyệt hoặc từ chối các yêu cầu hoa hồng.
                            </p>
                        </div>
                        <div className="flex items-center gap-3">
                            <div className="flex h-16 w-16 items-center justify-center rounded-2xl bg-white/20 backdrop-blur-md">
                                <Share2 className="h-8 w-8" />
                            </div>
                        </div>
                    </div>
                </motion.div>

                {/* Search Bar */}
                <div className="flex items-center gap-3">
                    <div className="relative flex-1">
                        <Search className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                        <Input
                            type="search"
                            placeholder="Tìm kiếm email, mã đơn hàng..."
                            value={searchTerm}
                            onChange={(e) => setSearchTerm(e.target.value)}
                            className="w-full rounded-2xl pl-9"
                        />
                    </div>
                </div>

            <Card className="rounded-3xl">
                <CardHeader>
                    <CardTitle>Lịch sử Hoa hồng</CardTitle>
                </CardHeader>
                <CardContent>
                    {isLoading ? (
                        <TableSkeleton headers={['Email', 'Đơn hàng', 'Hoa hồng', 'Ngày', 'Trạng thái', 'Hành động']} />
                    ) : (
                        <div className="w-full overflow-auto">
                            <Table>
                                <TableHeader>
                                    <TableRow>
                                        <TableHead>Email</TableHead>
                                        <TableHead>Đơn hàng</TableHead>
                                        <TableHead>Hoa hồng</TableHead>
                                        <TableHead>Ngày</TableHead>
                                        <TableHead>Trạng thái</TableHead>
                                        <TableHead>Hành động</TableHead>
                                    </TableRow>
                                </TableHeader>
                                <TableBody>
                                    {commissions.map(c => (
                                        <TableRow key={c.id}>
                                            <TableCell className="font-medium">{c.userEmail}</TableCell>
                                            <TableCell className="font-medium">{c.orderId}</TableCell>
                                            <TableCell className="font-semibold">{formatCurrency(c.commissionAmount)}</TableCell>
                                            <TableCell className="font-medium">{new Date(c.date).toLocaleString('vi-VN')}</TableCell>
                                            <TableCell>
                                                <Badge variant={getStatusVariant(c.status)}>{c.status}</Badge>
                                            </TableCell>
                                            <TableCell>
                                                {c.status === 'pending' && (
                                                    <div className="flex gap-2">
                                                        <Button 
                                                            variant="outline" 
                                                            size="sm" 
                                                            onClick={() => setCommissionToConfirm({ commission: c, action: 'approve' })}
                                                            className="rounded-xl"
                                                        >
                                                            <Check size={14} className="mr-2" /> Duyệt
                                                        </Button>
                                                        <Button 
                                                            variant="destructive" 
                                                            size="sm" 
                                                            onClick={() => setCommissionToConfirm({ commission: c, action: 'reject' })}
                                                            className="rounded-xl"
                                                        >
                                                            <X size={14} className="mr-2" /> Từ chối
                                                        </Button>
                                                    </div>
                                                )}
                                            </TableCell>
                                        </TableRow>
                                    ))}
                                </TableBody>
                            </Table>
                        </div>
                    )}
                    {!isLoading && commissions.length === 0 && (
                        <p className="text-center p-8 text-muted-foreground">Không có dữ liệu hoa hồng.</p>
                    )}
                    {totalPages > 1 && (
                        <div className="mt-6">
                            <Pagination
                                currentPage={currentPage}
                                totalPages={totalPages}
                                totalItems={totalItems}
                                itemsPerPage={ITEMS_PER_PAGE}
                                onPageChange={handlePageChange}
                            />
                        </div>
                    )}
                </CardContent>
            </Card>
            </div>

            {commissionToConfirm && (
                <ConfirmationModal
                    title={`Xác nhận ${commissionToConfirm.action === 'approve' ? 'duyệt' : 'từ chối'}`}
                    message={`Bạn có chắc muốn ${commissionToConfirm.action === 'approve' ? 'duyệt' : 'từ chối'} hoa hồng ${formatCurrency(commissionToConfirm.commission.commissionAmount)}?`}
                    isDestructive={commissionToConfirm.action === 'reject'}
                    onConfirm={handleUpdateStatus}
                    onCancel={() => setCommissionToConfirm(null)}
                />
            )}
        </>
    );
}