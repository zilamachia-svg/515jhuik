import React, { Suspense, useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { toast } from 'sonner';
import { Link } from 'react-router-dom';
import { ApiError } from '../../types';
import { fetchDashboardData, DashboardData } from '../../services/dashboardService';
import { formatApiErrorForToast, formatCurrency } from '../../utils';
import { usePageTitle } from '../../contexts/PageTitleContext';

import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Spinner } from '@/components/ui/spinner';
import { Timeline } from '../../components/Timeline';
import { PATHS } from '../../constants/paths';
import { Users, ShoppingCart, DollarSign, Percent, TrendingUp, ArrowRight } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
const SpendingChart = React.lazy(() => import('../../components/SpendingChart').then(m => ({ default: m.SpendingChart })));

export default function AdminDashboardPage() {
    usePageTitle("Tổng quan");

    const [data, setData] = useState<DashboardData | null>(null);
    const [isLoading, setIsLoading] = useState(true);

    useEffect(() => {
        const loadData = async () => {
            setIsLoading(true);
            try {
                const dashboardData = await fetchDashboardData();
                setData(dashboardData);
            } catch (error) {
                toast.error(formatApiErrorForToast(error as ApiError, 'Không thể tải dữ liệu tổng quan.'));
            } finally {
                setIsLoading(false);
            }
        };
        loadData();
    }, []);
    
    if (isLoading) {
        return <div className="flex justify-center items-center h-64"><Spinner className="w-10 h-10" /></div>;
    }

    if (!data) {
        return <Card><CardContent><p>Không có dữ liệu để hiển thị.</p></CardContent></Card>;
    }
    
    const { stats, revenueLast7Days, recentActivities, topProducts } = data;

    const statCards = [
        { icon: <DollarSign className="h-4 w-4 text-muted-foreground" />, label: 'Tổng doanh thu', value: formatCurrency(stats.totalRevenue), change: '+20.1% from last month' },
        { icon: <Users className="h-4 w-4 text-muted-foreground" />, label: 'User mới (tháng)', value: `+${stats.newUsersMonthly.toLocaleString('vi-VN')}`, change: '+180.1% from last month' },
        { icon: <ShoppingCart className="h-4 w-4 text-muted-foreground" />, label: 'Đơn hàng (24h)', value: `+${stats.newOrders24h.toLocaleString('vi-VN')}`, change: '+19% from last month' },
        { icon: <Percent className="h-4 w-4 text-muted-foreground" />, label: 'Tỉ lệ chuyển đổi', value: `${stats.conversionRate.toFixed(2)}%`, change: '+2.1% from last month' },
    ];
    
    const timelineItems = recentActivities.map(activity => ({
        icon: activity.type === 'newUser' ? <Users size={16}/> : <ShoppingCart size={16}/>,
        title: activity.text,
        timestamp: new Date(activity.timestamp).toLocaleString('vi-VN'),
    }));

    return (
        <div className="space-y-8">
            {/* Welcome Banner */}
            <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5 }}
                className="overflow-hidden rounded-3xl bg-gradient-to-r from-indigo-400/85 via-purple-400/85 to-pink-400/85 p-8 text-white"
            >
                <div className="flex flex-col gap-6 md:flex-row md:items-center md:justify-between">
                    <div className="space-y-4">
                        <Badge className="bg-white/20 text-white hover:bg-white/30 rounded-xl">Admin Panel</Badge>
                        <h2 className="text-3xl font-bold flex items-center gap-2">
                            <span className="text-3xl">🧠</span>
                            Tổng quan Hệ thống
                        </h2>
                        <p className="max-w-[600px] text-white/80">
                            Quản lý và theo dõi toàn bộ hoạt động của hệ thống từ một nơi.
                        </p>
                    </div>
                    <div className="hidden lg:block">
                        <motion.div
                            animate={{ rotate: 360 }}
                            transition={{ duration: 50, repeat: Number.POSITIVE_INFINITY, ease: "linear" }}
                            className="relative h-40 w-40"
                        >
                            <div className="absolute inset-0 rounded-full bg-white/10 backdrop-blur-md" />
                            <div className="absolute inset-4 rounded-full bg-white/20" />
                            <div className="absolute inset-8 rounded-full bg-white/30" />
                        </motion.div>
                    </div>
                </div>
            </motion.div>

            {/* Stats Cards */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
                {statCards.map((card, index) => (
                    <motion.div
                        key={index}
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ duration: 0.3, delay: index * 0.1 }}
                        whileHover={{ scale: 1.02, y: -5 }}
                    >
                        <Card className="overflow-hidden rounded-3xl border-2 hover:border-primary/50 transition-all duration-300">
                            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                                <CardTitle className="text-sm font-medium">{card.label}</CardTitle>
                                <div className="rounded-2xl bg-muted p-2">{card.icon}</div>
                            </CardHeader>
                            <CardContent>
                                <div className="text-2xl font-bold">{card.value}</div>
                                <p className="text-sm text-muted-foreground mt-1 flex items-center gap-1">
                                    <TrendingUp className="h-3 w-3 text-green-500" />
                                    {card.change}
                                </p>
                            </CardContent>
                        </Card>
                    </motion.div>
                ))}
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-5 gap-6 items-start">
                <Card className="lg:col-span-3 rounded-3xl">
                    <CardHeader>
                        <CardTitle>Doanh thu 7 ngày qua</CardTitle>
                    </CardHeader>
                    <CardContent>
                        <Suspense fallback={<div className="h-48 flex items-center justify-center">Đang tải biểu đồ...</div>}>
                            <SpendingChart data={revenueLast7Days} />
                        </Suspense>
                    </CardContent>
                </Card>
                
                <Card className="lg:col-span-2 rounded-3xl">
                    <CardHeader>
                        <CardTitle>Hoạt động gần đây</CardTitle>
                        <CardDescription>Có {recentActivities.length} hoạt động mới.</CardDescription>
                    </CardHeader>
                    <CardContent>
                       <Timeline items={timelineItems} />
                    </CardContent>
                </Card>
            </div>

            <Card className="rounded-3xl">
                <CardHeader className="flex flex-row items-center justify-between">
                    <div>
                        <CardTitle>Sản phẩm bán chạy</CardTitle>
                        <CardDescription>Top sản phẩm bán chạy nhất trong tháng.</CardDescription>
                    </div>
                    <Button variant="ghost" className="rounded-2xl" asChild>
                        <Link to={PATHS.ADMIN_PRODUCTS}>
                            Xem tất cả <ArrowRight className="ml-2 h-4 w-4" />
                        </Link>
                    </Button>
                </CardHeader>
                <CardContent>
                    <div className="w-full overflow-auto rounded-2xl border">
                        <Table>
                            <TableHeader>
                                <TableRow>
                                    <TableHead>Sản phẩm</TableHead>
                                    <TableHead className="text-right">Số lượng bán</TableHead>
                                    <TableHead className="text-right">Hành động</TableHead>
                                </TableRow>
                            </TableHeader>
                            <TableBody>
                                {topProducts.map((product, index) => (
                                    <TableRow key={index} className="hover:bg-muted/50 transition-colors">
                                        <TableCell className="font-medium">{product.name}</TableCell>
                                        <TableCell className="text-right font-bold">{product.sales.toLocaleString('vi-VN')}</TableCell>
                                        <TableCell className="text-right">
                                            <Button asChild variant="outline" size="sm" className="rounded-xl">
                                                <Link to={PATHS.ADMIN_PRODUCTS}>Xem</Link>
                                            </Button>
                                        </TableCell>
                                    </TableRow>
                                ))}
                            </TableBody>
                        </Table>
                    </div>
                </CardContent>
            </Card>
        </div>
    );
}