import { useState, useRef, useEffect, useMemo } from 'react';
import { toast } from 'sonner';
import { UploadedFile } from '../../types';
import { usePageTitle } from '../../contexts/PageTitleContext';
import { useCopyToClipboard } from '../../hooks/useCopyToClipboard';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { ConfirmationModal } from '../../components/ConfirmationModal';
import { 
    Upload, 
    Link, 
    Trash2, 
    File, 
    FolderOpen, 
    Image, 
    Search,
    Download,
    Eye,
    Edit,
    Folder,
    FileText,
    FileImage,
    FileVideo,
    FileAudio,
    Archive,
    MoreVertical,
    Grid,
    List,
    SortAsc,
    Filter
} from 'lucide-react';
import { cn } from '@/lib/utils';
import apiClient from '@/services/apiClient';
import {
    DropdownMenu,
    DropdownMenuContent,
    DropdownMenuItem,
    DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import {
    Dialog,
    DialogContent,
    DialogDescription,
    DialogHeader,
    DialogTitle,
} from '@/components/ui/dialog';

type FileViewMode = 'grid' | 'list';
type FileSortBy = 'name' | 'size' | 'date' | 'type';
type FileType = 'all' | 'image' | 'document' | 'video' | 'audio' | 'archive' | 'other';

interface FileWithMetadata extends UploadedFile {
    uploadedAt?: string;
    folder?: string;
    description?: string;
}

const mockFiles: FileWithMetadata[] = [
    { id: 'file_1', name: 'logo.png', url: '/logo.png', type: 'image/png', size: 12345, uploadedAt: '2024-01-15', folder: 'images' },
    { id: 'file_2', name: 'banner.jpg', url: '/banner.jpg', type: 'image/jpeg', size: 123456, uploadedAt: '2024-01-14', folder: 'images' },
    { id: 'file_3', name: 'icon-light-32x32.png', url: '/icon-light-32x32.png', type: 'image/png', size: 5432, uploadedAt: '2024-01-13', folder: 'icons' },
    { id: 'file_4', name: 'icon-dark-32x32.png', url: '/icon-dark-32x32.png', type: 'image/png', size: 5621, uploadedAt: '2024-01-13', folder: 'icons' },
    { id: 'file_5', name: 'placeholder-user.jpg', url: '/placeholder-user.jpg', type: 'image/jpeg', size: 15234, uploadedAt: '2024-01-12', folder: 'images' },
    { id: 'file_6', name: 'document.pdf', url: '/document.pdf', type: 'application/pdf', size: 245678, uploadedAt: '2024-01-11', folder: 'documents' },
    { id: 'file_7', name: 'video.mp4', url: '/video.mp4', type: 'video/mp4', size: 5242880, uploadedAt: '2024-01-10', folder: 'videos' },
];

const getFileIcon = (type: string) => {
    if (type.startsWith('image/')) return <FileImage className="w-8 h-8 text-blue-500" />;
    if (type.startsWith('video/')) return <FileVideo className="w-8 h-8 text-purple-500" />;
    if (type.startsWith('audio/')) return <FileAudio className="w-8 h-8 text-green-500" />;
    if (type === 'application/pdf' || type.startsWith('text/')) return <FileText className="w-8 h-8 text-red-500" />;
    if (type.includes('zip') || type.includes('rar') || type.includes('tar')) return <Archive className="w-8 h-8 text-orange-500" />;
    return <File className="w-8 h-8 text-gray-500" />;
};

const getFileType = (type: string): FileType => {
    if (type.startsWith('image/')) return 'image';
    if (type.startsWith('video/')) return 'video';
    if (type.startsWith('audio/')) return 'audio';
    if (type === 'application/pdf' || type.startsWith('text/') || type.includes('document')) return 'document';
    if (type.includes('zip') || type.includes('rar') || type.includes('tar')) return 'archive';
    return 'other';
};

export default function FileManagerPage() {
    usePageTitle("Quản lý Tệp tin");
    const [files, setFiles] = useState<FileWithMetadata[]>(mockFiles);
    const [filteredFiles, setFilteredFiles] = useState<FileWithMetadata[]>(mockFiles);
    const [fileToDelete, setFileToDelete] = useState<FileWithMetadata | null>(null);
    const [selectedFile, setSelectedFile] = useState<FileWithMetadata | null>(null);
    const [isUploading, setIsUploading] = useState(false);
    const [viewMode, setViewMode] = useState<FileViewMode>('grid');
    const [sortBy, setSortBy] = useState<FileSortBy>('date');
    const [fileTypeFilter, setFileTypeFilter] = useState<FileType>('all');
    const [searchQuery, setSearchQuery] = useState('');
    const [currentFolder, setCurrentFolder] = useState<string | null>(null);
    const [copy] = useCopyToClipboard();
    const fileInputRef = useRef<HTMLInputElement>(null);

    // Get unique folders
    const folders = Array.from(new Set(files.map(f => f.folder).filter(Boolean))) as string[];

    // Filter and sort files
    useEffect(() => {
        let filtered = [...files];

        // Filter by folder
        if (currentFolder) {
            filtered = filtered.filter(f => f.folder === currentFolder);
        } else {
            // Show all files when no folder selected
        }

        // Filter by type
        if (fileTypeFilter !== 'all') {
            filtered = filtered.filter(f => getFileType(f.type) === fileTypeFilter);
        }

        // Filter by search query
        if (searchQuery) {
            filtered = filtered.filter(f => 
                f.name.toLowerCase().includes(searchQuery.toLowerCase())
            );
        }

        // Sort
        filtered.sort((a, b) => {
            switch (sortBy) {
                case 'name':
                    return a.name.localeCompare(b.name);
                case 'size':
                    return b.size - a.size;
                case 'date':
                    return (b.uploadedAt || '').localeCompare(a.uploadedAt || '');
                case 'type':
                    return a.type.localeCompare(b.type);
                default:
                    return 0;
            }
        });

        setFilteredFiles(filtered);
    }, [files, currentFolder, fileTypeFilter, searchQuery, sortBy]);

    const handleUpload = () => {
        fileInputRef.current?.click();
    };

    const handleFileSelect = async (e: React.ChangeEvent<HTMLInputElement>) => {
        const selectedFiles = e.target.files;
        if (!selectedFiles || selectedFiles.length === 0) return;

        setIsUploading(true);
        
        try {
            const uploadedFiles: FileWithMetadata[] = [];
            
            for (let i = 0; i < selectedFiles.length; i++) {
                const file = selectedFiles[i];
                
                // Upload to server
                const formData = new FormData();
                formData.append('file', file);
                if (currentFolder) {
                    formData.append('folder', currentFolder);
                }
                
                const response = await apiClient.post('/admin/files/upload', formData, {
                    headers: {
                        'Content-Type': 'multipart/form-data',
                    },
                });
                
                uploadedFiles.push({
                    id: response.data.id || `file_${Date.now()}_${i}`,
                    name: response.data.name || file.name,
                    url: response.data.url,
                    type: file.type,
                    size: file.size,
                    uploadedAt: new Date().toISOString().split('T')[0],
                    folder: currentFolder || response.data.folder || 'root',
                });
            }
            
            setFiles(prev => [...uploadedFiles, ...prev]);
            toast.success(`Đã tải lên ${uploadedFiles.length} file thành công!`);
            
            // Reset input
            if (fileInputRef.current) {
                fileInputRef.current.value = '';
            }
        } catch (error: any) {
            toast.error(error.response?.data?.message || 'Có lỗi khi tải file lên.');
        } finally {
            setIsUploading(false);
        }
    };
    
    const handleDelete = async () => {
        if (!fileToDelete) return;
        
        try {
            await apiClient.delete(`/admin/files/${fileToDelete.id}`);
            setFiles(prev => prev.filter(f => f.id !== fileToDelete.id));
            toast.success(`Đã xóa tệp ${fileToDelete.name}.`);
        } catch (error: any) {
            toast.error(error.response?.data?.message || 'Không thể xóa file.');
        } finally {
            setFileToDelete(null);
        }
    };

    const handleDownload = (file: FileWithMetadata) => {
        const link = document.createElement('a');
        link.href = file.url;
        link.download = file.name;
        link.click();
    };

    const formatSize = (bytes: number) => {
        if (bytes === 0) return '0 Bytes';
        const k = 1024;
        const sizes = ['Bytes', 'KB', 'MB', 'GB'];
        const i = Math.floor(Math.log(bytes) / Math.log(k));
        return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
    };

    const formatDate = (dateString?: string) => {
        if (!dateString) return 'N/A';
        return new Date(dateString).toLocaleDateString('vi-VN');
    };

    // Memoize file type counts to avoid recalculating on every render
    const totalSize = filteredFiles.reduce((sum, f) => sum + f.size, 0);
    const fileTypeCounts = useMemo(() => {
        return files.reduce(
            (acc, file) => {
                const type = getFileType(file.type);
                acc.all++;
                acc[type]++;
                return acc;
            },
            {
                all: 0,
                image: 0,
                document: 0,
                video: 0,
                audio: 0,
                archive: 0,
                other: 0,
            }
        );
    }, [files]);

    return (
        <>
            <input
                ref={fileInputRef}
                type="file"
                multiple
                accept="*/*"
                className="hidden"
                onChange={handleFileSelect}
            />
            
            <div className="space-y-6">
                {/* Header Stats */}
                <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                    <Card>
                        <CardContent className="pt-6">
                            <div className="flex items-center justify-between">
                                <div>
                                    <p className="text-sm text-muted-foreground">Tổng số file</p>
                                    <p className="text-2xl font-bold">{files.length}</p>
                                </div>
                                <File className="h-8 w-8 text-muted-foreground" />
                            </div>
                        </CardContent>
                    </Card>
                    <Card>
                        <CardContent className="pt-6">
                            <div className="flex items-center justify-between">
                                <div>
                                    <p className="text-sm text-muted-foreground">Tổng dung lượng</p>
                                    <p className="text-2xl font-bold">{formatSize(totalSize)}</p>
                                </div>
                                <FolderOpen className="h-8 w-8 text-muted-foreground" />
                            </div>
                        </CardContent>
                    </Card>
                    <Card>
                        <CardContent className="pt-6">
                            <div className="flex items-center justify-between">
                                <div>
                                    <p className="text-sm text-muted-foreground">Thư mục</p>
                                    <p className="text-2xl font-bold">{folders.length}</p>
                                </div>
                                <Folder className="h-8 w-8 text-muted-foreground" />
                            </div>
                        </CardContent>
                    </Card>
                    <Card>
                        <CardContent className="pt-6">
                            <div className="flex items-center justify-between">
                                <div>
                                    <p className="text-sm text-muted-foreground">Đang hiển thị</p>
                                    <p className="text-2xl font-bold">{filteredFiles.length}</p>
                                </div>
                                <Eye className="h-8 w-8 text-muted-foreground" />
                            </div>
                        </CardContent>
                    </Card>
                </div>

                {/* Main File Manager */}
                <Card>
                    <CardHeader>
                        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
                            <div className="space-y-1">
                                <CardTitle className="text-2xl font-bold">Quản lý Tệp tin</CardTitle>
                                <CardDescription>
                                    Quản lý và tổ chức tất cả các file của website
                                </CardDescription>
                            </div>
                            <Button onClick={handleUpload} disabled={isUploading} size="lg" className="shadow-lg">
                                {isUploading ? (
                                    <>
                                        <div className="mr-2 h-4 w-4 animate-spin rounded-full border-2 border-current border-t-transparent" />
                                        Đang tải...
                                    </>
                                ) : (
                                    <>
                                        <Upload size={18} className="mr-2" />
                                        Tải lên File
                                    </>
                                )}
                            </Button>
                        </div>
                    </CardHeader>
                    <CardContent>
                        <Tabs defaultValue="files" className="w-full">
                            <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 mb-6">
                                <TabsList>
                                    <TabsTrigger value="files">Tất cả Files</TabsTrigger>
                                    <TabsTrigger value="folders">Thư mục</TabsTrigger>
                                </TabsList>

                                <div className="flex items-center gap-2 w-full sm:w-auto">
                                    {/* Search */}
                                    <div className="relative flex-1 sm:flex-initial">
                                        <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                                        <Input
                                            placeholder="Tìm kiếm file..."
                                            value={searchQuery}
                                            onChange={(e) => setSearchQuery(e.target.value)}
                                            className="pl-9 w-full sm:w-[250px]"
                                        />
                                    </div>

                                    {/* Sort */}
                                    <Select value={sortBy} onValueChange={(value) => setSortBy(value as FileSortBy)}>
                                        <SelectTrigger className="w-[140px]">
                                            <SortAsc className="h-4 w-4 mr-2" />
                                            <SelectValue />
                                        </SelectTrigger>
                                        <SelectContent>
                                            <SelectItem value="name">Tên A-Z</SelectItem>
                                            <SelectItem value="date">Ngày tải</SelectItem>
                                            <SelectItem value="size">Kích thước</SelectItem>
                                            <SelectItem value="type">Loại file</SelectItem>
                                        </SelectContent>
                                    </Select>

                                    {/* Filter by Type */}
                                    <Select value={fileTypeFilter} onValueChange={(value) => setFileTypeFilter(value as FileType)}>
                                        <SelectTrigger className="w-[140px]">
                                            <Filter className="h-4 w-4 mr-2" />
                                            <SelectValue />
                                        </SelectTrigger>
                                        <SelectContent>
                                            <SelectItem value="all">Tất cả ({fileTypeCounts.all})</SelectItem>
                                            <SelectItem value="image">Hình ảnh ({fileTypeCounts.image})</SelectItem>
                                            <SelectItem value="document">Tài liệu ({fileTypeCounts.document})</SelectItem>
                                            <SelectItem value="video">Video ({fileTypeCounts.video})</SelectItem>
                                            <SelectItem value="audio">Âm thanh ({fileTypeCounts.audio})</SelectItem>
                                            <SelectItem value="archive">Nén ({fileTypeCounts.archive})</SelectItem>
                                            <SelectItem value="other">Khác ({fileTypeCounts.other})</SelectItem>
                                        </SelectContent>
                                    </Select>

                                    {/* View Mode */}
                                    <div className="flex border rounded-lg">
                                        <Button
                                            variant={viewMode === 'grid' ? 'default' : 'ghost'}
                                            size="icon"
                                            onClick={() => setViewMode('grid')}
                                            className="rounded-r-none"
                                        >
                                            <Grid className="h-4 w-4" />
                                        </Button>
                                        <Button
                                            variant={viewMode === 'list' ? 'default' : 'ghost'}
                                            size="icon"
                                            onClick={() => setViewMode('list')}
                                            className="rounded-l-none"
                                        >
                                            <List className="h-4 w-4" />
                                        </Button>
                                    </div>
                                </div>
                            </div>

                            <TabsContent value="files" className="space-y-4">
                                {/* Folder Navigation */}
                                {folders.length > 0 && (
                                    <div className="flex items-center gap-2 flex-wrap">
                                        <Button
                                            variant={currentFolder === null ? 'default' : 'outline'}
                                            size="sm"
                                            onClick={() => setCurrentFolder(null)}
                                        >
                                            <FolderOpen className="h-4 w-4 mr-2" />
                                            Tất cả
                                        </Button>
                                        {folders.map(folder => (
                                            <Button
                                                key={folder}
                                                variant={currentFolder === folder ? 'default' : 'outline'}
                                                size="sm"
                                                onClick={() => setCurrentFolder(folder)}
                                            >
                                                <Folder className="h-4 w-4 mr-2" />
                                                {folder}
                                            </Button>
                                        ))}
                                    </div>
                                )}

                                {/* Files Grid/List */}
                                {filteredFiles.length === 0 ? (
                                    <div className="flex flex-col items-center justify-center py-16 space-y-4">
                                        <div className="rounded-full bg-primary/10 p-6">
                                            <FolderOpen className="h-12 w-12 text-primary" />
                                        </div>
                                        <div className="text-center space-y-2">
                                            <p className="text-lg font-semibold">Không tìm thấy file</p>
                                            <p className="text-sm text-muted-foreground">
                                                {searchQuery ? 'Thử tìm kiếm với từ khóa khác' : 'Nhấn "Tải lên File" để thêm file'}
                                            </p>
                                        </div>
                                    </div>
                                ) : viewMode === 'grid' ? (
                                    <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-4">
                                        {filteredFiles.map(file => (
                                            <div key={file.id} className="border-2 border-gray-200 dark:border-gray-800 rounded-xl overflow-hidden group hover:border-primary/50 hover:shadow-lg transition-all duration-200">
                                                <div className="aspect-square bg-gradient-to-br from-gray-50 to-gray-100 dark:from-gray-900 dark:to-gray-800 flex items-center justify-center relative">
                                                    {file.type.startsWith('image/') ? (
                                                        <img src={file.url} alt={file.name} className="w-full h-full object-cover" />
                                                    ) : (
                                                        getFileIcon(file.type)
                                                    )}
                                                    <div className="absolute inset-0 bg-black/0 group-hover:bg-black/10 transition-colors" />
                                                    <div className="absolute top-2 right-2 opacity-0 group-hover:opacity-100 transition-opacity">
                                                        <DropdownMenu>
                                                            <DropdownMenuTrigger asChild>
                                                                <Button size="icon" variant="secondary" className="h-8 w-8 bg-white/90 backdrop-blur-sm">
                                                                    <MoreVertical className="h-4 w-4" />
                                                                </Button>
                                                            </DropdownMenuTrigger>
                                                            <DropdownMenuContent align="end">
                                                                <DropdownMenuItem onClick={() => setSelectedFile(file)}>
                                                                    <Eye className="h-4 w-4 mr-2" />
                                                                    Xem chi tiết
                                                                </DropdownMenuItem>
                                                                <DropdownMenuItem onClick={() => handleDownload(file)}>
                                                                    <Download className="h-4 w-4 mr-2" />
                                                                    Tải xuống
                                                                </DropdownMenuItem>
                                                                <DropdownMenuItem onClick={() => copy(file.url, 'Đã sao chép URL!')}>
                                                                    <Link className="h-4 w-4 mr-2" />
                                                                    Sao chép URL
                                                                </DropdownMenuItem>
                                                                <DropdownMenuItem 
                                                                    onClick={() => setFileToDelete(file)}
                                                                    className="text-destructive"
                                                                >
                                                                    <Trash2 className="h-4 w-4 mr-2" />
                                                                    Xóa
                                                                </DropdownMenuItem>
                                                            </DropdownMenuContent>
                                                        </DropdownMenu>
                                                    </div>
                                                </div>
                                                <div className="p-3 bg-background space-y-2">
                                                    <p className="font-semibold text-sm truncate" title={file.name}>{file.name}</p>
                                                    <div className="flex items-center justify-between">
                                                        <p className="text-xs text-muted-foreground">{formatSize(file.size)}</p>
                                                        {file.folder && (
                                                            <Badge variant="outline" className="text-xs">
                                                                <Folder className="h-3 w-3 mr-1" />
                                                                {file.folder}
                                                            </Badge>
                                                        )}
                                                    </div>
                                                </div>
                                            </div>
                                        ))}
                                    </div>
                                ) : (
                                    <div className="space-y-2">
                                        {filteredFiles.map(file => (
                                            <div key={file.id} className="flex items-center gap-4 p-4 border rounded-lg hover:bg-muted/50 transition-colors group">
                                                <div className="flex-shrink-0">
                                                    {file.type.startsWith('image/') ? (
                                                        <img src={file.url} alt={file.name} className="w-12 h-12 object-cover rounded" />
                                                    ) : (
                                                        <div className="w-12 h-12 flex items-center justify-center bg-muted rounded">
                                                            {getFileIcon(file.type)}
                                                        </div>
                                                    )}
                                                </div>
                                                <div className="flex-1 min-w-0">
                                                    <p className="font-semibold truncate">{file.name}</p>
                                                    <div className="flex items-center gap-4 text-sm text-muted-foreground mt-1">
                                                        <span>{formatSize(file.size)}</span>
                                                        <span>•</span>
                                                        <span>{formatDate(file.uploadedAt)}</span>
                                                        {file.folder && (
                                                            <>
                                                                <span>•</span>
                                                                <Badge variant="outline" className="text-xs">
                                                                    <Folder className="h-3 w-3 mr-1" />
                                                                    {file.folder}
                                                                </Badge>
                                                            </>
                                                        )}
                                                    </div>
                                                </div>
                                                <div className="flex items-center gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                                                    <Button size="icon" variant="ghost" onClick={() => setSelectedFile(file)}>
                                                        <Eye className="h-4 w-4" />
                                                    </Button>
                                                    <Button size="icon" variant="ghost" onClick={() => handleDownload(file)}>
                                                        <Download className="h-4 w-4" />
                                                    </Button>
                                                    <Button size="icon" variant="ghost" onClick={() => copy(file.url, 'Đã sao chép URL!')}>
                                                        <Link className="h-4 w-4" />
                                                    </Button>
                                                    <Button size="icon" variant="ghost" className="text-destructive" onClick={() => setFileToDelete(file)}>
                                                        <Trash2 className="h-4 w-4" />
                                                    </Button>
                                                </div>
                                            </div>
                                        ))}
                                    </div>
                                )}
                            </TabsContent>

                            <TabsContent value="folders" className="space-y-4">
                                <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-4">
                                    {folders.map(folder => {
                                        const folderFiles = files.filter(f => f.folder === folder);
                                        const folderSize = folderFiles.reduce((sum, f) => sum + f.size, 0);
                                        return (
                                            <Card key={folder} className="cursor-pointer hover:shadow-lg transition-shadow" onClick={() => setCurrentFolder(folder)}>
                                                <CardContent className="pt-6">
                                                    <div className="flex flex-col items-center text-center space-y-2">
                                                        <Folder className="h-12 w-12 text-primary" />
                                                        <p className="font-semibold">{folder}</p>
                                                        <p className="text-sm text-muted-foreground">
                                                            {folderFiles.length} file • {formatSize(folderSize)}
                                                        </p>
                                                    </div>
                                                </CardContent>
                                            </Card>
                                        );
                                    })}
                                </div>
                            </TabsContent>
                        </Tabs>
                    </CardContent>
                </Card>
            </div>

            {/* File Detail Dialog */}
            <Dialog open={!!selectedFile} onOpenChange={() => setSelectedFile(null)}>
                <DialogContent className="max-w-2xl">
                    {selectedFile && (
                        <>
                            <DialogHeader>
                                <DialogTitle>{selectedFile.name}</DialogTitle>
                                <DialogDescription>Chi tiết file</DialogDescription>
                            </DialogHeader>
                            <div className="space-y-4">
                                <div className="flex items-center justify-center p-8 bg-muted rounded-lg">
                                    {selectedFile.type.startsWith('image/') ? (
                                        <img src={selectedFile.url} alt={selectedFile.name} className="max-w-full max-h-64 object-contain" />
                                    ) : (
                                        getFileIcon(selectedFile.type)
                                    )}
                                </div>
                                <div className="grid grid-cols-2 gap-4">
                                    <div>
                                        <p className="text-sm font-semibold mb-1">Tên file</p>
                                        <p className="text-sm text-muted-foreground">{selectedFile.name}</p>
                                    </div>
                                    <div>
                                        <p className="text-sm font-semibold mb-1">Kích thước</p>
                                        <p className="text-sm text-muted-foreground">{formatSize(selectedFile.size)}</p>
                                    </div>
                                    <div>
                                        <p className="text-sm font-semibold mb-1">Loại file</p>
                                        <p className="text-sm text-muted-foreground">{selectedFile.type}</p>
                                    </div>
                                    <div>
                                        <p className="text-sm font-semibold mb-1">Ngày tải lên</p>
                                        <p className="text-sm text-muted-foreground">{formatDate(selectedFile.uploadedAt)}</p>
                                    </div>
                                    {selectedFile.folder && (
                                        <div>
                                            <p className="text-sm font-semibold mb-1">Thư mục</p>
                                            <Badge variant="outline">
                                                <Folder className="h-3 w-3 mr-1" />
                                                {selectedFile.folder}
                                            </Badge>
                                        </div>
                                    )}
                                    <div className="col-span-2">
                                        <p className="text-sm font-semibold mb-1">URL</p>
                                        <div className="flex items-center gap-2">
                                            <Input value={selectedFile.url} readOnly className="font-mono text-xs" />
                                            <Button size="icon" variant="outline" onClick={() => copy(selectedFile.url, 'Đã sao chép URL!')}>
                                                <Link className="h-4 w-4" />
                                            </Button>
                                        </div>
                                    </div>
                                </div>
                                <div className="flex gap-2 pt-4">
                                    <Button onClick={() => handleDownload(selectedFile)} className="flex-1">
                                        <Download className="h-4 w-4 mr-2" />
                                        Tải xuống
                                    </Button>
                                    <Button variant="outline" onClick={() => copy(selectedFile.url, 'Đã sao chép URL!')} className="flex-1">
                                        <Link className="h-4 w-4 mr-2" />
                                        Sao chép URL
                                    </Button>
                                    <Button variant="destructive" onClick={() => {
                                        setFileToDelete(selectedFile);
                                        setSelectedFile(null);
                                    }}>
                                        <Trash2 className="h-4 w-4 mr-2" />
                                        Xóa
                                    </Button>
                                </div>
                            </div>
                        </>
                    )}
                </DialogContent>
            </Dialog>

            {/* Delete Confirmation */}
            {fileToDelete && (
                <ConfirmationModal
                    title="Xác nhận xóa"
                    message={`Bạn có chắc muốn xóa tệp "${fileToDelete.name}"? Hành động này không thể hoàn tác.`}
                    isDestructive
                    onConfirm={handleDelete}
                    onCancel={() => setFileToDelete(null)}
                />
            )}
        </>
    );
}
