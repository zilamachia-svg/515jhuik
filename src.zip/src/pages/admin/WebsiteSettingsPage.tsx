import React, { useState, useEffect } from 'react';
// FIX: Use sonner for notifications
import { toast } from 'sonner';
import { GeneralSettings, ApiError } from '../../types';
import { formatApiErrorForToast } from '../../utils';
import { usePageTitle } from '../../contexts/PageTitleContext';
// FIX: Use Card components from shadcn/ui
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
// FIX: Use Button from shadcn/ui
import { Button } from '@/components/ui/button';
// FIX: Use Spinner from shadcn/ui
import { Spinner } from '@/components/ui/spinner';
// FIX: Use Switch from shadcn/ui
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';

const initialSettings: GeneralSettings = {
    siteName: '',
    siteLogoUrl: '',
    siteFaviconUrl: '',
    primaryDomain: '',
    apiDomain: '',
    maintenanceMode: false,
    systemNotification: '',
    contactEmail: '',
    contactZalo: '',
    contactTelegram: '',
};

export default function WebsiteSettingsPage() {
    usePageTitle("Cài đặt Website");
    const [settings, setSettings] = useState<GeneralSettings>(initialSettings);
    const [isLoading, setIsLoading] = useState(true);
    const [isSaving, setIsSaving] = useState(false);

    useEffect(() => {
        const fetchSettings = async () => {
            setIsLoading(true);
            try {
                // Mocking response as it's not in mock adapter. Using a more complete structure.
                const mockData: GeneralSettings = {
                    siteName: 'Hải Đăng Meta',
                    siteLogoUrl: '/logo.png',
                    siteFaviconUrl: '/favicon.ico',
                    primaryDomain: 'haidangmeta.com',
                    apiDomain: 'backend.haidangmeta.com',
                    maintenanceMode: false,
                    systemNotification: 'Hệ thống sẽ bảo trì vào 2h sáng ngày mai.',
                    contactEmail: 'support@haidangmeta.com',
                    contactZalo: '0123456789',
                    contactTelegram: '@haidangmeta',
                };
                // In a real app: const response = await apiClient.get('/admin/settings/general');
                // setSettings(response.data);
                setSettings(mockData);
            } catch (error) {
                toast.error(formatApiErrorForToast(error as ApiError, 'Không thể tải cài đặt.'));
            } finally {
                setIsLoading(false);
            }
        };
        fetchSettings();
    }, []);

    const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
        const { name, value } = e.target;
        setSettings(prev => ({ ...prev, [name]: value }));
    };

    const handleToggle = (checked: boolean) => {
        setSettings(prev => ({ ...prev, maintenanceMode: checked }));
    };

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        setIsSaving(true);
        try {
            // In a real app: await apiClient.put('/admin/settings/general', settings);
            await new Promise(resolve => setTimeout(resolve, 1000)); // Mock delay
            toast.success("Đã lưu cài đặt thành công!");
        } catch (error) {
             toast.error(formatApiErrorForToast(error as ApiError, 'Lưu cài đặt thất bại.'));
        } finally {
            setIsSaving(false);
        }
    };

    if (isLoading) {
        return <div className="flex justify-center"><Spinner className="h-10 w-10" /></div>;
    }

    return (
        <form onSubmit={handleSubmit} className="space-y-6">
            <Card className="rounded-2xl shadow-xl hover:shadow-2xl transition-shadow duration-300">
                <CardHeader><CardTitle className="text-xl font-bold">Cài đặt Chung</CardTitle></CardHeader>
                <CardContent className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div className="space-y-2">
                        <Label htmlFor="siteName" className="text-sm font-semibold">Tên Website</Label>
                        <Input id="siteName" name="siteName" value={settings.siteName} onChange={handleChange} className="rounded-xl shadow-sm font-medium" />
                    </div>
                    <div className="space-y-2">
                        <Label htmlFor="primaryDomain" className="text-sm font-semibold">Tên miền chính</Label>
                        <Input id="primaryDomain" name="primaryDomain" value={settings.primaryDomain} onChange={handleChange} className="rounded-xl shadow-sm font-medium" />
                    </div>
                     <div className="space-y-2">
                        <Label htmlFor="siteLogoUrl" className="text-sm font-semibold">URL Logo</Label>
                        <Input id="siteLogoUrl" name="siteLogoUrl" value={settings.siteLogoUrl} onChange={handleChange} className="rounded-xl shadow-sm font-medium" />
                    </div>
                    <div className="space-y-2">
                        <Label htmlFor="siteFaviconUrl" className="text-sm font-semibold">URL Favicon</Label>
                        <Input id="siteFaviconUrl" name="siteFaviconUrl" value={settings.siteFaviconUrl} onChange={handleChange} className="rounded-xl shadow-sm font-medium" />
                    </div>
                </CardContent>
            </Card>

            <Card className="rounded-2xl shadow-xl hover:shadow-2xl transition-shadow duration-300">
                <CardHeader><CardTitle className="text-xl font-bold">Hệ thống</CardTitle></CardHeader>
                <CardContent className="space-y-4">
                    <div className="space-y-2">
                        <Label htmlFor="systemNotification" className="text-sm font-semibold">Thông báo hệ thống</Label>
                        <Textarea id="systemNotification" name="systemNotification" value={settings.systemNotification} onChange={handleChange} rows={3} className="rounded-xl shadow-sm font-medium" />
                        <p className="text-sm text-muted-foreground font-medium">Hiển thị một banner thông báo cho tất cả người dùng.</p>
                    </div>
                    <div className="flex items-center space-x-2 p-4 bg-gray-50 rounded-xl border-2">
                        <Switch id="maintenanceMode" checked={settings.maintenanceMode} onCheckedChange={handleToggle} />
                        <Label htmlFor="maintenanceMode" className="font-semibold">Chế độ bảo trì ({settings.maintenanceMode ? 'Đang bật' : 'Đang tắt'})</Label>
                    </div>
                    <p className="text-sm text-muted-foreground font-medium">Khi bật, chỉ admin mới có thể truy cập website.</p>
                </CardContent>
            </Card>

             <Card className="rounded-2xl shadow-xl hover:shadow-2xl transition-shadow duration-300">
                <CardHeader><CardTitle className="text-xl font-bold">Thông tin Liên hệ</CardTitle></CardHeader>
                <CardContent className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div className="space-y-2">
                        <Label htmlFor="contactEmail" className="text-sm font-semibold">Email hỗ trợ</Label>
                        <Input id="contactEmail" name="contactEmail" value={settings.contactEmail} onChange={handleChange} className="rounded-xl shadow-sm font-medium" />
                    </div>
                    <div className="space-y-2">
                        <Label htmlFor="contactZalo" className="text-sm font-semibold">Số Zalo</Label>
                        <Input id="contactZalo" name="contactZalo" value={settings.contactZalo} onChange={handleChange} className="rounded-xl shadow-sm font-medium" />
                    </div>
                    <div className="space-y-2">
                        <Label htmlFor="contactTelegram" className="text-sm font-semibold">Telegram</Label>
                        <Input id="contactTelegram" name="contactTelegram" value={settings.contactTelegram} onChange={handleChange} className="rounded-xl shadow-sm font-medium" />
                    </div>
                </CardContent>
            </Card>

             <div className="sticky bottom-6 flex justify-end">
                <Button type="submit" disabled={isSaving} size="lg" className="shadow-xl hover:shadow-2xl transition-all duration-300 rounded-xl font-bold text-base px-8">
                    {isSaving && <Spinner className="mr-2 h-5 w-5 animate-spin" />}
                    Lưu thay đổi
                </Button>
            </div>
        </form>
    );
}