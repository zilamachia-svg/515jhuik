import { useState, useEffect } from 'react';
import { toast } from 'sonner';
import { AdminApiKey, ApiError } from '../../types';
import apiClient from '../../services/apiClient';
import { formatApiErrorForToast } from '../../utils';
import { usePageTitle } from '../../contexts/PageTitleContext';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Plus, Trash2, History } from 'lucide-react';
import { ConfirmationModal } from '../../components/ConfirmationModal';
import { ApiKeyHistoryModal } from '../../components/ApiKeyHistoryModal';
import { TableSkeleton } from '../../components/skeletons/TableSkeleton';

export default function AdminApiPage() {
    usePageTitle("Quản lý API Keys");

    const [apiKeys, setApiKeys] = useState<AdminApiKey[]>([]);
    const [isLoading, setIsLoading] = useState(true);
    const [keyToRevoke, setKeyToRevoke] = useState<AdminApiKey | null>(null);
    const [keyToShowHistory, setKeyToShowHistory] = useState<AdminApiKey | null>(null);

    const fetchApiKeys = async () => {
        setIsLoading(true);
        try {
            const response = await apiClient.get('/admin/api-keys');
            setApiKeys(response.data);
        } catch (error) {
            toast.error(formatApiErrorForToast(error as ApiError, 'Không thể tải API keys.'));
        } finally {
            setIsLoading(false);
        }
    };

    useEffect(() => {
        fetchApiKeys();
    }, []);

    const handleCreateKey = async () => {
        try {
            const response = await apiClient.post('/admin/api-keys');
            toast.success('Đã tạo API key mới!', {
                description: `Your new key is: ${response.data.apiKey}. Please save it securely, you will not be able to see it again.`,
                duration: 10000,
            });
            fetchApiKeys();
        } catch (error) {
            toast.error(formatApiErrorForToast(error as ApiError, 'Tạo key thất bại.'));
        }
    };

    const handleRevokeKey = async () => {
        if (!keyToRevoke) return;
        try {
            await apiClient.delete(`/admin/api-keys/${keyToRevoke.id}`);
            toast.success(`Đã thu hồi key ${keyToRevoke.keyPreview}.`);
            setKeyToRevoke(null);
            fetchApiKeys();
        } catch (error) {
            toast.error(formatApiErrorForToast(error as ApiError, 'Thu hồi key thất bại.'));
            setKeyToRevoke(null);
        }
    };

    return (
        <>
            <Card>
                <CardHeader className="flex flex-row items-center justify-between">
                    <CardTitle>API Keys</CardTitle>
                    <Button onClick={handleCreateKey}>
                        <Plus size={16} className="mr-2" /> Tạo Key mới
                    </Button>
                </CardHeader>
                <CardContent>
                    {isLoading ? (
                         <TableSkeleton headers={['Key', 'Ngày tạo', 'Lần cuối sử dụng', 'Trạng thái', 'Hành động']} />
                    ) : (
                        <div className="w-full overflow-auto">
                            <Table>
                                <TableHeader>
                                    <TableRow>
                                        <TableHead>Key</TableHead>
                                        <TableHead>Ngày tạo</TableHead>
                                        <TableHead>Lần cuối sử dụng</TableHead>
                                        <TableHead>Trạng thái</TableHead>
                                        <TableHead>Hành động</TableHead>
                                    </TableRow>
                                </TableHeader>
                                <TableBody>
                                    {apiKeys.map(key => (
                                        <TableRow key={key.id}>
                                            <TableCell className="font-mono">{key.keyPreview}</TableCell>
                                            <TableCell>{new Date(key.createdAt).toLocaleString('vi-VN')}</TableCell>
                                            <TableCell>{key.lastUsed ? new Date(key.lastUsed).toLocaleString('vi-VN') : 'Chưa sử dụng'}</TableCell>
                                            <TableCell>
                                                <span className={key.status === 'active' ? 'text-green-500' : 'text-red-500'}>
                                                    {key.status === 'active' ? 'Hoạt động' : 'Đã thu hồi'}
                                                </span>
                                            </TableCell>
                                            <TableCell>
                                                <div className="flex items-center gap-2">
                                                    <Button variant="outline" size="sm" onClick={() => setKeyToShowHistory(key)}>
                                                        <History size={14} className="mr-2" /> Lịch sử
                                                    </Button>
                                                    <Button variant="destructive" size="sm" onClick={() => setKeyToRevoke(key)} disabled={key.status === 'revoked'}>
                                                        <Trash2 size={14} className="mr-2" /> Thu hồi
                                                    </Button>
                                                </div>
                                            </TableCell>
                                        </TableRow>
                                    ))}
                                </TableBody>
                            </Table>
                        </div>
                    )}
                </CardContent>
            </Card>

            {keyToRevoke && (
                <ConfirmationModal
                    title="Xác nhận thu hồi key"
                    message={`Bạn có chắc muốn thu hồi vĩnh viễn key "${keyToRevoke.keyPreview}"? Hành động này không thể hoàn tác.`}
                    isDestructive
                    onConfirm={handleRevokeKey}
                    onCancel={() => setKeyToRevoke(null)}
                />
            )}
            
            {keyToShowHistory && (
                <ApiKeyHistoryModal
                    apiKey={keyToShowHistory}
                    onClose={() => setKeyToShowHistory(null)}
                />
            )}
        </>
    );
}