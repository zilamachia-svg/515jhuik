import React, { useState, useRef } from 'react';
import { toast } from 'sonner';
import { Upload, FileText, Download, Loader2, CheckCircle, AlertTriangle } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Progress } from '@/components/ui/progress';
import apiClient from '@/services/apiClient';
import { usePageTitle } from '@/contexts/PageTitleContext';

interface ImportLog {
  message: string;
  type: 'success' | 'error' | 'info';
  timestamp: string;
}

interface ImportResult {
  success: number;
  failure: number;
  total: number;
  logs: ImportLog[];
}

export default function AccountImportPage() {
  usePageTitle('Import Accounts');
  
  const [isLoading, setIsLoading] = useState(false);
  const [importResults, setImportResults] = useState<ImportResult | null>(null);
  const csvFileRef = useRef<HTMLInputElement>(null);
  const pipeFileRef = useRef<HTMLInputElement>(null);
  const txtFileRef = useRef<HTMLInputElement>(null);
  const batchFileRef = useRef<HTMLInputElement>(null);

  const handleImportCsv = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    await uploadFile(file, 'csv');
  };

  const handleImportTxt = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    await uploadFile(file, 'txt');
  };

  const handleImportBatch = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;

    setIsLoading(true);
    try {
      const formData = new FormData();
      Array.from(files).forEach((file) => {
        formData.append('files[]', file);
      });

      const response = await apiClient.post('/admin/products/import/batch', formData, {
        headers: {
          'Content-Type': 'multipart/form-data',
        },
      });

      toast.success('Import batch thành công!');
      console.log('Batch import results:', response.data);
      setImportResults({
        success: response.data.data.summary.total_success,
        failure: response.data.data.summary.total_failure,
        total: response.data.data.summary.total_success + response.data.data.summary.total_failure,
        logs: [],
      });
    } catch (error: unknown) {
      const err = error as { response?: { data?: { error?: string } } };
      toast.error(err?.response?.data?.error || 'Lỗi import batch');
    } finally {
      setIsLoading(false);
      if (batchFileRef.current) batchFileRef.current.value = '';
    }
  };

  const uploadFile = async (file: File, type: 'csv' | 'txt') => {
    setIsLoading(true);
    try {
      const formData = new FormData();
      formData.append('file', file);

      const endpoint = type === 'csv' ? '/admin/products/import/csv' : '/admin/products/import/txt';
      const response = await apiClient.post(endpoint, formData, {
        headers: {
          'Content-Type': 'multipart/form-data',
        },
      });

      const result = response.data.data;
      setImportResults(result);

      toast.success(
        `Import thành công! ${result.success} thành công, ${result.failure} thất bại`
      );
    } catch (error: unknown) {
      const err = error as { response?: { data?: { error?: string } } };
      toast.error(err?.response?.data?.error || 'Lỗi import');
      console.error('Import error:', error);
    } finally {
      setIsLoading(false);
      if (type === 'csv' && csvFileRef.current) csvFileRef.current.value = '';
      if (type === 'txt' && txtFileRef.current) txtFileRef.current.value = '';
    }
  };

  const downloadTemplate = async () => {
    try {
      const response = await apiClient.get('/admin/products/import/template');
      const template = response.data.template;

      // Tạo blob và download
      const blob = new Blob([template], { type: 'text/csv;charset=utf-8;' });
      const link = document.createElement('a');
      const url = URL.createObjectURL(blob);
      link.setAttribute('href', url);
      link.setAttribute('download', 'products_template.csv');
      link.style.visibility = 'hidden';
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);

      toast.success('Template đã tải về!');
    } catch (error) {
      toast.error('Lỗi tải template');
    }
  };

  const successPercentage =
    importResults && importResults.total > 0
      ? (importResults.success / importResults.total) * 100
      : 0;

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold">Import Sản Phẩm</h1>
        <p className="text-muted-foreground mt-2">
          Nhập sản phẩm hàng loạt từ CSV hoặc TXT
        </p>
      </div>

      <Tabs defaultValue="csv" className="space-y-4">
        <TabsList>
          <TabsTrigger value="csv">CSV Import</TabsTrigger>
          <TabsTrigger value="txt">TXT Import</TabsTrigger>
          <TabsTrigger value="batch">Batch Import</TabsTrigger>
        </TabsList>

        {/* CSV TAB */}
        <TabsContent value="csv" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Import từ CSV</CardTitle>
              <CardDescription>
                Tải file CSV chứa danh sách sản phẩm
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="border-2 border-dashed rounded-lg p-8 text-center hover:bg-muted/50 transition cursor-pointer"
                onClick={() => csvFileRef.current?.click()}>
                <Upload className="mx-auto h-12 w-12 text-muted-foreground mb-2" />
                <p className="font-semibold">Kéo file vào đây hoặc click để chọn</p>
                <p className="text-sm text-muted-foreground">CSV file only</p>
                <input
                  ref={txtFileRef}
                  type="file"
                  accept=".csv"
                  onChange={handleImportTxt}
                  disabled={isLoading}
                  className="hidden"
                  aria-label="Upload CSV file"
                />
              </div>

              <Button
                onClick={downloadTemplate}
                variant="outline"
                className="w-full"
              >
                <Download className="w-4 h-4 mr-2" />
                Tải Template CSV
              </Button>

              <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 text-sm text-blue-800">
                <p className="font-semibold mb-2">Format CSV:</p>
                <code className="block bg-white p-2 rounded border border-blue-200 overflow-x-auto text-xs">
                  name,description,price,stock,category,image_url,is_active
                </code>
                <p className="mt-2">Dòng đầu tiên phải là header</p>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* TXT TAB */}
        <TabsContent value="txt" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Import từ TXT</CardTitle>
              <CardDescription>
                Mỗi dòng là một sản phẩm
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="border-2 border-dashed rounded-lg p-8 text-center hover:bg-muted/50 transition cursor-pointer"
                onClick={() => txtFileRef.current?.click()}>
                <FileText className="mx-auto h-12 w-12 text-muted-foreground mb-2" />
                <p className="font-semibold">Kéo file vào đây hoặc click để chọn</p>
                <p className="text-sm text-muted-foreground">TXT file only</p>
                <input
                  ref={pipeFileRef}
                  type="file"
                  accept=".txt"
                  onChange={handleImportCsv}
                  disabled={isLoading}
                  className="hidden"
                  aria-label="Upload pipe-delimited file"
                />
              </div>

              <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 text-sm text-blue-800">
                <p className="font-semibold mb-2">Format TXT:</p>
                <code className="block bg-white p-2 rounded border border-blue-200 overflow-x-auto text-xs">
                  name|price|stock|description|category|country
                </code>
                <p className="mt-2 text-xs">
                  Ví dụ: Sản phẩm 1|100000|50|Mô tả|Điện tử|Việt Nam
                </p>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* BATCH TAB */}
        <TabsContent value="batch" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Batch Import</CardTitle>
              <CardDescription>
                Import nhiều file cùng một lúc
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="border-2 border-dashed rounded-lg p-8 text-center hover:bg-muted/50 transition cursor-pointer"
                onClick={() => batchFileRef.current?.click()}>
                <Upload className="mx-auto h-12 w-12 text-muted-foreground mb-2" />
                <p className="font-semibold">Chọn nhiều file (CSV hoặc TXT)</p>
                <p className="text-sm text-muted-foreground">Ctrl+Click để chọn nhiều file</p>
                <input
                  ref={batchFileRef}
                  type="file"
                  multiple
                  accept=".csv,.txt"
                  onChange={handleImportBatch}
                  disabled={isLoading}
                  className="hidden"
                  aria-label="Upload multiple files"
                />
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* RESULTS */}
      {importResults && (
        <Card className="border-green-200 bg-green-50">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-green-900">
              <CheckCircle className="w-5 h-5" />
              Kết Quả Import
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-3 gap-4">
              <div className="bg-white p-4 rounded-lg border">
                <p className="text-sm text-muted-foreground">Thành công</p>
                <p className="text-2xl font-bold text-green-600">{importResults.success}</p>
              </div>
              <div className="bg-white p-4 rounded-lg border">
                <p className="text-sm text-muted-foreground">Thất bại</p>
                <p className="text-2xl font-bold text-red-600">{importResults.failure}</p>
              </div>
              <div className="bg-white p-4 rounded-lg border">
                <p className="text-sm text-muted-foreground">Tổng cộng</p>
                <p className="text-2xl font-bold">{importResults.total}</p>
              </div>
            </div>

            <div>
              <div className="flex justify-between text-sm mb-2">
                <span>Tỉ lệ thành công</span>
                <span>{Math.round(successPercentage)}%</span>
              </div>
              <Progress value={successPercentage} />
            </div>

            {/* LOGS */}
            {importResults.logs && importResults.logs.length > 0 && (
              <div className="bg-white rounded-lg border p-4 max-h-96 overflow-y-auto">
                <p className="font-semibold mb-3">Chi tiết</p>
                <div className="space-y-2 text-sm">
                  {importResults.logs.slice(-20).map((log, idx) => (
                    <div key={idx} className="flex gap-2">
                      {log.type === 'success' && (
                        <CheckCircle className="w-4 h-4 text-green-600 flex-shrink-0 mt-0.5" />
                      )}
                      {log.type === 'error' && (
                        <AlertTriangle className="w-4 h-4 text-red-600 flex-shrink-0 mt-0.5" />
                      )}
                      <span className={
                        log.type === 'success' ? 'text-green-700' : 'text-red-700'
                      }>
                        {log.message}
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </CardContent>
        </Card>
      )}

      {isLoading && (
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-center gap-3">
              <Loader2 className="w-5 h-5 animate-spin" />
              <p>Đang xử lý import...</p>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
