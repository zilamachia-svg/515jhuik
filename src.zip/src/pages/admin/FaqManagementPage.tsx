import { useState, useEffect } from 'react';
import { toast } from 'sonner';
import { Faq, ApiError } from '../../types';
import apiClient from '../../services/apiClient';
import { formatApiErrorForToast } from '../../utils';
import { usePageTitle } from '../../contexts/PageTitleContext';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Plus, Edit, Trash2 } from 'lucide-react';
import { EditFaqModal } from '../../components/admin/EditFaqModal';
import { ConfirmationModal } from '../../components/ConfirmationModal';
import { TableSkeleton } from '../../components/skeletons/TableSkeleton';

export default function FaqManagementPage() {
    usePageTitle("Quản lý FAQ");

    const [faqs, setFaqs] = useState<Faq[]>([]);
    const [isLoading, setIsLoading] = useState(true);
    const [faqToEdit, setFaqToEdit] = useState<Faq | 'new' | null>(null);
    const [faqToDelete, setFaqToDelete] = useState<Faq | null>(null);

    const fetchFaqs = async () => {
        setIsLoading(true);
        try {
            const response = await apiClient.get('/admin/faq');
            setFaqs(response.data.faqs);
        } catch (error) {
            toast.error(formatApiErrorForToast(error as ApiError, 'Không thể tải FAQ.'));
        } finally {
            setIsLoading(false);
        }
    };

    useEffect(() => {
        fetchFaqs();
    }, []);

    const handleDelete = async () => {
        if (!faqToDelete) return;
        try {
            await apiClient.delete(`/admin/faq/${faqToDelete.id}`);
            toast.success('Đã xóa FAQ.');
            setFaqToDelete(null);
            fetchFaqs();
        } catch (error) {
            toast.error(formatApiErrorForToast(error as ApiError, 'Xóa FAQ thất bại.'));
            setFaqToDelete(null);
        }
    };

    return (
        <>
            <Card>
                <CardHeader className="flex-row items-center justify-between">
                    <CardTitle>Câu hỏi thường gặp (FAQ)</CardTitle>
                    <Button onClick={() => setFaqToEdit('new')}><Plus size={16} className="mr-2" /> Thêm mới</Button>
                </CardHeader>
                <CardContent>
                    {isLoading ? (
                        <TableSkeleton headers={['Câu hỏi', 'Trạng thái', 'Thứ tự', 'Hành động']} />
                    ) : (
                        <div className="w-full overflow-auto">
                            <Table>
                                <TableHeader>
                                    <TableRow>
                                        <TableHead>Câu hỏi</TableHead>
                                        <TableHead>Trạng thái</TableHead>
                                        <TableHead>Thứ tự</TableHead>
                                        <TableHead>Hành động</TableHead>
                                    </TableRow>
                                </TableHeader>
                                <TableBody>
                                    {faqs.map(faq => (
                                        <TableRow key={faq.id}>
                                            <TableCell>{faq.question}</TableCell>
                                            <TableCell>{faq.is_active ? 'Công khai' : 'Ẩn'}</TableCell>
                                            <TableCell>{faq.order}</TableCell>
                                            <TableCell>
                                                <div className="flex items-center gap-2">
                                                    <Button variant="ghost" size="icon" onClick={() => setFaqToEdit(faq)}><Edit size={14} /></Button>
                                                    <Button variant="ghost" size="icon" className="text-destructive" onClick={() => setFaqToDelete(faq)}><Trash2 size={14} /></Button>
                                                </div>
                                            </TableCell>
                                        </TableRow>
                                    ))}
                                </TableBody>
                            </Table>
                        </div>
                    )}
                </CardContent>
            </Card>

            {faqToEdit && (
                <EditFaqModal 
                    faq={faqToEdit}
                    onClose={() => setFaqToEdit(null)}
                    onSave={() => {
                        setFaqToEdit(null);
                        fetchFaqs();
                    }}
                />
            )}

            {faqToDelete && (
                <ConfirmationModal
                    title="Xác nhận xóa"
                    message={`Bạn có chắc muốn xóa câu hỏi "${faqToDelete.question}"?`}
                    isDestructive
                    onConfirm={handleDelete}
                    onCancel={() => setFaqToDelete(null)}
                />
            )}
        </>
    );
}