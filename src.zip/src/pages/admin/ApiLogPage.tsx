import { useApiLog } from '../../contexts/ApiLogContext';
import { usePageTitle } from '../../contexts/PageTitleContext';
// FIX: Use Card from shadcn/ui
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
// FIX: Use Button from shadcn/ui
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';

export default function ApiLogPage() {
    usePageTitle("API Logs");
    const { logs, clearLogs } = useApiLog();

    const getMethodVariant = (method: string): 'default' | 'secondary' | 'destructive' | 'outline' => {
        switch (method.toUpperCase()) {
            case 'GET': return 'default';
            case 'POST': return 'secondary';
            case 'PUT': return 'outline';
            case 'DELETE': return 'destructive';
            default: return 'secondary';
        }
    };
    
    return (
        <Card>
            <CardHeader className="flex-row items-center justify-between">
                <CardTitle>API Request Logs (Live)</CardTitle>
                <Button variant="outline" onClick={clearLogs}>Xóa Logs</Button>
            </CardHeader>
            <CardContent>
                <div className="border rounded-lg max-h-[600px] overflow-y-auto">
                    {logs.length > 0 ? logs.map(log => (
                        <details key={log.id} className="border-b last:border-b-0">
                            <summary className="flex items-center gap-4 p-3 cursor-pointer hover:bg-accent">
                                <Badge variant={getMethodVariant(log.method)}>{log.method}</Badge>
                                <span className="font-mono text-sm flex-1 truncate">{log.path}</span>
                                <span className="text-xs text-muted-foreground">{new Date(log.timestamp).toLocaleTimeString()}</span>
                            </summary>
                            {log.payload && (
                                <div className="p-4 bg-muted">
                                    <strong>Payload:</strong>
                                    <pre className="text-xs bg-background p-2 rounded-md mt-1 overflow-x-auto"><code >{JSON.stringify(log.payload, null, 2)}</code></pre>
                                </div>
                            )}
                        </details>
                    )) : (
                        <div className="p-6 text-center text-muted-foreground">
                            Chưa có request nào được ghi lại.
                        </div>
                    )}
                </div>
            </CardContent>
        </Card>
    );
}