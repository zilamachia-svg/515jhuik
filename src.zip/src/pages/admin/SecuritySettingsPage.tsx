import React, { useState } from 'react';
// FIX: Use sonner for consistent notifications
import { toast } from 'sonner';
import { SecuritySettings } from '../../types';
import { usePageTitle } from '../../contexts/PageTitleContext';
// FIX: Use Card from shadcn/ui
import { Card, CardContent, CardHeader, CardTitle, CardFooter } from '@/components/ui/card';
// FIX: Use Button from shadcn/ui
import { Button } from '@/components/ui/button';
// FIX: Use Switch from shadcn/ui
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Spinner } from '@/components/ui/spinner';

const mockSettings: SecuritySettings = {
    enable2FA: true,
    rateLimitGlobal: 120,
    rateLimitAuth: 60,
    adminIpWhitelist: '127.0.0.1, 192.168.1.1',
};

export default function SecuritySettingsPage() {
    usePageTitle("Cài đặt Bảo mật");
    const [settings, setSettings] = useState<SecuritySettings>(mockSettings);
    const [isLoading, setIsLoading] = useState(false);

    const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
        const { name, value } = e.target;
        const isNumeric = ['rateLimitGlobal', 'rateLimitAuth'].includes(name);
        setSettings(prev => ({...prev, [name]: isNumeric ? Number(value) : value}));
    };
    
    const handleToggle = (checked: boolean) => {
        setSettings(prev => ({ ...prev, enable2FA: checked }));
    };

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        setIsLoading(true);
        // Mock API call
        setTimeout(() => {
            toast.success("Đã lưu cài đặt bảo mật!");
            setIsLoading(false);
        }, 1000);
    };

    return (
        <Card className="rounded-2xl shadow-xl hover:shadow-2xl transition-shadow duration-300">
            <CardHeader>
                <CardTitle className="text-xl font-bold">Cài đặt Bảo mật & Rate Limiting</CardTitle>
                <p className="text-sm text-muted-foreground font-medium mt-2">
                    Bảo vệ hệ thống khỏi các cuộc tấn công và truy cập trái phép
                </p>
            </CardHeader>
            <form onSubmit={handleSubmit}>
                <CardContent className="space-y-6">
                    <div className="flex items-center space-x-3 p-4 bg-green-50 border-2 border-green-200 rounded-xl">
                        <Switch id="enable2FA" checked={settings.enable2FA} onCheckedChange={handleToggle} />
                        <Label htmlFor="enable2FA" className="font-semibold cursor-pointer">
                            Bắt buộc 2FA cho Admin 
                            <span className={`ml-2 text-sm ${settings.enable2FA ? 'text-green-600' : 'text-gray-500'}`}>
                                ({settings.enable2FA ? 'Đang bật' : 'Đang tắt'})
                            </span>
                        </Label>
                    </div>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div className="space-y-2">
                            <Label htmlFor="rateLimitGlobal" className="text-sm font-semibold">Giới hạn request chung (request/phút)</Label>
                            <Input type="number" id="rateLimitGlobal" name="rateLimitGlobal" value={settings.rateLimitGlobal} onChange={handleChange} className="rounded-xl shadow-sm font-bold text-lg" />
                            <p className="text-xs text-muted-foreground font-medium">Áp dụng cho tất cả API endpoints</p>
                        </div>
                        <div className="space-y-2">
                            <Label htmlFor="rateLimitAuth" className="text-sm font-semibold">Giới hạn request xác thực (request/phút)</Label>
                            <Input type="number" id="rateLimitAuth" name="rateLimitAuth" value={settings.rateLimitAuth} onChange={handleChange} className="rounded-xl shadow-sm font-bold text-lg" />
                            <p className="text-xs text-muted-foreground font-medium">Bảo vệ khỏi brute force attack</p>
                        </div>
                    </div>
                    <div className="space-y-2">
                        <Label htmlFor="adminIpWhitelist" className="text-sm font-semibold">Admin IP Whitelist</Label>
                        <Textarea id="adminIpWhitelist" name="adminIpWhitelist" value={settings.adminIpWhitelist} onChange={handleChange} rows={3} className="rounded-xl shadow-sm font-mono text-sm" />
                        <p className="text-sm text-muted-foreground font-medium">Các địa chỉ IP được phép truy cập trang quản trị, phân tách bằng dấu phẩy.</p>
                    </div>
                </CardContent>
                <CardFooter className="flex justify-end border-t pt-6">
                    <Button type="submit" disabled={isLoading} size="lg" className="shadow-xl hover:shadow-2xl transition-all duration-300 rounded-xl font-bold text-base px-8">
                        {isLoading && <Spinner className="mr-2 h-5 w-5 animate-spin" />}
                        Lưu thay đổi
                    </Button>
                </CardFooter>
            </form>
        </Card>
    );
}