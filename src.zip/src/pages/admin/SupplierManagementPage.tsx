import React, { useState } from 'react';
import { toast } from 'sonner';
import { Supplier, SupplierProduct } from '../../types';
import { usePageTitle } from '../../contexts/PageTitleContext';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Plus, Edit, Trash2 } from 'lucide-react';
import { ConfirmationModal } from '../../components/ConfirmationModal';
import { EditSupplierProductModal } from '../../components/admin/EditSupplierProductModal';
import { formatCurrency } from '../../utils';

const mockSuppliers: Supplier[] = [
    { id: 'sup_1', name: 'Nhà cung cấp A', productCount: 2 },
    { id: 'sup_2', name: 'Nhà cung cấp B', productCount: 1 },
];

const mockSupplierProducts: Record<string, SupplierProduct[]> = {
    'sup_1': [
        { id: 'sup_prod_1', name: 'VIA US (NCC A)', cost: 25000, stock: 500 },
        { id: 'sup_prod_2', name: 'Clone PH (NCC A)', cost: 7000, stock: 10000 },
    ],
    'sup_2': [
        { id: 'sup_prod_3', name: 'BM5 kháng (NCC B)', cost: 400000, stock: 50 },
    ],
};

export default function SupplierManagementPage() {
    usePageTitle("Quản lý Nhà cung cấp");

    const [suppliers] = useState<Supplier[]>(mockSuppliers);
    const [selectedSupplier, setSelectedSupplier] = useState<Supplier | null>(mockSuppliers[0] || null);
    const [productToEdit, setProductToEdit] = useState<SupplierProduct | 'new' | null>(null);
    const [productToDelete, setProductToDelete] = useState<SupplierProduct | null>(null);

    const handleSelectSupplier = (supplier: Supplier) => {
        setSelectedSupplier(supplier);
    };

    const handleDelete = () => {
        if (!productToDelete || !selectedSupplier) return;
        toast.success(`(Mock) Đã xóa sản phẩm "${productToDelete.name}".`);
        setProductToDelete(null);
    };

    const handleSave = () => {
        setProductToEdit(null);
        toast.info("(Mock) Dữ liệu sản phẩm NCC đã được cập nhật.");
    };

    return (
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 items-start">
            <div className="md:col-span-1">
                <Card>
                    <CardHeader>
                        <CardTitle>Nhà cung cấp</CardTitle>
                    </CardHeader>
                    <CardContent>
                        <ul className="space-y-2">
                            {suppliers.map(sup => (
                                <li key={sup.id}>
                                    <Button
                                        variant={selectedSupplier?.id === sup.id ? 'secondary' : 'ghost'}
                                        className="w-full justify-between"
                                        onClick={() => handleSelectSupplier(sup)}
                                    >
                                        <span>{sup.name}</span>
                                        <span className="text-xs text-muted-foreground">{sup.productCount}</span>
                                    </Button>
                                </li>
                            ))}
                        </ul>
                    </CardContent>
                </Card>
            </div>
            <div className="md:col-span-3">
                {selectedSupplier ? (
                    <Card>
                        <CardHeader className="flex-row items-center justify-between">
                            <CardTitle>Sản phẩm của {selectedSupplier.name}</CardTitle>
                            <Button onClick={() => setProductToEdit('new')}>
                                <Plus size={16} className="mr-2" /> Thêm sản phẩm
                            </Button>
                        </CardHeader>
                        <CardContent>
                            <Table>
                                <TableHeader>
                                    <TableRow>
                                        <TableHead>Tên sản phẩm</TableHead>
                                        <TableHead>Giá nhập</TableHead>
                                        <TableHead>Tồn kho</TableHead>
                                        <TableHead>Hành động</TableHead>
                                    </TableRow>
                                </TableHeader>
                                <TableBody>
                                    {mockSupplierProducts[selectedSupplier.id]?.map(prod => (
                                        <TableRow key={prod.id}>
                                            <TableCell>{prod.name}</TableCell>
                                            <TableCell>{formatCurrency(prod.cost)}</TableCell>
                                            <TableCell>{prod.stock}</TableCell>
                                            <TableCell>
                                                <div className="flex gap-2">
                                                    <Button variant="ghost" size="icon" onClick={() => setProductToEdit(prod)}><Edit size={14} /></Button>
                                                    <Button variant="ghost" size="icon" className="text-destructive" onClick={() => setProductToDelete(prod)}><Trash2 size={14} /></Button>
                                                </div>
                                            </TableCell>
                                        </TableRow>
                                    ))}
                                </TableBody>
                            </Table>
                        </CardContent>
                    </Card>
                ) : (
                    <Card>
                        <CardContent className="p-12 text-center text-muted-foreground">
                            <p>Chọn một nhà cung cấp để xem sản phẩm.</p>
                        </CardContent>
                    </Card>
                )}
            </div>

            {productToEdit && selectedSupplier && (
                <EditSupplierProductModal
                    product={productToEdit}
                    supplierId={selectedSupplier.id}
                    onClose={() => setProductToEdit(null)}
                    onSave={handleSave}
                />
            )}
            
            {productToDelete && (
                <ConfirmationModal
                    title="Xác nhận xóa"
                    message={`Bạn có chắc muốn xóa sản phẩm "${productToDelete.name}"?`}
                    isDestructive
                    onConfirm={handleDelete}
                    onCancel={() => setProductToDelete(null)}
                />
            )}
        </div>
    );
}
