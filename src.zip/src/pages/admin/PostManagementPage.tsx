import { useState, useEffect, useCallback } from 'react';
import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';
import { toast } from 'sonner';
import { Post, ApiError } from '../../types';
import apiClient from '../../services/apiClient';
import { formatApiErrorForToast } from '../../utils';
import { usePageTitle } from '../../contexts/PageTitleContext';
import { useDebounce } from '../../hooks/useDebounce';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Pagination } from '@/components/Pagination';
import { Edit, Trash2, Plus, FileText, Search } from 'lucide-react';
import { PATHS } from '../../constants/paths';
import { EditPostModal } from '../../components/admin/EditPostModal';
import { ConfirmationModal } from '../../components/ConfirmationModal';
import { TableSkeleton } from '../../components/skeletons/TableSkeleton';

const ITEMS_PER_PAGE = 10;

export default function PostManagementPage() {
    usePageTitle("Quản lý Bài viết");

    const [posts, setPosts] = useState<Post[]>([]);
    const [isLoading, setIsLoading] = useState(true);
    const [currentPage, setCurrentPage] = useState(1);
    const [totalPages, setTotalPages] = useState(1);
    const [totalItems, setTotalItems] = useState(0);
    const [searchTerm, setSearchTerm] = useState('');
    const debouncedSearch = useDebounce(searchTerm, 500);

    const [postToEdit, setPostToEdit] = useState<Post | 'new' | null>(null);
    const [postToDelete, setPostToDelete] = useState<Post | null>(null);

    const fetchPosts = useCallback(async (page: number, search: string) => {
        setIsLoading(true);
        try {
            const response = await apiClient.get('/admin/posts', {
                params: { page, limit: ITEMS_PER_PAGE, search: search || undefined },
            });
            setPosts(response.data.data);
            setTotalPages(response.data.totalPages);
            setTotalItems(response.data.totalItems);
            setCurrentPage(response.data.currentPage);
        } catch (error) {
            toast.error(formatApiErrorForToast(error as ApiError, 'Không thể tải bài viết.'));
        } finally {
            setIsLoading(false);
        }
    }, []);

    useEffect(() => {
        fetchPosts(currentPage, debouncedSearch);
    }, [fetchPosts, currentPage, debouncedSearch]);

    const handlePageChange = (page: number) => {
        setCurrentPage(page);
    };

    const handleDelete = async () => {
        if (!postToDelete) return;
        try {
            await apiClient.delete(`/admin/posts/${postToDelete.id}`);
            toast.success('Đã xóa bài viết.');
            setPostToDelete(null);
            fetchPosts(currentPage, debouncedSearch);
        } catch (error) {
            toast.error(formatApiErrorForToast(error as ApiError, 'Xóa bài viết thất bại.'));
            setPostToDelete(null);
        }
    };

    return (
        <>
            <div className="space-y-8">
                {/* Banner Section */}
                <motion.div
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.5 }}
                    className="overflow-hidden rounded-3xl bg-gradient-to-r from-indigo-400/85 via-purple-400/85 to-pink-400/85 p-8 text-white"
                >
                    <div className="flex flex-col gap-6 md:flex-row md:items-center md:justify-between">
                        <div className="space-y-2">
                            <h2 className="text-3xl font-bold flex items-center gap-2">
                                <span className="text-3xl">📝</span>
                                Quản lý Bài viết
                            </h2>
                            <p className="max-w-[600px] text-white/80">
                                Quản lý tất cả bài viết, tạo mới, chỉnh sửa và xóa bài viết trong hệ thống.
                            </p>
                        </div>
                        <div className="flex items-center gap-3">
                            <div className="flex h-16 w-16 items-center justify-center rounded-2xl bg-white/20 backdrop-blur-md">
                                <FileText className="h-8 w-8" />
                            </div>
                        </div>
                    </div>
                </motion.div>

                {/* Search Bar */}
                <div className="flex items-center gap-3">
                    <div className="relative flex-1">
                        <Search className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                        <Input
                            type="search"
                            placeholder="Tìm kiếm tiêu đề..."
                            value={searchTerm}
                            onChange={(e) => setSearchTerm(e.target.value)}
                            className="w-full rounded-2xl pl-9"
                        />
                    </div>
                    <Button 
                        onClick={() => setPostToEdit('new')}
                        className="rounded-2xl"
                    >
                        <Plus size={16} className="mr-2" />Viết bài mới
                    </Button>
                </div>

            <Card className="rounded-3xl">
                <CardHeader>
                    <CardTitle>Danh sách bài viết</CardTitle>
                </CardHeader>
                <CardContent>
                     {isLoading && !posts.length ? (
                        <TableSkeleton headers={['Tiêu đề', 'Tác giả', 'Trạng thái', 'Ngày tạo', 'Hành động']} />
                     ) : (
                        <div className="w-full overflow-auto">
                            <Table>
                                <TableHeader>
                                    <TableRow>
                                        <TableHead>Tiêu đề</TableHead>
                                        <TableHead>Tác giả</TableHead>
                                        <TableHead>Trạng thái</TableHead>
                                        <TableHead>Ngày tạo</TableHead>
                                        <TableHead>Hành động</TableHead>
                                    </TableRow>
                                </TableHeader>
                                <TableBody>
                                    {posts.map(post => (
                                        <TableRow key={post.id}>
                                            <TableCell>
                                                <Link to={`${PATHS.POSTS}/${post.slug}`} className="font-medium hover:underline">{post.title}</Link>
                                            </TableCell>
                                            <TableCell>{post.authorName}</TableCell>
                                            <TableCell>{post.status === 'published' ? 'Xuất bản' : 'Bản nháp'}</TableCell>
                                            <TableCell>{new Date(post.createdAt).toLocaleDateString('vi-VN')}</TableCell>
                                            <TableCell>
                                                <div className="flex items-center gap-2">
                                                    <Button variant="ghost" size="icon" onClick={() => setPostToEdit(post)}><Edit size={14} /></Button>
                                                    <Button variant="ghost" size="icon" className="text-destructive" onClick={() => setPostToDelete(post)}><Trash2 size={14} /></Button>
                                                </div>
                                            </TableCell>
                                        </TableRow>
                                    ))}
                                </TableBody>
                            </Table>
                        </div>
                     )}
                     {!isLoading && posts.length === 0 && (
                        <p className="text-center p-8 text-muted-foreground">Không có bài viết nào.</p>
                     )}
                     {totalPages > 1 && (
                        <div className="mt-6">
                            <Pagination
                                currentPage={currentPage}
                                totalPages={totalPages}
                                totalItems={totalItems}
                                itemsPerPage={ITEMS_PER_PAGE}
                                onPageChange={handlePageChange}
                            />
                        </div>
                     )}
                </CardContent>
            </Card>
            </div>

            {postToEdit && (
                <EditPostModal 
                    post={postToEdit}
                    onClose={() => setPostToEdit(null)}
                    onSave={() => {
                        setPostToEdit(null);
                        fetchPosts(currentPage, debouncedSearch);
                    }}
                />
            )}

            {postToDelete && (
                <ConfirmationModal
                    title="Xác nhận xóa"
                    message={`Bạn có chắc muốn xóa bài viết "${postToDelete.title}"?`}
                    isDestructive
                    onConfirm={handleDelete}
                    onCancel={() => setPostToDelete(null)}
                />
            )}
        </>
    );
}