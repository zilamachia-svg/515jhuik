import { useState, useEffect, useCallback } from 'react';
import { toast } from 'sonner';
import { Product, ApiError } from '../../types';
import apiClient from '../../services/apiClient';
import { formatCurrency, formatApiErrorForToast } from '../../utils';
import { usePageTitle } from '../../contexts/PageTitleContext';
import { useDebounce } from '../../hooks/useDebounce';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Pagination } from '@/components/Pagination';
import { Edit, Trash2, Plus, Search } from 'lucide-react';
import { EditProductModal } from '../../components/admin/EditProductModal';
import { ConfirmationModal } from '../../components/ConfirmationModal';
import { TableSkeleton } from '../../components/skeletons/TableSkeleton';

const ITEMS_PER_PAGE = 10;

export default function ProductManagementPage() {
    usePageTitle("Quản lý Sản phẩm");

    const [products, setProducts] = useState<Product[]>([]);
    const [isLoading, setIsLoading] = useState(true);
    const [currentPage, setCurrentPage] = useState(1);
    const [totalPages, setTotalPages] = useState(1);
    const [totalItems, setTotalItems] = useState(0);
    const [searchTerm, setSearchTerm] = useState('');
    const debouncedSearch = useDebounce(searchTerm, 500);

    const [productToEdit, setProductToEdit] = useState<Product | 'new' | null>(null);
    const [productToDelete, setProductToDelete] = useState<Product | null>(null);

    const fetchProducts = useCallback(async (page: number, search: string) => {
        setIsLoading(true);
        try {
            const response = await apiClient.get('/admin/products', {
                params: { page, limit: ITEMS_PER_PAGE, search: search || undefined },
            });
            setProducts(response.data.data);
            setTotalPages(response.data.totalPages);
            setTotalItems(response.data.totalItems);
            setCurrentPage(response.data.currentPage);
        } catch (error) {
            toast.error(formatApiErrorForToast(error as ApiError, 'Không thể tải danh sách sản phẩm.'));
        } finally {
            setIsLoading(false);
        }
    }, []);

    useEffect(() => {
        fetchProducts(currentPage, debouncedSearch);
    }, [fetchProducts, currentPage, debouncedSearch]);

    const handlePageChange = (page: number) => {
        setCurrentPage(page);
    };

    const handleDeleteProduct = async () => {
        if (!productToDelete) return;
        try {
            await apiClient.delete(`/admin/products/${productToDelete.id}`);
            toast.success(`Đã xóa sản phẩm ${productToDelete.name}.`);
            setProductToDelete(null);
            fetchProducts(currentPage, debouncedSearch);
        } catch (error) {
            toast.error(formatApiErrorForToast(error as ApiError, 'Xóa sản phẩm thất bại.'));
            setProductToDelete(null);
        }
    };
    
    const handleSave = () => {
        setProductToEdit(null);
        fetchProducts(currentPage, debouncedSearch);
    };

    return (
        <>
            <div className="space-y-6">
                <Card>
                    <CardHeader className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
                        <CardTitle className="flex items-center gap-2">
                            <span className="text-xl">📦</span>
                            Quản lý Sản phẩm
                        </CardTitle>
                        <div className="flex items-center gap-2 w-full sm:w-auto">
                            <div className="relative flex-1 sm:flex-initial">
                                <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                                <Input
                                    type="search"
                                    placeholder="Tìm kiếm sản phẩm..."
                                    value={searchTerm}
                                    onChange={(e) => setSearchTerm(e.target.value)}
                                    className="pl-9 w-full sm:w-[250px]"
                                />
                            </div>
                            <Button onClick={() => setProductToEdit('new')}>
                                <Plus size={16} className="mr-2" /> Thêm sản phẩm
                            </Button>
                        </div>
                    </CardHeader>
                    <CardContent>
                        {isLoading && !products.length ? (
                            <TableSkeleton headers={['Tên', 'Danh mục', 'Giá', 'Tồn kho', 'Quốc gia', 'Hành động']} />
                        ) : (
                            <div className="w-full overflow-auto">
                                <Table>
                                    <TableHeader>
                                        <TableRow>
                                            <TableHead>LOGO</TableHead>
                                            <TableHead>DANH MỤC</TableHead>
                                            <TableHead>GIÁ</TableHead>
                                            <TableHead>TRẠNG THÁI</TableHead>
                                            <TableHead>THAO TÁC</TableHead>
                                        </TableRow>
                                    </TableHeader>
                                    <TableBody>
                                        {products.map(product => {
                                            // Determine logo based on category
                                            const getLogo = () => {
                                                if (product.imageUrl) {
                                                    return <img src={product.imageUrl} alt={product.name} className="w-8 h-8 object-contain" />;
                                                }
                                                const categoryLower = product.category?.toLowerCase() || '';
                                                if (categoryLower.includes('gmail')) {
                                                    return <div className="flex items-center justify-center w-8 h-8 rounded bg-gradient-to-br from-red-500 to-blue-500 text-white font-bold text-xs">M</div>;
                                                }
                                                if (categoryLower.includes('hotmail') || categoryLower.includes('outlook')) {
                                                    return <div className="flex items-center justify-center w-8 h-8 rounded bg-blue-500 text-white"><svg className="w-5 h-5" fill="currentColor" viewBox="0 0 20 20"><path d="M2.003 5.884L10 9.882l7.997-3.998A2 2 0 0016 4H4a2 2 0 00-1.997 1.884z" /><path d="M18 8.118l-8 4-8-4V14a2 2 0 002 2h12a2 2 0 002-2V8.118z" /></svg></div>;
                                                }
                                                if (categoryLower.includes('facebook')) {
                                                    return <div className="flex items-center justify-center w-8 h-8 rounded bg-blue-600 text-white font-bold">f</div>;
                                                }
                                                return <div className="flex items-center justify-center w-8 h-8 rounded bg-muted text-muted-foreground">?</div>;
                                            };
                                            
                                            return (
                                                <TableRow key={product.id}>
                                                    <TableCell>
                                                        <div className="flex items-center gap-2">
                                                            {getLogo()}
                                                            <span className="font-medium">{product.name}</span>
                                                        </div>
                                                    </TableCell>
                                                    <TableCell>{product.category}</TableCell>
                                                    <TableCell>{formatCurrency(product.price)}</TableCell>
                                                    <TableCell>Hiện</TableCell>
                                                    <TableCell>
                                                        <div className="flex items-center gap-2">
                                                            <Button variant="ghost" size="icon" onClick={() => setProductToEdit(product)}>
                                                                <Edit size={14} />
                                                            </Button>
                                                            <Button variant="ghost" size="icon" className="text-destructive" onClick={() => setProductToDelete(product)}>
                                                                <Trash2 size={14} />
                                                            </Button>
                                                        </div>
                                                    </TableCell>
                                                </TableRow>
                                            );
                                        })}
                                    </TableBody>
                                </Table>
                            </div>
                        )}

                        {!isLoading && products.length === 0 && (
                            <p className="text-center p-8 text-muted-foreground">Không tìm thấy sản phẩm nào.</p>
                        )}

                        {totalPages > 1 && (
                            <div className="mt-6">
                                <Pagination
                                    currentPage={currentPage}
                                    totalPages={totalPages}
                                    totalItems={totalItems}
                                    itemsPerPage={ITEMS_PER_PAGE}
                                    onPageChange={handlePageChange}
                                />
                            </div>
                        )}
                    </CardContent>
                </Card>
            </div>

            {productToEdit && (
                <EditProductModal
                    product={productToEdit}
                    onClose={() => setProductToEdit(null)}
                    onSave={handleSave}
                />
            )}
            
            {productToDelete && (
                <ConfirmationModal
                    title="Xác nhận xóa sản phẩm"
                    message={`Bạn có chắc muốn xóa vĩnh viễn sản phẩm "${productToDelete.name}"?`}
                    isDestructive
                    onConfirm={handleDeleteProduct}
                    onCancel={() => setProductToDelete(null)}
                />
            )}
        </>
    );
}
