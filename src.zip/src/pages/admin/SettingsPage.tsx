import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Save, TestTube, Trash2, Loader2, Settings, Palette, Globe, Wrench, Badge } from 'lucide-react';
import { ImageUpload } from '@/components/ImageUpload';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { toast } from 'sonner';
import apiClient from '@/services/apiClient';
import { ApiError } from '@/types';
import { formatApiErrorForToast } from '@/utils';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Info, Eye, EyeOff, Copy, Check, AlertCircle } from 'lucide-react';
import { useCopyToClipboard } from '@/hooks/useCopyToClipboard';
import RichTextEditor from '@/components/RichTextEditor';
import {
    AlertDialog,
    AlertDialogAction,
    AlertDialogCancel,
    AlertDialogContent,
    AlertDialogDescription,
    AlertDialogFooter,
    AlertDialogHeader,
    AlertDialogTitle,
} from '@/components/ui/alert-dialog';

export default function SettingsPage() {
    // Branding states
    const [logoUrl, setLogoUrl] = useState('/logo.png');
    const [faviconUrl, setFaviconUrl] = useState('/favicon.ico');
    
    // General states
    const [siteName, setSiteName] = useState('Hải Đăng Meta');
    const [siteDescription, setSiteDescription] = useState('Nền tảng dịch vụ meta hàng đầu Việt Nam');
    
    // Tools states - Facebook Token
    const [facebookToken, setFacebookToken] = useState('');
    const [showFacebookToken, setShowFacebookToken] = useState(false);
    const [copyToken, isTokenCopied] = useCopyToClipboard();
    const [isTestingToken, setIsTestingToken] = useState(false);
    const [tokenTestResult, setTokenTestResult] = useState<{ valid: boolean; message: string } | null>(null);
    const [showDeleteDialog, setShowDeleteDialog] = useState(false);
    // Hardcoded Facebook configuration - should not be changed
    const FACEBOOK_DOMAIN_VERIFICATION = 'mivfxi411r8is9w2ieh05ahhliejo8';
    const FACEBOOK_APP_ID = '820326607281961';
    
    const [facebookDomainVerification, setFacebookDomainVerification] = useState(FACEBOOK_DOMAIN_VERIFICATION);
    const [facebookAppId, setFacebookAppId] = useState(FACEBOOK_APP_ID);
    
    // Tools states - Messenger (Page ID can be configured)
    const [messengerPageId, setMessengerPageId] = useState('');
    const [messengerAppId, setMessengerAppId] = useState(FACEBOOK_APP_ID);
    
    // Tools states - Gemini
    const [geminiApiKey, setGeminiApiKey] = useState('');
    const [showGeminiKey, setShowGeminiKey] = useState(false);
    
    // General states
    const [isSaving, setIsSaving] = useState(false);
    
    // System notification
    const [systemNotification, setSystemNotification] = useState('');

    // Load settings on mount
    useEffect(() => {
        const loadSettings = async () => {
            try {
                const response = await apiClient.get('/admin/settings');
                const settings = response.data.settings;
                
                // Load branding settings (Logo, Favicon)
                if (settings?.branding?.logo_url) {
                    setLogoUrl(settings.branding.logo_url);
                }
                if (settings?.branding?.favicon_url) {
                    setFaviconUrl(settings.branding.favicon_url);
                }
                
                // Load homepage settings
                if (settings?.homepage?.welcomeTitle) {
                    setSiteName(settings.homepage.welcomeTitle);
                }
                if (settings?.homepage?.welcomeSubtitle) {
                    setSiteDescription(settings.homepage.welcomeSubtitle);
                }
                
                // Load tools settings
                if (settings?.tools?.facebook_access_token) {
                    setFacebookToken(settings.tools.facebook_access_token);
                }
                if (settings?.tools?.messenger_page_id) {
                    setMessengerPageId(settings.tools.messenger_page_id);
                }
                if (settings?.tools?.messenger_app_id) {
                    setMessengerAppId(settings.tools.messenger_app_id);
                }
                if (settings?.tools?.gemini_api_key) {
                    setGeminiApiKey(settings.tools.gemini_api_key);
                }
                if (settings?.tools?.facebook_domain_verification) {
                    setFacebookDomainVerification(settings.tools.facebook_domain_verification);
                }
                if (settings?.tools?.facebook_app_id) {
                    setFacebookAppId(settings.tools.facebook_app_id);
                }
            } catch (error) {
                console.error('Failed to load settings:', error);
                toast.error('Không thể tải cài đặt. Vui lòng thử lại.');
            }
        };
        loadSettings();
    }, []);

    const handleSave = async () => {
        setIsSaving(true);
        
        try {
            const payload = {
                // Branding settings - Lưu URLs vào database
                branding: {
                    logo_url: logoUrl || '/logo.png',
                    favicon_url: faviconUrl || '/favicon.ico',
                },
                
                // Contact settings
                contact: {
                    email: '',
                    zalo: '',
                    telegram: '',
                    facebook: '',
                },
                
                // Homepage settings
                homepage: {
                    welcomeTitle: siteName,
                    welcomeSubtitle: siteDescription,
                },
                
                // Tools settings
                tools: {
                    facebook_access_token: facebookToken,
                    messenger_page_id: messengerPageId,
                    messenger_app_id: messengerAppId,
                    gemini_api_key: geminiApiKey,
                    facebook_domain_verification: facebookDomainVerification,
                    facebook_app_id: facebookAppId,
                },
            };
            
            await apiClient.put('/admin/settings', payload);
            toast.success('Đã lưu cài đặt thành công!');
            setTokenTestResult(null);
        } catch (error) {
            toast.error(formatApiErrorForToast(error as ApiError, 'Lưu cài đặt thất bại!'));
        } finally {
            setIsSaving(false);
        }
    };

    const handleTestToken = async () => {
        if (!facebookToken.trim()) {
            toast.error('Vui lòng nhập token trước khi test!');
            return;
        }

        setIsTestingToken(true);
        setTokenTestResult(null);

        try {
            const response = await apiClient.post('/api/v1/tools/test-facebook-token', {
                token: facebookToken,
            });

            const result = response.data;
            setTokenTestResult(result);

            if (result.valid) {
                toast.success('Token hợp lệ! ' + (result.data?.name ? `Xin chào ${result.data.name}` : ''));
            } else {
                toast.error('Token không hợp lệ: ' + result.message);
            }
        } catch (error) {
            const errorMessage = formatApiErrorForToast(error as ApiError, 'Lỗi khi test token!');
            setTokenTestResult({
                valid: false,
                message: errorMessage,
            });
            toast.error(errorMessage);
        } finally {
            setIsTestingToken(false);
        }
    };

    const handleDeleteToken = async () => {
        setFacebookToken('');
        setTokenTestResult(null);
        setShowDeleteDialog(false);
        toast.success('Đã xóa token khỏi form. Nhấn "Lưu cài đặt" để xác nhận xóa vĩnh viễn khỏi database.');
    };

    return (
        <div className="space-y-8">
            {/* Banner */}
            <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5 }}
                className="overflow-hidden rounded-3xl bg-gradient-to-r from-amber-400/85 via-orange-400/85 to-red-400/85 p-8 text-white"
            >
                <div className="flex flex-col gap-6 md:flex-row md:items-center md:justify-between">
                    <div className="space-y-2">
                        <Badge className="bg-white/20 text-white hover:bg-white/30 rounded-xl">Admin Settings</Badge>
                        <h2 className="text-3xl font-bold">Cài đặt Hệ thống</h2>
                        <p className="max-w-[600px] text-white/80">
                            Quản lý cấu hình website, thương hiệu, và các công cụ tích hợp.
                        </p>
                    </div>
                    <div className="flex h-16 w-16 items-center justify-center rounded-2xl bg-white/20 backdrop-blur-md">
                        <Settings className="h-8 w-8" />
                    </div>
                </div>
            </motion.div>

            <Tabs defaultValue="branding" className="space-y-6">
                <TabsList className="grid w-full grid-cols-3 rounded-2xl bg-muted p-1">
                    <TabsTrigger value="branding" className="rounded-xl">
                        <Palette className="mr-2 h-4 w-4" />
                        Nhận diện thương hiệu
                    </TabsTrigger>
                    <TabsTrigger value="general" className="rounded-xl">
                        <Globe className="mr-2 h-4 w-4" />
                        Thông tin chung
                    </TabsTrigger>
                    <TabsTrigger value="tools" className="rounded-xl">
                        <Wrench className="mr-2 h-4 w-4" />
                        Công cụ & API
                    </TabsTrigger>
                </TabsList>

                {/* Tab: Nhận diện thương hiệu */}
                <TabsContent value="branding" className="space-y-6">
                    <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                        <ImageUpload
                            title="Logo trang web"
                            description="Logo hiển thị trên header và footer"
                            currentImage={logoUrl}
                            onImageUploaded={setLogoUrl}
                            maxSizeMB={2}
                            recommendedSize="200x50px"
                        />
                        <ImageUpload
                            title="Favicon"
                            description="Icon hiển thị trên tab trình duyệt"
                            currentImage={faviconUrl}
                            onImageUploaded={setFaviconUrl}
                            maxSizeMB={1}
                            recommendedSize="32x32px hoặc 64x64px"
                        />
                    </div>
                    
                    {/* Background đăng nhập và đăng ký */}
                    <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                        <div className="space-y-2">
                            <Label>Background đăng nhập</Label>
                            <div className="border-2 border-dashed border-muted rounded-lg p-4 bg-muted/30 min-h-[200px] flex items-center justify-center">
                                <p className="text-sm text-muted-foreground">Upload background đăng nhập</p>
                            </div>
                        </div>
                        <div className="space-y-2">
                            <Label>Background đăng ký</Label>
                            <div className="border-2 border-dashed border-muted rounded-lg p-4 bg-muted/30 min-h-[200px] flex items-center justify-center">
                                <p className="text-sm text-muted-foreground">Upload background đăng ký</p>
                            </div>
                        </div>
                    </div>
                    
                    {/* Thông báo toàn hệ thống */}
                    <Card className="rounded-3xl">
                        <CardHeader>
                            <CardTitle>Thông báo toàn hệ thống</CardTitle>
                            <CardDescription>
                                Thông báo hiển thị cho tất cả người dùng
                            </CardDescription>
                        </CardHeader>
                        <CardContent>
                            <RichTextEditor 
                                value={systemNotification} 
                                onChange={setSystemNotification}
                            />
                        </CardContent>
                    </Card>

                    {/* Current URLs Display */}
                    <Card className="rounded-3xl">
                        <CardHeader>
                            <CardTitle>URL hiện tại</CardTitle>
                            <CardDescription>
                                Các đường dẫn ảnh đang được lưu trong database
                            </CardDescription>
                        </CardHeader>
                        <CardContent className="space-y-3">
                            <div className="flex items-center gap-3 p-3 bg-muted rounded-xl border">
                                <span className="text-sm font-semibold w-24">Logo:</span>
                                <code className="flex-1 text-xs bg-background px-3 py-2 rounded-xl border font-mono text-primary break-all">
                                    {logoUrl}
                                </code>
                            </div>
                            <div className="flex items-center gap-3 p-3 bg-muted rounded-xl border">
                                <span className="text-sm font-semibold w-24">Favicon:</span>
                                <code className="flex-1 text-xs bg-background px-3 py-2 rounded-xl border font-mono text-primary break-all">
                                    {faviconUrl}
                                </code>
                            </div>
                        </CardContent>
                    </Card>

                    {/* Current Icons Preview */}
                    <Card className="rounded-3xl">
                        <CardHeader>
                            <CardTitle>Icons hiện tại</CardTitle>
                            <CardDescription>
                                Các icon đang được sử dụng trong hệ thống
                            </CardDescription>
                        </CardHeader>
                        <CardContent>
                            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                                <div className="flex flex-col items-center space-y-2 p-4 bg-muted rounded-xl border">
                                    <img 
                                        src={logoUrl} 
                                        alt="Logo" 
                                        className="h-12 object-contain"
                                        onError={(e) => {
                                            e.currentTarget.src = 'https://ui-avatars.com/api/?name=HD&background=3b82f6&color=fff&size=128';
                                        }}
                                    />
                                    <span className="text-xs font-medium text-muted-foreground">Logo</span>
                                </div>
                                <div className="flex flex-col items-center space-y-2 p-4 bg-muted rounded-xl border">
                                    <img 
                                        src={faviconUrl} 
                                        alt="Favicon" 
                                        className="h-8 w-8 object-contain"
                                        onError={(e) => {
                                            e.currentTarget.src = 'https://ui-avatars.com/api/?name=HD&background=3b82f6&color=fff&size=64';
                                        }}
                                    />
                                    <span className="text-xs font-medium text-muted-foreground">Favicon</span>
                                </div>
                            </div>
                        </CardContent>
                    </Card>
                </TabsContent>

                {/* Tab: Thông tin chung */}
                <TabsContent value="general" className="space-y-6">
                    <Card className="rounded-3xl">
                        <CardHeader>
                            <CardTitle>Thông tin website</CardTitle>
                            <CardDescription>
                                Các thông tin cơ bản về website
                            </CardDescription>
                        </CardHeader>
                        <CardContent className="space-y-4">
                            <div className="space-y-2">
                                <Label htmlFor="siteName">
                                    Tên website
                                </Label>
                                <Input
                                    id="siteName"
                                    value={siteName}
                                    onChange={(e) => setSiteName(e.target.value)}
                                    placeholder="Nhập tên website"
                                    className="rounded-2xl"
                                />
                            </div>
                            <div className="space-y-2">
                                <Label htmlFor="siteDescription">
                                    Mô tả website
                                </Label>
                                <textarea
                                    id="siteDescription"
                                    value={siteDescription}
                                    onChange={(e) => setSiteDescription(e.target.value)}
                                    placeholder="Nhập mô tả website"
                                    className="flex min-h-[80px] w-full rounded-2xl border border-muted bg-background px-4 py-3 text-sm transition-all duration-200 focus-visible:border-primary focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary/20 focus-visible:ring-offset-2 focus-visible:shadow-lg"
                                    rows={3}
                                />
                            </div>
                        </CardContent>
                    </Card>
                </TabsContent>

                {/* Tab: Công cụ & API */}
                <TabsContent value="tools" className="space-y-6">
                    {/* Facebook Access Token */}
                    <Card className="rounded-3xl">
                        <CardHeader>
                            <CardTitle>Facebook Access Token</CardTitle>
                            <CardDescription>
                                Token để check live FB và các tính năng Facebook API (EAAAAU...)
                            </CardDescription>
                        </CardHeader>
                        <CardContent className="space-y-4">
                            <div className="space-y-2">
                                <Label htmlFor="facebookToken">
                                    Token Facebook
                                </Label>
                                <div className="relative">
                                    <Input
                                        id="facebookToken"
                                        type={showFacebookToken ? 'text' : 'password'}
                                        value={facebookToken}
                                        onChange={(e) => setFacebookToken(e.target.value)}
                                        placeholder="EAAAAUaZA8jlABO7dYQaH0JKGgOoLZCADEUCzKwuU8sfrSw3W4y3URAVdoUKDIGExPgZAmYxcid3PirVNZC6yfMFPJhGEkT43a9HiWJL2Jnx4ZCis6ImXfUJpbTCmzVf0VajISjJSj0tMGyqFgu687g6PZC63tHLU492393mW351Qidz5wXcQsmx8KlJDK1MyRUZA2qYA7GMfAZDZD"
                                        className="rounded-2xl pr-10 font-mono text-xs"
                                    />
                                    <Button
                                        type="button"
                                        variant="ghost"
                                        size="icon"
                                        onClick={() => setShowFacebookToken(!showFacebookToken)}
                                        className="absolute right-1 top-1/2 -translate-y-1/2 rounded-xl"
                                    >
                                        {showFacebookToken ? <EyeOff size={18} /> : <Eye size={18} />}
                                    </Button>
                                </div>
                            </div>
                            
                            {tokenTestResult && (
                                <Alert className={tokenTestResult.valid ? 'border-green-200 bg-green-50 dark:border-green-800 dark:bg-green-900/20' : 'border-red-200 bg-red-50 dark:border-red-800 dark:bg-red-900/20'}>
                                    <AlertCircle className={tokenTestResult.valid ? 'text-green-600 dark:text-green-400' : 'text-red-600 dark:text-red-400'} />
                                    <AlertDescription className={tokenTestResult.valid ? 'text-green-800 dark:text-green-200' : 'text-red-800 dark:text-red-200'}>
                                        {tokenTestResult.message}
                                    </AlertDescription>
                                </Alert>
                            )}

                            <div className="flex flex-wrap gap-2">
                                <Button
                                    onClick={handleTestToken}
                                    disabled={isTestingToken || !facebookToken.trim()}
                                    variant="outline"
                                    className="rounded-2xl"
                                >
                                    {isTestingToken ? (
                                        <>
                                            <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                                            Đang test...
                                        </>
                                    ) : (
                                        <>
                                            <TestTube className="mr-2 h-4 w-4" />
                                            Test Token
                                        </>
                                    )}
                                </Button>
                                <Button
                                    onClick={() => setShowDeleteDialog(true)}
                                    disabled={!facebookToken.trim()}
                                    variant="destructive"
                                    className="rounded-2xl"
                                >
                                    <Trash2 className="mr-2 h-4 w-4" />
                                    Xóa Token
                                </Button>
                                {facebookToken && (
                                    <Button
                                        onClick={() => copyToken(facebookToken)}
                                        variant="outline"
                                        className="rounded-2xl"
                                    >
                                        {isTokenCopied ? (
                                            <>
                                                <Check className="mr-2 h-4 w-4" />
                                                Đã copy!
                                            </>
                                        ) : (
                                            <>
                                                <Copy className="mr-2 h-4 w-4" />
                                                Copy
                                            </>
                                        )}
                                    </Button>
                                )}
                            </div>

                            <Alert>
                                <Info className="h-4 w-4" />
                                <AlertDescription>
                                    <div className="space-y-2">
                                        <p className="font-semibold">Về Facebook Access Token:</p>
                                        <p className="text-xs">Token này được sử dụng cho tính năng check live FB và các tính năng Facebook API khác. Token sẽ được lưu an toàn trong database.</p>
                                        <div className="pt-2 space-y-1">
                                            <p className="font-semibold text-xs">Cách lấy Facebook Token:</p>
                                            <ol className="list-decimal list-inside space-y-1 text-xs">
                                                <li>Truy cập <a href="https://developers.facebook.com/tools/explorer/" target="_blank" rel="noopener noreferrer" className="underline hover:text-primary">Facebook Graph API Explorer</a></li>
                                                <li>Chọn ứng dụng Facebook của bạn hoặc tạo mới</li>
                                                <li>Click &quot;Generate Access Token&quot; và chọn quyền cần thiết</li>
                                                <li>Copy token (bắt đầu với EAAAAU...) và paste vào ô trên</li>
                                                <li>Click &quot;Test Token&quot; để kiểm tra token có hợp lệ không</li>
                                            </ol>
                                        </div>
                                        <p className="text-xs pt-2"><strong>Lưu ý:</strong> Token có thể hết hạn sau một thời gian. Nếu tính năng không hoạt động, hãy tạo token mới.</p>
                                    </div>
                                </AlertDescription>
                            </Alert>
                        </CardContent>
                    </Card>

                    {/* Facebook Domain Verification & App ID */}
                    <Card className="rounded-3xl">
                        <CardHeader>
                            <CardTitle>Facebook Domain Verification</CardTitle>
                            <CardDescription>
                                Cấu hình xác thực domain và App ID cho Facebook
                            </CardDescription>
                        </CardHeader>
                        <CardContent className="space-y-4">
                            <div className="space-y-2">
                                <Label htmlFor="facebookDomainVerification">
                                    Domain Verification Code
                                </Label>
                                <Input
                                    id="facebookDomainVerification"
                                    value={facebookDomainVerification}
                                    readOnly
                                    disabled
                                    placeholder="mivfxi411r8is9w2ieh05ahhliejo8"
                                    className="rounded-2xl font-mono text-xs bg-muted/50 cursor-not-allowed"
                                />
                                <p className="text-xs text-muted-foreground">
                                    Code này được sử dụng trong meta tag: &lt;meta name=&quot;facebook-domain-verification&quot; content=&quot;...&quot; /&gt;
                                </p>
                            </div>
                            <div className="space-y-2">
                                <Label htmlFor="facebookAppId">
                                    Facebook App ID
                                </Label>
                                <Input
                                    id="facebookAppId"
                                    value={facebookAppId}
                                    readOnly
                                    disabled
                                    placeholder="820326607281961"
                                    className="rounded-2xl font-mono text-xs bg-muted/50 cursor-not-allowed"
                                />
                            </div>
                        </CardContent>
                    </Card>

                    {/* Messenger Settings */}
                    <Card className="rounded-3xl">
                        <CardHeader>
                            <CardTitle>Facebook Messenger</CardTitle>
                            <CardDescription>
                                Cấu hình Messenger Customer Chat Plugin
                            </CardDescription>
                        </CardHeader>
                        <CardContent className="space-y-4">
                            <div className="space-y-2">
                                <Label htmlFor="messengerPageId">
                                    Messenger Page ID
                                </Label>
                                <Input
                                    id="messengerPageId"
                                    value={messengerPageId}
                                    onChange={(e) => setMessengerPageId(e.target.value)}
                                    placeholder="Nhập Page ID (ví dụ: 123456789012345)"
                                    className="rounded-2xl"
                                />
                            </div>
                            <div className="space-y-2">
                                <Label htmlFor="messengerAppId">
                                    Messenger App ID
                                </Label>
                                <Input
                                    id="messengerAppId"
                                    value={messengerAppId}
                                    readOnly
                                    disabled
                                    placeholder="820326607281961"
                                    className="rounded-2xl font-mono text-xs bg-muted/50 cursor-not-allowed"
                                />
                            </div>
                            
                                <Alert className="bg-purple-50/50 border-purple-200 dark:bg-purple-900/10 dark:border-purple-800">
                                <Info className="h-4 w-4 text-purple-600 dark:text-purple-400" />
                                <AlertDescription className="text-sm text-purple-800 dark:text-purple-200">
                                    <div className="space-y-2">
                                        <p className="font-semibold">Cách lấy Messenger Page ID:</p>
                                        <ol className="list-decimal list-inside space-y-1 text-xs">
                                            <li>Truy cập trang Facebook của bạn</li>
                                            <li>Click &quot;About&quot; / &quot;Giới thiệu&quot; ở sidebar</li>
                                            <li>Kéo xuống phần &quot;More Info&quot; / &quot;Thêm thông tin&quot;</li>
                                            <li>Tìm &quot;Page ID&quot; và copy số ID</li>
                                            <li>Hoặc lấy từ URL: facebook.com/[page-id]</li>
                                        </ol>
                                    </div>
                                </AlertDescription>
                                </Alert>
                                
                                {/* Nếu bạn muốn giữ dòng ghi chú này, hãy để nó ở ngoài Alert hoặc xóa nếu không cần */}
                                <p className="text-xs pt-1"><strong>Sử dụng cho:</strong> Widget chat Messenger</p>

                        </CardContent>
                    </Card>

                    {/* Gemini API Key */}
                    <Card className="rounded-3xl">
                        <CardHeader>
                            <CardTitle>Gemini API Key</CardTitle>
                            <CardDescription>
                                API key cho tính năng chat AI (Gemini)
                            </CardDescription>
                        </CardHeader>
                        <CardContent className="space-y-4">
                            <div className="space-y-2">
                                <Label htmlFor="geminiApiKey">
                                    Gemini API Key
                                </Label>
                                <div className="relative">
                                    <Input
                                        id="geminiApiKey"
                                        type={showGeminiKey ? 'text' : 'password'}
                                        value={geminiApiKey}
                                        onChange={(e) => setGeminiApiKey(e.target.value)}
                                        placeholder="AIzaSy... (40+ ký tự)"
                                        className="rounded-2xl pr-10 font-mono text-xs"
                                    />
                                    <Button
                                        type="button"
                                        variant="ghost"
                                        size="icon"
                                        onClick={() => setShowGeminiKey(!showGeminiKey)}
                                        className="absolute right-1 top-1/2 -translate-y-1/2 rounded-xl"
                                    >
                                        {showGeminiKey ? <EyeOff size={18} /> : <Eye size={18} />}
                                    </Button>
                                </div>
                            </div>
                            
                            <Alert className="bg-blue-50/50 border-blue-200 dark:bg-blue-900/10 dark:border-blue-800">
                                <Info className="h-4 w-4 text-blue-600 dark:text-blue-400" />
                                <AlertDescription className="text-sm text-blue-800 dark:text-blue-200">
                                    <div className="space-y-2">
                                        <p className="font-semibold">Cách lấy Gemini API Key:</p>
                                        <ol className="list-decimal list-inside space-y-1 text-xs">
                                            <li>Truy cập <a href="https://makersuite.google.com/app/apikey" target="_blank" rel="noopener noreferrer" className="underline hover:text-blue-600">Google AI Studio</a></li>
                                            <li>Đăng nhập với tài khoản Google</li>
                                            <li>Click "Get API Key" hoặc "Create API Key"</li>
                                            <li>Copy API key và paste vào ô trên</li>
                                        </ol>
                                        <p className="text-xs pt-1"><strong>Sử dụng cho:</strong> Chat AI, tạo nội dung tự động, hỗ trợ khách hàng thông minh</p>
                                    </div>
                                </AlertDescription>
                            </Alert>
                        </CardContent>
                    </Card>
                </TabsContent>
            </Tabs>

            {/* Save Button - Fixed at bottom */}
            <div className="sticky bottom-6 flex justify-end z-10">
                <Button
                    onClick={handleSave}
                    disabled={isSaving}
                    size="lg"
                    className="shadow-xl hover:shadow-2xl transition-all duration-300 rounded-2xl font-bold text-base px-8"
                >
                    {isSaving ? (
                        <>
                            <Loader2 className="mr-2 h-5 w-5 animate-spin" />
                            Đang lưu...
                        </>
                    ) : (
                        <>
                            <Save className="mr-2 h-5 w-5" />
                            Lưu cài đặt
                        </>
                    )}
                </Button>
            </div>

            {/* Delete Token Dialog */}
            <AlertDialog open={showDeleteDialog} onOpenChange={setShowDeleteDialog}>
                <AlertDialogContent className="rounded-3xl">
                    <AlertDialogHeader>
                        <AlertDialogTitle>Xác nhận xóa token</AlertDialogTitle>
                        <AlertDialogDescription>
                            Bạn có chắc chắn muốn xóa token Facebook? Token sẽ bị xóa khỏi database và các tính năng sử dụng token sẽ không hoạt động.
                        </AlertDialogDescription>
                    </AlertDialogHeader>
                    <AlertDialogFooter>
                        <AlertDialogCancel className="rounded-xl">Hủy</AlertDialogCancel>
                        <AlertDialogAction
                            onClick={handleDeleteToken}
                            className="bg-destructive text-destructive-foreground hover:bg-destructive/90 rounded-xl"
                        >
                            Xóa Token
                        </AlertDialogAction>
                    </AlertDialogFooter>
                </AlertDialogContent>
            </AlertDialog>
        </div>
    );
}