import React from 'react';
import { toast } from 'sonner';
import { useImageSettings, ImageFormat } from '../../contexts/ImageSettingsContext';
import { usePageTitle } from '../../contexts/PageTitleContext';
import { Card, CardContent, CardHeader, CardTitle, CardFooter } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Slider } from '@/components/ui/slider';

export default function ImageSettingsPage() {
    usePageTitle("Cài đặt Hình ảnh");
    const { settings, setSettings } = useImageSettings();

    const handleFormatChange = (value: ImageFormat) => {
        setSettings({ ...settings, format: value });
    };

    const handleQualityChange = (value: number[]) => {
        setSettings({ ...settings, quality: value[0] });
    };
    
    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        toast.success("Đã lưu cài đặt hình ảnh!");
    };

    return (
        <Card className="rounded-2xl shadow-xl hover:shadow-2xl transition-shadow duration-300">
            <CardHeader>
                <CardTitle className="text-xl font-bold">Cài đặt Tối ưu hóa Hình ảnh</CardTitle>
                <p className="text-sm text-muted-foreground font-medium mt-2">
                    Cấu hình chất lượng và định dạng ảnh tự động
                </p>
            </CardHeader>
            <form onSubmit={handleSubmit}>
                <CardContent className="space-y-6">
                    <div className="space-y-2">
                        <Label htmlFor="format" className="text-sm font-semibold">Định dạng thế hệ tiếp theo</Label>
                        <Select value={settings.format} onValueChange={handleFormatChange}>
                            <SelectTrigger id="format" className="w-full md:w-[240px] rounded-xl shadow-sm font-medium">
                                <SelectValue placeholder="Chọn định dạng" />
                            </SelectTrigger>
                            <SelectContent className="rounded-xl">
                                <SelectItem value="webp" className="font-medium">WebP (Khuyến nghị)</SelectItem>
                                <SelectItem value="avif" className="font-medium">AVIF (Tối ưu nhất)</SelectItem>
                            </SelectContent>
                        </Select>
                        <p className="text-xs text-muted-foreground font-medium">
                            WebP: hỗ trợ rộng rãi, AVIF: nhẹ hơn nhưng ít trình duyệt hỗ trợ
                        </p>
                    </div>
                    <div className="space-y-3">
                        <div className="flex items-center justify-between">
                            <Label htmlFor="quality" className="text-sm font-semibold">Chất lượng ảnh</Label>
                            <div className="flex items-center gap-2">
                                <span className="text-2xl font-bold text-primary">{settings.quality}</span>
                                <span className="text-sm text-muted-foreground font-medium">/ 100</span>
                            </div>
                        </div>
                        <Slider
                            id="quality"
                            min={50}
                            max={100}
                            step={5}
                            value={[settings.quality]}
                            onValueChange={handleQualityChange}
                            className="py-4"
                        />
                        <div className="flex items-center justify-between text-xs text-muted-foreground font-medium">
                            <span>Thấp (50)</span>
                            <span>Trung bình (75)</span>
                            <span>Cao (100)</span>
                        </div>
                    </div>
                    <div className="p-4 bg-blue-50 border-2 border-blue-200 rounded-xl">
                        <p className="text-sm font-semibold text-blue-900">💡 Gợi ý</p>
                        <p className="text-xs text-blue-700 font-medium mt-1">
                            Chất lượng 80-85 mang lại sự cân bằng tốt nhất giữa kích thước file và chất lượng hình ảnh.
                        </p>
                    </div>
                </CardContent>
                <CardFooter className="flex justify-end border-t pt-6">
                    <Button type="submit" size="lg" className="shadow-xl hover:shadow-2xl transition-all duration-300 rounded-xl font-bold text-base px-8">Lưu thay đổi</Button>
                </CardFooter>
            </form>
        </Card>
    );
}
