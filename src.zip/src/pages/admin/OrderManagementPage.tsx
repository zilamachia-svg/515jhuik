import { useState, useEffect, useCallback } from 'react';
import { motion } from 'framer-motion';
import { toast } from 'sonner';
import { Order, ApiError } from '../../types';
import apiClient from '../../services/apiClient';
import { formatCurrency, formatApiErrorForToast } from '../../utils';
import { usePageTitle } from '../../contexts/PageTitleContext';
import { useDebounce } from '../../hooks/useDebounce';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Pagination } from '@/components/Pagination';
import { Eye, ShoppingCart, Search } from 'lucide-react';
import { TableSkeleton } from '../../components/skeletons/TableSkeleton';
import { OrderDetailModal } from '../../components/admin/OrderDetailModal';

const ITEMS_PER_PAGE = 10;

export default function OrderManagementPage() {
    usePageTitle("Quản lý Đơn hàng");

    const [orders, setOrders] = useState<Order[]>([]);
    const [isLoading, setIsLoading] = useState(true);
    const [currentPage, setCurrentPage] = useState(1);
    const [totalPages, setTotalPages] = useState(1);
    const [totalItems, setTotalItems] = useState(0);
    const [searchTerm, setSearchTerm] = useState('');
    const debouncedSearch = useDebounce(searchTerm, 500);
    const [orderToView, setOrderToView] = useState<Order | null>(null);

    const fetchOrders = useCallback(async (page: number, search: string) => {
        setIsLoading(true);
        try {
            const response = await apiClient.get('/admin/orders', {
                params: { page, limit: ITEMS_PER_PAGE, search: search || undefined },
            });
            setOrders(response.data.data);
            setTotalPages(response.data.totalPages);
            setTotalItems(response.data.totalItems);
            setCurrentPage(response.data.currentPage);
        } catch (error) {
            toast.error(formatApiErrorForToast(error as ApiError, 'Không thể tải danh sách đơn hàng.'));
        } finally {
            setIsLoading(false);
        }
    }, []);

    useEffect(() => {
        fetchOrders(currentPage, debouncedSearch);
    }, [fetchOrders, currentPage, debouncedSearch]);

    const handlePageChange = (page: number) => {
        setCurrentPage(page);
    };

    const getStatusBadge = (status: string) => {
        const variants: Record<string, 'default' | 'secondary' | 'destructive'> = {
            'completed': 'default',
            'pending': 'secondary',
            'failed': 'destructive',
        };
        return variants[status.toLowerCase()] || 'secondary';
    };

    return (
        <>
            <div className="space-y-8">
                {/* Banner Section */}
                <motion.div
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.5 }}
                    className="overflow-hidden rounded-3xl bg-gradient-to-r from-green-400/85 via-emerald-400/85 to-teal-400/85 p-8 text-white"
                >
                    <div className="flex flex-col gap-6 md:flex-row md:items-center md:justify-between">
                        <div className="space-y-2">
                            <h2 className="text-3xl font-bold flex items-center gap-2">
                                <span className="text-3xl">📋</span>
                                Quản lý Đơn hàng
                            </h2>
                            <p className="max-w-[600px] text-white/80">
                                Xem và quản lý tất cả đơn hàng trong hệ thống, theo dõi trạng thái và chi tiết giao dịch.
                            </p>
                        </div>
                        <div className="flex items-center gap-3">
                            <div className="flex h-16 w-16 items-center justify-center rounded-2xl bg-white/20 backdrop-blur-md">
                                <ShoppingCart className="h-8 w-8" />
                            </div>
                        </div>
                    </div>
                </motion.div>

                {/* Search Bar */}
                <div className="flex items-center gap-3">
                    <div className="relative flex-1">
                        <Search className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                        <Input
                            type="search"
                            placeholder="Tìm kiếm email, tên sản phẩm..."
                            value={searchTerm}
                            onChange={(e) => setSearchTerm(e.target.value)}
                            className="w-full rounded-2xl pl-9"
                        />
                    </div>
                </div>

                {/* Orders Table */}
                <Card className="rounded-3xl">
                    <CardHeader>
                        <CardTitle>Danh sách Đơn hàng</CardTitle>
                    </CardHeader>
                    <CardContent>
                        {isLoading && !orders.length ? (
                            <TableSkeleton headers={['Email', 'Sản phẩm', 'Tổng tiền', 'Ngày mua', 'Trạng thái', 'Hành động']} />
                        ) : (
                            <div className="w-full overflow-auto rounded-2xl border">
                                <Table>
                                    <TableHeader>
                                        <TableRow>
                                            <TableHead>Email</TableHead>
                                            <TableHead>Sản phẩm</TableHead>
                                            <TableHead>Tổng tiền</TableHead>
                                            <TableHead>Ngày mua</TableHead>
                                            <TableHead>Trạng thái</TableHead>
                                            <TableHead>Hành động</TableHead>
                                        </TableRow>
                                    </TableHeader>
                                    <TableBody>
                                        {orders.map(order => (
                                            <TableRow key={order.id} className="hover:bg-muted/50 transition-colors">
                                                <TableCell>{order.userEmail}</TableCell>
                                                <TableCell className="font-medium">{order.productName}</TableCell>
                                                <TableCell className="font-semibold">{formatCurrency(order.totalPrice)}</TableCell>
                                                <TableCell>{new Date(order.purchaseDate).toLocaleString('vi-VN')}</TableCell>
                                                <TableCell>
                                                    <Badge variant={getStatusBadge(order.status)} className="rounded-xl">
                                                        {order.status}
                                                    </Badge>
                                                </TableCell>
                                                <TableCell>
                                                    <Button variant="ghost" size="icon" className="rounded-xl" onClick={() => setOrderToView(order)}>
                                                        <Eye size={14} />
                                                    </Button>
                                                </TableCell>
                                            </TableRow>
                                        ))}
                                    </TableBody>
                                </Table>
                            </div>
                        )}
                        {!isLoading && orders.length === 0 && (
                            <div className="text-center p-12">
                                <ShoppingCart className="mx-auto h-12 w-12 text-muted-foreground mb-4" />
                                <p className="text-muted-foreground">Không có đơn hàng nào.</p>
                            </div>
                        )}
                        {totalPages > 1 && (
                            <div className="mt-6">
                                <Pagination
                                    currentPage={currentPage}
                                    totalPages={totalPages}
                                    totalItems={totalItems}
                                    itemsPerPage={ITEMS_PER_PAGE}
                                    onPageChange={handlePageChange}
                                />
                            </div>
                        )}
                    </CardContent>
                </Card>
            </div>

            {orderToView && (
                <OrderDetailModal
                    order={orderToView}
                    onClose={() => setOrderToView(null)}
                />
            )}
        </>
    );
}