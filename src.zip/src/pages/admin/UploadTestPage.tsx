import { useState } from 'react';
import { PageHeader } from '@/components/PageHeader';
import { ImageUpload } from '@/components/ImageUpload';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Copy, CheckCircle2 } from 'lucide-react';
import { useCopyToClipboard } from '@/hooks/useCopyToClipboard';

export default function UploadTestPage() {
    const [uploadedUrl, setUploadedUrl] = useState<string>('');
    const [copy] = useCopyToClipboard();

    return (
        <div className="space-y-6">
            <PageHeader title="Test Upload Ảnh" />

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                {/* Upload Area */}
                <ImageUpload
                    title="Tải ảnh lên"
                    description="Chọn ảnh để upload lên server"
                    currentImage={uploadedUrl}
                    onImageUploaded={setUploadedUrl}
                    maxSizeMB={5}
                />

                {/* Result Display */}
                <Card className="rounded-2xl shadow-xl hover:shadow-2xl transition-shadow duration-300">
                    <CardHeader>
                        <CardTitle className="text-lg font-bold flex items-center gap-2">
                            {uploadedUrl ? <CheckCircle2 className="h-5 w-5 text-green-500" /> : null}
                            Kết quả Upload
                        </CardTitle>
                        <CardDescription className="text-sm font-medium">
                            URL của ảnh vừa tải lên
                        </CardDescription>
                    </CardHeader>
                    <CardContent className="space-y-4">
                        {uploadedUrl ? (
                            <>
                                <div className="p-4 bg-green-50 border-2 border-green-200 rounded-xl space-y-3">
                                    <div className="flex items-center justify-between">
                                        <p className="text-sm font-semibold text-green-900">✅ Upload thành công!</p>
                                        <Button
                                            size="sm"
                                            variant="outline"
                                            onClick={() => copy(uploadedUrl, 'Đã copy URL!')}
                                            className="shadow-md font-semibold"
                                        >
                                            <Copy size={14} className="mr-2" />
                                            Copy URL
                                        </Button>
                                    </div>
                                    <code className="block text-xs bg-white px-3 py-2 rounded border font-mono text-primary break-all">
                                        {uploadedUrl}
                                    </code>
                                </div>

                                {/* Preview */}
                                <div className="space-y-2">
                                    <p className="text-sm font-semibold text-gray-700">Preview:</p>
                                    <div className="border-2 border-gray-200 rounded-xl overflow-hidden">
                                        <img 
                                            src={uploadedUrl} 
                                            alt="Uploaded" 
                                            className="w-full h-auto"
                                            onError={(e) => {
                                                e.currentTarget.src = '/placeholder.svg';
                                            }}
                                        />
                                    </div>
                                </div>

                                {/* Usage Examples */}
                                <div className="space-y-3">
                                    <p className="text-sm font-semibold text-gray-700">Cách sử dụng:</p>
                                    
                                    <div className="space-y-2">
                                        <p className="text-xs font-semibold text-muted-foreground">HTML:</p>
                                        <code className="block text-xs bg-gray-900 text-green-400 px-3 py-2 rounded font-mono overflow-x-auto">
                                            {`<img src="${uploadedUrl}" alt="Image" />`}
                                        </code>
                                    </div>

                                    <div className="space-y-2">
                                        <p className="text-xs font-semibold text-muted-foreground">React:</p>
                                        <code className="block text-xs bg-gray-900 text-green-400 px-3 py-2 rounded font-mono overflow-x-auto">
                                            {`<img src="${uploadedUrl}" alt="Image" className="..." />`}
                                        </code>
                                    </div>

                                    <div className="space-y-2">
                                        <p className="text-xs font-semibold text-muted-foreground">CSS Background:</p>
                                        <code className="block text-xs bg-gray-900 text-green-400 px-3 py-2 rounded font-mono overflow-x-auto">
                                            {`background-image: url('${uploadedUrl}');`}
                                        </code>
                                    </div>
                                </div>
                            </>
                        ) : (
                            <div className="flex flex-col items-center justify-center py-12 space-y-3">
                                <div className="rounded-full bg-gray-100 p-4">
                                    <Copy className="h-8 w-8 text-gray-400" />
                                </div>
                                <p className="text-sm text-muted-foreground font-medium text-center">
                                    Chưa có ảnh nào được tải lên
                                </p>
                            </div>
                        )}
                    </CardContent>
                </Card>
            </div>

            {/* Instructions */}
            <Card className="rounded-2xl shadow-xl border-2 border-blue-200 bg-blue-50/50">
                <CardHeader>
                    <CardTitle className="text-lg font-bold text-blue-900">💡 Hướng dẫn sử dụng</CardTitle>
                </CardHeader>
                <CardContent className="space-y-3 text-sm text-blue-800 font-medium">
                    <p>1. <strong>Upload ảnh:</strong> Kéo thả hoặc click để chọn ảnh từ máy tính</p>
                    <p>2. <strong>Chờ upload:</strong> Hệ thống sẽ tự động upload lên server</p>
                    <p>3. <strong>Copy URL:</strong> Sau khi upload xong, URL sẽ hiển thị bên phải</p>
                    <p>4. <strong>Sử dụng:</strong> Dùng URL này cho logo, avatar, hoặc bất kỳ đâu cần ảnh</p>
                    <p className="pt-2 border-t border-blue-200">
                        <strong>Lưu ý:</strong> File được lưu trên server và có thể truy cập từ bất kỳ đâu
                    </p>
                </CardContent>
            </Card>
        </div>
    );
}
