import { useState, useEffect, useCallback } from 'react';
import { toast } from 'sonner';
import { ProductCategory, ApiError } from '../../types';
import apiClient from '../../services/apiClient';
import { formatApiErrorForToast } from '../../utils';
import { usePageTitle } from '../../contexts/PageTitleContext';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Plus, Edit, Trash2 } from 'lucide-react';
import { EditProductCategoryModal } from '../../components/admin/EditProductCategoryModal';
import { ConfirmationModal } from '../../components/ConfirmationModal';
import { TableSkeleton } from '../../components/skeletons/TableSkeleton';

export default function ProductCategoryManagementPage() {
    usePageTitle("Quản lý Danh mục Sản phẩm");

    const [categories, setCategories] = useState<ProductCategory[]>([]);
    const [isLoading, setIsLoading] = useState(true);
    const [categoryToEdit, setCategoryToEdit] = useState<ProductCategory | 'new' | null>(null);
    const [categoryToDelete, setCategoryToDelete] = useState<ProductCategory | null>(null);

    const fetchCategories = useCallback(async () => {
        setIsLoading(true);
        try {
            const response = await apiClient.get('/admin/product-categories');
            // Backend đã sắp xếp: 4 danh mục cũ trước, sau đó là danh mục mới
            setCategories(response.data.categories || []);
        } catch (error) {
            toast.error(formatApiErrorForToast(error as ApiError, 'Không thể tải danh mục.'));
        } finally {
            setIsLoading(false);
        }
    }, []);

    useEffect(() => {
        fetchCategories();
    }, [fetchCategories]);

    const handleDelete = async () => {
        if (!categoryToDelete) return;
        try {
            await apiClient.delete(`/admin/product-categories/${categoryToDelete.id}`);
            toast.success(`Đã xóa danh mục "${categoryToDelete.name}".`);
            setCategoryToDelete(null);
            fetchCategories(); // Refresh data
        } catch (error) {
            toast.error(formatApiErrorForToast(error as ApiError, 'Xóa danh mục thất bại.'));
            setCategoryToDelete(null);
        }
    };
    
    const handleSave = () => {
        setCategoryToEdit(null);
        fetchCategories();
    };

    return (
        <>
            <Card>
                <CardHeader className="flex-row items-center justify-between">
                    <CardTitle>Danh mục Sản phẩm</CardTitle>
                    <Button onClick={() => setCategoryToEdit('new')}>
                        <Plus size={16} className="mr-2" /> Thêm danh mục
                    </Button>
                </CardHeader>
                <CardContent>
                    {isLoading ? (
                        <TableSkeleton headers={['Tên', 'Mô tả', 'Số sản phẩm', 'Hành động']} />
                    ) : (
                        <div className="w-full overflow-auto">
                            <Table>
                                <TableHeader>
                                    <TableRow>
                                        <TableHead>Tên</TableHead>
                                        <TableHead>Mô tả</TableHead>
                                        <TableHead>Số sản phẩm</TableHead>
                                        <TableHead>Hành động</TableHead>
                                    </TableRow>
                                </TableHeader>
                                <TableBody>
                                    {categories.map(cat => (
                                        <TableRow key={cat.id}>
                                            <TableCell className="font-medium">{cat.name}</TableCell>
                                            <TableCell>{cat.description}</TableCell>
                                            <TableCell>{cat.product_count}</TableCell>
                                            <TableCell>
                                                <div className="flex items-center gap-2">
                                                    <Button variant="ghost" size="icon" onClick={() => setCategoryToEdit(cat)}>
                                                        <Edit size={14} />
                                                    </Button>
                                                    <Button variant="ghost" size="icon" className="text-destructive" onClick={() => setCategoryToDelete(cat)}>
                                                        <Trash2 size={14} />
                                                    </Button>
                                                </div>
                                            </TableCell>
                                        </TableRow>
                                    ))}
                                </TableBody>
                            </Table>
                        </div>
                    )}
                </CardContent>
            </Card>
            
            {categoryToEdit && (
                <EditProductCategoryModal
                    category={categoryToEdit}
                    onClose={() => setCategoryToEdit(null)}
                    onSave={handleSave}
                />
            )}
            
            {categoryToDelete && (
                <ConfirmationModal
                    title="Xác nhận xóa danh mục"
                    message={`Bạn có chắc muốn xóa danh mục "${categoryToDelete.name}"? Tất cả sản phẩm thuộc danh mục này sẽ bị ảnh hưởng.`}
                    isDestructive
                    onConfirm={handleDelete}
                    onCancel={() => setCategoryToDelete(null)}
                />
            )}
        </>
    );
}
