import { useState, useEffect } from 'react';
import { toast } from 'sonner';
import { TopUser, ApiError } from '../types';
import apiClient from '../services/apiClient';
import { formatCurrency, formatApiErrorForToast } from '../utils';
import { usePageTitle } from '../contexts/PageTitleContext';
import { useLanguage } from '../contexts/LanguageContext';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Spinner } from '@/components/ui/spinner';
import { Trophy, Medal, Award } from 'lucide-react';

export default function TopNapPage() {
    const { t } = useLanguage();
    usePageTitle(t('sidebar.topUpLeaderboard', { defaultValue: 'Top Nạp Tiền' }));

    const [topUsers, setTopUsers] = useState<TopUser[]>([]);
    const [isLoading, setIsLoading] = useState(true);

    useEffect(() => {
        const fetchTopUsers = async () => {
            setIsLoading(true);
            try {
                const response = await apiClient.get('/users/top-depositors');
                setTopUsers(response.data);
            } catch (error) {
                toast.error(formatApiErrorForToast(error as ApiError, 'Không thể tải bảng xếp hạng.'));
            } finally {
                setIsLoading(false);
            }
        };
        fetchTopUsers();
    }, []);

    const getRankIcon = (rank: number) => {
        if (rank === 1) return <Trophy className="text-yellow-400" />;
        if (rank === 2) return <Medal className="text-gray-400" />;
        if (rank === 3) return <Award className="text-yellow-600" />;
        return <span className="text-sm font-bold">{rank}</span>;
    };

    return (
        <Card>
            <CardHeader>
                <CardTitle className="flex items-center gap-2">
                    <span className="text-xl">🏆</span>
                    {t('sidebar.topUpLeaderboard', { defaultValue: 'Top Nạp Tiền' })}
                </CardTitle>
            </CardHeader>
            <CardContent>
                {isLoading ? (
                    <div className="flex justify-center p-6"><Spinner /></div>
                ) : topUsers.length > 0 ? (
                    <ul className="space-y-4">
                        {topUsers.map(user => (
                            <li key={user.rank} className="flex items-center gap-4 p-3 bg-muted/50 rounded-lg">
                                <div className="flex items-center justify-center w-8 font-bold">{getRankIcon(user.rank)}</div>
                                <img src={user.avatar} alt={user.name} className="w-12 h-12 rounded-full" />
                                <div className="flex-1">
                                    <p className="font-semibold">{user.name}</p>
                                    <p className="text-sm font-bold text-green-500">{formatCurrency(user.amount)}</p>
                                </div>
                            </li>
                        ))}
                    </ul>
                ) : (
                    <div className="p-6 text-center text-muted-foreground">
                        <p>Chưa có dữ liệu để hiển thị bảng xếp hạng.</p>
                    </div>
                )}
            </CardContent>
        </Card>
    );
}