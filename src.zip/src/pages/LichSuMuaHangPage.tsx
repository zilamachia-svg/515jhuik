import { useState, useEffect, useCallback } from 'react';
import { motion } from 'framer-motion';
import { toast } from 'sonner';
import { Order, ApiError } from '../types';
import apiClient from '../services/apiClient';
import { formatCurrency, formatApiErrorForToast } from '../utils';
import { usePageTitle } from '../contexts/PageTitleContext';
import { useLanguage } from '../contexts/LanguageContext';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Pagination } from '@/components/Pagination';
import { TableSkeleton } from '../components/skeletons/TableSkeleton';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { FileText, Clock, Users, Star, Trash2, Search, Filter, ArrowUpDown, Cloud, Upload, ShoppingBag, Eye, Download, Copy, Check } from 'lucide-react';
import { Link } from 'react-router-dom';
import { PATHS } from '../constants/paths';
import { BannerContent } from '../components/BannerContent';
import { UserOrderDetailModal } from '../components/UserOrderDetailModal';
import { useCopyToClipboard } from '../hooks/useCopyToClipboard';
import {
    AlertDialog,
    AlertDialogAction,
    AlertDialogCancel,
    AlertDialogContent,
    AlertDialogDescription,
    AlertDialogFooter,
    AlertDialogHeader,
    AlertDialogTitle,
} from '@/components/ui/alert-dialog';

const ITEMS_PER_PAGE = 10;

export default function LichSuMuaHangPage() {
    const { t } = useLanguage();
    usePageTitle(t('sidebar.purchaseHistory'));

    const [orders, setOrders] = useState<Order[]>([]);
    const [isLoading, setIsLoading] = useState(true);
    const [currentPage, setCurrentPage] = useState(1);
    const [totalPages, setTotalPages] = useState(1);
    const [totalItems, setTotalItems] = useState(0);
    const [activeFilter, setActiveFilter] = useState<'all' | 'recent' | 'shared' | 'favorites'>('all');
    const [searchQuery, setSearchQuery] = useState('');
    const [orderToView, setOrderToView] = useState<Order | null>(null);
    const [orderToDelete, setOrderToDelete] = useState<Order | null>(null);
    const [copiedOrderId, setCopiedOrderId] = useState<string | null>(null);
    const [copy] = useCopyToClipboard();

    const fetchOrders = useCallback(async (page: number) => {
        setIsLoading(true);
        try {
            const response = await apiClient.get('/orders', {
                params: { page, limit: ITEMS_PER_PAGE },
            });
            setOrders(response.data.data);
            setTotalPages(response.data.totalPages);
            setTotalItems(response.data.totalItems);
            setCurrentPage(response.data.currentPage);
        } catch (error) {
            toast.error(formatApiErrorForToast(error as ApiError, 'Không thể tải lịch sử mua hàng.'));
        } finally {
            setIsLoading(false);
        }
    }, []);

    useEffect(() => {
        fetchOrders(currentPage);
    }, [fetchOrders, currentPage]);

    const handlePageChange = (page: number) => {
        setCurrentPage(page);
    };

    // Filter orders based on active filter
    const filteredOrders = orders.filter(order => {
        if (searchQuery && !order.productName.toLowerCase().includes(searchQuery.toLowerCase())) {
            return false;
        }
        
        // Apply filter based on activeFilter
        if (activeFilter === 'recent') {
            const orderDate = new Date(order.purchaseDate);
            const daysDiff = (Date.now() - orderDate.getTime()) / (1000 * 60 * 60 * 24);
            return daysDiff <= 7; // Last 7 days
        }
        // Note: 'shared' and 'favorites' filters would need additional data from API
        // For now, they just show all orders
        
        return true;
    });

    const getOrderIcon = (productName: string) => {
        if (productName.toLowerCase().includes('facebook')) return <FileText className="h-5 w-5 text-blue-500" />;
        if (productName.toLowerCase().includes('instagram')) return <FileText className="h-5 w-5 text-pink-500" />;
        if (productName.toLowerCase().includes('tiktok')) return <FileText className="h-5 w-5 text-black" />;
        return <FileText className="h-5 w-5 text-violet-500" />;
    };

    const handleDownloadOrder = async (order: Order) => {
        try {
            const response = await apiClient.get(`/orders/${order.id}/download`, {
                responseType: 'text',
            });
            
            const orderData = typeof response.data === 'string' 
                ? response.data 
                : `Đơn hàng #${order.id}\nSản phẩm: ${order.productName}\nSố lượng: ${order.quantity}\nTổng tiền: ${formatCurrency(order.totalPrice)}\nNgày mua: ${new Date(order.purchaseDate).toLocaleString('vi-VN')}`;
            
            const blob = new Blob([orderData], { type: 'text/plain;charset=utf-8' });
            const url = URL.createObjectURL(blob);
            const link = document.createElement('a');
            link.href = url;
            link.setAttribute('download', `don-hang-${order.id}.txt`);
            document.body.appendChild(link);
            link.click();
            document.body.removeChild(link);
            URL.revokeObjectURL(url);
            toast.success('Đã bắt đầu tải xuống!');
        } catch (error) {
            // Fallback: create file from order info
            const orderData = `Đơn hàng #${order.id}\nSản phẩm: ${order.productName}\nSố lượng: ${order.quantity}\nTổng tiền: ${formatCurrency(order.totalPrice)}\nNgày mua: ${new Date(order.purchaseDate).toLocaleString('vi-VN')}\nTrạng thái: ${order.status}`;
            const blob = new Blob([orderData], { type: 'text/plain;charset=utf-8' });
            const url = URL.createObjectURL(blob);
            const link = document.createElement('a');
            link.href = url;
            link.setAttribute('download', `don-hang-${order.id}.txt`);
            document.body.appendChild(link);
            link.click();
            document.body.removeChild(link);
            URL.revokeObjectURL(url);
            toast.success('Đã tải xuống thông tin đơn hàng!');
        }
    };

    const handleCopyOrder = async (order: Order) => {
        try {
            const response = await apiClient.get(`/orders/${order.id}`);
            const orderDetails = response.data.order || response.data;
            
            let orderData = '';
            if (orderDetails.items && orderDetails.items.length > 0) {
                orderData = orderDetails.items.map((item: { data: string }) => item.data).join('\n');
            } else {
                orderData = `Đơn hàng #${order.id}\nSản phẩm: ${order.productName}\nSố lượng: ${order.quantity}\nTổng tiền: ${formatCurrency(order.totalPrice)}\nNgày mua: ${new Date(order.purchaseDate).toLocaleString('vi-VN')}`;
            }
            
            copy(orderData, 'Đã sao chép dữ liệu đơn hàng!');
            setCopiedOrderId(order.id);
            setTimeout(() => setCopiedOrderId(null), 2000);
        } catch (error) {
            // Fallback: copy order info
            const orderData = `Đơn hàng #${order.id}\nSản phẩm: ${order.productName}\nSố lượng: ${order.quantity}\nTổng tiền: ${formatCurrency(order.totalPrice)}\nNgày mua: ${new Date(order.purchaseDate).toLocaleString('vi-VN')}`;
            copy(orderData, 'Đã sao chép thông tin đơn hàng!');
            setCopiedOrderId(order.id);
            setTimeout(() => setCopiedOrderId(null), 2000);
        }
    };

    const handleDeleteOrder = async () => {
        if (!orderToDelete) return;
        
        try {
            await apiClient.delete(`/orders/${orderToDelete.id}`);
            toast.success('Đã xóa đơn hàng thành công!');
            setOrderToDelete(null);
            // Refresh orders list
            fetchOrders(currentPage);
        } catch (error) {
            toast.error(formatApiErrorForToast(error as ApiError, 'Không thể xóa đơn hàng.'));
        }
    };

    return (
        <div className="space-y-8">
            {/* Banner Section */}
            <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5 }}
                className="overflow-hidden rounded-3xl bg-gradient-to-r from-blue-400/85 via-cyan-400/85 to-teal-400/85 p-8 text-white"
            >
                <div className="flex flex-col gap-6 md:flex-row md:items-center md:justify-between">
                    <div className="space-y-2">
                        <h2 className="text-3xl font-bold flex items-center gap-3">
                            <span className="text-3xl">📋</span>
                            Lịch sử mua hàng của bạn
                        </h2>
                        <p className="max-w-[600px] text-white/80">
                            Xem, quản lý và theo dõi tất cả các đơn hàng của bạn ở một nơi.
                        </p>
                    </div>
                    <div className="flex flex-wrap gap-3">
                        <Button className="rounded-2xl bg-white text-cyan-700 hover:bg-white/90" asChild>
                            <Link to={PATHS.DEPOSIT}>
                                <Cloud className="mr-2 h-4 w-4" />
                                Nạp tiền
                            </Link>
                        </Button>
                        <Button
                            variant="outline"
                            className="rounded-2xl bg-transparent border-white text-white hover:bg-white/10"
                            asChild
                        >
                            <Link to={PATHS.STORE}>
                                <Upload className="mr-2 h-4 w-4" />
                                Mua thêm
                            </Link>
                        </Button>
                    </div>
                </div>
                <BannerContent />
            </motion.div>

            {/* Filter Buttons */}
            <div className="flex flex-wrap items-center gap-3">
                <Button
                    variant={activeFilter === 'all' ? 'default' : 'outline'}
                    className="rounded-2xl"
                    onClick={() => setActiveFilter('all')}
                >
                    <FileText className="mr-2 h-4 w-4" />
                    Tất cả đơn hàng
                </Button>
                <Button
                    variant={activeFilter === 'recent' ? 'default' : 'outline'}
                    className="rounded-2xl"
                    onClick={() => setActiveFilter('recent')}
                >
                    <Clock className="mr-2 h-4 w-4" />
                    Gần đây
                </Button>
                <Button
                    variant={activeFilter === 'shared' ? 'default' : 'outline'}
                    className="rounded-2xl"
                    onClick={() => setActiveFilter('shared')}
                >
                    <Users className="mr-2 h-4 w-4" />
                    Đã chia sẻ
                </Button>
                <Button
                    variant={activeFilter === 'favorites' ? 'default' : 'outline'}
                    className="rounded-2xl"
                    onClick={() => setActiveFilter('favorites')}
                >
                    <Star className="mr-2 h-4 w-4" />
                    Yêu thích
                </Button>
                <div className="flex-1"></div>
                <div className="relative w-full md:w-auto">
                    <Search className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                    <Input
                        type="search"
                        placeholder="Tìm kiếm đơn hàng..."
                        className="w-full rounded-2xl pl-9 md:w-[250px]"
                        value={searchQuery}
                        onChange={(e) => setSearchQuery(e.target.value)}
                    />
                </div>
                <Button 
                    variant="outline" 
                    className="rounded-2xl"
                    onClick={() => toast.info('Tính năng lọc nâng cao đang được phát triển')}
                >
                    <Filter className="mr-2 h-4 w-4" />
                    Lọc
                </Button>
                <Button 
                    variant="outline" 
                    className="rounded-2xl"
                    onClick={() => toast.info('Tính năng sắp xếp đang được phát triển')}
                >
                    <ArrowUpDown className="mr-2 h-4 w-4" />
                    Sắp xếp
                </Button>
            </div>

            {/* Orders Table */}
            <Card className="rounded-3xl">
                <CardHeader>
                    <CardTitle>Tất cả đơn hàng</CardTitle>
                </CardHeader>
                <CardContent>
                {isLoading && !orders.length ? (
                    <TableSkeleton headers={['Tên', 'Loại', 'Số lượng', 'Tổng tiền', 'Ngày mua']} />
                ) : filteredOrders.length > 0 ? (
                    <>
                        <div className="w-full overflow-auto rounded-2xl border">
                            <Table>
                                <TableHeader>
                                    <TableRow>
                                        <TableHead>Tên</TableHead>
                                        <TableHead>Loại</TableHead>
                                        <TableHead>Số lượng</TableHead>
                                        <TableHead>Tổng tiền</TableHead>
                                        <TableHead>Ngày mua</TableHead>
                                        <TableHead className="text-right">Thao tác</TableHead>
                                    </TableRow>
                                </TableHeader>
                                <TableBody>
                                    {filteredOrders.map(order => (
                                        <TableRow
                                            key={order.id}
                                            className="border-b transition-colors hover:bg-muted/50"
                                        >
                                            <TableCell>
                                                <div className="flex items-center gap-3">
                                                    <div className="flex h-10 w-10 items-center justify-center rounded-2xl bg-muted">
                                                        {getOrderIcon(order.productName)}
                                                    </div>
                                                    <div>
                                                        <p className="font-medium">{order.productName}</p>
                                                        <p className="text-sm text-muted-foreground">
                                                            {order.status === 'Đã hoàn thành' && 'Đã hoàn thành'}
                                                        </p>
                                                    </div>
                                                </div>
                                            </TableCell>
                                            <TableCell>
                                                <Badge variant="outline" className="rounded-xl">
                                                    Tài khoản
                                                </Badge>
                                            </TableCell>
                                            <TableCell>{order.quantity}</TableCell>
                                            <TableCell className="font-semibold">{formatCurrency(order.totalPrice)}</TableCell>
                                            <TableCell>
                                                <div>
                                                    <p>{new Date(order.purchaseDate).toLocaleDateString('vi-VN')}</p>
                                                    <p className="text-sm text-muted-foreground">
                                                        {new Date(order.purchaseDate).toLocaleTimeString('vi-VN', { hour: '2-digit', minute: '2-digit' })}
                                                    </p>
                                                </div>
                                            </TableCell>
                                            <TableCell>
                                                <div className="flex items-center justify-end gap-2">
                                                    <Button
                                                        variant="ghost"
                                                        size="icon"
                                                        className="h-8 w-8 rounded-xl"
                                                        onClick={() => setOrderToView(order)}
                                                        title="Xem chi tiết"
                                                    >
                                                        <Eye className="h-4 w-4" />
                                                    </Button>
                                                    <Button
                                                        variant="ghost"
                                                        size="icon"
                                                        className="h-8 w-8 rounded-xl"
                                                        onClick={() => handleDownloadOrder(order)}
                                                        title="Tải về"
                                                    >
                                                        <Download className="h-4 w-4" />
                                                    </Button>
                                                    <Button
                                                        variant="ghost"
                                                        size="icon"
                                                        className="h-8 w-8 rounded-xl"
                                                        onClick={() => handleCopyOrder(order)}
                                                        title="Sao chép"
                                                    >
                                                        {copiedOrderId === order.id ? <Check className="h-4 w-4" /> : <Copy className="h-4 w-4" />}
                                                    </Button>
                                                    <Button
                                                        variant="ghost"
                                                        size="icon"
                                                        className="h-8 w-8 rounded-xl text-destructive hover:text-destructive hover:bg-destructive/10"
                                                        onClick={() => setOrderToDelete(order)}
                                                        title="Xóa đơn hàng"
                                                    >
                                                        <Trash2 className="h-4 w-4" />
                                                    </Button>
                                                </div>
                                            </TableCell>
                                        </TableRow>
                                    ))}
                                </TableBody>
                            </Table>
                        </div>
                        {totalPages > 1 && (
                            <div className="mt-6">
                                <Pagination
                                    currentPage={currentPage}
                                    totalPages={totalPages}
                                    totalItems={totalItems}
                                    itemsPerPage={ITEMS_PER_PAGE}
                                    onPageChange={handlePageChange}
                                />
                            </div>
                        )}
                    </>
                ) : (
                    <div className="text-center p-12">
                        <FileText className="mx-auto h-12 w-12 text-muted-foreground mb-4" />
                        <p className="text-muted-foreground">Bạn chưa có đơn hàng nào.</p>
                        <Button className="mt-4 rounded-2xl" asChild>
                            <Link to={PATHS.STORE}>Mua ngay</Link>
                        </Button>
                    </div>
                )}
                </CardContent>
            </Card>

            {/* Order Detail Modal */}
            {orderToView && (
                <UserOrderDetailModal
                    order={orderToView}
                    onClose={() => setOrderToView(null)}
                />
            )}

            {/* Delete Confirmation Dialog */}
            <AlertDialog open={!!orderToDelete} onOpenChange={(open) => !open && setOrderToDelete(null)}>
                <AlertDialogContent className="rounded-3xl">
                    <AlertDialogHeader>
                        <AlertDialogTitle>Xác nhận xóa đơn hàng</AlertDialogTitle>
                        <AlertDialogDescription>
                            Bạn có chắc chắn muốn xóa đơn hàng <strong>#{orderToDelete?.id}</strong> - <strong>{orderToDelete?.productName}</strong>? 
                            Hành động này không thể hoàn tác.
                        </AlertDialogDescription>
                    </AlertDialogHeader>
                    <AlertDialogFooter>
                        <AlertDialogCancel className="rounded-xl">Hủy</AlertDialogCancel>
                        <AlertDialogAction
                            onClick={handleDeleteOrder}
                            className="rounded-xl bg-destructive hover:bg-destructive/90"
                        >
                            Xóa
                        </AlertDialogAction>
                    </AlertDialogFooter>
                </AlertDialogContent>
            </AlertDialog>
        </div>
    );
}