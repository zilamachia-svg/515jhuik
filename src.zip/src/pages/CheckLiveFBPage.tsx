import { useState, useEffect } from 'react';
import { toast } from 'sonner';
import { usePageTitle } from '../contexts/PageTitleContext';
import { useLanguage } from '../contexts/LanguageContext';
import apiClient from '../services/apiClient';
import { ApiError } from '../types';
import { formatApiErrorForToast } from '../utils';
import { Card, CardHeader, CardTitle, CardContent, CardFooter } from '@/components/ui/card';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Button } from '@/components/ui/button';
import { Spinner } from '@/components/ui/spinner';
import * as TabsPrimitive from '@radix-ui/react-tabs';

const Tabs = TabsPrimitive.Root;
const TabsList = TabsPrimitive.List;
const TabsTrigger = TabsPrimitive.Trigger;
const TabsContent = TabsPrimitive.Content;
import * as React from "react";
import * as ProgressPrimitive from '@radix-ui/react-progress';
import { cn } from "@/lib/utils";

const Progress = React.forwardRef<
  React.ElementRef<typeof ProgressPrimitive.Root>,
  React.ComponentPropsWithoutRef<typeof ProgressPrimitive.Root>
>(({ className, value, ...props }, ref) => (
  <ProgressPrimitive.Root
    ref={ref}
    className={cn("relative h-4 w-full overflow-hidden rounded-full bg-secondary", className)}
    {...props}
  >
    <ProgressPrimitive.Indicator
      className="h-full w-full flex-1 bg-primary transition-all"
      style={{ transform: `translateX(-${100 - (value || 0)}%)` }}
    />
  </ProgressPrimitive.Root>
));

Progress.displayName = 'Progress';

import { Badge } from '@/components/ui/badge';
import { Zap, Copy, Check, AlertCircle, RefreshCw, Download } from 'lucide-react';
import { useCopyToClipboard } from '../hooks/useCopyToClipboard';
import { motion } from 'framer-motion';

type CheckResult = {
    uid: string;
    status: 'Live' | 'Die';
};

type CheckStats = {
    total: number;
    live: number;
    die: number;
    liveRate: number;
};

export default function CheckLiveFBPage() {
    const { t } = useLanguage();
    usePageTitle(t('sidebar.checkLiveFB'));

    const [uids, setUids] = useState('');
    const [liveUids, setLiveUids] = useState<string[]>([]);
    const [dieUids, setDieUids] = useState<string[]>([]);
    const [stats, setStats] = useState<CheckStats | null>(null);
    const [isLoading, setIsLoading] = useState(false);
    const [progress, setProgress] = useState(0);
    const [activeTab, setActiveTab] = useState<'input' | 'results'>('input');
    
    const [copyLive, isLiveCopied] = useCopyToClipboard();
    const [copyDie, isDieCopied] = useCopyToClipboard();

    type TabValue = 'input' | 'results';
    const handleTabChange = (value: string) => {
        setActiveTab(value as TabValue);
    };

    // Reset progress when not loading
    useEffect(() => {
        if (!isLoading) {
            setProgress(0);
        }
    }, [isLoading]);

    const handleCheck = async () => {
        // Clean and validate input
        // Accept raw UIDs or URLs. Extract numeric IDs found in input.
        const uidList = uids
            .split('\n')
            .map(line => line.trim())
            .map(line => {
                // If it's a full URL (facebook.com/...), try to extract the id param or last numeric segment
                try {
                    const url = new URL(line);
                    // example: /profile.php?id=123 or /123456789
                    const idParam = url.searchParams.get('id');
                    if (idParam && /^\d+$/.test(idParam)) return idParam;
                    const parts = url.pathname.split('/').filter(Boolean);
                    const last = parts[parts.length - 1];
                    if (/^\d+$/.test(last)) return last;
                } catch {
                    // not a URL, continue
                }

                // If line contains numeric substrings, pick the longest numeric sequence
                const match = line.match(/(\d{6,})/g);
                if (match && match.length) {
                    // choose the longest match
                    return match.reduce((a, b) => (a.length > b.length ? a : b));
                }

                return line;
            })
            .map(uid => uid.replace(/\D/g, ''))
            .filter(uid => /^\d{6,}$/.test(uid)); // ensure reasonable length

        if (uidList.length === 0) {
            toast.warning('Vui lòng nhập danh sách UID hợp lệ.');
            return;
        }

        setIsLoading(true);
        setLiveUids([]);
        setDieUids([]);
        setStats(null);
        setActiveTab('results');

        try {
            // Process in batches of 100 UIDs
            const batchSize = 100;
            // const totalBatches = Math.ceil(uidList.length / batchSize); // Not used in current logic
            const live: string[] = [];
            const die: string[] = [];

            for (let i = 0; i < uidList.length; i += batchSize) {
                const batch = uidList.slice(i, i + batchSize);
                const response = await apiClient.post('/tools/check-live-fb', { uids: batch });
                const results: CheckResult[] = response.data.results;
                
                results.forEach(result => {
                    if (result.status === 'Live') {
                        live.push(result.uid);
                    } else {
                        die.push(result.uid);
                    }
                });

                // Update progress
                const progress = Math.min(((i + batchSize) / uidList.length) * 100, 100);
                setProgress(progress);
            }

            // Update final results
            setLiveUids(live);
            setDieUids(die);
            setStats({
                total: uidList.length,
                live: live.length,
                die: uidList.length - live.length,
                liveRate: uidList.length > 0 ? (live.length / uidList.length) * 100 : 0
            });

            toast.success(`Đã kiểm tra xong ${uidList.length} UID.`);

            // Update final results
            setLiveUids(live);
            setDieUids(die);
            
            const total = uidList.length;
            const liveCount = live.length;
            setStats({
                total: total,
                live: liveCount,
                die: total - liveCount,
                liveRate: total > 0 ? (liveCount / total) * 100 : 0
            });

            toast.success(`Đã kiểm tra xong ${uidList.length} UID.`);

        } catch (error) {
            toast.error(formatApiErrorForToast(error as ApiError, 'Kiểm tra thất bại.'));
        } finally {
            setIsLoading(false);
            setProgress(100);
        }
    };

    return (
        <Card>
            <CardHeader>
                <CardTitle className="flex items-center gap-2">
                    <span>{t('sidebar.checkLiveFB')}</span>
                    {isLoading && (
                        <RefreshCw className="w-4 h-4 animate-spin text-muted-foreground" />
                    )}
                </CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
                <Tabs value={activeTab} onValueChange={handleTabChange}>
                    <TabsList className="grid w-full grid-cols-2">
                        <TabsTrigger value="input">Nhập UID</TabsTrigger>
                        <TabsTrigger value="results">Kết quả</TabsTrigger>
                    </TabsList>

                    <TabsContent value="input" className="space-y-4">
                        <div className="space-y-2">
                            <Label htmlFor="uids-input" className="flex items-center gap-2">
                                Danh sách UID (mỗi UID một dòng)
                                <AlertCircle className="w-4 h-4 text-muted-foreground" />
                            </Label>
                            <Textarea
                                id="uids-input"
                                value={uids}
                                onChange={(e) => setUids(e.target.value)}
                                rows={10}
                                placeholder="10000123456789..."
                                disabled={isLoading}
                                className="font-mono"
                            />
                        </div>
                
                        {isLoading && (
                            <div className="space-y-2">
                                <div className="flex items-center justify-between text-sm">
                                    <span className="text-muted-foreground">Đang kiểm tra...</span>
                                    <span className="font-medium">{Math.round(progress)}%</span>
                                </div>
                                <Progress value={progress} className="h-2" />
                            </div>
                        )}
                    </TabsContent>

                    <TabsContent value="results" className="space-y-4">
                        {stats && (
                            <motion.div
                                initial={{ opacity: 0, y: 20 }}
                                animate={{ opacity: 1, y: 0 }}
                                transition={{ duration: 0.3 }}
                            >
                                <Card className="bg-muted/50">
                                    <CardContent className="p-4 grid grid-cols-2 md:grid-cols-4 gap-4 text-center">
                                        <motion.div
                                            initial={{ scale: 0 }}
                                            animate={{ scale: 1 }}
                                            transition={{ delay: 0.1 }}
                                        >
                                            <p className="text-sm text-muted-foreground">Tổng kiểm tra</p>
                                            <p className="text-2xl font-bold">{stats.total}</p>
                                        </motion.div>
                                        <motion.div
                                            initial={{ scale: 0 }}
                                            animate={{ scale: 1 }}
                                            transition={{ delay: 0.2 }}
                                        >
                                            <p className="text-sm text-muted-foreground">Live</p>
                                            <Badge variant="default" className="text-2xl font-bold px-3 py-1 bg-green-500 hover:bg-green-600">
                                                {stats.live}
                                            </Badge>
                                        </motion.div>
                                        <motion.div
                                            initial={{ scale: 0 }}
                                            animate={{ scale: 1 }}
                                            transition={{ delay: 0.3 }}
                                        >
                                            <p className="text-sm text-muted-foreground">Die</p>
                                            <Badge variant="destructive" className="text-2xl font-bold px-3 py-1">
                                                {stats.die}
                                            </Badge>
                                        </motion.div>
                                        <motion.div
                                            initial={{ scale: 0 }}
                                            animate={{ scale: 1 }}
                                            transition={{ delay: 0.4 }}
                                        >
                                            <p className="text-sm text-muted-foreground">Tỉ lệ Live</p>
                                            <Badge variant="default" className="text-2xl font-bold px-3 py-1">
                                                {stats.liveRate.toFixed(2)}%
                                            </Badge>
                                        </motion.div>
                                    </CardContent>
                                </Card>
                            </motion.div>
                        )}

                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                            <Card>
                                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                                    <CardTitle className="text-base font-medium">
                                        UID Live ({liveUids.length})
                                    </CardTitle>
                                    <div className="flex gap-2">
                                        <Button 
                                            variant="ghost" 
                                            size="icon"
                                            onClick={() => {
                                                const blob = new Blob([liveUids.join('\n')], { type: 'text/plain' });
                                                const url = window.URL.createObjectURL(blob);
                                                const a = document.createElement('a');
                                                a.href = url;
                                                a.download = 'live_uids.txt';
                                                a.click();
                                            }}
                                        >
                                            <Download size={16} />
                                        </Button>
                                        <Button 
                                            variant="ghost" 
                                            size="icon" 
                                            onClick={() => copyLive(liveUids.join('\n'), 'Đã sao chép UID Live!')}
                                        >
                                            {isLiveCopied ? <Check size={16}/> : <Copy size={16} />}
                                        </Button>
                                    </div>
                                </CardHeader>
                                <CardContent>
                                    <Textarea
                                        readOnly
                                        value={liveUids.join('\n')}
                                        rows={10}
                                        className="font-mono bg-green-50/50 dark:bg-green-900/20 focus-visible:ring-green-500"
                                    />
                                </CardContent>
                            </Card>
                            <Card>
                                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                                    <CardTitle className="text-base font-medium">
                                        UID Die ({dieUids.length})
                                    </CardTitle>
                                    <div className="flex gap-2">
                                        <Button 
                                            variant="ghost" 
                                            size="icon"
                                            onClick={() => {
                                                const blob = new Blob([dieUids.join('\n')], { type: 'text/plain' });
                                                const url = window.URL.createObjectURL(blob);
                                                const a = document.createElement('a');
                                                a.href = url;
                                                a.download = 'die_uids.txt';
                                                a.click();
                                            }}
                                        >
                                            <Download size={16} />
                                        </Button>
                                        <Button 
                                            variant="ghost" 
                                            size="icon" 
                                            onClick={() => copyDie(dieUids.join('\n'), 'Đã sao chép UID Die!')}
                                        >
                                            {isDieCopied ? <Check size={16}/> : <Copy size={16} />}
                                        </Button>
                                    </div>
                                </CardHeader>
                                <CardContent>
                                    <Textarea
                                        readOnly
                                        value={dieUids.join('\n')}
                                        rows={10}
                                        className="font-mono bg-red-50/50 dark:bg-red-900/20 focus-visible:ring-red-500"
                                    />
                                </CardContent>
                            </Card>
                        </div>
                    </TabsContent>
                </Tabs>
            </CardContent>
            <CardFooter>
                <Button 
                    onClick={handleCheck} 
                    disabled={isLoading} 
                    className="w-full" 
                    size="lg"
                >
                    {isLoading ? (
                        <>
                            <Spinner className="mr-2 h-4 w-4" />
                            Đang kiểm tra...
                        </>
                    ) : (
                        <>
                            <Zap size={16} className="mr-2" />
                            Bắt đầu kiểm tra
                        </>
                    )}
                </Button>
            </CardFooter>
        </Card>
    );
}