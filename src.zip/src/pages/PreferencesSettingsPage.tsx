import { useLanguage } from '../contexts/LanguageContext';
import { LanguageCode } from '../locales/config';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';

export default function PreferencesSettingsPage() {
    const { t, language, setLanguage, availableLanguages } = useLanguage();

    return (
        <Card>
            <CardHeader>
                <CardTitle>{t('settings.preferences.title')}</CardTitle>
            </CardHeader>
            <CardContent>
                <div className="space-y-6">
                    {/* Dark mode toggle removed - always light mode */}
                    <div className="flex items-center justify-between">
                        <Label htmlFor="language-select">Ngôn ngữ</Label>
                        <Select
                            value={language}
                            onValueChange={(value) => setLanguage(value as LanguageCode)}
                        >
                            <SelectTrigger id="language-select" className="w-[180px]">
                                <SelectValue placeholder="Chọn ngôn ngữ" />
                            </SelectTrigger>
                            <SelectContent>
                                {availableLanguages.map((lang) => (
                                    <SelectItem key={lang.code} value={lang.code}>
                                        {lang.name}
                                    </SelectItem>
                                ))}
                            </SelectContent>
                        </Select>
                    </div>
                    {/* Add other preferences here */}
                </div>
            </CardContent>
        </Card>
    );
}
