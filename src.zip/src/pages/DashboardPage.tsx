import React, { Suspense } from 'react';
import { motion } from 'framer-motion';
import { usePageTitle } from '../contexts/PageTitleContext';
import { useLanguage } from '../contexts/LanguageContext';
import { useUser } from '../services/UserContext';
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { DollarSign, ShoppingCart, Users, HandCoins, Store, FileText, Package, TrendingUp, ArrowRight, Star, Clock, Eye, BarChart3, Activity, Sparkles } from 'lucide-react';
const SpendingChart = React.lazy(() => import('../components/SpendingChart').then(m => ({ default: m.SpendingChart })));
const LiveActivityFeed = React.lazy(() => import('../components/LiveActivityFeed').then(m => ({ default: m.LiveActivityFeed })));
import { TestimonialCard } from '../components/TestimonialCard';
import { mockTestimonials, mockDashboardData, mockOrders, mockAffiliateStats } from '../assets/api/mockData';
import { formatCurrency } from '../utils';
import { Link } from 'react-router-dom';
import { PATHS } from '../constants/paths';

export default function DashboardPage() {
    const { t } = useLanguage();
    usePageTitle(t('pageTitles.home'));
    const { user } = useUser();

    // Use mock data for demonstration
    const { revenueLast7Days } = mockDashboardData;
    const totalSpent = mockOrders.reduce((sum, order) => sum + order.totalPrice, 0);

    // Stats cards - moved below charts
    const statCards = [
        { icon: <DollarSign className="h-5 w-5 text-primary" />, label: 'Số dư của bạn', value: formatCurrency(user?.balance ?? 0), color: 'text-green-600' },
        { icon: <ShoppingCart className="h-5 w-5 text-primary" />, label: 'Tổng đơn hàng', value: mockOrders.length, color: 'text-blue-600' },
        { icon: <HandCoins className="h-5 w-5 text-primary" />, label: 'Đã chi tiêu', value: formatCurrency(totalSpent), color: 'text-orange-600' },
    ];

    // Featured products with detailed descriptions
    const featuredProducts = [
        {
            id: 'prod_1',
            name: 'VIA US Cổ',
            description: 'Tài khoản VIA US cổ, trust cao, phù hợp chạy quảng cáo. Tài khoản đã được verify và có lịch sử hoạt động tốt.',
            price: 50000,
            stock: 150,
            country: 'US',
            category: 'VIA',
            icon: <Store className="h-5 w-5" />,
            features: ['Trust cao', 'Đã verify', 'Sẵn sàng sử dụng'],
        },
        {
            id: 'prod_2',
            name: 'Clone Philippines',
            description: 'Tài khoản clone profile thật, tương tác tốt, dùng để seeding. Phù hợp cho các chiến dịch marketing.',
            price: 15000,
            stock: 2500,
            country: 'PH',
            category: 'Clone',
            icon: <Users className="h-5 w-5" />,
            features: ['Profile thật', 'Tương tác tốt', 'Giá rẻ'],
        },
        {
            id: 'prod_3',
            name: 'BM5 kháng',
            description: 'Business Manager 5 đã kháng, sẵn sàng cho chiến dịch lớn. Hỗ trợ quảng cáo với budget cao.',
            price: 750000,
            stock: 10,
            country: 'VN',
            category: 'BM',
            icon: <Package className="h-5 w-5" />,
            features: ['Đã kháng', 'Budget cao', 'Chuyên nghiệp'],
        },
    ];

    // Recent orders - compact table
    const recentOrders = mockOrders.slice(0, 5).map(order => ({
        id: order.id,
        productName: order.productName,
        totalPrice: order.totalPrice,
        purchaseDate: order.purchaseDate,
        status: order.status,
    }));

    // Mock active projects (orders in progress)
    const activeProjects = [
        {
            name: 'Đơn hàng gần đây',
            description: 'Các giao dịch và đơn hàng của bạn',
            progress: 100,
            dueDate: 'Hoàn thành',
            members: 1,
            files: mockOrders.length,
        },
        {
            name: 'Tài khoản đã mua',
            description: 'Danh sách tài khoản bạn đã sở hữu',
            progress: 85,
            dueDate: 'Đang sử dụng',
            members: 1,
            files: mockOrders.filter(o => o.status === 'Đã hoàn thành').length,
        },
    ];

    return (
        <div className="space-y-8">
            {/* Welcome Banner */}
            <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5 }}
                className="overflow-hidden rounded-3xl bg-gradient-to-r from-violet-400/85 via-indigo-400/85 to-blue-400/85 p-8 text-white dark:from-violet-500/70 dark:via-indigo-500/70 dark:to-blue-500/70"
            >
                <div className="flex flex-col gap-6 md:flex-row md:items-center md:justify-between">
                    <div className="space-y-4">
                        <Badge className="bg-white/20 text-white hover:bg-white/30 rounded-xl">Premium</Badge>
                        <h2 className="text-3xl font-bold">Chào mừng đến với Hải Đăng Meta</h2>
                        <p className="max-w-[600px] text-white/80">
                            Nền tảng dịch vụ meta hàng đầu Việt Nam - Nơi bạn tìm thấy giải pháp hoàn hảo cho nhu cầu của mình.
                        </p>
                        <div className="flex flex-wrap gap-3">
                            <Button asChild className="rounded-2xl bg-white text-indigo-700 hover:bg-white/90">
                                <Link to={PATHS.STORE}>Khám phá cửa hàng</Link>
                            </Button>
                            <Button
                                variant="outline"
                                className="rounded-2xl bg-transparent border-white text-white hover:bg-white/10"
                                asChild
                            >
                                <Link to={PATHS.DEPOSIT}>Nạp tiền ngay</Link>
                            </Button>
                        </div>
                    </div>
                    <div className="hidden lg:block">
                        <motion.div
                            animate={{ rotate: 360 }}
                            transition={{ duration: 50, repeat: Number.POSITIVE_INFINITY, ease: "linear" }}
                            className="relative h-40 w-40"
                        >
                            <div className="absolute inset-0 rounded-full bg-white/10 backdrop-blur-md" />
                            <div className="absolute inset-4 rounded-full bg-white/20" />
                            <div className="absolute inset-8 rounded-full bg-white/30" />
                            <div className="absolute inset-12 rounded-full bg-white/40" />
                            <div className="absolute inset-16 rounded-full bg-white/50" />
                        </motion.div>
                    </div>
                </div>
            </motion.div>

            {/* Charts and Statistics - Moved to top */}
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                <div className="lg:col-span-2">
                    <Card className="rounded-3xl">
                        <CardHeader>
                            <CardTitle className="flex items-center gap-2">
                                <span className="text-xl">📊</span>
                                Thống kê chi tiêu (7 ngày qua)
                            </CardTitle>
                        </CardHeader>
                        <CardContent>
                            <Suspense fallback={<div className="h-48 flex items-center justify-center">Đang tải biểu đồ...</div>}>
                                <SpendingChart data={revenueLast7Days} />
                            </Suspense>
                        </CardContent>
                    </Card>
                </div>
                <div>
                    <Card className="rounded-3xl">
                        <CardHeader>
                            <CardTitle className="flex items-center gap-2">
                                <span className="text-xl">🛍️</span>
                                Đơn hàng mới nhất
                            </CardTitle>
                        </CardHeader>
                            <CardContent className="p-0">
                            <div className="divide-y">
                                {recentOrders.slice(0, 5).map((order, index) => (
                                    <motion.div
                                        key={order.id}
                                        initial={{ opacity: 0, x: -20 }}
                                        animate={{ opacity: 1, x: 0 }}
                                        transition={{ duration: 0.3, delay: index * 0.05 }}
                                        className="flex items-center justify-between p-3 hover:bg-muted/50 transition-colors"
                                    >
                                        <div className="flex items-center gap-3 flex-1 min-w-0">
                                            <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-primary/10 text-primary">
                                                <ShoppingCart className="h-4 w-4" />
                                            </div>
                                            <div className="flex-1 min-w-0">
                                                <p className="font-medium text-sm truncate">{order.productName}</p>
                                                <p className="text-xs text-muted-foreground">
                                                    {new Date(order.purchaseDate).toLocaleDateString('vi-VN')}
                                                </p>
                                            </div>
                                        </div>
                                        <div className="flex items-center gap-2 ml-2">
                                            <span className="text-sm font-semibold text-primary">{formatCurrency(order.totalPrice)}</span>
                                            <Badge variant="outline" className="rounded-lg text-xs">{order.status}</Badge>
                                        </div>
                                    </motion.div>
                                ))}
                            </div>
                            <div className="p-3 border-t">
                                <Button variant="ghost" className="w-full rounded-xl" asChild>
                                    <Link to={PATHS.ORDERS_HISTORY}>
                                        Xem tất cả <ArrowRight className="ml-2 h-4 w-4" />
                                    </Link>
                                </Button>
                            </div>
                            </CardContent>
                    </Card>
                </div>
                    {/* Live activity feed lazy-loaded to reduce initial bundle */}
                    <div className="mt-6">
                        <Suspense fallback={<div className="h-32 flex items-center justify-center">Đang tải hoạt động...</div>}>
                            <LiveActivityFeed />
                        </Suspense>
                    </div>
            </div>

            {/* Stats Cards - Moved below charts */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                {statCards.map((card, index) => (
                    <motion.div
                        key={index}
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ duration: 0.3, delay: index * 0.1 }}
                        whileHover={{ scale: 1.02, y: -2 }}
                    >
                        <Card className="overflow-hidden rounded-2xl border-2 hover:border-primary/50 transition-all duration-300">
                            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                                <CardTitle className="text-sm font-medium">{card.label}</CardTitle>
                                <div className="rounded-xl bg-primary/10 p-2 text-primary">{card.icon}</div>
                            </CardHeader>
                            <CardContent>
                                <div className={`text-2xl font-bold ${card.color}`}>{card.value}</div>
                            </CardContent>
                        </Card>
                    </motion.div>
                ))}
            </div>

            {/* Featured Products Section */}
            <section className="space-y-4">
                <div className="flex items-center justify-between">
                    <h2 className="text-2xl font-semibold flex items-center gap-2">
                        <span className="text-2xl">⭐</span>
                        Sản phẩm nổi bật
                    </h2>
                    <Button variant="ghost" className="rounded-2xl" asChild>
                        <Link to={PATHS.STORE}>Xem tất cả <ArrowRight className="ml-2 h-4 w-4" /></Link>
                    </Button>
                </div>
                <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-3 md:gap-4">
                    {featuredProducts.map((product, index) => (
                        <motion.div
                            key={product.id}
                            initial={{ opacity: 0, y: 20 }}
                            animate={{ opacity: 1, y: 0 }}
                            transition={{ duration: 0.3, delay: index * 0.05 }}
                            whileHover={{ scale: 1.05, y: -3 }}
                        >
                            <Card className="h-full overflow-hidden rounded-2xl border-2 hover:border-primary/50 transition-all duration-300">
                                <CardHeader className="p-3 md:p-4">
                                    <div className="flex items-start justify-between mb-2">
                                        <div className="flex h-8 w-8 md:h-10 md:w-10 items-center justify-center rounded-xl bg-primary/10 text-primary text-sm">
                                            {product.icon}
                                        </div>
                                        <Badge variant="outline" className="rounded-lg text-[10px] px-1.5 py-0.5">
                                            {product.category}
                                        </Badge>
                                    </div>
                                    <CardTitle className="text-sm md:text-base line-clamp-2 leading-tight">{product.name}</CardTitle>
                                    <CardDescription className="mt-1.5 text-xs line-clamp-2">
                                        {product.description}
                                    </CardDescription>
                                </CardHeader>
                                <CardContent className="p-3 md:p-4 pt-0">
                                    <div className="space-y-2">
                                        <div className="flex items-center gap-1 flex-wrap">
                                            {product.features.slice(0, 2).map((feature, idx) => (
                                                <Badge key={idx} variant="secondary" className="rounded-md text-[9px] px-1 py-0">
                                                    {feature}
                                                </Badge>
                                            ))}
                                        </div>
                                        <div className="flex items-center justify-between pt-1.5 border-t">
                                            <div>
                                                <p className="text-[10px] text-muted-foreground">Giá</p>
                                                <p className="text-sm font-bold text-primary">{formatCurrency(product.price)}</p>
                                            </div>
                                            <div className="text-right">
                                                <p className="text-[10px] text-muted-foreground">Tồn</p>
                                                <p className="text-xs font-semibold">{product.stock}</p>
                                            </div>
                                        </div>
                                    </div>
                                </CardContent>
                                <CardFooter className="p-3 md:p-4 pt-0">
                                    <Button className="w-full rounded-xl text-xs h-8" asChild>
                                        <Link to={PATHS.STORE}>Chi tiết</Link>
                                    </Button>
                                </CardFooter>
                            </Card>
                        </motion.div>
                    ))}
                </div>
            </section>
        </div>
    );
}
