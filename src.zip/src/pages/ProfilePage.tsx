import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { toast } from 'sonner';
import { useUser } from '../services/UserContext';
import { formatApiErrorForToast, getApiValidationErrors } from '../utils';
import { validatePassword } from '../utils/validators';
import { ApiError } from '../types';
import * as authService from '../services/authService';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { PasswordInput } from '../components/PasswordInput';
import { PasswordStrengthIndicator } from '../components/PasswordStrengthIndicator';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { Spinner } from '@/components/ui/spinner';
import { ImageUpload } from '@/components/ImageUpload';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { User, Lock, Camera, Mail, CheckCircle2 } from 'lucide-react';
import apiClient from '../services/apiClient';
import { Link } from 'react-router-dom';
import { PATHS } from '../constants/paths';

const ProfileForm = () => {
    const { user, setUser } = useUser();
    const [name, setName] = useState(user?.name || '');
    const [email, setEmail] = useState(user?.email || '');
    const [avatarUrl, setAvatarUrl] = useState(user?.avatarUrl || '');
    const [isLoading, setIsLoading] = useState(false);
    const [errors, setErrors] = useState<Record<string, string>>({});

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        setIsLoading(true);
        setErrors({});
        try {
            const updateData: any = { name, email };
            if (avatarUrl) {
                updateData.avatar = avatarUrl;
            }
            const updatedUser = await authService.updateProfile(updateData);
            setUser(updatedUser);
            toast.success('Cập nhật thông tin thành công!');
        } catch (error) {
            const validationErrors = getApiValidationErrors(error as ApiError);
            if (validationErrors) {
                setErrors(validationErrors);
            } else {
                toast.error(formatApiErrorForToast(error as ApiError));
            }
        } finally {
            setIsLoading(false);
        }
    };

    const handleAvatarUpload = async (url: string) => {
        setAvatarUrl(url);
        if (url) {
            try {
                const updateData = { avatar: url };
                const updatedUser = await authService.updateProfile(updateData);
                setUser(updatedUser);
                toast.success('Đã cập nhật ảnh đại diện!');
            } catch (error) {
                toast.error('Không thể cập nhật ảnh đại diện');
            }
        }
    };

    return (
        <div className="space-y-6">
            {/* Avatar Upload Section - Compact */}
            <div className="flex flex-col sm:flex-row items-center sm:items-start gap-4 p-4 rounded-2xl border bg-muted/30">
                <div className="relative">
                    <Avatar className="h-20 w-20 border-2 border-background shadow-md">
                        <AvatarImage src={avatarUrl || user?.avatarUrl} alt={user?.name || 'Avatar'} />
                        <AvatarFallback className="bg-gradient-to-br from-primary to-blue-600 text-white text-xl font-bold">
                            {user?.name?.charAt(0)?.toUpperCase() || 'U'}
                        </AvatarFallback>
                    </Avatar>
                </div>
                <div className="flex-1 min-w-0 text-center sm:text-left">
                    <p className="font-semibold truncate">{user?.name || 'Người dùng'}</p>
                    <p className="text-sm text-muted-foreground truncate">{user?.email}</p>
                </div>
            </div>
            <ImageUpload
                title="Ảnh đại diện"
                description="Tải lên ảnh đại diện của bạn (khuyến nghị: 200x200px)"
                currentImage={avatarUrl || user?.avatarUrl}
                onImageUploaded={handleAvatarUpload}
                maxSizeMB={2}
                aspectRatio={1}
                recommendedSize="200x200px"
            />

            {/* Profile Form */}
            <form onSubmit={handleSubmit} className="space-y-4">
                <div className="space-y-2">
                    <Label htmlFor="name">Tên hiển thị</Label>
                    <Input 
                        id="name" 
                        type="text" 
                        value={name} 
                        onChange={e => setName(e.target.value)} 
                        required 
                        aria-invalid={!!errors.name}
                        className="rounded-2xl"
                    />
                    {errors.name && <small className="text-destructive text-sm">{errors.name}</small>}
                </div>
                <div className="space-y-2">
                    <Label htmlFor="email">Email</Label>
                    <Input 
                        id="email" 
                        type="email" 
                        value={email} 
                        onChange={e => setEmail(e.target.value)} 
                        required 
                        aria-invalid={!!errors.email}
                        className="rounded-2xl"
                    />
                    {errors.email && <small className="text-destructive text-sm">{errors.email}</small>}
                </div>
                <div className="mt-6 flex justify-end">
                    <Button type="submit" disabled={isLoading} className="rounded-2xl">
                        {isLoading && <Spinner className="mr-2 h-4 w-4 animate-spin" />}
                        Lưu thay đổi
                    </Button>
                </div>
            </form>
        </div>
    );
};

const PasswordForm = () => {
    const [currentPassword, setCurrentPassword] = useState('');
    const [newPassword, setNewPassword] = useState('');
    const [passwordConfirmation, setPasswordConfirmation] = useState('');
    const [isLoading, setIsLoading] = useState(false);
    const [errors, setErrors] = useState<Record<string, string>>({});

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        setErrors({});

        if (newPassword !== passwordConfirmation) {
            toast.error("Mật khẩu mới không khớp.");
            return;
        }

        const validation = validatePassword(newPassword);
        if (!validation.isValid) {
            toast.error(validation.message);
            return;
        }

        setIsLoading(true);
        try {
            await authService.updatePassword({
                current_password: currentPassword,
                password: newPassword,
                password_confirmation: passwordConfirmation,
            });
            toast.success("Đổi mật khẩu thành công!");
            setCurrentPassword('');
            setNewPassword('');
            setPasswordConfirmation('');
        } catch (error) {
            const validationErrors = getApiValidationErrors(error as ApiError);
            if (validationErrors) {
                setErrors(validationErrors);
            } else {
                toast.error(formatApiErrorForToast(error as ApiError));
            }
        } finally {
            setIsLoading(false);
        }
    };

    return (
         <form onSubmit={handleSubmit} className="space-y-4">
            <div className="space-y-2">
                <Label htmlFor="current_password">Mật khẩu hiện tại</Label>
                <PasswordInput 
                    id="current_password" 
                    value={currentPassword} 
                    onChange={e => setCurrentPassword(e.target.value)} 
                    required 
                    aria-invalid={!!errors.current_password}
                    className="rounded-2xl"
                />
                {errors.current_password && <small className="text-destructive text-sm">{errors.current_password}</small>}
            </div>
            <div className="space-y-2">
                <Label htmlFor="password">Mật khẩu mới</Label>
                <PasswordInput 
                    id="password" 
                    value={newPassword} 
                    onChange={e => setNewPassword(e.target.value)} 
                    required 
                    aria-invalid={!!errors.password}
                    className="rounded-2xl"
                />
                {errors.password && <small className="text-destructive text-sm">{errors.password}</small>}
                <PasswordStrengthIndicator password={newPassword}/>
            </div>
             <div className="space-y-2">
                <Label htmlFor="password_confirmation">Xác nhận mật khẩu mới</Label>
                <PasswordInput 
                    id="password_confirmation" 
                    value={passwordConfirmation} 
                    onChange={e => setPasswordConfirmation(e.target.value)} 
                    required
                    className="rounded-2xl"
                />
            </div>
            <div className="mt-6 flex justify-end">
                <Button type="submit" disabled={isLoading} className="rounded-2xl">
                    {isLoading && <Spinner className="mr-2 h-4 w-4 animate-spin" />}
                    Đổi mật khẩu
                </Button>
            </div>
        </form>
    );
};

const EmailVerificationForm = () => {
    const { user, setUser } = useUser();
    const [email, setEmail] = useState(user?.email || '');
    const [verificationCode, setVerificationCode] = useState('');
    const [isSendingCode, setIsSendingCode] = useState(false);
    const [isVerifying, setIsVerifying] = useState(false);
    const [codeSent, setCodeSent] = useState(false);
    const [errors, setErrors] = useState<Record<string, string>>({});

    const handleSendCode = async (e: React.FormEvent) => {
        e.preventDefault();
        if (!email.trim()) {
            toast.error('Vui lòng nhập email');
            return;
        }

        setIsSendingCode(true);
        setErrors({});
        try {
            await apiClient.post('/api/v1/me/email/send-verification-code', { email });
            setCodeSent(true);
            toast.success('Đã gửi mã xác thực đến email của bạn. Vui lòng kiểm tra hộp thư.');
        } catch (error) {
            const validationErrors = getApiValidationErrors(error as ApiError);
            if (validationErrors) {
                setErrors(validationErrors);
            } else {
                toast.error(formatApiErrorForToast(error as ApiError, 'Không thể gửi mã xác thực.'));
            }
        } finally {
            setIsSendingCode(false);
        }
    };

    const handleVerifyCode = async (e: React.FormEvent) => {
        e.preventDefault();
        if (!verificationCode.trim()) {
            toast.error('Vui lòng nhập mã xác thực');
            return;
        }

        setIsVerifying(true);
        setErrors({});
        try {
            const response = await apiClient.post('/api/v1/me/email/verify-code', {
                email,
                code: verificationCode,
            });
            const updatedUser = response.data?.user;
            if (updatedUser) {
                setUser(updatedUser);
            }
            toast.success('Xác thực email thành công!');
            setCodeSent(false);
            setVerificationCode('');
        } catch (error) {
            const validationErrors = getApiValidationErrors(error as ApiError);
            if (validationErrors) {
                setErrors(validationErrors);
            } else {
                toast.error(formatApiErrorForToast(error as ApiError, 'Mã xác thực không đúng.'));
            }
        } finally {
            setIsVerifying(false);
        }
    };

    const isEmailVerified = user?.emailVerified || (user as any)?.email_verified_at;

    return (
        <div className="space-y-6">
            {/* Trạng thái xác thực */}
            {isEmailVerified ? (
                <div className="p-4 rounded-2xl border bg-green-50 dark:bg-green-950/20 border-green-200 dark:border-green-800">
                    <div className="flex items-center gap-3">
                        <CheckCircle2 className="h-5 w-5 text-green-600 dark:text-green-400" />
                        <div>
                            <p className="font-semibold text-green-900 dark:text-green-100">Email đã được xác thực</p>
                            <p className="text-sm text-green-700 dark:text-green-300">
                                Email {user?.email} đã được xác thực thành công.
                            </p>
                        </div>
                    </div>
                </div>
            ) : (
                <div className="p-4 rounded-2xl border bg-yellow-50 dark:bg-yellow-950/20 border-yellow-200 dark:border-yellow-800">
                    <div className="flex items-start gap-3">
                        <Mail className="h-5 w-5 text-yellow-600 dark:text-yellow-400 mt-0.5" />
                        <div className="flex-1">
                            <p className="font-semibold text-yellow-900 dark:text-yellow-100">Email chưa được xác thực</p>
                            <p className="text-sm text-yellow-700 dark:text-yellow-300 mt-1">
                                Vui lòng xác thực email để có thể nạp tiền và mua hàng. Mã xác thực sẽ được gửi đến email của bạn.
                            </p>
                        </div>
                    </div>
                </div>
            )}

            {/* Form xác thực email */}
            {!isEmailVerified && (
                <div className="space-y-4">
                    <form onSubmit={handleSendCode} className="space-y-4">
                        <div className="space-y-2">
                            <Label htmlFor="verification-email">Email cần xác thực</Label>
                            <Input
                                id="verification-email"
                                type="email"
                                placeholder="Nhập email của bạn"
                                value={email}
                                onChange={(e) => {
                                    setEmail(e.target.value);
                                    setCodeSent(false);
                                    setVerificationCode('');
                                }}
                                required
                                disabled={codeSent}
                                aria-invalid={!!errors.email}
                                className="rounded-2xl"
                            />
                            {errors.email && <small className="text-destructive text-sm">{errors.email}</small>}
                        </div>
                        {!codeSent ? (
                            <Button type="submit" disabled={isSendingCode} className="w-full rounded-2xl">
                                {isSendingCode ? (
                                    <>
                                        <Spinner className="mr-2 h-4 w-4 animate-spin" />
                                        Đang gửi mã...
                                    </>
                                ) : (
                                    <>
                                        <Mail className="mr-2 h-4 w-4" />
                                        Gửi mã xác thực
                                    </>
                                )}
                            </Button>
                        ) : (
                            <div className="p-3 rounded-xl bg-muted/50 border">
                                <p className="text-sm text-muted-foreground">
                                    Mã xác thực đã được gửi đến <strong>{email}</strong>. Vui lòng kiểm tra hộp thư (có thể trong thư mục spam).
                                </p>
                            </div>
                        )}
                    </form>

                    {codeSent && (
                        <form onSubmit={handleVerifyCode} className="space-y-4 pt-4 border-t">
                            <div className="space-y-2">
                                <Label htmlFor="verification-code">Mã xác thực</Label>
                                <Input
                                    id="verification-code"
                                    type="text"
                                    placeholder="Nhập mã xác thực (6 chữ số)"
                                    value={verificationCode}
                                    onChange={(e) => setVerificationCode(e.target.value.replace(/\D/g, '').slice(0, 6))}
                                    required
                                    maxLength={6}
                                    aria-invalid={!!errors.code}
                                    className="rounded-2xl text-center text-2xl font-mono tracking-widest"
                                />
                                {errors.code && <small className="text-destructive text-sm">{errors.code}</small>}
                                <p className="text-xs text-muted-foreground">
                                    Nhập mã 6 chữ số đã được gửi đến email của bạn
                                </p>
                            </div>
                            <Button type="submit" disabled={isVerifying || verificationCode.length !== 6} className="w-full rounded-2xl">
                                {isVerifying ? (
                                    <>
                                        <Spinner className="mr-2 h-4 w-4 animate-spin" />
                                        Đang xác thực...
                                    </>
                                ) : (
                                    <>
                                        <CheckCircle2 className="mr-2 h-4 w-4" />
                                        Xác thực email
                                    </>
                                )}
                            </Button>
                            <Button
                                type="button"
                                variant="outline"
                                onClick={() => {
                                    setCodeSent(false);
                                    setVerificationCode('');
                                }}
                                className="w-full rounded-2xl"
                            >
                                Gửi lại mã
                            </Button>
                        </form>
                    )}
                </div>
            )}
        </div>
    );
};

export default function ProfilePage() {
    return (
        <Card className="rounded-3xl">
                    <CardHeader>
                        <CardTitle className="flex items-center gap-2">
                            <span className="text-xl">🧠</span>
                            Thông tin Tài khoản
                        </CardTitle>
                        <CardDescription>Quản lý thông tin cá nhân và bảo mật</CardDescription>
                    </CardHeader>
            <CardContent>
                <Tabs defaultValue="profile" className="w-full">
                    <TabsList className="grid w-full grid-cols-3 rounded-2xl">
                        <TabsTrigger value="profile" className="rounded-xl">
                            <User className="mr-2 h-4 w-4" />
                            Thông tin cá nhân
                        </TabsTrigger>
                        <TabsTrigger value="email" className="rounded-xl">
                            <Mail className="mr-2 h-4 w-4" />
                            Xác thực Email
                        </TabsTrigger>
                        <TabsTrigger value="password" className="rounded-xl">
                            <Lock className="mr-2 h-4 w-4" />
                            Đổi mật khẩu
                        </TabsTrigger>
                    </TabsList>
                    <TabsContent value="profile" className="pt-6">
                        <ProfileForm />
                    </TabsContent>
                    <TabsContent value="email" className="pt-6">
                        <EmailVerificationForm />
                    </TabsContent>
                    <TabsContent value="password" className="pt-6">
                        <PasswordForm />
                    </TabsContent>
                </Tabs>
            </CardContent>
        </Card>
    );
}