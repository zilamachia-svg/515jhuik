import React, { useState } from 'react';
import { usePageTitle } from '../contexts/PageTitleContext';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { DocumentItem } from '../components/DocumentItem';
import { Document } from '../types';
import { toast } from 'sonner';

const mockDocuments: Document[] = [
    { id: 'doc_1', name: 'Bộ tài liệu Hướng dẫn chạy Ads A-Z', description: 'Tài liệu chi tiết từ cơ bản đến nâng cao về quảng cáo Facebook, Google, và Tiktok.', price: 500000, downloadUrl: '#', version: '1.2', releaseDate: '2023-10-01' },
    { id: 'doc_2', name: 'Tổng hợp tuts blackhat 2024', description: 'Các thủ thuật nâng cao và mẹo độc quyền dành cho người dùng có kinh nghiệm.', price: 1000000, downloadUrl: '#', version: '2.0', releaseDate: '2023-09-15' },
    { id: 'doc_3', name: 'Ebook: Xây dựng thương hiệu cá nhân', description: 'Bí quyết xây dựng hình ảnh và thương hiệu cá nhân thành công trên mạng xã hội.', price: 250000, downloadUrl: '#', version: '1.0', releaseDate: '2023-11-05' },
];


export default function MuaTaiLieuPage() {
    usePageTitle("Mua tài liệu");
    const [documents] = useState<Document[]>(mockDocuments);

    const handleBuy = (doc: Document) => {
        toast.info(`Chức năng mua tài liệu "${doc.name}" đang được phát triển.`);
    };

    return (
        <Card>
            <CardHeader>
                <CardTitle>Tài liệu & Ebooks</CardTitle>
            </CardHeader>
            <CardContent>
                 <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                    {documents.map(doc => (
                        <DocumentItem key={doc.id} document={doc} onBuy={handleBuy} />
                    ))}
                </div>
            </CardContent>
        </Card>
    );
}
