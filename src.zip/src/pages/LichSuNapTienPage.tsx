import { useState, useEffect, useCallback } from 'react';
import { motion } from 'framer-motion';
import { toast } from 'sonner';
import { Deposit, ApiError } from '../types';
import apiClient from '../services/apiClient';
import { formatCurrency, formatApiErrorForToast } from '../utils';
import { usePageTitle } from '../contexts/PageTitleContext';
import { useLanguage } from '../contexts/LanguageContext';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Pagination } from '@/components/Pagination';
import { TableSkeleton } from '../components/skeletons/TableSkeleton';
import { Badge } from '@/components/ui/badge';
import { Wallet } from 'lucide-react';
import { BannerContent } from '@/components/BannerContent';

const ITEMS_PER_PAGE = 10;

export default function LichSuNapTienPage() {
    const { t } = useLanguage();
    usePageTitle(t('sidebar.depositHistory', { defaultValue: 'Lịch sử nạp tiền' }));

    const [deposits, setDeposits] = useState<Deposit[]>([]);
    const [isLoading, setIsLoading] = useState(true);
    const [currentPage, setCurrentPage] = useState(1);
    const [totalPages, setTotalPages] = useState(1);
    const [totalItems, setTotalItems] = useState(0);

    const fetchDeposits = useCallback(async (page: number) => {
        setIsLoading(true);
        try {
            const response = await apiClient.get('/deposits', {
                params: { page, limit: ITEMS_PER_PAGE },
            });
            setDeposits(response.data.data);
            setTotalPages(response.data.totalPages);
            setTotalItems(response.data.totalItems);
            setCurrentPage(response.data.currentPage);
        } catch (error) {
            toast.error(formatApiErrorForToast(error as ApiError, 'Không thể tải lịch sử nạp tiền.'));
        } finally {
            setIsLoading(false);
        }
    }, []);

    useEffect(() => {
        fetchDeposits(currentPage);
    }, [fetchDeposits, currentPage]);

    const handlePageChange = (page: number) => {
        setCurrentPage(page);
    };
    
    const getStatusVariant = (status: 'Hoàn thành' | 'Đang chờ' | 'Thất bại'): 'default' | 'secondary' | 'destructive' => {
        switch (status) {
            case 'Hoàn thành': return 'default';
            case 'Đang chờ': return 'secondary';
            case 'Thất bại': return 'destructive';
            default: return 'secondary';
        }
    }


    return (
        <div className="space-y-8">
            {/* Banner Section */}
            <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5 }}
                className="overflow-hidden rounded-3xl bg-gradient-to-r from-yellow-400/85 via-amber-400/85 to-orange-400/85 p-8 text-white"
            >
                <div className="flex flex-col gap-6 md:flex-row md:items-center md:justify-between">
                    <div className="space-y-2">
                        <div className="flex items-center gap-3">
                            <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-white/20 backdrop-blur-md">
                                <Wallet className="h-6 w-6" />
                            </div>
                            <div>
                                <h1 className="text-3xl font-bold flex items-center gap-2">
                                    <span className="text-3xl">💰</span>
                                    Lịch sử Nạp tiền
                                </h1>
                                <p className="text-white/80">Xem tất cả giao dịch nạp tiền của bạn</p>
                            </div>
                        </div>
                    </div>
                </div>
                <BannerContent />
            </motion.div>

            <Card className="rounded-3xl">
                <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                        <span className="text-xl">💰</span>
                        {t('sidebar.depositHistory', { defaultValue: 'Lịch sử nạp tiền' })}
                    </CardTitle>
                </CardHeader>
                <CardContent>
                {isLoading && !deposits.length ? (
                    <TableSkeleton headers={['Số tiền', 'Phương thức', 'Ngày tạo', 'Trạng thái', 'Mã GD']} />
                ) : deposits.length > 0 ? (
                    <>
                        <div className="w-full overflow-auto">
                            <Table>
                                <TableHeader>
                                    <TableRow>
                                        <TableHead>Số tiền</TableHead>
                                        <TableHead>Phương thức</TableHead>
                                        <TableHead>Ngày tạo</TableHead>
                                        <TableHead>Trạng thái</TableHead>
                                        <TableHead>Mã GD</TableHead>
                                    </TableRow>
                                </TableHeader>
                                <TableBody>
                                    {deposits.map(deposit => (
                                        <TableRow key={deposit.id}>
                                            <TableCell className="font-semibold">{formatCurrency(deposit.amount)}</TableCell>
                                            <TableCell>{deposit.method}</TableCell>
                                            <TableCell>{new Date(deposit.createdAt).toLocaleString('vi-VN')}</TableCell>
                                            <TableCell>
                                                <Badge variant={getStatusVariant(deposit.status)}>{deposit.status}</Badge>
                                            </TableCell>
                                            <TableCell>{deposit.transactionCode || 'N/A'}</TableCell>
                                        </TableRow>
                                    ))}
                                </TableBody>
                            </Table>
                        </div>
                         {totalPages > 1 && (
                            <div className="mt-6">
                                <Pagination
                                    currentPage={currentPage}
                                    totalPages={totalPages}
                                    totalItems={totalItems}
                                    itemsPerPage={ITEMS_PER_PAGE}
                                    onPageChange={handlePageChange}
                                />
                            </div>
                        )}
                    </>
                ) : (
                    <p className="text-center p-8 text-muted-foreground">Bạn chưa có giao dịch nạp tiền nào.</p>
                )}
            </CardContent>
        </Card>
        </div>
    );
}