import { motion } from 'framer-motion';
import { usePageTitle } from '../contexts/PageTitleContext';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Shield, CheckCircle, XCircle, Clock } from 'lucide-react';
import { BannerContent } from '@/components/BannerContent';

export default function WarrantyPage() {
    usePageTitle('Chính sách bảo hành - Hải Đăng Meta');

    return (
        <div className="space-y-8">
            {/* Banner với nội dung */}
            <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5 }}
                className="overflow-hidden rounded-3xl bg-gradient-to-r from-green-400/85 via-emerald-400/85 to-teal-400/85 p-8 text-white"
            >
                <div className="flex flex-col gap-6 md:flex-row md:items-center md:justify-between">
                    <div className="space-y-4">
                        <div className="flex items-center gap-3">
                            <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-white/20 backdrop-blur-md">
                                <Shield className="h-6 w-6" />
                            </div>
                            <div>
                                <h1 className="text-3xl font-bold">Chính sách bảo hành</h1>
                                <p className="text-white/80">Cam kết chất lượng và hỗ trợ khách hàng</p>
                            </div>
                        </div>
                    </div>
                </div>
                <BannerContent />
            </motion.div>

            {/* Nội dung chính */}
            <Card className="rounded-3xl">
                <CardHeader>
                    <CardTitle>Chính sách bảo hành và đổi trả</CardTitle>
                </CardHeader>
                <CardContent className="prose prose-slate max-w-none space-y-6">
                    <section>
                        <h2 className="text-2xl font-bold mb-4">1. Cam kết chất lượng</h2>
                        <p className="text-muted-foreground leading-relaxed">
                            <strong>Hải Đăng Meta</strong> cam kết cung cấp sản phẩm và dịch vụ chất lượng cao. 
                            Tất cả sản phẩm được kiểm tra kỹ lưỡng trước khi giao đến khách hàng. Chúng tôi đảm bảo 
                            sản phẩm hoạt động đúng như mô tả tại thời điểm giao hàng.
                        </p>
                    </section>

                    <section>
                        <h2 className="text-2xl font-bold mb-4">2. Thời gian bảo hành</h2>
                        <div className="space-y-4">
                            <div>
                                <h3 className="text-xl font-semibold mb-2 flex items-center gap-2">
                                    <CheckCircle className="h-5 w-5 text-green-600" />
                                    2.1. Bảo hành sản phẩm
                                </h3>
                                <p className="text-muted-foreground">
                                    Tất cả sản phẩm được bảo hành trong vòng <strong>30 ngày</strong> kể từ ngày giao hàng. 
                                    Trong thời gian này, nếu sản phẩm gặp lỗi kỹ thuật hoặc không hoạt động đúng như cam kết, 
                                    chúng tôi sẽ:
                                </p>
                                <ul className="list-disc pl-6 mt-2 space-y-1 text-muted-foreground">
                                    <li>Thay thế sản phẩm tương đương</li>
                                    <li>Hoàn tiền 100% nếu không thể thay thế</li>
                                    <li>Hỗ trợ kỹ thuật miễn phí</li>
                                </ul>
                            </div>
                            <div>
                                <h3 className="text-xl font-semibold mb-2 flex items-center gap-2">
                                    <Clock className="h-5 w-5 text-blue-600" />
                                    2.2. Hỗ trợ kỹ thuật
                                </h3>
                                <p className="text-muted-foreground">
                                    Chúng tôi cung cấp hỗ trợ kỹ thuật miễn phí trong vòng <strong>90 ngày</strong> sau khi mua hàng. 
                                    Hỗ trợ bao gồm hướng dẫn sử dụng, xử lý sự cố và tư vấn kỹ thuật.
                                </p>
                            </div>
                        </div>
                    </section>

                    <section>
                        <h2 className="text-2xl font-bold mb-4">3. Điều kiện bảo hành</h2>
                        <div className="space-y-4">
                            <div className="p-4 bg-green-50 dark:bg-green-900/20 rounded-2xl border border-green-200 dark:border-green-800">
                                <h3 className="text-xl font-semibold mb-2 flex items-center gap-2 text-green-700 dark:text-green-300">
                                    <CheckCircle className="h-5 w-5" />
                                    Được bảo hành khi:
                                </h3>
                                <ul className="list-disc pl-6 space-y-1 text-muted-foreground">
                                    <li>Sản phẩm không hoạt động ngay sau khi nhận</li>
                                    <li>Sản phẩm bị lỗi kỹ thuật do nhà cung cấp</li>
                                    <li>Thông tin đăng nhập không chính xác (đã xác minh)</li>
                                    <li>Sản phẩm bị khóa/khóa tài khoản trong vòng 7 ngày đầu</li>
                                    <li>Giao nhầm sản phẩm không đúng mô tả</li>
                                </ul>
                            </div>
                            <div className="p-4 bg-red-50 dark:bg-red-900/20 rounded-2xl border border-red-200 dark:border-red-800">
                                <h3 className="text-xl font-semibold mb-2 flex items-center gap-2 text-red-700 dark:text-red-300">
                                    <XCircle className="h-5 w-5" />
                                    Không được bảo hành khi:
                                </h3>
                                <ul className="list-disc pl-6 space-y-1 text-muted-foreground">
                                    <li>Đã quá thời hạn bảo hành (30 ngày)</li>
                                    <li>Khách hàng tự ý thay đổi thông tin đăng nhập</li>
                                    <li>Sản phẩm bị khóa do vi phạm điều khoản của bên thứ ba</li>
                                    <li>Khách hàng đã sử dụng/sửa đổi sản phẩm</li>
                                    <li>Không cung cấp đủ thông tin để xác minh</li>
                                    <li>Mua nhầm sản phẩm (không đọc kỹ mô tả)</li>
                                </ul>
                            </div>
                        </div>
                    </section>

                    <section>
                        <h2 className="text-2xl font-bold mb-4">4. Quy trình yêu cầu bảo hành</h2>
                        <div className="space-y-3">
                            <div className="flex gap-3">
                                <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-primary text-primary-foreground font-bold">
                                    1
                                </div>
                                <div>
                                    <h3 className="font-semibold mb-1">Liên hệ hỗ trợ</h3>
                                    <p className="text-sm text-muted-foreground">
                                        Gửi yêu cầu bảo hành qua email support@haidangmeta.com hoặc chat trực tiếp trên website. 
                                        Cung cấp mã đơn hàng và mô tả vấn đề.
                                    </p>
                                </div>
                            </div>
                            <div className="flex gap-3">
                                <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-primary text-primary-foreground font-bold">
                                    2
                                </div>
                                <div>
                                    <h3 className="font-semibold mb-1">Xác minh thông tin</h3>
                                    <p className="text-sm text-muted-foreground">
                                        Chúng tôi sẽ xác minh thông tin đơn hàng và kiểm tra điều kiện bảo hành trong vòng 24 giờ.
                                    </p>
                                </div>
                            </div>
                            <div className="flex gap-3">
                                <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-primary text-primary-foreground font-bold">
                                    3
                                </div>
                                <div>
                                    <h3 className="font-semibold mb-1">Xử lý yêu cầu</h3>
                                    <p className="text-sm text-muted-foreground">
                                        Nếu đủ điều kiện, chúng tôi sẽ thay thế sản phẩm hoặc hoàn tiền trong vòng 3-5 ngày làm việc.
                                    </p>
                                </div>
                            </div>
                        </div>
                    </section>

                    <section>
                        <h2 className="text-2xl font-bold mb-4">5. Chính sách đổi trả</h2>
                        <div className="space-y-4">
                            <div>
                                <h3 className="text-xl font-semibold mb-2">5.1. Thời gian đổi trả</h3>
                                <p className="text-muted-foreground">
                                    Khách hàng có thể yêu cầu đổi trả trong vòng <strong>7 ngày</strong> kể từ ngày nhận sản phẩm, 
                                    với điều kiện sản phẩm chưa được sử dụng hoặc thay đổi.
                                </p>
                            </div>
                            <div>
                                <h3 className="text-xl font-semibold mb-2">5.2. Lý do đổi trả được chấp nhận</h3>
                                <ul className="list-disc pl-6 space-y-1 text-muted-foreground">
                                    <li>Giao nhầm sản phẩm</li>
                                    <li>Sản phẩm không đúng mô tả</li>
                                    <li>Sản phẩm bị lỗi ngay khi nhận</li>
                                    <li>Khách hàng thay đổi ý định (phí đổi trả 10% giá trị đơn hàng)</li>
                                </ul>
                            </div>
                            <div>
                                <h3 className="text-xl font-semibold mb-2">5.3. Phí đổi trả</h3>
                                <p className="text-muted-foreground">
                                    Đổi trả do lỗi của chúng tôi: <strong>Miễn phí</strong><br />
                                    Đổi trả do khách hàng: <strong>Phí 10%</strong> giá trị đơn hàng (tối thiểu 10,000 VNĐ)
                                </p>
                            </div>
                        </div>
                    </section>

                    <section>
                        <h2 className="text-2xl font-bold mb-4">6. Hoàn tiền</h2>
                        <div className="space-y-4">
                            <div>
                                <h3 className="text-xl font-semibold mb-2">6.1. Thời gian hoàn tiền</h3>
                                <p className="text-muted-foreground">
                                    Sau khi yêu cầu hoàn tiền được chấp thuận, tiền sẽ được hoàn về tài khoản của bạn trong vòng 
                                    <strong> 5-7 ngày làm việc</strong> tùy theo phương thức thanh toán ban đầu.
                                </p>
                            </div>
                            <div>
                                <h3 className="text-xl font-semibold mb-2">6.2. Phương thức hoàn tiền</h3>
                                <ul className="list-disc pl-6 space-y-1 text-muted-foreground">
                                    <li>Chuyển khoản ngân hàng: Hoàn về tài khoản đã thanh toán</li>
                                    <li>Ví điện tử MoMo: Hoàn về ví MoMo</li>
                                    <li>Hoàn vào số dư tài khoản trên website (nếu yêu cầu)</li>
                                </ul>
                            </div>
                        </div>
                    </section>

                    <section>
                        <h2 className="text-2xl font-bold mb-4">7. Trường hợp đặc biệt</h2>
                        <div className="space-y-4">
                            <div>
                                <h3 className="text-xl font-semibold mb-2">7.1. Sản phẩm bị khóa sau 7 ngày</h3>
                                <p className="text-muted-foreground">
                                    Nếu sản phẩm bị khóa sau 7 ngày sử dụng, chúng tôi sẽ hỗ trợ tìm giải pháp thay thế hoặc 
                                    hoàn tiền một phần tùy theo từng trường hợp cụ thể.
                                </p>
                            </div>
                            <div>
                                <h3 className="text-xl font-semibold mb-2">7.2. Sản phẩm hết hạn</h3>
                                <p className="text-muted-foreground">
                                    Đối với các sản phẩm có thời hạn sử dụng, chúng tôi đảm bảo sản phẩm còn ít nhất 30 ngày 
                                    sử dụng tại thời điểm giao hàng.
                                </p>
                            </div>
                        </div>
                    </section>

                    <section>
                        <h2 className="text-2xl font-bold mb-4">8. Liên hệ hỗ trợ</h2>
                        <p className="text-muted-foreground">
                            Để được hỗ trợ về bảo hành, vui lòng liên hệ:
                        </p>
                        <ul className="list-disc pl-6 mt-2 space-y-1 text-muted-foreground">
                            <li>Email: warranty@haidangmeta.com</li>
                            <li>Hotline: 1900-xxxx</li>
                            <li>Thời gian: 8:00 - 22:00 hàng ngày</li>
                            <li>Chat trực tiếp trên website</li>
                        </ul>
                    </section>

                    <div className="mt-8 p-4 bg-muted rounded-2xl">
                        <p className="text-sm text-muted-foreground">
                            <strong>Lần cập nhật cuối:</strong> {new Date().toLocaleDateString('vi-VN')}
                        </p>
                    </div>
                </CardContent>
            </Card>
        </div>
    );
}

