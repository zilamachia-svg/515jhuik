import { motion } from 'framer-motion';
import { usePageTitle } from '../contexts/PageTitleContext';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Shield } from 'lucide-react';
import { BannerContent } from '@/components/BannerContent';

export default function PrivacyPolicyPage() {
    usePageTitle('Chính sách bảo mật - Hải Đăng Meta');

    return (
        <div className="space-y-8">
            {/* Banner với nội dung */}
            <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5 }}
                className="overflow-hidden rounded-3xl bg-gradient-to-r from-blue-400/85 via-cyan-400/85 to-teal-400/85 p-8 text-white"
            >
                <div className="flex flex-col gap-6 md:flex-row md:items-center md:justify-between">
                    <div className="space-y-4">
                        <div className="flex items-center gap-3">
                            <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-white/20 backdrop-blur-md">
                                <Shield className="h-6 w-6" />
                            </div>
                            <div>
                                <h1 className="text-3xl font-bold">Chính sách bảo mật</h1>
                                <p className="text-white/80">Cam kết bảo vệ thông tin cá nhân của bạn</p>
                            </div>
                        </div>
                    </div>
                </div>
                <BannerContent />
            </motion.div>

            {/* Nội dung chính */}
            <Card className="rounded-3xl">
                <CardHeader>
                    <CardTitle>Chính sách bảo mật thông tin</CardTitle>
                </CardHeader>
                <CardContent className="prose prose-slate max-w-none space-y-6">
                    <section>
                        <h2 className="text-2xl font-bold mb-4">1. Cam kết bảo mật</h2>
                        <p className="text-muted-foreground leading-relaxed">
                            <strong>Hải Đăng Meta</strong> cam kết bảo vệ quyền riêng tư và thông tin cá nhân của người dùng. 
                            Chính sách này mô tả cách chúng tôi thu thập, sử dụng, lưu trữ và bảo vệ thông tin của bạn khi sử dụng dịch vụ.
                        </p>
                    </section>

                    <section>
                        <h2 className="text-2xl font-bold mb-4">2. Thông tin chúng tôi thu thập</h2>
                        <div className="space-y-4">
                            <div>
                                <h3 className="text-xl font-semibold mb-2">2.1. Thông tin cá nhân</h3>
                                <p className="text-muted-foreground">
                                    Chúng tôi thu thập thông tin bạn cung cấp khi đăng ký tài khoản, bao gồm:
                                </p>
                                <ul className="list-disc pl-6 mt-2 space-y-1 text-muted-foreground">
                                    <li>Họ và tên</li>
                                    <li>Địa chỉ email</li>
                                    <li>Số điện thoại (nếu có)</li>
                                    <li>Thông tin thanh toán (được mã hóa và bảo mật)</li>
                                </ul>
                            </div>
                            <div>
                                <h3 className="text-xl font-semibold mb-2">2.2. Thông tin tự động</h3>
                                <p className="text-muted-foreground">
                                    Khi bạn truy cập website, chúng tôi tự động thu thập:
                                </p>
                                <ul className="list-disc pl-6 mt-2 space-y-1 text-muted-foreground">
                                    <li>Địa chỉ IP</li>
                                    <li>Loại trình duyệt và phiên bản</li>
                                    <li>Thời gian truy cập</li>
                                    <li>Trang bạn đã truy cập</li>
                                    <li>Cookies và công nghệ theo dõi tương tự</li>
                                </ul>
                            </div>
                        </div>
                    </section>

                    <section>
                        <h2 className="text-2xl font-bold mb-4">3. Mục đích sử dụng thông tin</h2>
                        <p className="text-muted-foreground mb-3">
                            Chúng tôi sử dụng thông tin của bạn để:
                        </p>
                        <ul className="list-disc pl-6 space-y-2 text-muted-foreground">
                            <li>Cung cấp và cải thiện dịch vụ</li>
                            <li>Xử lý giao dịch và thanh toán</li>
                            <li>Gửi thông báo về đơn hàng và dịch vụ</li>
                            <li>Hỗ trợ khách hàng và giải đáp thắc mắc</li>
                            <li>Phòng chống gian lận và bảo mật tài khoản</li>
                            <li>Gửi thông tin marketing (nếu bạn đồng ý)</li>
                            <li>Tuân thủ các yêu cầu pháp lý</li>
                        </ul>
                    </section>

                    <section>
                        <h2 className="text-2xl font-bold mb-4">4. Bảo vệ thông tin</h2>
                        <div className="space-y-4">
                            <div>
                                <h3 className="text-xl font-semibold mb-2">4.1. Biện pháp bảo mật</h3>
                                <p className="text-muted-foreground">
                                    Chúng tôi áp dụng các biện pháp bảo mật tiên tiến để bảo vệ thông tin của bạn:
                                </p>
                                <ul className="list-disc pl-6 mt-2 space-y-1 text-muted-foreground">
                                    <li>Mã hóa SSL/TLS cho tất cả kết nối</li>
                                    <li>Lưu trữ dữ liệu trên máy chủ an toàn</li>
                                    <li>Giới hạn quyền truy cập thông tin</li>
                                    <li>Thường xuyên kiểm tra và cập nhật bảo mật</li>
                                    <li>Backup dữ liệu định kỳ</li>
                                </ul>
                            </div>
                            <div>
                                <h3 className="text-xl font-semibold mb-2">4.2. Lưu trữ dữ liệu</h3>
                                <p className="text-muted-foreground">
                                    Thông tin của bạn được lưu trữ tại các máy chủ an toàn tại Việt Nam. 
                                    Chúng tôi chỉ lưu trữ thông tin trong thời gian cần thiết để cung cấp dịch vụ 
                                    hoặc theo yêu cầu pháp lý.
                                </p>
                            </div>
                        </div>
                    </section>

                    <section>
                        <h2 className="text-2xl font-bold mb-4">5. Chia sẻ thông tin</h2>
                        <p className="text-muted-foreground mb-3">
                            Chúng tôi <strong>KHÔNG</strong> bán, cho thuê hoặc chia sẻ thông tin cá nhân của bạn với bên thứ ba, 
                            trừ các trường hợp sau:
                        </p>
                        <ul className="list-disc pl-6 space-y-2 text-muted-foreground">
                            <li>Khi có yêu cầu từ cơ quan pháp luật</li>
                            <li>Với các đối tác dịch vụ cần thiết (như cổng thanh toán) - họ cũng cam kết bảo mật</li>
                            <li>Khi bạn đồng ý chia sẻ thông tin</li>
                            <li>Để bảo vệ quyền lợi và an toàn của chúng tôi và người dùng khác</li>
                        </ul>
                    </section>

                    <section>
                        <h2 className="text-2xl font-bold mb-4">6. Quyền của người dùng</h2>
                        <p className="text-muted-foreground mb-3">
                            Bạn có quyền:
                        </p>
                        <ul className="list-disc pl-6 space-y-2 text-muted-foreground">
                            <li><strong>Truy cập:</strong> Yêu cầu xem thông tin cá nhân của bạn</li>
                            <li><strong>Chỉnh sửa:</strong> Cập nhật hoặc sửa đổi thông tin không chính xác</li>
                            <li><strong>Xóa:</strong> Yêu cầu xóa thông tin cá nhân (trừ khi pháp luật yêu cầu lưu trữ)</li>
                            <li><strong>Rút lại đồng ý:</strong> Hủy đồng ý xử lý dữ liệu bất cứ lúc nào</li>
                            <li><strong>Khiếu nại:</strong> Gửi khiếu nại về việc xử lý dữ liệu</li>
                        </ul>
                    </section>

                    <section>
                        <h2 className="text-2xl font-bold mb-4">7. Cookies</h2>
                        <p className="text-muted-foreground">
                            Website sử dụng cookies để cải thiện trải nghiệm người dùng. Cookies là các file nhỏ được lưu trên 
                            thiết bị của bạn. Bạn có thể cấu hình trình duyệt để từ chối cookies, nhưng điều này có thể ảnh hưởng 
                            đến chức năng của website.
                        </p>
                    </section>

                    <section>
                        <h2 className="text-2xl font-bold mb-4">8. Liên kết bên thứ ba</h2>
                        <p className="text-muted-foreground">
                            Website có thể chứa liên kết đến các website khác. Chúng tôi không chịu trách nhiệm về chính sách bảo mật 
                            của các website đó. Chúng tôi khuyến khích bạn đọc chính sách bảo mật của các website bạn truy cập.
                        </p>
                    </section>

                    <section>
                        <h2 className="text-2xl font-bold mb-4">9. Thay đổi chính sách</h2>
                        <p className="text-muted-foreground">
                            Chúng tôi có quyền cập nhật chính sách này bất cứ lúc nào. Các thay đổi sẽ được thông báo trên website 
                            và có hiệu lực ngay sau khi đăng tải. Việc bạn tiếp tục sử dụng dịch vụ sau khi có thay đổi được coi là 
                            bạn đã chấp nhận chính sách mới.
                        </p>
                    </section>

                    <section>
                        <h2 className="text-2xl font-bold mb-4">10. Liên hệ</h2>
                        <p className="text-muted-foreground">
                            Nếu bạn có câu hỏi về chính sách bảo mật này, vui lòng liên hệ:
                        </p>
                        <ul className="list-disc pl-6 mt-2 space-y-1 text-muted-foreground">
                            <li>Email: privacy@haidangmeta.com</li>
                            <li>Hotline: 1900-xxxx</li>
                            <li>Địa chỉ: [Địa chỉ công ty]</li>
                        </ul>
                    </section>

                    <div className="mt-8 p-4 bg-muted rounded-2xl">
                        <p className="text-sm text-muted-foreground">
                            <strong>Lần cập nhật cuối:</strong> {new Date().toLocaleDateString('vi-VN')}
                        </p>
                    </div>
                </CardContent>
            </Card>
        </div>
    );
}

