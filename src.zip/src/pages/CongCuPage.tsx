import { NavLink, Outlet } from 'react-router-dom';
import { useLanguage } from '../contexts/LanguageContext';
import { usePageTitle } from '../contexts/PageTitleContext';
import { PATHS } from '../constants/paths';
import { Code, CheckSquare } from 'lucide-react';
import { Card, CardContent } from '@/components/ui/card';

export default function CongCuPage() {
    const { t } = useLanguage();
    usePageTitle(t('sidebar.toolsTitle'));

    const toolsNav = [
        { path: PATHS.TOOLS_GET_2FA, label: t('sidebar.get2FA'), icon: <Code size={20} /> },
        { path: PATHS.TOOLS_CHECK_LIVE_FB, label: t('sidebar.checkLiveFB'), icon: <CheckSquare size={20} /> },
    ];

    const getNavLinkClass = ({ isActive }: { isActive: boolean }) =>
        `flex items-center gap-3 p-3 rounded-lg hover:bg-accent ${isActive ? 'bg-accent font-semibold' : ''}`;

    return (
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
            <aside className="md:col-span-1">
                <Card>
                    <CardContent className="p-2">
                        <nav className="flex flex-col gap-1">
                            {toolsNav.map(item => (
                                <NavLink key={item.path} to={item.path} className={getNavLinkClass}>
                                    {item.icon}
                                    <span>{item.label}</span>
                                </NavLink>
                            ))}
                        </nav>
                    </CardContent>
                </Card>
            </aside>
            <div className="md:col-span-3">
                <Outlet />
            </div>
        </div>
    );
}