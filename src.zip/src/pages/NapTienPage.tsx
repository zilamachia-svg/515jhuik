import { useState, useEffect } from 'react';
import { toast } from 'sonner';
import { PaymentMethod, ApiError, User } from '../types';
import apiClient from '../services/apiClient';
import { formatApiErrorForToast, formatCurrency } from '../utils';
import { usePageTitle } from '../contexts/PageTitleContext';
import { useLanguage } from '../contexts/LanguageContext';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Spinner } from '@/components/ui/spinner';
import { PaymentInstructionsModal } from '../components/PaymentInstructionsModal';
import { useUser } from '../services/UserContext';
import * as authService from '../services/authService';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Info, Wallet, CreditCard, Smartphone, ArrowRight } from 'lucide-react';
import { Link } from 'react-router-dom';
import { PATHS } from '../constants/paths';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';

const QUICK_AMOUNTS = [50000, 100000, 200000, 500000, 1000000, 2000000];

export default function NapTienPage() {
    const { t } = useLanguage();
    usePageTitle(t('sidebar.deposit'));
    const { user, setUser } = useUser();

    const [methods, setMethods] = useState<PaymentMethod[]>([]);
    const [isLoading, setIsLoading] = useState(true);
    const [selectedMethod, setSelectedMethod] = useState<PaymentMethod | null>(null);
    const [amount, setAmount] = useState<number>(100000);
    const [amountInput, setAmountInput] = useState<string>('100.000');
    const [isSubmitting, setIsSubmitting] = useState(false);
    const [showInstructions, setShowInstructions] = useState(false);

    useEffect(() => {
        const fetchMethods = async () => {
            setIsLoading(true);
            try {
                const response = await apiClient.get('/api/v1/payment-methods');
                // Handle both response.data.methods and response.data.data (if it's an array)
                const paymentMethods = response.data?.methods || response.data?.data || (Array.isArray(response.data) ? response.data : []);
                setMethods(Array.isArray(paymentMethods) ? paymentMethods : []);
            } catch (error) {
                toast.error(formatApiErrorForToast(error as ApiError, 'Không thể tải phương thức thanh toán.'));
                setMethods([]); // Ensure methods is always an array
            } finally {
                setIsLoading(false);
            }
        };

        fetchMethods();
    }, []);

    const handleAmountChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        let rawValue = e.target.value.replace(/[^\d]/g, ''); // Chỉ giữ số
        
        // Giới hạn tối đa 9 chữ số (50,000,000)
        if (rawValue.length > 9) {
            rawValue = rawValue.slice(0, 9);
        }
        
        if (rawValue === '') {
            setAmountInput('');
            setAmount(0);
            return;
        }
        
        const numValue = parseInt(rawValue, 10);
        if (!isNaN(numValue) && numValue >= 0) {
            setAmount(numValue);
            // Format lại để hiển thị với dấu chấm phân cách hàng nghìn
            setAmountInput(new Intl.NumberFormat('vi-VN').format(numValue));
        }
    };

    const handleAmountBlur = () => {
        // Đảm bảo format đúng khi blur
        if (amount > 0) {
            setAmountInput(new Intl.NumberFormat('vi-VN').format(amount));
        } else {
            setAmountInput('');
        }
    };

    const handleQuickAmount = (quickAmount: number) => {
        setAmount(quickAmount);
        setAmountInput(new Intl.NumberFormat('vi-VN').format(quickAmount));
    };

    const handleDeposit = async () => {
        if (!selectedMethod) {
            toast.error('Vui lòng chọn phương thức thanh toán');
            return;
        }

        if (amount < 10000) {
            toast.error('Số tiền nạp tối thiểu là 10,000 VNĐ');
            return;
        }

        if (amount > 50000000) {
            toast.error('Số tiền nạp tối đa là 50,000,000 VNĐ');
            return;
        }

        setIsSubmitting(true);
        try {
            const response = await apiClient.post('/api/v1/deposits', {
                amount,
                payment_method_id: selectedMethod.id,
            });

            toast.success('Đã tạo yêu cầu nạp tiền thành công! Vui lòng thực hiện chuyển khoản theo hướng dẫn.');
            
            // Refresh user balance by re-fetching current user
            try {
                const latest = await authService.fetchCurrentUser();
                if (latest) {
                    setUser(latest);
                }
            } catch (e) {
                // ignore refresh error, UI still works
            }

            // Mở modal hướng dẫn thanh toán
            setShowInstructions(true);
        } catch (error) {
            const apiError = error as ApiError;
            const errorMessage = formatApiErrorForToast(apiError, 'Không thể tạo yêu cầu nạp tiền.');
            // Do not block or surface email-verification-specific messages here; show generic message
            toast.error(errorMessage);
        } finally {
            setIsSubmitting(false);
        }
    };

    const getMethodIcon = (type: string) => {
        switch (type) {
            case 'momo':
                return <Smartphone className="h-6 w-6" />;
            case 'bank':
                return <CreditCard className="h-6 w-6" />;
            default:
                return <Wallet className="h-6 w-6" />;
        }
    };

    if (isLoading) {
        return <div className="flex justify-center p-8"><Spinner className="h-10 w-10" /></div>;
    }

    const isEmailVerified = user?.email_verified_at || (user as any)?.emailVerified;
    const requireEmailVerification = (import.meta.env.VITE_REQUIRE_EMAIL_VERIFICATION === 'true') || false;
    
    return (
        <div className="space-y-6">
            {/* Email verification notice (only when feature flag enabled) */}
            {user && requireEmailVerification && !isEmailVerified && (
                <Alert className="border-yellow-200 bg-yellow-50 dark:bg-yellow-950/20 dark:border-yellow-800 rounded-2xl">
                    <Info className="h-5 w-5 text-yellow-600 dark:text-yellow-400" />
                    <AlertDescription className="text-yellow-900 dark:text-yellow-100">
                        <div className="flex flex-col gap-2">
                            <p className="font-semibold">Vui lòng xác thực email trước khi nạp tiền</p>
                            <p className="text-sm">Để nạp tiền, bạn cần xác thực email của mình. Vui lòng vào <Link to={PATHS.PROFILE} className="underline font-semibold">Cài đặt &gt; Xác thực Email</Link> để thực hiện xác thực.</p>
                        </div>
                    </AlertDescription>
                </Alert>
            )}
            
            {/* Số dư hiện tại - Compact */}
            {user && (
                <div className="flex items-center justify-between p-4 bg-muted/50 rounded-2xl border">
                    <span className="text-sm text-muted-foreground flex items-center gap-2">
                        <span>💰</span>
                        Số dư hiện tại:
                    </span>
                    <span className="text-xl font-bold text-primary">{formatCurrency(user.balance || 0)}</span>
                </div>
            )}

            {/* Form nhập số tiền - Compact */}
            <Card className="rounded-3xl">
                <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                        <span className="text-xl">💳</span>
                        Nạp tiền vào tài khoản
                    </CardTitle>
                </CardHeader>
                <CardContent className="p-6 space-y-4">
                    <div className="space-y-3">
                        <Label htmlFor="amount" className="text-base font-semibold">Số tiền cần nạp (VNĐ)</Label>
                        <Input
                            id="amount"
                            type="text"
                            inputMode="numeric"
                            value={amountInput}
                            onChange={handleAmountChange}
                            onBlur={handleAmountBlur}
                            placeholder="Nhập số tiền"
                            className="text-xl font-bold h-14 text-center"
                        />
                        <p className="text-xs text-muted-foreground text-center">
                            Tối thiểu: 10,000 VNĐ - Tối đa: 50,000,000 VNĐ
                        </p>
                    </div>

                    {/* Nút số tiền nhanh */}
                    <div className="space-y-2">
                        <Label className="text-sm text-muted-foreground">Chọn nhanh:</Label>
                        <div className="flex flex-wrap gap-2">
                            {QUICK_AMOUNTS.map((quickAmount) => (
                                <Button
                                    key={quickAmount}
                                    variant={amount === quickAmount ? "default" : "outline"}
                                    size="sm"
                                    onClick={() => handleQuickAmount(quickAmount)}
                                    className="rounded-xl"
                                >
                                    {formatCurrency(quickAmount)}
                                </Button>
                            ))}
                        </div>
                    </div>
                </CardContent>
            </Card>

            {/* Danh sách phương thức thanh toán - Card Style */}
            <div className="space-y-4">
                <Label className="text-base font-semibold">Chọn phương thức thanh toán</Label>
                {methods && methods.length > 0 ? (
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        {methods.map((method, index) => {
                            const isSelected = selectedMethod?.id === method.id;
                            const gradientColors = method.type === 'momo' 
                                ? 'from-pink-500/20 via-purple-500/20 to-pink-500/20'
                                : 'from-blue-500/20 via-cyan-500/20 to-blue-500/20';
                            
                            return (
                                <motion.div
                                    key={method.id}
                                    initial={{ opacity: 0, y: 20 }}
                                    animate={{ opacity: 1, y: 0 }}
                                    transition={{ duration: 0.3, delay: index * 0.1 }}
                                    whileHover={{ scale: 1.02, y: -2 }}
                                >
                                    <Card
                                        className={`cursor-pointer transition-all overflow-hidden h-full ${
                                            isSelected
                                                ? 'border-primary border-2 ring-2 ring-primary/30 shadow-lg shadow-primary/10'
                                                : 'border hover:border-primary/60 hover:shadow-md'
                                        } ${!method.is_active ? 'opacity-50 cursor-not-allowed' : ''} rounded-3xl`}
                                        onClick={() => method.is_active && setSelectedMethod(method)}
                                    >
                                        {/* Gradient Header */}
                                        <div className={`h-24 bg-gradient-to-r ${gradientColors} relative`}>
                                            <div className="absolute bottom-3 left-4">
                                                <Badge variant="secondary" className="rounded-lg">
                                                    {method.type === 'momo' ? 'Ví điện tử' : 'Ngân hàng'}
                                                </Badge>
                                            </div>
                                            {isSelected && (
                                                <div className="absolute top-3 right-3 h-6 w-6 rounded-full bg-primary flex items-center justify-center ring-2 ring-white">
                                                    <div className="h-2.5 w-2.5 rounded-full bg-white" />
                                                </div>
                                            )}
                                        </div>
                                        
                                        <CardContent className="p-4">
                                            <div className="flex items-center gap-3">
                                                <div className={`p-3 rounded-xl transition-all ${
                                                    isSelected
                                                        ? 'bg-primary text-white shadow-lg'
                                                        : 'bg-muted text-muted-foreground'
                                                }`}>
                                                    {getMethodIcon(method.type)}
                                                </div>
                                                <div className="flex-1">
                                                    <p className={`font-semibold text-lg ${
                                                        isSelected ? 'text-primary' : 'text-foreground'
                                                    }`}>
                                                        {method.name}
                                                    </p>
                                                    {!method.is_active && (
                                                        <Badge variant="secondary" className="text-xs mt-1">Tạm ngưng</Badge>
                                                    )}
                                                </div>
                                            </div>
                                        </CardContent>
                                    </Card>
                                </motion.div>
                            );
                        })}
                    </div>
                ) : (
                    <p className="text-center text-muted-foreground p-8">
                        {t('depositPage.noMethods', { defaultValue: 'Không có phương thức thanh toán nào khả dụng.' })}
                    </p>
                )}
            </div>

            {/* Nút nạp tiền */}
            <Button
                onClick={handleDeposit}
                disabled={!selectedMethod || !selectedMethod.is_active || isSubmitting || amount < 10000 || (requireEmailVerification && !isEmailVerified)}
                className="w-full rounded-2xl h-14 text-lg"
                size="lg"
            >
                {isSubmitting ? (
                    <>
                        <Spinner className="h-5 w-5 mr-2" />
                        Đang xử lý...
                    </>
                ) : (
                    <>
                        <Wallet className="h-5 w-5 mr-2" />
                        Nạp {formatCurrency(amount)}
                        <ArrowRight className="h-5 w-5 ml-2" />
                    </>
                )}
            </Button>

            {/* Modal hướng dẫn thanh toán */}
            {showInstructions && selectedMethod && user && (
                <PaymentInstructionsModal
                    method={selectedMethod}
                    user={user}
                    amount={amount}
                    onClose={() => {
                        setShowInstructions(false);
                        setSelectedMethod(null);
                    }}
                />
            )}
        </div>
    );
}
