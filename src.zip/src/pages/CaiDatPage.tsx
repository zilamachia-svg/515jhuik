import { NavLink, Outlet, useLocation } from 'react-router-dom';
import { motion } from 'framer-motion';
import { useLanguage } from '../contexts/LanguageContext';
import { usePageTitle } from '../contexts/PageTitleContext';
import { PATHS } from '../constants/paths';
import { Card, CardContent } from '@/components/ui/card';
import { cn } from '@/lib/utils';

export default function CaiDatPage() {
    const { t } = useLanguage();
    const location = useLocation();
    usePageTitle(t('sidebar.accountSettings'));

    const settingsNav = [
        { path: PATHS.PROFILE, label: 'Hồ sơ', icon: <span className="text-base">👤</span> },
        { path: PATHS.TASKS, label: 'Nhiệm vụ', icon: <span className="text-base">✅</span> },
        { path: PATHS.PREFERENCES, label: 'Tùy chọn', icon: <span className="text-base">⚙️</span> },
    ];

    const getNavLinkClass = ({ isActive }: { isActive: boolean }) =>
        cn(
            'flex items-center gap-3 rounded-xl px-4 py-2.5 text-sm font-medium transition-all duration-200',
            isActive
                ? 'bg-primary/10 text-primary shadow-sm'
                : 'text-muted-foreground hover:bg-muted hover:text-foreground'
        );

    return (
        <div className="space-y-6">
            {/* Banner */}
            <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5 }}
                className="overflow-hidden rounded-3xl bg-gradient-to-r from-purple-400/85 via-pink-400/85 to-rose-400/85 p-6 text-white"
            >
                <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
                    <div className="space-y-1">
                        <h2 className="text-2xl font-bold flex items-center gap-2">
                            <span className="text-2xl">⚙️</span>
                            Cài đặt Tài khoản
                        </h2>
                        <p className="text-sm text-white/80">
                            Quản lý thông tin cá nhân, nhiệm vụ và tùy chọn của bạn.
                        </p>
                    </div>
                    <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-white/20 backdrop-blur-md text-2xl">
                        ⚙️
                    </div>
                </div>
            </motion.div>

            <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
                <aside className="lg:col-span-1">
                    <Card className="rounded-2xl">
                        <CardContent className="p-3">
                            <nav className="flex flex-col gap-1">
                                {settingsNav.map(item => (
                                    <NavLink key={item.path} to={item.path} className={getNavLinkClass}>
                                        {item.icon}
                                        <span>{item.label}</span>
                                    </NavLink>
                                ))}
                            </nav>
                        </CardContent>
                    </Card>
                </aside>
                <div className="lg:col-span-3">
                    <Outlet />
                </div>
            </div>
        </div>
    );
}
