import { useState, useEffect, useRef } from 'react';
import { motion } from 'framer-motion';
import { usePageTitle } from '../contexts/PageTitleContext';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { BookOpen, ArrowRight, UserPlus, Wallet, ShoppingCart, Wrench, HelpCircle, Phone } from 'lucide-react';
import { BannerContent } from '@/components/BannerContent';
import { Link } from 'react-router-dom';
import { PATHS } from '../constants/paths';
import { cn } from '@/lib/utils';

export default function GuidePage() {
    usePageTitle('Hướng dẫn sử dụng - Hải Đăng Meta');
    const [activeSection, setActiveSection] = useState<string>('');
    const sectionRefs = useRef<{ [key: string]: HTMLElement | null }>({});

    const guides = [
        {
            id: 'dang-ky',
            title: 'Hướng dẫn đăng ký tài khoản',
            emoji: '✅',
            description: 'Cách tạo tài khoản và xác thực email',
            icon: <UserPlus className="h-4 w-4" />,
            steps: [
                'Truy cập trang đăng ký',
                'Điền thông tin cá nhân (họ tên, email, mật khẩu)',
                'Xác nhận email qua link được gửi đến hộp thư',
                'Đăng nhập và bắt đầu sử dụng dịch vụ',
            ],
        },
        {
            id: 'nap-tien',
            title: 'Hướng dẫn nạp tiền',
            emoji: '💡',
            description: 'Các bước nạp tiền vào tài khoản',
            icon: <Wallet className="h-4 w-4" />,
            steps: [
                'Vào mục "Nạp tiền" trên menu',
                'Chọn phương thức thanh toán (ngân hàng hoặc MoMo)',
                'Nhập số tiền muốn nạp (tối thiểu 10,000 VNĐ)',
                'Thực hiện chuyển khoản theo hướng dẫn',
                'Chờ xác nhận (thường trong 5-30 phút)',
            ],
        },
        {
            id: 'mua-hang',
            title: 'Hướng dẫn mua hàng',
            emoji: '📌',
            description: 'Quy trình mua sản phẩm trên website',
            icon: <ShoppingCart className="h-4 w-4" />,
            steps: [
                'Duyệt sản phẩm tại cửa hàng',
                'Chọn sản phẩm và xem chi tiết',
                'Nhấn "Mua ngay" và xác nhận đơn hàng',
                'Thanh toán bằng số dư hoặc phương thức khác',
                'Nhận thông tin sản phẩm qua email và trong tài khoản',
            ],
        },
        {
            id: 'cong-cu',
            title: 'Hướng dẫn sử dụng công cụ',
            emoji: '🧠',
            description: 'Cách sử dụng các công cụ hỗ trợ',
            icon: <Wrench className="h-4 w-4" />,
            steps: [
                'Truy cập mục "Công cụ" trên menu',
                'Chọn công cụ cần sử dụng (Get 2FA, Check Live FB)',
                'Nhập thông tin theo yêu cầu',
                'Nhấn "Thực hiện" và chờ kết quả',
            ],
        },
    ];

    const scrollToSection = (id: string) => {
        const element = sectionRefs.current[id];
        if (element) {
            const offset = 100; // Offset for sticky header
            const elementPosition = element.getBoundingClientRect().top;
            const offsetPosition = elementPosition + window.pageYOffset - offset;

            window.scrollTo({
                top: offsetPosition,
                behavior: 'smooth',
            });
        }
    };

    // Handle scroll to detect active section
    useEffect(() => {
        const handleScroll = () => {
            const scrollPosition = window.scrollY + 200; // Offset for header

            for (const guide of guides) {
                const element = sectionRefs.current[guide.id];
                if (element) {
                    const { offsetTop, offsetHeight } = element;
                    if (scrollPosition >= offsetTop && scrollPosition < offsetTop + offsetHeight) {
                        setActiveSection(guide.id);
                        // Update URL hash without scrolling
                        if (window.location.hash !== `#${guide.id}`) {
                            window.history.replaceState(null, '', `#${guide.id}`);
                        }
                        break;
                    }
                }
            }
        };

        // Check initial hash on mount
        const hash = window.location.hash.slice(1);
        if (hash && guides.some(g => g.id === hash)) {
            setTimeout(() => scrollToSection(hash), 300);
        }

        window.addEventListener('scroll', handleScroll, { passive: true });
        handleScroll(); // Initial check

        return () => window.removeEventListener('scroll', handleScroll);
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, []);

    return (
        <div className="space-y-8">
            {/* Banner với nội dung */}
            <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5 }}
                className="overflow-hidden rounded-3xl bg-gradient-to-r from-indigo-400/85 via-purple-400/85 to-pink-400/85 p-8 text-white"
            >
                <div className="flex flex-col gap-6 md:flex-row md:items-center md:justify-between">
                    <div className="space-y-4">
                        <div className="flex items-center gap-3">
                            <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-white/20 backdrop-blur-md">
                                <BookOpen className="h-6 w-6" />
                            </div>
                            <div>
                                <h1 className="text-3xl font-bold flex items-center gap-2">
                                    <span className="text-3xl">📚</span>
                                    Hướng dẫn sử dụng
                                </h1>
                                <p className="text-white/80">Hướng dẫn chi tiết cách sử dụng dịch vụ</p>
                            </div>
                        </div>
                    </div>
                </div>
                <BannerContent />
            </motion.div>

            {/* Layout với Sidebar và Content */}
            <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
                {/* Sidebar Mục lục - Timeline */}
                <aside className="lg:col-span-1">
                    <Card className="sticky top-24 rounded-2xl">
                        <CardHeader>
                            <CardTitle className="text-lg flex items-center gap-2">
                                <span>📑</span>
                                Mục lục
                            </CardTitle>
                        </CardHeader>
                        <CardContent className="p-0">
                            <nav className="relative">
                                {/* Timeline line */}
                                <div className="absolute left-4 top-0 bottom-0 w-0.5 bg-border" />
                                
                                <ul className="space-y-1 p-4">
                                    {guides.map((guide, index) => (
                                        <li key={guide.id}>
                                            <a
                                                href={`#${guide.id}`}
                                                onClick={(e) => {
                                                    e.preventDefault();
                                                    scrollToSection(guide.id);
                                                }}
                                                className={cn(
                                                    "relative flex w-full items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-medium transition-all duration-200",
                                                    "hover:bg-muted hover:text-foreground",
                                                    activeSection === guide.id
                                                        ? "bg-primary/10 text-primary shadow-sm"
                                                        : "text-muted-foreground"
                                                )}
                                            >
                                                {/* Timeline dot */}
                                                <div className={cn(
                                                    "relative z-10 flex h-8 w-8 shrink-0 items-center justify-center rounded-full border-2 transition-all text-lg",
                                                    activeSection === guide.id
                                                        ? "border-primary bg-primary text-white shadow-md"
                                                        : "border-muted bg-background"
                                                )}>
                                                    {guide.emoji}
                                                </div>
                                                <span className="flex-1 text-left truncate">{guide.title}</span>
                                            </a>
                                        </li>
                                    ))}
                                </ul>
                            </nav>
                        </CardContent>
                    </Card>
                </aside>

                {/* Main Content */}
                <div className="lg:col-span-3 space-y-6">
                    {guides.map((guide, index) => (
                        <motion.div
                            key={guide.id}
                            id={guide.id}
                            ref={(el) => { sectionRefs.current[guide.id] = el; }}
                            initial={{ opacity: 0, y: 20 }}
                            animate={{ opacity: 1, y: 0 }}
                            transition={{ duration: 0.3, delay: index * 0.1 }}
                        >
                            <Card className="rounded-3xl">
                                <CardHeader>
                                    <CardTitle className="flex items-center gap-3">
                                        <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-primary/10 text-primary text-xl">
                                            {guide.emoji}
                                        </div>
                                        <a 
                                            id={guide.id}
                                            href={`#${guide.id}`}
                                            className="hover:underline"
                                            onClick={(e) => {
                                                e.preventDefault();
                                                scrollToSection(guide.id);
                                            }}
                                        >
                                            {guide.title}
                                        </a>
                                    </CardTitle>
                                </CardHeader>
                                <CardContent>
                                    <p className="text-sm text-muted-foreground mb-6">{guide.description}</p>
                                    <ol className="space-y-3">
                                        {guide.steps.map((step, stepIndex) => (
                                            <li key={stepIndex} className="flex gap-4">
                                                <span className="flex h-7 w-7 shrink-0 items-center justify-center rounded-full bg-primary/10 text-primary font-semibold text-sm">
                                                    {stepIndex + 1}
                                                </span>
                                                <span className="flex-1 pt-1 text-sm text-foreground">{step}</span>
                                            </li>
                                        ))}
                                    </ol>
                                </CardContent>
                            </Card>
                        </motion.div>
                    ))}
                </div>
            </div>

            {/* FAQ nhanh */}
            <Card className="rounded-3xl">
                <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                        <span className="text-xl">❓</span>
                        Câu hỏi thường gặp
                    </CardTitle>
                </CardHeader>
                <CardContent>
                    <p className="text-muted-foreground mb-6">
                        Bạn có thắc mắc khác? Hãy xem thêm các câu hỏi thường gặp hoặc liên hệ hỗ trợ.
                    </p>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                        <Link to={PATHS.FAQ}>
                            <motion.div
                                whileHover={{ scale: 1.02 }}
                                whileTap={{ scale: 0.98 }}
                            >
                                <Card className="cursor-pointer rounded-2xl border-2 hover:border-primary/50 transition-all h-full">
                                    <CardContent className="p-5">
                                        <div className="flex items-center gap-3">
                                            <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-primary/10 text-primary">
                                                <HelpCircle className="h-5 w-5" />
                                            </div>
                                            <div className="flex-1">
                                                <p className="font-semibold">Xem FAQ đầy đủ</p>
                                                <p className="text-xs text-muted-foreground">Tìm câu trả lời cho các câu hỏi thường gặp</p>
                                            </div>
                                            <ArrowRight className="h-4 w-4 text-muted-foreground" />
                                        </div>
                                    </CardContent>
                                </Card>
                            </motion.div>
                        </Link>
                        <Link to={PATHS.CONTACT}>
                            <motion.div
                                whileHover={{ scale: 1.02 }}
                                whileTap={{ scale: 0.98 }}
                            >
                                <Card className="cursor-pointer rounded-2xl border-2 hover:border-primary/50 transition-all h-full">
                                    <CardContent className="p-5">
                                        <div className="flex items-center gap-3">
                                            <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-primary/10 text-primary">
                                                <Phone className="h-5 w-5" />
                                            </div>
                                            <div className="flex-1">
                                                <p className="font-semibold">Liên hệ hỗ trợ</p>
                                                <p className="text-xs text-muted-foreground">Nhận hỗ trợ trực tiếp từ đội ngũ</p>
                                            </div>
                                            <ArrowRight className="h-4 w-4 text-muted-foreground" />
                                        </div>
                                    </CardContent>
                                </Card>
                            </motion.div>
                        </Link>
                    </div>
                </CardContent>
            </Card>
        </div>
    );
}