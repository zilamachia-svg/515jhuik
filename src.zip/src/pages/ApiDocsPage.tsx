import { useState, useEffect } from 'react';
import { useUser } from '../services/UserContext';
import { Link } from 'react-router-dom';
import { PATHS } from '../constants/paths';
import { usePageTitle } from '../contexts/PageTitleContext';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Info, CheckCircle, BookOpen } from 'lucide-react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { SwaggerUI } from '@/components/SwaggerUI';

export default function ApiDocsPage() {
    const { user } = useUser();
    const [openApiSpec, setOpenApiSpec] = useState<any>(null);
    const disableSwagger = import.meta.env.VITE_DISABLE_SWAGGER === 'true';
    usePageTitle("Tài liệu API");

    useEffect(() => {
        // Load OpenAPI spec from public folder
        fetch('/api-docs/openapi.json')
            .then(res => res.json())
            .then(data => {
                // Update server URL based on environment
                if (data.servers && data.servers.length > 0) {
                    const apiBaseUrl = import.meta.env.VITE_API_BASE_URL || 'https://api.haidangmeta.com';
                    data.servers[0].url = `${apiBaseUrl}/api/v1`;
                }
                setOpenApiSpec(data);
            })
            .catch(err => {
                console.error('Failed to load OpenAPI spec:', err);
                // Fallback to inline spec
                setOpenApiSpec(getDefaultOpenApiSpec());
            });
    }, []);

    const getDefaultOpenApiSpec = () => {
        const apiBaseUrl = import.meta.env.VITE_API_BASE_URL || 'https://api.haidangmeta.com';
        return {
            openapi: "3.0.0",
            info: {
                title: "Hải Đăng Meta API",
                version: "1.0.0",
                description: "API documentation for Hải Đăng Meta - Facebook Account Store"
            },
            servers: [
                {
                    url: `${apiBaseUrl}/api/v1`,
                    description: "API Server"
                }
            ],
            paths: {}
        };
    };

    return (
        <div className="space-y-6">
            <Card>
                <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                        <BookOpen className="h-5 w-5" />
                        Tài liệu API
                    </CardTitle>
                </CardHeader>
                <CardContent className="prose dark:prose-invert max-w-none">
                    <p>Chào mừng bạn đến với tài liệu API của Hải Đăng Meta. API của chúng tôi cho phép bạn tích hợp các dịch vụ của chúng tôi vào ứng dụng của riêng bạn một cách tự động.</p>
                    
                    <h3>Xác thực</h3>
                    <p>Tất cả các yêu cầu đến API đều phải được xác thực bằng API Key. Bạn có thể tạo và quản lý API Key của mình trong trang quản trị.</p>
                    
                    {!user || user.role !== 'admin' ? (
                        <Alert>
                            <Info className="h-4 w-4" />
                            <AlertDescription>
                                Bạn cần có quyền quản trị viên để tạo và quản lý API key.
                            </AlertDescription>
                        </Alert>
                    ) : (
                        <Alert variant="default">
                            <CheckCircle className="h-4 w-4" />
                            <AlertDescription>
                                Bạn có thể quản lý API key của mình tại <Link to={PATHS.ADMIN_API_KEYS} className="font-bold underline">đây</Link>.
                            </AlertDescription>
                        </Alert>
                    )}
                    
                    <p className="mt-4">
                        Thêm header <code>Authorization</code> vào mỗi request với giá trị <code>Bearer YOUR_API_KEY</code>.
                    </p>
                </CardContent>
            </Card>

            <Card>
                <CardContent className="p-0">
                    <Tabs defaultValue={disableSwagger ? "info" : "swagger"} className="w-full">
                        <TabsList className="w-full justify-start rounded-none border-b">
                            {!disableSwagger && <TabsTrigger value="swagger">Swagger UI</TabsTrigger>}
                            <TabsTrigger value="info">Thông tin</TabsTrigger>
                        </TabsList>

                        {!disableSwagger && (
                            <TabsContent value="swagger" className="mt-0">
                                {openApiSpec ? (
                                    <div className="min-h-[600px]">
                                        <SwaggerUI spec={openApiSpec} />
                                    </div>
                                ) : (
                                    <div className="flex items-center justify-center h-[600px]">
                                        <div className="text-center">
                                            <p className="text-muted-foreground">Đang tải tài liệu API...</p>
                                        </div>
                                    </div>
                                )}
                            </TabsContent>
                        )}

                        <TabsContent value="info" className="p-6">
                            <div className="space-y-4">
                                <div>
                                    <h3 className="font-semibold mb-2">Base URL</h3>
                                    <code className="block p-2 bg-muted rounded">
                                        {import.meta.env.VITE_API_BASE_URL || 'https://api.haidangmeta.com'}/api/v1
                                    </code>
                                </div>
                                
                                <div>
                                    <h3 className="font-semibold mb-2">Authentication</h3>
                                    <p className="text-sm text-muted-foreground">
                                        Sử dụng Bearer token trong header Authorization:
                                    </p>
                                    <code className="block p-2 bg-muted rounded mt-2">
                                        Authorization: Bearer YOUR_API_KEY
                                    </code>
                                </div>
                                
                                <div>
                                    <h3 className="font-semibold mb-2">Response Format</h3>
                                    <p className="text-sm text-muted-foreground">
                                        Tất cả responses đều trả về JSON format.
                                    </p>
                                </div>
                                
                                <div>
                                    <h3 className="font-semibold mb-2">Rate Limiting</h3>
                                    <p className="text-sm text-muted-foreground">
                                        API có giới hạn số lượng requests. Vui lòng xem chi tiết trong Swagger UI.
                                    </p>
                                </div>
                            </div>
                        </TabsContent>
                    </Tabs>
                </CardContent>
            </Card>
        </div>
    );
}
