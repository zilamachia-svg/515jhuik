import { lazy } from 'react';

const DashboardPage = lazy(() => import('./DashboardPage'));

export default function HomePage() {
    // The home page is now the dashboard page.
    return <DashboardPage />;
}
