import { useState, useEffect, useCallback } from 'react';
import { authenticator } from 'otplib';
import { usePageTitle } from '../contexts/PageTitleContext';
import { useLanguage } from '../contexts/LanguageContext';
import { Card, CardHeader, CardTitle, CardContent, CardFooter } from '@/components/ui/card';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { 
    Copy, 
    Check, 
    RefreshCw, 
    History, 
    Save, 
    Trash2, 
    Key, 
    ShieldCheck,
    AlertCircle
} from 'lucide-react';
import * as TabsPrimitive from "@radix-ui/react-tabs";
import {
    AlertDialog,
    AlertDialogAction,
    AlertDialogCancel,
    AlertDialogContent,
    AlertDialogDescription,
    AlertDialogFooter,
    AlertDialogHeader,
    AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { useCopyToClipboard } from '../hooks/useCopyToClipboard';
import { toast } from 'sonner';

interface SavedSecret {
    key: string;
    label: string;
    timestamp: number;
}

export default function Get2FAPage() {
    const { t } = useLanguage();
    usePageTitle(t('sidebar.get2FA'));

    const [secretKey, setSecretKey] = useState('');
    const [keyLabel, setKeyLabel] = useState('');
    const [totpCode, setTotpCode] = useState('');
    const [metaCode, setMetaCode] = useState('');
    const [timeLeft, setTimeLeft] = useState(30);
    const [activeTab, setActiveTab] = useState<'current' | 'saved'>('current');
    const [savedSecrets, setSavedSecrets] = useState<SavedSecret[]>(() => {
        const saved = localStorage.getItem('2fa_secrets');
        return saved ? JSON.parse(saved) : [];
    });
    const [selectedSecret, setSelectedSecret] = useState<SavedSecret | null>(null);
    const [showDeleteDialog, setShowDeleteDialog] = useState(false);
    const [showSaveDialog, setShowSaveDialog] = useState(false);
    const [copy, isCopied] = useCopyToClipboard();

    // Hàm validate Base32
    const validateBase32 = useCallback((input: string): string => {
        // Normalize: remove spaces and hyphens, uppercase
        let cleaned = input.replace(/[\s-]/g, '').toUpperCase();

        // Allow only A-Z and 2-7 plus optional padding
        cleaned = cleaned.replace(/[^A-Z2-7=]/g, '');

        // Heuristic: if the string looks like an alphanumeric long ID (not Base32), try to detect and warn
        if (/^[0-9A-Z]{30,}$/.test(cleaned) && !/[2-7]/.test(cleaned)) {
            // Likely not valid Base32
            return cleaned; // let generation fail and show error
        }

        // Fix padding to multiple of 8 if needed
        const padLength = (8 - (cleaned.length % 8)) % 8;
        if (padLength > 0 && !cleaned.includes('=')) {
            cleaned = cleaned + '='.repeat(padLength);
        }

        return cleaned;
    }, []);

    const generateCode = useCallback(() => {
        if (!secretKey.trim()) {
            setTotpCode('');
            return;
        }
        try {
            const cleanedKey = validateBase32(secretKey);
            console.log('Processing key:', {
                original: secretKey,
                cleaned: cleanedKey,
                length: cleanedKey.length
            });

            if (cleanedKey.length < 16) {
                throw new Error("Mã bí mật quá ngắn. Cần ít nhất 16 ký tự.");
            }

            try {
                // Cấu hình authenticator
                authenticator.options = {
                    digits: 6,
                    step: 30,
                    window: 1
                };
                
                // Generate mã TOTP
                const code = authenticator.generate(cleanedKey);
                console.log('Generated TOTP:', code);
                setTotpCode(code);
                
                // Tạo mã 4 số bằng cách lấy 4 số cuối
                const metaCode = code.slice(-4);
                setMetaCode(metaCode);
                
            } catch (error) {
                console.error('Error generating code:', error);
                setTotpCode('Mã không hợp lệ');
                setMetaCode('');
                toast.error("Mã bí mật không hợp lệ. Vui lòng kiểm tra lại.");
            }
        } catch (error) {
            console.error("Invalid 2FA secret", error);
            setTotpCode('Mã không hợp lệ');
            toast.error("Mã bí mật không hợp lệ. Vui lòng kiểm tra lại. Mã phải ở định dạng Base32 và đủ dài.");
        }
    }, [secretKey, validateBase32]);

    const handleSaveSecret = useCallback(() => {
        if (!secretKey.trim() || !keyLabel.trim()) {
            toast.error("Vui lòng nhập cả mã bí mật và nhãn!");
            return;
        }

        const newSecret: SavedSecret = {
            key: secretKey,
            label: keyLabel,
            timestamp: Date.now()
        };

        const updatedSecrets = [...savedSecrets, newSecret];
        setSavedSecrets(updatedSecrets);
        localStorage.setItem('2fa_secrets', JSON.stringify(updatedSecrets));
        setShowSaveDialog(false);
        setKeyLabel('');
        toast.success('Đã lưu mã bí mật!');
    }, [secretKey, keyLabel, savedSecrets]);

    const handleDeleteSecret = useCallback((secret: SavedSecret) => {
        setSelectedSecret(secret);
        setShowDeleteDialog(true);
    }, []);

    const confirmDelete = useCallback(() => {
        if (selectedSecret) {
            const updatedSecrets = savedSecrets.filter(s => s.key !== selectedSecret.key);
            setSavedSecrets(updatedSecrets);
            localStorage.setItem('2fa_secrets', JSON.stringify(updatedSecrets));
            setShowDeleteDialog(false);
            toast.success('Đã xóa mã bí mật!');
        }
    }, [selectedSecret, savedSecrets]);

    const loadSecret = useCallback((secret: SavedSecret) => {
        setSecretKey(secret.key);
        setActiveTab('current');
    }, []);

    // Generate code whenever the secret key changes
    useEffect(() => {
        generateCode();
    }, [generateCode]);

    // Set up a single interval to manage the timer and code regeneration
    useEffect(() => {
        const timerId = setInterval(() => {
            const epoch = Math.round(new Date().getTime() / 1000.0);
            const newTimeLeft = 30 - (epoch % 30);
            setTimeLeft(newTimeLeft);
            if (newTimeLeft === 30) {
                generateCode();
            }
        }, 1000);

        // Initial call to set timer immediately
        const epoch = Math.round(new Date().getTime() / 1000.0);
        setTimeLeft(30 - (epoch % 30));

        return () => clearInterval(timerId);
    }, [generateCode]);


    return (
        <>
            <Card>
                <CardHeader>
                    <CardTitle className="flex items-center justify-between">
                        <span className="flex items-center gap-2">
                            <ShieldCheck className="h-5 w-5 text-primary" />
                            {t('sidebar.get2FA')}
                        </span>
                        {activeTab === 'current' && secretKey && (
                            <Button 
                                variant="outline" 
                                size="sm"
                                className="gap-2"
                                onClick={() => setShowSaveDialog(true)}
                            >
                                <Save size={16} />
                                Lưu mã
                            </Button>
                        )}
                    </CardTitle>
                </CardHeader>
                <CardContent>
                    <TabsPrimitive.Root value={activeTab} onValueChange={(value: string) => setActiveTab(value as 'current' | 'saved')} className="space-y-4">
                        <TabsPrimitive.List className="grid w-full grid-cols-2">
                            <TabsPrimitive.Trigger value="current" className="gap-2">
                                <Key size={16} />
                                Tạo mã
                            </TabsPrimitive.Trigger>
                            <TabsPrimitive.Trigger value="saved" className="gap-2">
                                <History size={16} />
                                Đã lưu ({savedSecrets.length})
                            </TabsPrimitive.Trigger>
                        </TabsPrimitive.List>

                        <TabsPrimitive.Content value="current" className="space-y-4">
                            <div className="space-y-2">
                                <Label htmlFor="secret-key" className="flex items-center gap-2">
                                    Mã bí mật 2FA (Base32)
                                    <AlertCircle className="h-4 w-4 text-muted-foreground" />
                                </Label>
                                <Input
                                    id="secret-key"
                                    value={secretKey}
                                    onChange={(e) => setSecretKey(e.target.value)}
                                    placeholder="Nhập mã bí mật của bạn..."
                                    className="font-mono"
                                />
                            </div>

                            {totpCode && (
                                <div className="space-y-4 animate-in fade-in-50">
                                    {/* TOTP 6 số */}
                                    <div className="space-y-2">
                                        <Label className="flex items-center justify-between">
                                            <span>Mã 2FA (6 số)</span>
                                            <Badge variant="outline" className="font-mono">
                                                {timeLeft}s
                                            </Badge>
                                        </Label>
                                        <div className="relative">
                                            <div 
                                                className="absolute inset-0 bg-primary/10 rounded-lg"
                                            />
                                            <div className="flex items-center gap-2 relative">
                                                <div className="flex-1 text-3xl font-bold tracking-widest text-center bg-muted p-6 rounded-lg font-mono">
                                                    {totpCode}
                                                </div>
                                                <Button 
                                                    variant="outline" 
                                                    size="icon" 
                                                    onClick={() => copy(totpCode, 'Đã sao chép mã 6 số!')} 
                                                    disabled={totpCode === 'Mã không hợp lệ'}
                                                >
                                                    {isCopied ? <Check size={16} /> : <Copy size={16} />}
                                                </Button>
                                            </div>
                                        </div>
                                    </div>
                                    
                                    {/* Meta code 4 số */}
                                    <div className="space-y-2">
                                        <Label className="flex items-center justify-between">
                                            <span>Mã Meta (4 số)</span>
                                            <Badge variant="outline" className="font-mono">
                                                4 số
                                            </Badge>
                                        </Label>
                                        <div className="flex items-center gap-2">
                                            <div className="flex-1 text-3xl font-bold tracking-widest text-center bg-muted p-6 rounded-lg font-mono">
                                                {metaCode}
                                            </div>
                                            <Button 
                                                variant="outline" 
                                                size="icon" 
                                                onClick={() => copy(metaCode, 'Đã sao chép mã 4 số!')} 
                                                disabled={!metaCode}
                                            >
                                                {isCopied ? <Check size={16} /> : <Copy size={16} />}
                                            </Button>
                                        </div>
                                    </div>
                                </div>
                            )}
                        </TabsPrimitive.Content>

                        <TabsPrimitive.Content value="saved" className="space-y-4">
                            {savedSecrets.length === 0 ? (
                                <div className="text-center py-8 text-muted-foreground">
                                    <History className="h-12 w-12 mx-auto mb-4 opacity-50" />
                                    <p>Chưa có mã bí mật nào được lưu</p>
                                </div>
                            ) : (
                                <div className="space-y-2">
                                    {savedSecrets.map((secret) => (
                                        <Card key={secret.key}>
                                            <CardContent className="p-4 flex items-center justify-between">
                                                <div className="space-y-1">
                                                    <p className="font-medium">{secret.label}</p>
                                                    <p className="text-sm text-muted-foreground font-mono">
                                                        {secret.key.slice(0, 4)}...{secret.key.slice(-4)}
                                                    </p>
                                                </div>
                                                <div className="flex gap-2">
                                                    <Button 
                                                        variant="outline" 
                                                        size="icon"
                                                        onClick={() => loadSecret(secret)}
                                                    >
                                                        <Key size={16} />
                                                    </Button>
                                                    <Button 
                                                        variant="outline" 
                                                        size="icon"
                                                        onClick={() => handleDeleteSecret(secret)}
                                                    >
                                                        <Trash2 size={16} className="text-destructive" />
                                                    </Button>
                                                </div>
                                            </CardContent>
                                        </Card>
                                    ))}
                                </div>
                            )}
                        </TabsPrimitive.Content>
                    </TabsPrimitive.Root>
                </CardContent>
                <CardFooter>
                    <Button 
                        onClick={generateCode} 
                        className="w-full" 
                        size="lg"
                        disabled={!secretKey.trim()}
                    >
                        <RefreshCw size={16} className="mr-2" />
                        Tạo mã mới
                    </Button>
                </CardFooter>
            </Card>

            <AlertDialog open={showSaveDialog} onOpenChange={setShowSaveDialog}>
                <AlertDialogContent>
                    <AlertDialogHeader>
                        <AlertDialogTitle>Lưu mã bí mật</AlertDialogTitle>
                        <AlertDialogDescription>
                            Nhập nhãn để dễ dàng nhận biết mã này sau này.
                        </AlertDialogDescription>
                    </AlertDialogHeader>
                    <div className="py-4">
                        <Label htmlFor="key-label">Nhãn</Label>
                        <Input
                            id="key-label"
                            value={keyLabel}
                            onChange={(e) => setKeyLabel(e.target.value)}
                            placeholder="VD: Facebook, Gmail,..."
                            className="mt-2"
                        />
                    </div>
                    <AlertDialogFooter>
                        <AlertDialogCancel>Hủy</AlertDialogCancel>
                        <AlertDialogAction onClick={handleSaveSecret}>
                            <Save size={16} className="mr-2" />
                            Lưu
                        </AlertDialogAction>
                    </AlertDialogFooter>
                </AlertDialogContent>
            </AlertDialog>

            <AlertDialog open={showDeleteDialog} onOpenChange={setShowDeleteDialog}>
                <AlertDialogContent>
                    <AlertDialogHeader>
                        <AlertDialogTitle>Xóa mã bí mật</AlertDialogTitle>
                        <AlertDialogDescription>
                            Bạn có chắc chắn muốn xóa mã bí mật &quot;{selectedSecret?.label}&quot; không?
                            Hành động này không thể hoàn tác.
                        </AlertDialogDescription>
                    </AlertDialogHeader>
                    <AlertDialogFooter>
                        <AlertDialogCancel>Hủy</AlertDialogCancel>
                        <AlertDialogAction onClick={confirmDelete} className="bg-destructive text-destructive-foreground hover:bg-destructive/90">
                            <Trash2 size={16} className="mr-2" />
                            Xóa
                        </AlertDialogAction>
                    </AlertDialogFooter>
                </AlertDialogContent>
            </AlertDialog>
        </>
    );
}