import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { toast } from 'sonner';
import { Faq, ApiError } from '../types';
import apiClient from '../services/apiClient';
import { formatApiErrorForToast } from '../utils';
import { usePageTitle } from '../contexts/PageTitleContext';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Spinner } from '@/components/ui/spinner';
import { HelpCircle } from 'lucide-react';
import { BannerContent } from '@/components/BannerContent';
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";

export default function FaqPage() {
    usePageTitle("Câu hỏi thường gặp (FAQ) - Hải Đăng Meta");
    const [faqs, setFaqs] = useState<Faq[]>([]);
    const [isLoading, setIsLoading] = useState(true);

    useEffect(() => {
        const fetchFaqs = async () => {
            setIsLoading(true);
            try {
                const response = await apiClient.get('/faq');
                setFaqs(response.data.faqs);
            } catch (error) {
                toast.error(formatApiErrorForToast(error as ApiError, 'Không thể tải FAQ.'));
            } finally {
                setIsLoading(false);
            }
        };
        fetchFaqs();
    }, []);

    if (isLoading) {
        return <div className="flex justify-center p-8"><Spinner className="h-10 w-10" /></div>;
    }

    return (
        <div className="space-y-8">
            {/* Banner với nội dung */}
            <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5 }}
                className="overflow-hidden rounded-3xl bg-gradient-to-r from-orange-400/85 via-red-400/85 to-pink-400/85 p-8 text-white"
            >
                <div className="flex flex-col gap-6 md:flex-row md:items-center md:justify-between">
                    <div className="space-y-4">
                        <div className="flex items-center gap-3">
                            <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-white/20 backdrop-blur-md">
                                <HelpCircle className="h-6 w-6" />
                            </div>
                            <div>
                                <h1 className="text-3xl font-bold flex items-center gap-2">
                                    <span className="text-3xl">❓</span>
                                    Câu hỏi thường gặp
                                </h1>
                                <p className="text-white/80">Giải đáp các thắc mắc phổ biến của khách hàng</p>
                            </div>
                        </div>
                    </div>
                </div>
                <BannerContent />
            </motion.div>

            {/* Nội dung FAQ */}
            <Card className="rounded-3xl">
                <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                        <span className="text-xl">💬</span>
                        Danh sách câu hỏi
                    </CardTitle>
                </CardHeader>
                <CardContent>
                    {faqs.length > 0 ? (
                        <Accordion type="single" collapsible className="w-full">
                            {faqs.map(faq => (
                                <AccordionItem key={faq.id} value={faq.id}>
                                    <AccordionTrigger className="text-left">{faq.question}</AccordionTrigger>
                                    <AccordionContent>
                                        <p className="prose prose-slate max-w-none text-muted-foreground">{faq.answer}</p>
                                    </AccordionContent>
                                </AccordionItem>
                            ))}
                        </Accordion>
                    ) : (
                        <p className="text-center p-8 text-muted-foreground">Chưa có câu hỏi nào.</p>
                    )}
                </CardContent>
            </Card>
        </div>
    );
}