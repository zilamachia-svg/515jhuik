import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { toast } from 'sonner';
import { Post, ApiError } from '../types';
import { usePageTitle } from '../contexts/PageTitleContext';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Spinner } from '@/components/ui/spinner';
import { PATHS } from '../constants/paths';
import apiClient from '../services/apiClient';
import { formatApiErrorForToast } from '../utils';

export default function PostListPage() {
    usePageTitle("📰 Bài viết");
    const [posts, setPosts] = useState<Post[]>([]);
    const [isLoading, setIsLoading] = useState(true);

    useEffect(() => {
        const fetchPosts = async () => {
            setIsLoading(true);
            try {
                const response = await apiClient.get('/posts');
                setPosts(response.data.posts || []);
            } catch (error) {
                // The interceptor will toast most errors, but this is a fallback.
                toast.error(formatApiErrorForToast(error as ApiError, 'Không thể tải bài viết.'));
            } finally {
                setIsLoading(false);
            }
        };

        fetchPosts();
    }, []);

    if (isLoading) {
        return <div className="flex justify-center p-8"><Spinner className="h-10 w-10" /></div>;
    }

    return (
        <div className="space-y-6">
            <div className="flex items-center gap-2 mb-4">
                <span className="text-2xl">📰</span>
                <h1 className="text-2xl font-bold">Bài viết</h1>
            </div>
            {posts.length > 0 ? posts.map(post => (
                <Card key={post.id}>
                    <CardHeader>
                        <CardTitle className="text-2xl font-bold mb-2">
                            <Link to={`${PATHS.POSTS}/${post.slug}`} className="hover:text-primary">
                                {post.title}
                            </Link>
                        </CardTitle>
                        <div className="text-sm text-muted-foreground">
                            <span>Đăng bởi {post.authorName}</span> - <span>{new Date(post.createdAt).toLocaleDateString('vi-VN')}</span>
                        </div>
                    </CardHeader>
                    <CardContent>
                        <p className="text-muted-foreground line-clamp-3">
                            {/* Simple excerpt */}
                            {post.content.substring(0, 200)}...
                        </p>
                        <Link to={`${PATHS.POSTS}/${post.slug}`} className="text-primary font-semibold mt-4 inline-block">
                            Đọc thêm →
                        </Link>
                    </CardContent>
                </Card>
            )) : (
                <Card>
                    <CardContent>
                        <p className="text-center p-8 text-muted-foreground">Chưa có bài viết nào.</p>
                    </CardContent>
                </Card>
            )}
        </div>
    );
}