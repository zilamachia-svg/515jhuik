/**
 * Wishlist Page
 * Display user's saved products
 */

import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Heart, Trash2, ShoppingCart, AlertCircle } from 'lucide-react';
import { toast } from 'sonner';
import { wishlistApi, WishlistItem } from '../api/features.api';
import { useApi } from '../hooks/useApi';
import { useAuth } from '../hooks/useAuth';
import { Button } from '../components/ui/button';
import { Card, CardContent } from '../components/ui/card';
import { formatPrice } from '../utils';

export const WishlistPage = () => {
  const navigate = useNavigate();
  const { user } = useAuth();
  const [wishlist, setWishlist] = useState<WishlistItem[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  const { execute: removeItem, isLoading: isRemoving } = useApi(wishlistApi.remove);

  useEffect(() => {
    if (!user) {
      navigate('/');
      return;
    }
    loadWishlist();
  }, [user, navigate]);

  const loadWishlist = async () => {
    setIsLoading(true);
    try {
      const response = await wishlistApi.getAll();
      setWishlist(response.data.data || []);
    } catch (error) {
      console.error('Failed to load wishlist:', error);
      toast.error('Không thể tải danh sách yêu thích');
    } finally {
      setIsLoading(false);
    }
  };

  const handleRemove = async (productId: number) => {
    try {
      await removeItem(productId);
      setWishlist(prev => prev.filter(item => item.product_id !== productId));
      toast.success('Đã xóa khỏi danh sách yêu thích');
    } catch (error) {
      toast.error('Không thể xóa sản phẩm');
    }
  };

  const handleBuyNow = (productId: number) => {
    navigate(`/products/${productId}`);
  };

  if (isLoading) {
    return (
      <div className="container mx-auto px-4 py-8">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {[...Array(6)].map((_, i) => (
            <Card key={i} className="animate-pulse">
              <div className="h-48 bg-gray-200 dark:bg-gray-700"></div>
              <CardContent className="p-4">
                <div className="h-4 bg-gray-200 dark:bg-gray-700 rounded mb-2"></div>
                <div className="h-4 bg-gray-200 dark:bg-gray-700 rounded w-2/3"></div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    );
  }

  if (wishlist.length === 0) {
    return (
      <div className="container mx-auto px-4 py-16">
        <div className="max-w-md mx-auto text-center">
          <Heart className="w-16 h-16 mx-auto text-gray-300 dark:text-gray-600 mb-4" />
          <h2 className="text-2xl font-bold mb-2">Danh sách yêu thích trống</h2>
          <p className="text-gray-600 dark:text-gray-400 mb-6">
            Bạn chưa lưu sản phẩm nào vào danh sách yêu thích
          </p>
          <Button onClick={() => navigate('/products')}>
            Khám phá sản phẩm
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-3xl font-bold flex items-center gap-2">
            <Heart className="w-8 h-8 text-red-500 fill-current" />
            Danh sách yêu thích
          </h1>
          <p className="text-gray-600 dark:text-gray-400 mt-1">
            {wishlist.length} sản phẩm
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
        {wishlist.map((item) => (
          <Card key={item.id} className="group hover:shadow-lg transition-shadow">
            <div className="relative">
              {item.product?.image ? (
                <img
                  src={item.product.image}
                  alt={item.product.name}
                  className="w-full h-48 object-cover rounded-t-lg"
                />
              ) : (
                <div className="w-full h-48 bg-gray-200 dark:bg-gray-700 flex items-center justify-center rounded-t-lg">
                  <AlertCircle className="w-12 h-12 text-gray-400" />
                </div>
              )}
              <button
                onClick={() => handleRemove(item.product_id)}
                disabled={isRemoving}
                className="absolute top-2 right-2 p-2 bg-white dark:bg-gray-800 rounded-full shadow-md hover:bg-red-50 dark:hover:bg-red-900/20 transition-colors"
                title="Xóa khỏi danh sách"
              >
                <Trash2 className="w-4 h-4 text-red-500" />
              </button>
            </div>

            <CardContent className="p-4">
              <h3 className="font-semibold text-lg mb-2 line-clamp-2 min-h-[3.5rem]">
                {item.product?.name || 'Sản phẩm'}
              </h3>
              
              {item.product?.category && (
                <p className="text-sm text-gray-500 dark:text-gray-400 mb-2">
                  {typeof item.product.category === 'object' 
                    ? item.product.category.name 
                    : item.product.category}
                </p>
              )}

              <div className="flex items-center justify-between mb-4">
                <span className="text-2xl font-bold text-primary">
                  {formatPrice(item.product?.price || 0)}
                </span>
              </div>

              <div className="flex gap-2">
                <Button
                  variant="outline"
                  size="sm"
                  className="flex-1"
                  onClick={() => handleBuyNow(item.product_id)}
                >
                  <ShoppingCart className="w-4 h-4 mr-2" />
                  Mua ngay
                </Button>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => handleRemove(item.product_id)}
                  disabled={isRemoving}
                >
                  <Trash2 className="w-4 h-4" />
                </Button>
              </div>

              <p className="text-xs text-gray-400 mt-2">
                Đã lưu: {new Date(item.created_at).toLocaleDateString('vi-VN')}
              </p>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
};

export default WishlistPage;
