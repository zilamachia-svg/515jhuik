import { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import { toast } from 'sonner';
import { Post, ApiError } from '../types';
import apiClient from '../services/apiClient';
import { formatApiErrorForToast, createMetaDescription } from '../utils';
import { usePageTitleContext } from '../contexts/PageTitleContext';
import { parseMarkdown } from '../utils/markdownParser';
import { Card, CardContent, CardHeader } from '@/components/ui/card';
import { Spinner } from '@/components/ui/spinner';
import { PATHS } from '../constants/paths';
import { Button } from '@/components/ui/button';

export default function PostDetailPage() {
    const { slug } = useParams<{ slug: string }>();
    const [post, setPost] = useState<Post | null>(null);
    const [isLoading, setIsLoading] = useState(true);
    const { setTitle } = usePageTitleContext();

    useEffect(() => {
        const fetchPost = async () => {
            if (!slug) return;
            setIsLoading(true);
            try {
                const response = await apiClient.get(`/posts/${slug}`);
                setPost(response.data.post);
            } catch (error) {
                toast.error(formatApiErrorForToast(error as ApiError, 'Không tìm thấy bài viết.'));
            } finally {
                setIsLoading(false);
            }
        };
        fetchPost();
    }, [slug]);
    
    useEffect(() => {
        if (post?.title) {
            setTitle(post.title);
        }
        return () => setTitle('');
    }, [post, setTitle]);

    // Effect for SEO meta tags
    useEffect(() => {
        const originalTitle = document.title;
        let metaDescriptionEl = document.querySelector('meta[name="description"]');
        const originalDescription = metaDescriptionEl?.getAttribute('content') || '';

        // Create meta tag if it doesn't exist
        if (!metaDescriptionEl) {
            metaDescriptionEl = document.createElement('meta');
            metaDescriptionEl.setAttribute('name', 'description');
            document.head.appendChild(metaDescriptionEl);
        }

        if (post) {
            const newTitle = `${post.title} | HẢI ĐĂNG META`;
            const newDescription = createMetaDescription(post.content);

            document.title = newTitle;
            metaDescriptionEl.setAttribute('content', newDescription);
        }

        // Cleanup on unmount
        return () => {
            document.title = originalTitle;
            if (metaDescriptionEl) {
                metaDescriptionEl.setAttribute('content', originalDescription);
            }
        };
    }, [post]);

    if (isLoading) {
        return <div className="flex justify-center p-8"><Spinner className="h-10 w-10" /></div>;
    }

    if (!post) {
        return (
            <Card>
                <CardContent>
                    <div className="text-center p-12">
                        <h2 className="text-2xl font-bold mb-4">404 - Không tìm thấy bài viết</h2>
                        <p className="text-muted-foreground">Bài viết bạn đang tìm kiếm không tồn tại hoặc đã bị xóa.</p>
                        <Button asChild className="mt-6">
                            <Link to={PATHS.POSTS}>Quay lại danh sách bài viết</Link>
                        </Button>
                    </div>
                </CardContent>
            </Card>
        );
    }

    return (
        <Card>
            <CardHeader>
                <div className="text-sm text-muted-foreground mb-2">
                    <span>Đăng bởi {post.authorName}</span> - <span>{new Date(post.createdAt).toLocaleDateString('vi-VN')}</span>
                </div>
                <h1 className="text-3xl font-bold leading-none tracking-tight">{post.title}</h1>
            </CardHeader>
            <CardContent>
                <article className="prose dark:prose-invert max-w-none">
                    {parseMarkdown(post.content)}
                </article>
            </CardContent>
        </Card>
    );
}