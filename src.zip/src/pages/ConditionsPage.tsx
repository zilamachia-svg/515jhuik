import { motion } from 'framer-motion';
import { usePageTitle } from '../contexts/PageTitleContext';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { BookOpen } from 'lucide-react';
import { BannerContent } from '@/components/BannerContent';

export default function ConditionsPage() {
    usePageTitle('Điều kiện giao dịch - Hải Đăng Meta');

    return (
        <div className="space-y-8">
            {/* Banner với nội dung */}
            <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5 }}
                className="overflow-hidden rounded-3xl bg-gradient-to-r from-orange-400/85 via-amber-400/85 to-yellow-400/85 p-8 text-white"
            >
                <div className="flex flex-col gap-6 md:flex-row md:items-center md:justify-between">
                    <div className="space-y-4">
                        <div className="flex items-center gap-3">
                            <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-white/20 backdrop-blur-md">
                                <BookOpen className="h-6 w-6" />
                            </div>
                            <div>
                                <h1 className="text-3xl font-bold">Điều kiện giao dịch</h1>
                                <p className="text-white/80">Quy trình và điều kiện thực hiện giao dịch</p>
                            </div>
                        </div>
                    </div>
                </div>
                <BannerContent />
            </motion.div>

            {/* Nội dung chính */}
            <Card className="rounded-3xl">
                <CardHeader>
                    <CardTitle>Điều kiện và quy trình giao dịch</CardTitle>
                </CardHeader>
                <CardContent className="prose prose-slate max-w-none space-y-6">
                    <section>
                        <h2 className="text-2xl font-bold mb-4">1. Điều kiện đặt hàng</h2>
                        <div className="space-y-4">
                            <div>
                                <h3 className="text-xl font-semibold mb-2">1.1. Tài khoản người dùng</h3>
                                <p className="text-muted-foreground">
                                    Để đặt hàng, bạn cần có tài khoản đã đăng ký và xác thực email. Tài khoản phải có đủ số dư 
                                    hoặc phương thức thanh toán hợp lệ.
                                </p>
                            </div>
                            <div>
                                <h3 className="text-xl font-semibold mb-2">1.2. Số dư tối thiểu</h3>
                                <p className="text-muted-foreground">
                                    Một số sản phẩm yêu cầu số dư tối thiểu. Vui lòng kiểm tra yêu cầu trước khi đặt hàng.
                                </p>
                            </div>
                            <div>
                                <h3 className="text-xl font-semibold mb-2">1.3. Xác minh danh tính</h3>
                                <p className="text-muted-foreground">
                                    Đối với các giao dịch lớn (trên 5,000,000 VNĐ), chúng tôi có thể yêu cầu xác minh danh tính 
                                    để đảm bảo an toàn.
                                </p>
                            </div>
                        </div>
                    </section>

                    <section>
                        <h2 className="text-2xl font-bold mb-4">2. Quy trình đặt hàng</h2>
                        <div className="space-y-3">
                            <div className="flex gap-3">
                                <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-primary text-primary-foreground font-bold">
                                    1
                                </div>
                                <div>
                                    <h3 className="font-semibold mb-1">Chọn sản phẩm</h3>
                                    <p className="text-sm text-muted-foreground">
                                        Duyệt và chọn sản phẩm phù hợp từ cửa hàng. Đọc kỹ mô tả, thông tin và điều kiện sử dụng.
                                    </p>
                                </div>
                            </div>
                            <div className="flex gap-3">
                                <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-primary text-primary-foreground font-bold">
                                    2
                                </div>
                                <div>
                                    <h3 className="font-semibold mb-1">Xác nhận đơn hàng</h3>
                                    <p className="text-sm text-muted-foreground">
                                        Kiểm tra lại thông tin đơn hàng, số lượng và tổng tiền. Xác nhận đặt hàng.
                                    </p>
                                </div>
                            </div>
                            <div className="flex gap-3">
                                <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-primary text-primary-foreground font-bold">
                                    3
                                </div>
                                <div>
                                    <h3 className="font-semibold mb-1">Thanh toán</h3>
                                    <p className="text-sm text-muted-foreground">
                                        Chọn phương thức thanh toán và hoàn tất thanh toán trong vòng 24 giờ.
                                    </p>
                                </div>
                            </div>
                            <div className="flex gap-3">
                                <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-primary text-primary-foreground font-bold">
                                    4
                                </div>
                                <div>
                                    <h3 className="font-semibold mb-1">Xử lý đơn hàng</h3>
                                    <p className="text-sm text-muted-foreground">
                                        Chúng tôi sẽ xử lý đơn hàng trong vòng 1-6 giờ (trong giờ hành chính). 
                                        Bạn sẽ nhận được thông báo khi đơn hàng sẵn sàng.
                                    </p>
                                </div>
                            </div>
                            <div className="flex gap-3">
                                <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-primary text-primary-foreground font-bold">
                                    5
                                </div>
                                <div>
                                    <h3 className="font-semibold mb-1">Nhận sản phẩm</h3>
                                    <p className="text-sm text-muted-foreground">
                                        Thông tin sản phẩm sẽ được gửi đến email và hiển thị trong mục &quot;Lịch sử mua hàng&quot; 
                                        của bạn.
                                    </p>
                                </div>
                            </div>
                        </div>
                    </section>

                    <section>
                        <h2 className="text-2xl font-bold mb-4">3. Phương thức thanh toán</h2>
                        <div className="space-y-4">
                            <div>
                                <h3 className="text-xl font-semibold mb-2">3.1. Chuyển khoản ngân hàng</h3>
                                <p className="text-muted-foreground">
                                    Chuyển khoản trực tiếp vào tài khoản ngân hàng của chúng tôi. Thông tin tài khoản sẽ được 
                                    hiển thị sau khi đặt hàng. Vui lòng ghi nội dung chuyển khoản theo đúng mã đơn hàng.
                                </p>
                            </div>
                            <div>
                                <h3 className="text-xl font-semibold mb-2">3.2. Ví điện tử MoMo</h3>
                                <p className="text-muted-foreground">
                                    Thanh toán qua ví điện tử MoMo bằng cách quét mã QR hoặc chuyển khoản đến số điện thoại 
                                    được cung cấp.
                                </p>
                            </div>
                            <div>
                                <h3 className="text-xl font-semibold mb-2">3.3. Số dư tài khoản</h3>
                                <p className="text-muted-foreground">
                                    Sử dụng số dư có sẵn trong tài khoản Hải Đăng Meta. Bạn có thể nạp tiền vào tài khoản 
                                    trước khi mua hàng.
                                </p>
                            </div>
                        </div>
                    </section>

                    <section>
                        <h2 className="text-2xl font-bold mb-4">4. Thời gian xử lý</h2>
                        <div className="space-y-4">
                            <div>
                                <h3 className="text-xl font-semibold mb-2">4.1. Xác nhận thanh toán</h3>
                                <p className="text-muted-foreground">
                                    Sau khi nhận được thanh toán, chúng tôi sẽ xác nhận trong vòng <strong>30 phút - 2 giờ</strong> 
                                    (trong giờ hành chính 8:00 - 22:00).
                                </p>
                            </div>
                            <div>
                                <h3 className="text-xl font-semibold mb-2">4.2. Xử lý đơn hàng</h3>
                                <p className="text-muted-foreground">
                                    Đơn hàng sẽ được xử lý trong vòng <strong>1-6 giờ</strong> sau khi thanh toán được xác nhận. 
                                    Đối với đơn hàng ngoài giờ hành chính, sẽ được xử lý vào ngày làm việc tiếp theo.
                                </p>
                            </div>
                            <div>
                                <h3 className="text-xl font-semibold mb-2">4.3. Giao hàng</h3>
                                <p className="text-muted-foreground">
                                    Thông tin sản phẩm sẽ được gửi ngay sau khi đơn hàng được xử lý xong, thông qua email và 
                                    trong tài khoản của bạn.
                                </p>
                            </div>
                        </div>
                    </section>

                    <section>
                        <h2 className="text-2xl font-bold mb-4">5. Hủy đơn hàng</h2>
                        <div className="space-y-4">
                            <div>
                                <h3 className="text-xl font-semibold mb-2">5.1. Điều kiện hủy</h3>
                                <p className="text-muted-foreground">
                                    Bạn có thể hủy đơn hàng trong các trường hợp sau:
                                </p>
                                <ul className="list-disc pl-6 mt-2 space-y-1 text-muted-foreground">
                                    <li>Trước khi thanh toán</li>
                                    <li>Trong vòng 1 giờ sau khi thanh toán (nếu đơn hàng chưa được xử lý)</li>
                                    <li>Đơn hàng bị trễ quá 24 giờ so với cam kết</li>
                                </ul>
                            </div>
                            <div>
                                <h3 className="text-xl font-semibold mb-2">5.2. Hoàn tiền khi hủy</h3>
                                <p className="text-muted-foreground">
                                    Nếu hủy đơn hàng đúng điều kiện, bạn sẽ được hoàn tiền 100% trong vòng 3-5 ngày làm việc.
                                </p>
                            </div>
                        </div>
                    </section>

                    <section>
                        <h2 className="text-2xl font-bold mb-4">6. Giá cả và phí</h2>
                        <div className="space-y-4">
                            <div>
                                <h3 className="text-xl font-semibold mb-2">6.1. Giá sản phẩm</h3>
                                <p className="text-muted-foreground">
                                    Tất cả giá được hiển thị bằng VNĐ và đã bao gồm thuế VAT (nếu có). Giá có thể thay đổi 
                                    mà không cần thông báo trước, nhưng đơn hàng đã đặt sẽ giữ nguyên giá đã xác nhận.
                                </p>
                            </div>
                            <div>
                                <h3 className="text-xl font-semibold mb-2">6.2. Phí giao dịch</h3>
                                <p className="text-muted-foreground">
                                    Chúng tôi không thu thêm phí giao dịch. Tuy nhiên, ngân hàng hoặc cổng thanh toán có thể 
                                    thu phí chuyển khoản theo quy định của họ.
                                </p>
                            </div>
                        </div>
                    </section>

                    <section>
                        <h2 className="text-2xl font-bold mb-4">7. Xác nhận đơn hàng</h2>
                        <p className="text-muted-foreground">
                            Sau khi đặt hàng thành công, bạn sẽ nhận được email xác nhận chứa:
                        </p>
                        <ul className="list-disc pl-6 mt-2 space-y-1 text-muted-foreground">
                            <li>Mã đơn hàng</li>
                            <li>Thông tin sản phẩm đã đặt</li>
                            <li>Tổng tiền và phương thức thanh toán</li>
                            <li>Hướng dẫn thanh toán (nếu chưa thanh toán)</li>
                            <li>Thời gian dự kiến nhận hàng</li>
                        </ul>
                    </section>

                    <section>
                        <h2 className="text-2xl font-bold mb-4">8. Khiếu nại và giải quyết tranh chấp</h2>
                        <p className="text-muted-foreground">
                            Nếu bạn có khiếu nại về giao dịch, vui lòng liên hệ bộ phận hỗ trợ trong vòng 7 ngày kể từ ngày 
                            nhận sản phẩm. Chúng tôi cam kết giải quyết mọi khiếu nại một cách công bằng và nhanh chóng.
                        </p>
                    </section>

                    <section>
                        <h2 className="text-2xl font-bold mb-4">9. Liên hệ</h2>
                        <p className="text-muted-foreground">
                            Mọi thắc mắc về điều kiện giao dịch, vui lòng liên hệ:
                        </p>
                        <ul className="list-disc pl-6 mt-2 space-y-1 text-muted-foreground">
                            <li>Email: orders@haidangmeta.com</li>
                            <li>Hotline: 1900-xxxx</li>
                            <li>Thời gian: 8:00 - 22:00 hàng ngày</li>
                        </ul>
                    </section>

                    <div className="mt-8 p-4 bg-muted rounded-2xl">
                        <p className="text-sm text-muted-foreground">
                            <strong>Lần cập nhật cuối:</strong> {new Date().toLocaleDateString('vi-VN')}
                        </p>
                    </div>
                </CardContent>
            </Card>
        </div>
    );
}

