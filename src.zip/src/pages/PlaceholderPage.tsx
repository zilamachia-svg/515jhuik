import { PlaceholderContent } from '../components/PlaceholderContent';
import { Card, CardContent } from '../components/ui/card';
import { TriangleAlert } from 'lucide-react';

export default function PlaceholderPage() {
    return (
        <div className="flex items-center justify-center h-full">
            <Card className="max-w-md w-full">
                 <CardContent className="p-0">
                    <PlaceholderContent
                        icon={<TriangleAlert className="w-12 h-12" />}
                        title="404 - Không tìm thấy trang"
                        message="Trang bạn đang tìm kiếm không tồn tại hoặc đã bị di chuyển."
                        showCta={true}
                    />
                </CardContent>
            </Card>
        </div>
    );
}