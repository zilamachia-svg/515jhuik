import { usePageTitle } from '../contexts/PageTitleContext';
import { Card, CardHeader, CardTitle, CardDescription, CardContent, CardFooter } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Phone, Send, Mail } from 'lucide-react';

export default function LienHePage() {
    usePageTitle("Liên hệ & Hỗ trợ");

    const contactMethods = [
        {
            icon: <Phone size={32} />,
            title: "Zalo",
            detail: "0123 456 789",
            link: "https://zalo.me/0123456789",
            cta: "Chat qua Zalo"
        },
        {
            icon: <Send size={32} />,
            title: "Telegram",
            detail: "@haidangmeta",
            link: "https://t.me/haidangmeta",
            cta: "Chat qua Telegram"
        },
        {
            icon: <Mail size={32} />,
            title: "Email",
            detail: "support@haidangmeta.com",
            link: "mailto:support@haidangmeta.com",
            cta: "Gửi Email"
        }
    ];

    return (
        <div className="space-y-6">
            <Card className="text-center">
                <CardHeader>
                    <CardTitle className="text-2xl flex items-center justify-center gap-2">
                        <span className="text-2xl">📞</span>
                        Chúng tôi có thể giúp gì cho bạn?
                    </CardTitle>
                    <CardDescription>Nếu bạn có bất kỳ câu hỏi hoặc cần hỗ trợ, đừng ngần ngại liên hệ với chúng tôi qua các kênh dưới đây.</CardDescription>
                </CardHeader>
            </Card>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                {contactMethods.map((method, index) => (
                    <Card key={index} className="flex flex-col items-center text-center">
                        <CardHeader>
                            <div className="p-4 bg-muted rounded-full mb-4 w-fit mx-auto">
                                {method.icon}
                            </div>
                            <CardTitle>{method.title}</CardTitle>
                        </CardHeader>
                        <CardContent className="flex-grow">
                            <p className="text-muted-foreground">{method.detail}</p>
                        </CardContent>
                        <CardFooter>
                            <Button asChild variant="outline" className="w-full">
                                <a href={method.link} target="_blank" rel="noopener noreferrer">
                                    {method.cta}
                                </a>
                            </Button>
                        </CardFooter>
                    </Card>
                ))}
            </div>
        </div>
    );
}
