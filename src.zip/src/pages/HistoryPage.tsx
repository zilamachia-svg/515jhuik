import { NavLink, Outlet, useLocation, Navigate } from 'react-router-dom';
import { useLanguage } from '../contexts/LanguageContext';
import { usePageTitle } from '../contexts/PageTitleContext';
import { PATHS } from '../constants/paths';
import { History, Wallet } from 'lucide-react';
import { Card, CardContent } from '@/components/ui/card';

export default function HistoryPage() {
    const { t } = useLanguage();
    const location = useLocation();
    usePageTitle(t('sidebar.financial')); // A general title for the section

    // If on the base /history path, redirect to the default history page
    if (location.pathname === '/history') {
        return <Navigate to={PATHS.ORDERS_HISTORY} replace />;
    }

    const historyNav = [
        { path: PATHS.ORDERS_HISTORY, label: t('sidebar.purchaseHistory'), icon: <History size={20} /> },
        { path: PATHS.DEPOSIT_HISTORY, label: t('sidebar.depositHistory'), icon: <Wallet size={20} /> },
    ];

    const getNavLinkClass = ({ isActive }: { isActive: boolean }) =>
        `flex items-center gap-3 p-3 rounded-lg hover:bg-accent ${isActive ? 'bg-accent font-semibold' : ''}`;

    return (
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
            <aside className="md:col-span-1">
                <Card>
                    <CardContent className="p-2">
                        <nav className="flex flex-col gap-1">
                            {historyNav.map(item => (
                                <NavLink key={item.path} to={item.path} className={getNavLinkClass}>
                                    {item.icon}
                                    <span>{item.label}</span>
                                </NavLink>
                            ))}
                        </nav>
                    </CardContent>
                </Card>
            </aside>
            <div className="md:col-span-3">
                <Outlet />
            </div>
        </div>
    );
}
