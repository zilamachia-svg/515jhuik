import React, { useState, useEffect, useMemo } from 'react';
import { toast } from 'sonner';
import { Task, ApiError } from '../types';
import apiClient from '../services/apiClient';
import { formatApiErrorForToast } from '../utils';
import { usePageTitle } from '../contexts/PageTitleContext';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Spinner } from '@/components/ui/spinner';
import { Plus, Trash2, ListTodo } from 'lucide-react';
import { Input } from '@/components/ui/input';
import { Checkbox } from '@/components/ui/checkbox';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';

export default function TasksPage() {
    usePageTitle("Công việc của tôi");

    const [tasks, setTasks] = useState<Task[]>([]);
    const [isLoading, setIsLoading] = useState(true);
    const [newTaskTitle, setNewTaskTitle] = useState('');
    const [newTaskPriority, setNewTaskPriority] = useState<'low' | 'medium' | 'high'>('medium');

    const [statusFilter, setStatusFilter] = useState('all'); // 'all', 'pending', 'completed'
    const [priorityFilter, setPriorityFilter] = useState('all'); // 'all', 'low', 'medium', 'high'

    useEffect(() => {
        const fetchTasks = async () => {
            setIsLoading(true);
            try {
                const response = await apiClient.get('/tasks');
                setTasks(response.data.tasks);
            } catch (error) {
                toast.error(formatApiErrorForToast(error as ApiError, 'Không thể tải công việc.'));
            } finally {
                setIsLoading(false);
            }
        };
        fetchTasks();
    }, []);
    
    const filteredTasks = useMemo(() => {
        return tasks.filter(task => {
            const statusMatch = statusFilter === 'all' ||
                                (statusFilter === 'pending' && !task.isCompleted) ||
                                (statusFilter === 'completed' && task.isCompleted);

            const priorityMatch = priorityFilter === 'all' || task.priority === priorityFilter;

            return statusMatch && priorityMatch;
        });
    }, [tasks, statusFilter, priorityFilter]);

    const handleAddTask = async (e: React.FormEvent) => {
        e.preventDefault();
        if (!newTaskTitle.trim()) return;

        try {
            const response = await apiClient.post('/tasks', { title: newTaskTitle, priority: newTaskPriority });
            setTasks(prev => [response.data.task, ...prev]);
            setNewTaskTitle('');
            setNewTaskPriority('medium');
        } catch (error) {
            toast.error(formatApiErrorForToast(error as ApiError, 'Không thể thêm công việc.'));
        }
    };
    
    const handleToggleTask = async (task: Task) => {
        try {
            const updatedTaskData = { ...task, isCompleted: !task.isCompleted };
            await apiClient.put(`/tasks/${task.id}`, { isCompleted: updatedTaskData.isCompleted });
            setTasks(prev => prev.map(t => t.id === task.id ? updatedTaskData : t));
        } catch (error) {
            toast.error(formatApiErrorForToast(error as ApiError, 'Không thể cập nhật công việc.'));
        }
    };

    const handleDeleteTask = async (taskId: string) => {
        try {
            await apiClient.delete(`/tasks/${taskId}`);
            setTasks(prev => prev.filter(t => t.id !== taskId));
            toast.success('Đã xóa công việc.');
        } catch (error) {
            toast.error(formatApiErrorForToast(error as ApiError, 'Không thể xóa công việc.'));
        }
    };

    const getPriorityBadgeVariant = (priority: 'low' | 'medium' | 'high'): 'default' | 'secondary' | 'destructive' | 'outline' => {
        switch (priority) {
            case 'high': return 'destructive';
            case 'medium': return 'default';
            case 'low': return 'secondary';
            default: return 'outline';
        }
    };

    const getPriorityLabel = (priority: 'low' | 'medium' | 'high'): string => {
        switch (priority) {
            case 'high': return 'Cao';
            case 'medium': return 'Vừa';
            case 'low': return 'Thấp';
            default: return priority;
        }
    };

    return (
            <Card className="rounded-3xl">
                <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                        <span className="text-xl">✅</span>
                        Nhiệm vụ của tôi
                    </CardTitle>
                </CardHeader>
            <CardContent>
                <form onSubmit={handleAddTask} className="flex flex-col sm:flex-row gap-2 mb-6">
                    <Input
                        type="text"
                        value={newTaskTitle}
                        onChange={(e) => setNewTaskTitle(e.target.value)}
                        placeholder="Thêm một công việc mới..."
                        className="flex-1 rounded-2xl"
                    />
                     <Select value={newTaskPriority} onValueChange={(v) => setNewTaskPriority(v as 'low' | 'medium' | 'high')}>
                        <SelectTrigger className="w-full sm:w-[120px] rounded-2xl">
                            <SelectValue />
                        </SelectTrigger>
                        <SelectContent className="rounded-2xl">
                            <SelectItem value="low">Thấp</SelectItem>
                            <SelectItem value="medium">Vừa</SelectItem>
                            <SelectItem value="high">Cao</SelectItem>
                        </SelectContent>
                    </Select>
                    <Button type="submit" className="rounded-2xl"><Plus size={18} className="mr-2" />Thêm</Button>
                </form>

                <div className="flex flex-col sm:flex-row gap-4 mb-4 p-4 bg-muted/50 rounded-2xl">
                    <div className="flex-1 space-y-2">
                        <Label>Lọc theo trạng thái</Label>
                        <Select value={statusFilter} onValueChange={setStatusFilter}>
                            <SelectTrigger className="rounded-2xl"><SelectValue /></SelectTrigger>
                            <SelectContent className="rounded-2xl">
                                <SelectItem value="all">Tất cả</SelectItem>
                                <SelectItem value="pending">Chưa hoàn thành</SelectItem>
                                <SelectItem value="completed">Đã hoàn thành</SelectItem>
                            </SelectContent>
                        </Select>
                    </div>
                    <div className="flex-1 space-y-2">
                        <Label>Lọc theo độ ưu tiên</Label>
                        <Select value={priorityFilter} onValueChange={setPriorityFilter}>
                            <SelectTrigger className="rounded-2xl"><SelectValue /></SelectTrigger>
                            <SelectContent className="rounded-2xl">
                                <SelectItem value="all">Tất cả</SelectItem>
                                <SelectItem value="low">Thấp</SelectItem>
                                <SelectItem value="medium">Vừa</SelectItem>
                                <SelectItem value="high">Cao</SelectItem>
                            </SelectContent>
                        </Select>
                    </div>
                </div>

                {isLoading ? <div className="flex justify-center"><Spinner /></div> : (
                    <ul className="space-y-2">
                        {filteredTasks.map(task => (
                            <li key={task.id} className={`flex items-center gap-3 p-3 rounded-xl border transition-all hover:bg-muted/50 ${task.isCompleted ? 'opacity-60' : ''}`}>
                                <Checkbox
                                    id={`task-${task.id}`}
                                    checked={task.isCompleted}
                                    onCheckedChange={() => handleToggleTask(task)}
                                    className="rounded-lg"
                                />
                                <label htmlFor={`task-${task.id}`} className={`flex-1 cursor-pointer ${task.isCompleted ? 'line-through text-muted-foreground' : ''}`}>
                                    {task.title}
                                </label>
                                <Badge variant={getPriorityBadgeVariant(task.priority)} className="rounded-xl">{getPriorityLabel(task.priority)}</Badge>
                                <Button
                                    variant="ghost"
                                    size="icon"
                                    className="h-8 w-8 rounded-xl text-muted-foreground hover:text-destructive"
                                    onClick={() => handleDeleteTask(task.id)}
                                >
                                    <Trash2 size={16} />
                                </Button>
                            </li>
                        ))}
                    </ul>
                )}
                {filteredTasks.length === 0 && !isLoading && <p className="text-center text-muted-foreground py-4">Không có công việc nào phù hợp.</p>}
            </CardContent>
        </Card>
    );
}