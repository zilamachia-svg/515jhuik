// Memoize formatters to avoid recreating them on every call
const currencyFormatters = new Map<string, Intl.NumberFormat>();

// FIX: Declare require to prevent TS error when using dynamic imports in try-catch blocks
declare const require: any;

const getCurrencyFormatter = (currency: string): Intl.NumberFormat => {
    if (!currencyFormatters.has(currency)) {
        currencyFormatters.set(
            currency,
            new Intl.NumberFormat('vi-VN', {
                style: 'currency',
                currency: currency,
            })
        );
    }
    return currencyFormatters.get(currency)!;
};

/**
 * Formats a number as Vietnamese Dong (VND).
 * Optimized: Reuses Intl.NumberFormat instances instead of creating new ones.
 * @param amount The number to format.
 * @param currency The currency code.
 * @returns A formatted currency string.
 */
export const formatCurrency = (amount: number, currency = 'VND'): string => {
    return getCurrencyFormatter(currency).format(amount);
};

/** Alias used in legacy components for price formatting */
export const formatPrice = (amount: number): string => formatCurrency(amount, 'VND');

/**
 * Parses an API error object and returns a user-friendly string for toasts.
 * It prioritizes specific messages from the backend response.
 * 
 * @deprecated Use `formatErrorMessage` from `errorHandler.ts` instead for better error classification.
 * This function is kept for backward compatibility.
 * 
 * @param error The error object, which should conform to the ApiError interface.
 * @param defaultMessage A fallback message if no specific error can be parsed.
 * @returns A user-friendly error string.
 */
// Fix: Use `any` for the error type and perform runtime checks for properties. This is safer than assuming all caught errors will match the ApiError interface.
export const formatApiErrorForToast = (error: any, defaultMessage = 'Đã có lỗi xảy ra.'): string => {
    // Import errorHandler dynamically to avoid circular dependencies
    try {
        // eslint-disable-next-line @typescript-eslint/no-var-requires
        const { formatErrorMessage } = require('./services/errorHandler');
        return formatErrorMessage(error, defaultMessage);
    } catch {
        // Fallback to original implementation if errorHandler is not available
    }

    // Check for network errors
    if (!error?.response) {
        if (error?.code === 'ERR_NETWORK' || error?.message?.includes('Network Error')) {
            return 'Không thể kết nối đến máy chủ. Vui lòng kiểm tra kết nối mạng.';
        }
        if (error?.code === 'ECONNABORTED' || error?.message?.includes('timeout')) {
            return 'Yêu cầu đã hết thời gian chờ. Vui lòng thử lại.';
        }
    }

    // Check for specific HTTP status codes
    const status = error?.response?.status;
    if (status === 401) {
        return error?.response?.data?.message || 'Phiên đăng nhập đã hết hạn. Vui lòng đăng nhập lại.';
    }
    if (status === 403) {
        return error?.response?.data?.message || 'Bạn không có quyền truy cập tài nguyên này.';
    }
    if (status === 404) {
        return error?.response?.data?.message || 'Không tìm thấy tài nguyên.';
    }
    if (status === 422) {
        // Validation errors - get first error message
        const errors = error?.response?.data?.errors;
        if (errors && typeof errors === 'object') {
            const firstError = Object.values(errors)[0];
            if (Array.isArray(firstError) && firstError.length > 0) {
                return firstError[0] as string;
            }
        }
        return error?.response?.data?.message || 'Dữ liệu không hợp lệ.';
    }
    if (status === 429) {
        return 'Quá nhiều yêu cầu. Vui lòng thử lại sau vài giây.';
    }
    if (status === 500) {
        return error?.response?.data?.message || 'Đã xảy ra lỗi máy chủ. Vui lòng thử lại sau.';
    }
    if (status === 503) {
        return 'Dịch vụ tạm thời không khả dụng. Vui lòng thử lại sau.';
    }

    // Check for response data message
    if (error?.response?.data?.message) {
        return error.response.data.message;
    }

    // Check for error message
    if (error?.message) {
        return error.message;
    }

    return defaultMessage;
};

/**
 * Extracts validation errors from a 422 API response.
 * Laravel's default validation failure response is an object where keys are field names
 * and values are arrays of error messages. This function extracts the first message for each field.
 * 
 * @deprecated Use `extractValidationErrors` from `errorHandler.ts` instead for better error handling.
 * This function is kept for backward compatibility.
 * 
 * @param error The error object.
 * @returns A record mapping field names to their first error message, or null if not a validation error.
 */
// FIX: Changed error type to `any` and added optional chaining to fix type errors.
export const getApiValidationErrors = (error: any): Record<string, string> | null => {
    // Try to use errorHandler if available
    try {
        // eslint-disable-next-line @typescript-eslint/no-var-requires
        const { extractValidationErrors } = require('./services/errorHandler');
        return extractValidationErrors(error);
    } catch {
        // Fallback to original implementation
    }

    if (error?.response && error.response.status === 422 && error.response.data?.errors) {
        const validationErrors: Record<string, string> = {};
        for (const key in error.response.data.errors) {
            if (Array.isArray(error.response.data.errors[key]) && error.response.data.errors[key].length > 0) {
                validationErrors[key] = error.response.data.errors[key][0];
            }
        }
        return validationErrors;
    }
    return null;
};

/**
 * Converts a hex color string to an HSL color string for CSS variables.
 * @param hex The hex color string (e.g., '#RRGGBB').
 * @returns The HSL string (e.g., '240 6% 90%').
 */
export const hexToHSL = (hex: string): string => {
  if (!hex || typeof hex !== 'string') return '';
  
  // Remove '#'
  let H = hex.replace('#', '');
  if (H.length === 3) {
    H = H.split('').map(c => c + c).join('');
  }
  
  if (H.length !== 6) {
    return '';
  }

  const r = parseInt(H.substring(0, 2), 16) / 255;
  const g = parseInt(H.substring(2, 4), 16) / 255;
  const b = parseInt(H.substring(4, 6), 16) / 255;

  const cmin = Math.min(r, g, b);
  const cmax = Math.max(r, g, b);
  const delta = cmax - cmin;
  let h = 0;
  let s = 0;
  let l = 0;

  if (delta === 0) h = 0;
  else if (cmax === r) h = ((g - b) / delta) % 6;
  else if (cmax === g) h = (b - r) / delta + 2;
  else h = (r - g) / delta + 4;

  h = Math.round(h * 60);
  if (h < 0) h += 360;

  l = (cmax + cmin) / 2;
  s = delta === 0 ? 0 : delta / (1 - Math.abs(2 * l - 1));
  s = +(s * 100).toFixed(1);
  l = +(l * 100).toFixed(1);

  return `${h} ${s}% ${l}%`;
};

/**
 * Converts a string into a URL-friendly slug.
 * @param text The string to slugify.
 * @returns A slugified string.
 */
export const slugify = (text: string): string => {
  if (!text) return '';
  return text
    .toString()
    .toLowerCase()
    .normalize('NFD') // separate accent from letter
    .replace(/[\u0300-\u036f]/g, '') // remove all separated accents
    .replace(/đ/g, 'd') // convert đ to d
    .trim()
    .replace(/\s+/g, '-') // replace spaces with -
    .replace(/[^\w-]+/g, '') // remove all non-word chars except hyphens
    .replace(/--+/g, '-'); // replace multiple hyphens with a single one
};


/**
 * Creates a meta description from markdown content.
 * It strips markdown formatting and truncates the text.
 * @param markdown The markdown content.
 * @param length The desired max length of the description.
 * @returns A plain text string for the meta description.
 */
export const createMetaDescription = (markdown: string, length = 160): string => {
  if (!markdown) return '';
  
  const plainText = markdown
    .replace(/!\[.*?\]\(.*?\)/g, '') // remove images
    .replace(/\[(.*?)\]\(.*?\)/g, '$1') // replace links with their text
    .replace(/^#+\s/gm, '') // remove headings
    .replace(/^>\s/gm, '') // remove blockquotes
    .replace(/^[-*+]\s/gm, '') // remove list items
    .replace(/(\*\*|__)(.*?)\1/g, '$2') // remove bold
    .replace(/(\*|_)(.*?)\1/g, '$2') // remove italic
    .replace(/`{1,3}(.*?)`{1,3}/g, '$1') // remove code
    .replace(/(\r\n|\n|\r)/gm, ' ') // replace newlines with spaces
    .replace(/\s+/g, ' ') // collapse whitespace
    .trim();

  if (plainText.length <= length) {
    return plainText;
  }
  
  const truncated = plainText.substring(0, length);
  // find last space to avoid cutting words
  const lastSpace = truncated.lastIndexOf(' ');
  return (lastSpace > 0 ? truncated.substring(0, lastSpace) : truncated).trim() + '...';
};
