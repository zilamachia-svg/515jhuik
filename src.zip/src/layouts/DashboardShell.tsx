import { ReactNode, useMemo, useState } from 'react';
import { motion } from 'framer-motion';
import { cn } from '@/lib/utils';
import Header from '@/components/layout/Header';
import { EmailVerificationBanner } from '@/components/EmailVerificationBanner';
import { GlobalNotificationBanner } from '@/components/GlobalNotificationBanner';

export type DashboardShellSidebarProps = {
    isCollapsed: boolean;
    isMobileOpen: boolean;
    onToggleCollapse: () => void;
    onCloseMobile: () => void;
    className?: string;
};

interface DashboardShellProps {
    renderSidebar: (props: DashboardShellSidebarProps) => ReactNode;
    children: ReactNode;
    showEmailVerificationBanner?: boolean;
    contentMaxWidth?: number | string;
}

export function DashboardShell({
    renderSidebar,
    children,
    showEmailVerificationBanner = false,
    contentMaxWidth = '100%',
}: DashboardShellProps) {
    const [isSidebarCollapsed, setIsSidebarCollapsed] = useState(false);
    const [isMobileSidebarOpen, setMobileSidebarOpen] = useState(false);

    const handleToggleSidebar = () => {
        if (typeof window !== 'undefined' && window.innerWidth < 1024) {
            setMobileSidebarOpen(prev => !prev);
        } else {
            setIsSidebarCollapsed(prev => !prev);
        }
    };

    const closeMobileSidebar = () => {
        setMobileSidebarOpen(false);
    };

    // Calculate sidebar width for content margin
    const sidebarWidthClass = isSidebarCollapsed ? 'lg:ml-[80px]' : 'lg:ml-[280px]';

    return (
        <div className="min-h-screen bg-gray-900 text-gray-100 font-sans selection:bg-indigo-500/30 selection:text-indigo-200">
            
            {/* Background Glow Effects */}
            <div className="fixed inset-0 -z-10 overflow-hidden pointer-events-none">
                <div className="absolute top-[-10%] left-[-10%] w-[40%] h-[40%] bg-indigo-600/10 rounded-full blur-[120px]" />
                <div className="absolute bottom-[-10%] right-[-10%] w-[40%] h-[40%] bg-purple-600/10 rounded-full blur-[120px]" />
            </div>

            {/* Mobile Sidebar Overlay */}
            {isMobileSidebarOpen && (
                <div
                    className="fixed inset-0 z-40 bg-gray-900/80 backdrop-blur-sm lg:hidden"
                    onClick={closeMobileSidebar}
                />
            )}

            {/* Sidebar Navigation */}
            <aside
                className={cn(
                    'fixed top-0 left-0 z-50 h-full bg-gray-900/95 backdrop-blur-xl border-r border-gray-800 transition-transform duration-300 ease-in-out lg:translate-x-0',
                    isMobileSidebarOpen ? 'translate-x-0' : '-translate-x-full',
                    isSidebarCollapsed ? 'lg:w-[80px]' : 'lg:w-[280px]',
                    'w-[280px]' // Default mobile width
                )}
            >
                {renderSidebar({
                    isCollapsed: isSidebarCollapsed,
                    isMobileOpen: isMobileSidebarOpen,
                    onToggleCollapse: handleToggleSidebar,
                    onCloseMobile: closeMobileSidebar,
                    className: 'h-full',
                })}
            </aside>

            {/* Main Content Wrapper */}
            <div className={cn("flex-1 min-h-screen transition-[margin] duration-300 ease-in-out", sidebarWidthClass)}>
                
                {/* Sticky Header */}
                <header className="sticky top-0 z-40 w-full h-16 border-b border-gray-800 bg-gray-900/80 backdrop-blur-xl">
                    <div className="h-full w-full px-4 sm:px-6 flex items-center">
                        <Header 
                            onToggleSidebar={handleToggleSidebar} 
                            isSidebarCollapsed={isSidebarCollapsed} 
                        />
                    </div>
                </header>

                {/* Notification Banners */}
                <div className="sticky top-16 z-30 w-full">
                    <GlobalNotificationBanner />
                    {showEmailVerificationBanner && (
                        <div className="border-b border-gray-800 bg-gray-900/90 backdrop-blur-md">
                            <div className="container mx-auto px-4">
                                <EmailVerificationBanner />
                            </div>
                        </div>
                    )}
                </div>

                {/* Page Content */}
                <main className="p-4 sm:p-6 lg:p-8">
                    <div 
                        className="mx-auto w-full animate-in fade-in duration-500"
                        style={{ maxWidth: contentMaxWidth }}
                    >
                        {children}
                    </div>
                </main>
            </div>
        </div>
    );
}

export default DashboardShell;