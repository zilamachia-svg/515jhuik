import { BrowserRouter } from 'react-router-dom';
import { Toaster } from 'sonner';

import { AppRoutes } from './routes/AppRoutes';
import { UserProvider } from './services/UserContext';
import { ThemeProvider } from './contexts/ThemeContext';
import { LanguageProvider } from './contexts/LanguageContext';
import { PageTitleProvider } from './contexts/PageTitleContext';
import { FilterProvider } from './contexts/FilterContext';
import { ImageSettingsProvider } from './contexts/ImageSettingsContext';
import { ApiLogProvider } from './contexts/ApiLogContext';
import { ErrorBoundary } from './components/ErrorBoundary';
import { TooltipProvider } from './components/ui/tooltip';

function App() {
    return (
        <BrowserRouter>
            <ErrorBoundary>
                <ThemeProvider>
                    <LanguageProvider>
                        <UserProvider>
                            <PageTitleProvider>
                                <FilterProvider>
                                    <ImageSettingsProvider>
                                        <ApiLogProvider>
                                            <TooltipProvider>
                                                <AppRoutes />
                                                <Toaster richColors position="top-right" closeButton />
                                            </TooltipProvider>
                                        </ApiLogProvider>
                                    </ImageSettingsProvider>
                                </FilterProvider>
                            </PageTitleProvider>
                        </UserProvider>
                    </LanguageProvider>
                </ThemeProvider>
            </ErrorBoundary>
        </BrowserRouter>
    );
}

export default App;