/**
 * Central configuration for internationalization.
 * To add a new language:
 * 1. Add a new JSON file in the `locales` directory (e.g., `fr.json`).
 * 2. Add a new entry to the `languages` array below with the language code,
 *    native name, and the dynamic import statement.
 */

export const languages = [
    { code: 'vi', name: 'Tiếng Việt', import: () => import('./vi.json') },
    { code: 'en', name: 'English', import: () => import('./en.json') },
    // Example for adding French:
    // { code: 'fr', name: 'Français', import: () => import('./fr.json') },
] as const; // `as const` is crucial for strong type inference.

export const defaultLanguage: LanguageCode = 'vi';

// --- Types derived from the configuration ---

// An array of all supported language codes (e.g., ['vi', 'en'])
export const languageCodes = languages.map(lang => lang.code);

// A union type of all supported language codes (e.g., 'vi' | 'en')
export type LanguageCode = typeof languageCodes[number];

/**
 * A helper function to find the configuration for a specific language code.
 * @param code The language code to look up.
 * @returns The language configuration object or undefined if not found.
 */
export const getLanguageConfig = (code: LanguageCode) => {
    return languages.find(lang => lang.code === code);
};
