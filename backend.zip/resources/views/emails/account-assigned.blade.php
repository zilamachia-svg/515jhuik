@component('mail::message')
# Tài Khoản Của Bạn Đã Sẵn Sàng 🎉

Chào {{ $order->user->name }},

Chúng tôi vui mừng thông báo rằng tài khoản **{{ $platform }}** của bạn cho đơn hàng **#{{ $order->id }}** đã được chuẩn bị.

@component('mail::panel')
**Chi Tiết Tài Khoản**

- **Platform:** {{ $platform }}
- **Tài Khoản (UID):** {{ $uid }}
- **Đơn Hàng:** #{{ $order->id }}
- **Thời Gian Tạo:** {{ $order->created_at->format('d/m/Y H:i:s') }}
@endcomponent

## Thông Tin Đăng Nhập

Thông tin đầu đủ của tài khoản đã được gửi đến hộp thư đến của bạn. Vui lòng kiểm tra email chi tiết trong thư đính kèm hoặc tại tài khoản của bạn.

@component('mail::button', ['url' => config('app.url') . '/orders/' . $order->id])
Xem Đơn Hàng
@endcomponent

## Lưu Ý Quan Trọng

⚠️ **Bảo mật:** Không chia sẻ thông tin đăng nhập của bạn với bất kỳ ai.

⚠️ **Quyền sở hữu:** Tài khoản này được mua từ chúng tôi và bạn phải tuân theo các điều khoản dịch vụ của {{ $platform }}.

⚠️ **Hỗ trợ:** Nếu có bất kỳ vấn đề nào, vui lòng liên hệ với chúng tôi qua [support@example.com](mailto:support@example.com).

Cảm ơn bạn đã tin tưởng chúng tôi! 👍

@endcomponent
