<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('users', function (Blueprint $table) {
            // Add balance if not exists
            if (!Schema::hasColumn('users', 'balance')) {
                $table->decimal('balance', 10, 2)->default(0)->after('email_verified_at');
            }
            
            // Add referral_link if not exists
            if (!Schema::hasColumn('users', 'referral_link')) {
                $table->string('referral_link')->nullable()->after('balance');
            }
            
            // Add role if not exists (for simple role management)
            if (!Schema::hasColumn('users', 'role')) {
                $table->string('role')->default('user')->after('referral_link');
            }
        });
    }

    public function down(): void
    {
        Schema::table('users', function (Blueprint $table) {
            if (Schema::hasColumn('users', 'balance')) {
                $table->dropColumn('balance');
            }
            if (Schema::hasColumn('users', 'referral_link')) {
                $table->dropColumn('referral_link');
            }
            if (Schema::hasColumn('users', 'role')) {
                $table->dropColumn('role');
            }
        });
    }
};

