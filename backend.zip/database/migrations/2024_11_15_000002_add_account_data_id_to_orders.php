<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('orders', function (Blueprint $table) {
            // Add account_data_id column if it doesn't exist
            if (!Schema::hasColumn('orders', 'account_data_id')) {
                $table->unsignedBigInteger('account_data_id')->nullable()->after('product_id');
                $table->foreign('account_data_id')->references('id')->on('account_data')->onDelete('set null');
                $table->index('account_data_id');
            }
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('orders', function (Blueprint $table) {
            if (Schema::hasColumn('orders', 'account_data_id')) {
                $table->dropForeign(['account_data_id']);
                $table->dropIndex(['account_data_id']);
                $table->dropColumn('account_data_id');
            }
        });
    }
};
