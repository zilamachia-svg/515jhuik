<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     * 
     * Adds database indexes to improve query performance
     * 
     * Note: Laravel will handle duplicate index errors gracefully
     * If indexes already exist, migration will fail but can be safely ignored
     */
    public function up(): void
    {
        // Products table indexes
        Schema::table('products', function (Blueprint $table) {
            // Index for is_active filtering (most common query)
            // Note: products table uses 'is_active' (boolean), not 'status'
            $table->index('is_active', 'products_is_active_index');
            
            // Index for category filtering
            $table->index('category_id', 'products_category_id_index');
            
            // Composite index for common queries (is_active + category)
            $table->index(['is_active', 'category_id'], 'products_is_active_category_index');
            
            // Index for sorting by created_at
            $table->index('created_at', 'products_created_at_index');
            
            // Index for price range queries
            $table->index('price', 'products_price_index');
        });

        // Orders table indexes
        Schema::table('orders', function (Blueprint $table) {
            // Index for user orders (most common query)
            $table->index('user_id', 'orders_user_id_index');
            
            // Index for status filtering
            $table->index('status', 'orders_status_index');
            
            // Composite index for user orders by status
            $table->index(['user_id', 'status'], 'orders_user_status_index');
            
            // Index for sorting
            $table->index('created_at', 'orders_created_at_index');
        });

        // Deposits table indexes
        Schema::table('deposits', function (Blueprint $table) {
            // Index for user deposits
            $table->index('user_id', 'deposits_user_id_index');
            
            // Index for status filtering
            $table->index('status', 'deposits_status_index');
            
            // Index for sorting
            $table->index('created_at', 'deposits_created_at_index');
        });

        // Users table indexes
        Schema::table('users', function (Blueprint $table) {
            // Index for email verification check
            $table->index('email_verified_at', 'users_email_verified_at_index');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('products', function (Blueprint $table) {
            $table->dropIndex('products_is_active_index');
            $table->dropIndex('products_category_id_index');
            $table->dropIndex('products_is_active_category_index');
            $table->dropIndex('products_created_at_index');
            $table->dropIndex('products_price_index');
        });

        Schema::table('orders', function (Blueprint $table) {
            $table->dropIndex('orders_user_id_index');
            $table->dropIndex('orders_status_index');
            $table->dropIndex('orders_user_status_index');
            $table->dropIndex('orders_created_at_index');
        });

        Schema::table('deposits', function (Blueprint $table) {
            $table->dropIndex('deposits_user_id_index');
            $table->dropIndex('deposits_status_index');
            $table->dropIndex('deposits_created_at_index');
        });

        Schema::table('users', function (Blueprint $table) {
            $table->dropIndex('users_email_verified_at_index');
        });
    }
};
