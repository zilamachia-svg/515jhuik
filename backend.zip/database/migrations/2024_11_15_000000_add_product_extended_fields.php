<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('products', function (Blueprint $table) {
            // Thêm các trường mới nếu chưa tồn tại
            if (!Schema::hasColumn('products', 'sku')) {
                $table->string('sku')->nullable()->unique()->after('name');
            }
            if (!Schema::hasColumn('products', 'type')) {
                $table->string('type')->default('simple')->after('sku'); // simple, variable, grouped
            }
            if (!Schema::hasColumn('products', 'short_description')) {
                $table->text('short_description')->nullable()->after('description');
            }
            if (!Schema::hasColumn('products', 'regular_price')) {
                $table->decimal('regular_price', 10, 2)->nullable()->after('price');
            }
            if (!Schema::hasColumn('products', 'sale_price')) {
                $table->decimal('sale_price', 10, 2)->nullable()->after('regular_price');
            }
            if (!Schema::hasColumn('products', 'on_sale')) {
                $table->boolean('on_sale')->default(false)->after('sale_price');
            }
            if (!Schema::hasColumn('products', 'views')) {
                $table->bigInteger('views')->default(0)->after('is_active');
            }
            if (!Schema::hasColumn('products', 'rating')) {
                $table->decimal('rating', 3, 2)->nullable()->after('views');
            }
        });
    }

    public function down(): void
    {
        Schema::table('products', function (Blueprint $table) {
            $table->dropColumn([
                'sku',
                'type',
                'short_description',
                'regular_price',
                'sale_price',
                'on_sale',
                'views',
                'rating',
            ]);
        });
    }
};
