<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('account_data', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('product_id')->nullable()->index();
            
            // Platform: facebook, tiktok, instagram, gmail, outlook
            $table->string('platform', 50)->index(); // facebook, tiktok, instagram, gmail, outlook
            
            // Thông tin tài khoản
            $table->string('uid')->nullable(); // User ID
            $table->text('pass')->nullable(); // Mật khẩu (encrypt)
            $table->string('password_2fa')->nullable(); // 2FA code/password
            $table->string('email')->nullable(); // Email đăng nhập
            $table->text('passmail')->nullable(); // Mật khẩu email (encrypt)
            $table->string('emailkp')->nullable(); // Email backup/khôi phục
            $table->integer('friend_count')->nullable(); // Số bạn bè (cho Facebook)
            $table->string('created_date')->nullable(); // Ngày tạo tài khoản
            $table->string('birthday')->nullable(); // Ngày sinh
            
            // Session & Token
            $table->longText('cookie')->nullable(); // Cookie session
            $table->longText('token')->nullable(); // Access token
            
            // Trạng thái sử dụng
            $table->boolean('is_used')->default(false)->index();
            $table->unsignedBigInteger('used_by_customer_id')->nullable()->index();
            $table->timestamp('used_at')->nullable();
            
            // Ghi chú
            $table->text('notes')->nullable();
            
            $table->timestamps();
            $table->softDeletes();
            
            // Foreign keys
            $table->foreign('product_id')->references('id')->on('products')->onDelete('cascade');
            $table->foreign('used_by_customer_id')->references('id')->on('users')->onDelete('set null');
            
            // Indexes for performance
            $table->index(['platform', 'is_used']);
            $table->index(['product_id', 'is_used']);
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('account_data');
    }
};
