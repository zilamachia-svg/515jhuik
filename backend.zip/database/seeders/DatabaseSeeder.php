<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     */
    public function run(): void
    {
        $this->call([
            AdminUserSeeder::class, // Add this line
            RolePermissionSeeder::class,
            UserSeeder::class,
            ProductCategorySeeder::class,
            ProductSeeder::class,
            PaymentMethodSeeder::class,
            PostSeeder::class,
            FaqSeeder::class,
            SettingSeeder::class,
        ]);
    }
}

