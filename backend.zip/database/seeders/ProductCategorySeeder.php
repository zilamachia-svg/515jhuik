<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\ProductCategory;

class ProductCategorySeeder extends Seeder
{
    public function run(): void
    {
        $categories = [
            [
                'name' => 'Facebook Account',
                'description' => 'Tài khoản Facebook các loại',
            ],
            [
                'name' => 'VIA US',
                'description' => 'Tài khoản VIA US',
            ],
            [
                'name' => 'Clone Philippines',
                'description' => 'Tài khoản Clone Philippines',
            ],
            [
                'name' => 'Tài khoản khác',
                'description' => 'Các loại tài khoản khác',
            ],
        ];

        foreach ($categories as $category) {
            ProductCategory::firstOrCreate(
                ['name' => $category['name']],
                $category
            );
        }
    }
}

