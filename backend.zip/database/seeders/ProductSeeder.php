<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\Product;
use App\Models\ProductCategory;

class ProductSeeder extends Seeder
{
    public function run(): void
    {
        $categories = ProductCategory::all();

        $products = [
            [
                'name' => 'VIA US Cổ',
                'description' => 'Tài khoản VIA US chất lượng cao, đã được verify',
                'price' => 50000,
                'stock' => 150,
                'country' => 'US',
                'category' => 'VIA US',
                'category_id' => $categories->where('name', 'VIA US')->first()?->id,
                'is_active' => true,
            ],
            [
                'name' => 'Clone Philippines',
                'description' => 'Tài khoản Clone Philippines giá rẻ, số lượng lớn',
                'price' => 15000,
                'stock' => 2500,
                'country' => 'Philippines',
                'category' => 'Clone Philippines',
                'category_id' => $categories->where('name', 'Clone Philippines')->first()?->id,
                'is_active' => true,
            ],
            [
                'name' => 'Facebook Account US',
                'description' => 'Tài khoản Facebook US mới, chưa sử dụng',
                'price' => 30000,
                'stock' => 500,
                'country' => 'US',
                'category' => 'Facebook Account',
                'category_id' => $categories->where('name', 'Facebook Account')->first()?->id,
                'is_active' => true,
            ],
            [
                'name' => 'Facebook Account VN',
                'description' => 'Tài khoản Facebook Việt Nam',
                'price' => 20000,
                'stock' => 800,
                'country' => 'VN',
                'category' => 'Facebook Account',
                'category_id' => $categories->where('name', 'Facebook Account')->first()?->id,
                'is_active' => true,
            ],
        ];

        foreach ($products as $product) {
            // Get category ID
            $categoryId = $product['category_id'] ?? null;
            
            if (!$categoryId) {
                // Skip if category not found
                $this->command->warn("Category '{$product['category']}' not found. Skipping product: {$product['name']}");
                continue;
            }
            
            // Prepare product data
            $productData = [
                'name' => $product['name'],
                'description' => $product['description'],
                'price' => $product['price'],
                'stock' => $product['stock'],
                'country' => $product['country'],
                'category' => $product['category'],
                'category_id' => $categoryId,
                'is_active' => $product['is_active'] ?? true,
            ];
            
            Product::firstOrCreate(
                ['name' => $productData['name']],
                $productData
            );
        }
    }
}

