<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\PaymentMethod;

class PaymentMethodSeeder extends Seeder
{
    public function run(): void
    {
        $methods = [
            [
                'id' => 'pm_bank_vietcombank',
                'type' => 'bank',
                'name' => 'Vietcombank',
                'account_name' => 'NGUYEN VAN A',
                'account_number' => '1234567890',
                'qr_code_url' => null,
                'is_active' => true,
            ],
            [
                'id' => 'pm_bank_techcombank',
                'type' => 'bank',
                'name' => 'Techcombank',
                'account_name' => 'NGUYEN VAN A',
                'account_number' => '0987654321',
                'qr_code_url' => null,
                'is_active' => true,
            ],
            [
                'id' => 'pm_momo',
                'type' => 'momo',
                'name' => 'MoMo',
                'account_name' => 'NGUYEN VAN A',
                'account_number' => '0901234567',
                'qr_code_url' => null,
                'is_active' => true,
            ],
        ];

        foreach ($methods as $method) {
            PaymentMethod::firstOrCreate(
                ['id' => $method['id']],
                $method
            );
        }
    }
}

