<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Facades\DB;

class RolePermissionSeeder extends Seeder
{
    public function run(): void
    {
        // Check if Spatie Permission tables exist
        $hasPermissionsTable = Schema::hasTable('permissions');
        $hasRolesTable = Schema::hasTable('roles');

        if ($hasPermissionsTable && $hasRolesTable) {
            // Use Spatie Permission if tables exist
            $this->seedWithSpatiePermission();
        } else {
            // Fallback: Just log that roles are managed via user.role column
            $this->seedWithoutSpatiePermission();
        }
    }

    private function seedWithSpatiePermission(): void
    {
        try {
            // Reset cached roles and permissions
            if (class_exists(\Spatie\Permission\PermissionRegistrar::class)) {
                app()[\Spatie\Permission\PermissionRegistrar::class]->forgetCachedPermissions();
            }

            $permissionModel = \Spatie\Permission\Models\Permission::class;
            $roleModel = \Spatie\Permission\Models\Role::class;

            // Create permissions
            $permissions = [
                'view products',
                'create products',
                'edit products',
                'delete products',
                'view orders',
                'manage orders',
                'view users',
                'manage users',
                'view deposits',
                'manage deposits',
                'manage settings',
                'manage posts',
                'manage faq',
            ];

            foreach ($permissions as $permission) {
                $permissionModel::firstOrCreate(['name' => $permission]);
            }

            // Create roles
            $adminRole = $roleModel::firstOrCreate(['name' => 'admin']);
            $userRole = $roleModel::firstOrCreate(['name' => 'user']);

            // Assign all permissions to admin
            $adminRole->syncPermissions($permissionModel::all());
        } catch (\Exception $e) {
            // If Spatie Permission fails, fallback to simple seeding
            $this->seedWithoutSpatiePermission();
        }
    }

    private function seedWithoutSpatiePermission(): void
    {
        // If Spatie Permission is not available, roles are managed via user.role column
        // This seeder will just ensure the role values are valid
        // Roles: 'admin', 'user' are already set in users table via migration
        
        $this->command->info('Spatie Permission tables not found. Roles are managed via user.role column.');
        $this->command->info('Valid roles: admin, user');
    }
}

