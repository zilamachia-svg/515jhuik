<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\Faq;

class FaqSeeder extends Seeder
{
    public function run(): void
    {
        $faqs = [
            [
                'question' => 'Làm thế nào để mua tài khoản?',
                'answer' => 'Bạn chỉ cần đăng ký tài khoản, nạp tiền vào tài khoản, sau đó chọn sản phẩm và mua.',
                'is_active' => true,
                'order' => 1,
            ],
            [
                'question' => 'Tài khoản có bảo hành không?',
                'answer' => 'Có, tất cả tài khoản đều có bảo hành theo chính sách của chúng tôi.',
                'is_active' => true,
                'order' => 2,
            ],
            [
                'question' => 'Thanh toán như thế nào?',
                'answer' => 'Bạn có thể thanh toán qua chuyển khoản ngân hàng hoặc ví điện tử MoMo.',
                'is_active' => true,
                'order' => 3,
            ],
            [
                'question' => 'Làm sao để liên hệ hỗ trợ?',
                'answer' => 'Bạn có thể liên hệ qua email hoặc chat trực tiếp trên website.',
                'is_active' => true,
                'order' => 4,
            ],
        ];

        foreach ($faqs as $faq) {
            Faq::firstOrCreate(
                ['question' => $faq['question']],
                $faq
            );
        }
    }
}

