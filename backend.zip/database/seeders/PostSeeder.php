<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\Post;
use App\Models\User;

class PostSeeder extends Seeder
{
    public function run(): void
    {
        $admin = User::where('email', 'admin@haidangmeta.com')->first();

        $posts = [
            [
                'author_id' => $admin?->id,
                'title' => 'Chào mừng đến với Hải Đăng Meta',
                'slug' => 'chao-mung-den-voi-hai-dang-meta',
                'content' => '<p>Chào mừng bạn đến với Hải Đăng Meta - Nền tảng mua bán tài khoản Facebook uy tín!</p>',
                'status' => 'published',
                'published_at' => now(),
            ],
            [
                'author_id' => $admin?->id,
                'title' => 'Hướng dẫn sử dụng dịch vụ',
                'slug' => 'huong-dan-su-dung-dich-vu',
                'content' => '<p>Hướng dẫn chi tiết cách sử dụng dịch vụ của chúng tôi.</p>',
                'status' => 'published',
                'published_at' => now()->subDays(1),
            ],
        ];

        if (!$admin) {
            $this->command->warn('Admin user not found. Skipping posts seeding.');
            return;
        }

        foreach ($posts as $post) {
            Post::firstOrCreate(
                ['slug' => $post['slug']],
                $post
            );
        }
    }
}

