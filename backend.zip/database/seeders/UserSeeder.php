<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\User;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Schema;

class UserSeeder extends Seeder
{
    public function run(): void
    {
        // Create admin user
        $admin = User::firstOrCreate(
            ['email' => 'admin@haidangmeta.com'],
            [
                'name' => 'Admin',
                'password' => Hash::make('admin123'),
                'email_verified_at' => now(),
                'balance' => 10000000, // 10 million VND
                'referral_link' => 'adminref',
                'role' => 'admin',
            ]
        );

        // Assign role using Spatie Permission if available, otherwise use role column
        if (Schema::hasTable('roles') && method_exists($admin, 'assignRole')) {
            try {
                $admin->assignRole('admin');
            } catch (\Exception $e) {
                // If Spatie Permission fails, role is already set in column
                $admin->update(['role' => 'admin']);
            }
        } else {
            // Use role column directly
            $admin->update(['role' => 'admin']);
        }

        // Create test user
        $user = User::firstOrCreate(
            ['email' => 'user@haidangmeta.com'],
            [
                'name' => 'Test User',
                'password' => Hash::make('user123'),
                'email_verified_at' => now(),
                'balance' => 500000, // 500k VND
                'referral_link' => 'userref',
                'role' => 'user',
            ]
        );

        // Assign role using Spatie Permission if available, otherwise use role column
        if (Schema::hasTable('roles') && method_exists($user, 'assignRole')) {
            try {
                $user->assignRole('user');
            } catch (\Exception $e) {
                // If Spatie Permission fails, role is already set in column
                $user->update(['role' => 'user']);
            }
        } else {
            // Use role column directly
            $user->update(['role' => 'user']);
        }
    }
}

