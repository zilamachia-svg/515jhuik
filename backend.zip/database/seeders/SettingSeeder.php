<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\Setting;

class SettingSeeder extends Seeder
{
    public function run(): void
    {
        $settings = [
            // Website settings
            ['key' => 'website_name', 'value' => 'Hải Đăng Meta', 'group' => 'website'],
            ['key' => 'website_description', 'value' => 'Nền tảng mua bán tài khoản Facebook uy tín', 'group' => 'website'],
            ['key' => 'website_email', 'value' => 'support@haidangmeta.com', 'group' => 'website'],
            ['key' => 'website_phone', 'value' => '0123456789', 'group' => 'website'],
            
            // Contact settings
            ['key' => 'contact_address', 'value' => '123 Đường ABC, Quận XYZ, TP.HCM', 'group' => 'contact'],
            ['key' => 'contact_email', 'value' => 'contact@haidangmeta.com', 'group' => 'contact'],
            ['key' => 'contact_phone', 'value' => '0123456789', 'group' => 'contact'],
            
            // Payment settings
            ['key' => 'min_deposit', 'value' => '50000', 'group' => 'payment'],
            ['key' => 'max_deposit', 'value' => '10000000', 'group' => 'payment'],
            
            // Social settings
            ['key' => 'facebook_page_id', 'value' => '', 'group' => 'social'],
            ['key' => 'facebook_app_id', 'value' => '820326607281961', 'group' => 'social'],
        ];

        foreach ($settings as $setting) {
            Setting::updateOrCreate(
                ['key' => $setting['key']],
                $setting
            );
        }
    }
}

