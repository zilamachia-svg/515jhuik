<?php

return [
    'paths' => ['api/*', 'sanctum/csrf-cookie'],

    'allowed_methods' => ['*'],

    'allowed_origins' => explode(',', env(
    'CORS_ALLOWED_ORIGINS',
    'https://haidangmeta.com,https://www.haidangmeta.com,http://localhost:5173,http://localhost:3000'
)),

    'allowed_origins_patterns' => [],

    'allowed_headers' => ['*'],

    'exposed_headers' => ['XSRF-TOKEN', 'Cache-Tag'],

    'max_age' => 0,

    'supports_credentials' => env('CORS_SUPPORTS_CREDENTIALS', true),
];