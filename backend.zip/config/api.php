<?php

return [
    /*
    |--------------------------------------------------------------------------
    | API Configuration
    |--------------------------------------------------------------------------
    |
    | Configuration for API features including monitoring, rate limiting,
    | and versioning.
    |
    */

    /*
    |--------------------------------------------------------------------------
    | API Monitoring
    |--------------------------------------------------------------------------
    |
    | Enable API monitoring to track performance metrics, request/response
    | logging, and error tracking.
    |
    */

    'monitoring' => [
        'enabled' => env('API_MONITORING_ENABLED', true),
        'log_slow_requests' => env('API_MONITORING_LOG_SLOW', true),
        'slow_request_threshold_ms' => env('API_MONITORING_SLOW_THRESHOLD', 1000), // 1 second
    ],

    /*
    |--------------------------------------------------------------------------
    | Rate Limiting
    |--------------------------------------------------------------------------
    |
    | Default rate limiting configuration for API endpoints.
    | Format: 'max_attempts,decay_minutes'
    |
    */

    'rate_limiting' => [
        'default' => '60,1', // 60 requests per minute
        'auth' => '5,1', // 5 requests per minute for auth endpoints
        'deposits' => '10,60', // 10 requests per hour for deposits
        'verification' => '3,60', // 3 requests per hour for verification
    ],

    /*
    |--------------------------------------------------------------------------
    | API Versioning
    |--------------------------------------------------------------------------
    |
    | Configuration for API versioning strategy.
    |
    */

    'versioning' => [
        'default_version' => 'v1',
        'supported_versions' => ['v1'],
        'version_header' => 'X-API-Version',
        'version_parameter' => 'api_version',
    ],

    /*
    |--------------------------------------------------------------------------
    | API Documentation
    |--------------------------------------------------------------------------
    |
    | Configuration for API documentation (Swagger/OpenAPI).
    |
    */

    'documentation' => [
        'enabled' => env('API_DOCS_ENABLED', true),
        'path' => env('API_DOCS_PATH', '/api/docs'),
        'title' => env('API_DOCS_TITLE', 'Hải Đăng Meta API'),
        'version' => env('API_DOCS_VERSION', '1.0.0'),
        'description' => env('API_DOCS_DESCRIPTION', 'API Documentation for Hải Đăng Meta'),
    ],
];

