<?php

use Illuminate\Foundation\Application;
use Illuminate\Foundation\Configuration\Exceptions;
use Illuminate\Foundation\Configuration\Middleware;

return Application::configure(dirname(__DIR__))
    ->withRouting(
        null, // $using
        __DIR__.'/../routes/web.php', // $web
        __DIR__.'/../routes/api.php', // $api
        __DIR__.'/../routes/console.php', // $commands
        null, // $channels
        null, // $pages
        '/up' // $health
    )
    ->withMiddleware(function (Middleware $middleware) {
        // Stateful API configuration for Laravel Sanctum SPA authentication
        // This enables session-based auth for frontend requests
        $middleware->statefulApi();
        
        // API middleware - Add Sanctum middleware to API routes
        $middleware->api(prepend: [
            \Laravel\Sanctum\Http\Middleware\EnsureFrontendRequestsAreStateful::class,
        ]);

        // Global middleware for monitoring
        $middleware->append(\App\Http\Middleware\ApiMonitoring::class);

        // Route middleware aliases
        $middleware->alias([
            'role' => \App\Http\Middleware\CheckRole::class,
        ]);
    })
    ->withExceptions(function (Exceptions $exceptions) {
        //
    })->create();
