<?php return array (
  'App\\Providers\\EventServiceProvider' => 
  array (
    'App\\Events\\AccountAssigned' => 
    array (
      0 => 'App\\Listeners\\SendAccountAssignedNotification',
    ),
  ),
  'Illuminate\\Foundation\\Support\\Providers\\EventServiceProvider' => 
  array (
    'App\\Events\\AccountAssigned' => 
    array (
      0 => 'App\\Listeners\\SendAccountAssignedNotification@handle',
    ),
  ),
);