<?php $__env->startComponent('mail::message'); ?>
# Tài Khoản Của Bạn Đã Sẵn Sàng 🎉

Chào <?php echo e($order->user->name); ?>,

Chúng tôi vui mừng thông báo rằng tài khoản **<?php echo e($platform); ?>** của bạn cho đơn hàng **#<?php echo e($order->id); ?>** đã được chuẩn bị.

<?php $__env->startComponent('mail::panel'); ?>
**Chi Tiết Tài Khoản**

- **Platform:** <?php echo e($platform); ?>

- **Tài Khoản (UID):** <?php echo e($uid); ?>

- **Đơn Hàng:** #<?php echo e($order->id); ?>

- **Thời Gian Tạo:** <?php echo e($order->created_at->format('d/m/Y H:i:s')); ?>

<?php echo $__env->renderComponent(); ?>

## Thông Tin Đăng Nhập

Thông tin đầu đủ của tài khoản đã được gửi đến hộp thư đến của bạn. Vui lòng kiểm tra email chi tiết trong thư đính kèm hoặc tại tài khoản của bạn.

<?php $__env->startComponent('mail::button', ['url' => config('app.url') . '/orders/' . $order->id]); ?>
Xem Đơn Hàng
<?php echo $__env->renderComponent(); ?>

## Lưu Ý Quan Trọng

⚠️ **Bảo mật:** Không chia sẻ thông tin đăng nhập của bạn với bất kỳ ai.

⚠️ **Quyền sở hữu:** Tài khoản này được mua từ chúng tôi và bạn phải tuân theo các điều khoản dịch vụ của <?php echo e($platform); ?>.

⚠️ **Hỗ trợ:** Nếu có bất kỳ vấn đề nào, vui lòng liên hệ với chúng tôi qua [support@example.com](mailto:support@example.com).

Cảm ơn bạn đã tin tưởng chúng tôi! 👍

<?php echo $__env->renderComponent(); ?>
<?php /**PATH C:\xampp\htdocs\hd\haidangmeta\resources\views\emails\account-assigned.blade.php ENDPATH**/ ?>