<!DOCTYPE html>
<html lang="vi">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    
    <!-- Primary Meta Tags -->
    <title>HẢI ĐĂNG META - Nền tảng dịch vụ meta hàng đầu Việt Nam</title>
    <meta name="title" content="HẢI ĐĂNG META - Nền tảng dịch vụ meta hàng đầu Việt Nam" />
    <meta name="description" content="Nền tảng dịch vụ meta hàng đầu Việt Nam. Mua bán tài khoản, nạp tiền, quản lý đơn hàng và nhiều tính năng khác." />
    <meta name="keywords" content="hải đăng meta, dịch vụ meta, tài khoản facebook, tài khoản instagram, nạp tiền online" />
    <meta name="author" content="Hải Đăng Meta" />
    <meta name="robots" content="index, follow" />
    
    <!-- Favicon -->
    <link rel="icon" type="image/x-icon" href="<?php echo e(asset('favicon.ico')); ?>" />
    <link rel="apple-touch-icon" href="<?php echo e(asset('apple-icon.png')); ?>" />
    
    <!-- Facebook / Open Graph -->
    <meta property="og:type" content="website" />
    <meta property="og:url" content="https://haidangmeta.com/" />
    <meta property="og:title" content="HẢI ĐĂNG META - Nền tảng dịch vụ meta hàng đầu Việt Nam" />
    <meta property="og:description" content="Nền tảng dịch vụ meta hàng đầu Việt Nam. Mua bán tài khoản, nạp tiền, quản lý đơn hàng và nhiều tính năng khác." />
    <meta property="og:image" content="<?php echo e(asset('logo.png')); ?>" />
    <meta property="fb:app_id" content="820326607281961" />
    <meta name="facebook-domain-verification" content="mivfxi411r8is9w2ieh05ahhliejo8" />
    
    <!-- Twitter -->
    <meta name="twitter:card" content="summary_large_image" />
    <meta name="twitter:title" content="HẢI ĐĂNG META - Nền tảng dịch vụ meta hàng đầu Việt Nam" />
    <meta name="twitter:description" content="Nền tảng dịch vụ meta hàng đầu Việt Nam. Mua bán tài khoản, nạp tiền, quản lý đơn hàng và nhiều tính năng khác." />
    <meta name="twitter:image" content="<?php echo e(asset('logo.png')); ?>" />
    
    <!-- Google Fonts: Inter & JetBrains Mono -->
    <link rel="preconnect" href="https://fonts.googleapis.com" />
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@100..900&family=JetBrains+Mono:wght@100..800&display=swap" rel="stylesheet" />
    
    <!-- Google Maps API -->
    <script>
      let mapScriptLoaded = false;
      function initMap() {
        // Google Maps initialization callback
        // This will be called when the map script loads
        if (window.google && window.google.maps) {
          mapScriptLoaded = true;
          console.log('Google Maps API loaded successfully');
        }
      }
      window.initMap = initMap;
    </script>
    <script 
      async 
      defer 
      src="https://maps.googleapis.com/maps/api/js?key=AIzaSyB41DRUbKWJHPxaFjMAwdrzWzbVKartNGg&callback=initMap&v=weekly&loading=async"
    ></script>
    
    <!-- Vite Build Assets - Dynamically loaded from manifest -->
    <?php
      $manifest = null;
      $manifestPath = public_path('.vite/manifest.json');
      
      // Try to load manifest if it exists
      if (file_exists($manifestPath)) {
          $manifest = json_decode(file_get_contents($manifestPath), true);
      }
      
      // Fallback: Find assets by pattern
      $cssFiles = glob(public_path('assets/index-*.css'));
      $jsFiles = glob(public_path('assets/index-*.js'));
      $vendorCssFiles = glob(public_path('assets/vendor-react-*.css'));
      $vendorJsFiles = glob(public_path('assets/vendor-react-*.js'));
      
      // Get filenames
      $cssFile = !empty($cssFiles) ? 'assets/' . basename($cssFiles[0]) : null;
      $jsFile = !empty($jsFiles) ? 'assets/' . basename($jsFiles[0]) : null;
      $vendorCss = !empty($vendorCssFiles) ? 'assets/' . basename($vendorCssFiles[0]) : null;
      $vendorJs = !empty($vendorJsFiles) ? 'assets/' . basename($vendorJsFiles[0]) : null;
    ?>
    
    <?php if($vendorCss): ?>
      <link rel="stylesheet" crossorigin href="<?php echo e(asset($vendorCss)); ?>">
    <?php endif; ?>
    <?php if($cssFile): ?>
      <link rel="stylesheet" crossorigin href="<?php echo e(asset($cssFile)); ?>">
    <?php endif; ?>
    <?php if($vendorJs): ?>
      <link rel="modulepreload" crossorigin href="<?php echo e(asset($vendorJs)); ?>">
    <?php endif; ?>
  </head>
  <body data-theme="light">
    <div id="root"></div>
    
    <?php if($jsFile): ?>
      <script type="module" crossorigin src="<?php echo e(asset($jsFile)); ?>"></script>
    <?php endif; ?>
  </body>
</html>
<?php /**PATH C:\xampp\htdocs\hd\haidangmeta\resources\views\app.blade.php ENDPATH**/ ?>