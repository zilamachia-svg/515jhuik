<?php

namespace App\Listeners;

use App\Events\AccountAssigned;
use App\Mail\AccountAssignedMail;
use App\Models\Notification;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\Log;

class SendAccountAssignedNotification implements ShouldQueue
{
    use InteractsWithQueue;

    /**
     * Create the event listener.
     */
    public function __construct()
    {
        //
    }

    /**
     * Handle the event.
     */
    public function handle(AccountAssigned $event): void
    {
        try {
            $order = $event->order;
            $user = $order->user;
            $account = $order->accountData;

            // 1️⃣ CREATE DATABASE NOTIFICATION
            Notification::notify(
                userId: $user->id,
                title: "Tài khoản {$event->platform} của bạn đã sẵn sàng",
                message: "Tài khoản {$event->platform} cho đơn hàng #{$order->id} đã được gán cho bạn.",
                type: 'order',
                data: [
                    'order_id' => $order->id,
                    'platform' => $event->platform,
                    'uid' => $event->uid,
                ]
            );

            // 2️⃣ SEND EMAIL IF USER HAS EMAIL
            if ($user->email) {
                // Prepare account data for display (mask sensitive info)
                $accountData = "UID: {$event->uid}";
                
                // Get additional encrypted data
                if ($account) {
                    if ($account->pass) {
                        $accountData .= "\nMật khẩu: " . substr($account->pass, 0, 4) . '****';
                    }
                    if ($account->passmail) {
                        $accountData .= "\nEmail liên kết: " . substr($account->passmail, 0, 4) . '****';
                    }
                }

                // Send email
                Mail::to($user->email)->send(
                    new AccountAssignedMail(
                        $order,
                        $event->platform,
                        $event->uid,
                        $accountData
                    )
                );

                Log::info('Account assigned email sent', [
                    'order_id' => $order->id,
                    'user_id' => $user->id,
                    'email' => $user->email,
                    'platform' => $event->platform,
                ]);
            } else {
                Log::warning('User has no email address', ['user_id' => $user->id]);
            }

        } catch (\Exception $e) {
            Log::error('Failed to send account assigned notification', [
                'order_id' => $event->order->id,
                'error' => $e->getMessage(),
            ]);
            // Re-throw to trigger retry mechanism
            throw $e;
        }
    }
}
