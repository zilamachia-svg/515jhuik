<?php

namespace App\Providers;

use Illuminate\Support\ServiceProvider;
use Illuminate\Support\Facades\URL; // Bổ sung dòng này

class AppServiceProvider extends ServiceProvider
{
    /**
     * Register any application services.
     */
    public function register(): void
    {
        //
    }

    /**
     * Bootstrap any application services.
     */
    public function boot(): void
    {
        // Buộc Laravel sử dụng HTTPS khi chạy trên Production (để hỗ trợ Sanctum và Proxy)
        if (config('app.env') === 'production') {
            URL::forceScheme('https');
        }
    }
}
