<?php

namespace App\Providers;

use Illuminate\Cache\RateLimiting\Limit;
use Illuminate\Foundation\Support\Providers\RouteServiceProvider as ServiceProvider;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\RateLimiter;
use Illuminate\Support\Facades\Route;

class RouteServiceProvider extends ServiceProvider
{
    /**
     * The path to your application's "home" route.
     *
     * Typically, users are redirected here after authentication.
     *
     * @var string
     */
    public const HOME = '/';

    /**
     * Define your route model bindings, pattern filters, and other route configuration.
     */
    public function boot(): void
    {
        // Định nghĩa giới hạn tần suất truy cập (Rate Limiting)
        RateLimiter::for('api', function (Request $request) {
            return Limit::perMinute(60)->by($request->user()?->id ?: $request->ip());
        });

        // Định nghĩa các tập tin Route của ứng dụng
        $this->routes(function () {
            // Định tuyến API (API Routes)
            Route::middleware('api')
                ->prefix('api')
                // ĐÃ SỬA: base_path() chỉ cần trỏ đến 'routes/api.php'
                ->group(base_path('routes/api.php')); 

            // Định tuyến Web (Web Routes)
            Route::middleware('web')
                // ĐÃ SỬA: base_path() chỉ cần trỏ đến 'routes/web.php'
                ->group(base_path('routes/web.php'));
        });
    }
}