<?php

namespace App\Providers;

// Bổ sung các Imports cần thiết (ví dụ: Gates, Policy mapping)
use Illuminate\Foundation\Support\Providers\AuthServiceProvider as ServiceProvider;
use Illuminate\Support\Facades\Gate;

class AuthServiceProvider extends ServiceProvider
{
    /**
     * The model to policy mappings for the application.
     *
     * @var array<class-string, class-string>
     */
    protected $policies = [
        // 'App\Models\Model' => 'App\Policies\ModelPolicy',
    ];

    /**
     * Register any authentication / authorization services.
     */
    public function boot(): void
    {
        // Khởi tạo các chính sách (Policies) nếu cần
        $this->registerPolicies();

        // Định nghĩa Gates (Quyền truy cập)
        // Ví dụ: Gate::define('edit-settings', function ($user) { ... });
    }
}