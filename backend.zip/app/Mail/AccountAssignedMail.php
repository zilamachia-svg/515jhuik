<?php

namespace App\Mail;

use App\Models\Order;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Mail\Mailable;
use Illuminate\Mail\Mailables\Content;
use Illuminate\Mail\Mailables\Envelope;
use Illuminate\Queue\SerializesModels;

class AccountAssignedMail extends Mailable implements ShouldQueue
{
    use Queueable, SerializesModels;

    public Order $order;
    public string $platform;
    public string $uid;
    public string $accountData;

    /**
     * Create a new message instance.
     */
    public function __construct(Order $order, string $platform, string $uid, string $accountData)
    {
        $this->order = $order;
        $this->platform = $platform;
        $this->uid = $uid;
        $this->accountData = $accountData;
    }

    /**
     * Get the message envelope.
     */
    public function envelope(): Envelope
    {
        return new Envelope(
            subject: "Tài khoản {$this->platform} của bạn đã sẵn sàng - Đơn hàng #{$this->order->id}",
        );
    }

    /**
     * Get the message content definition.
     */
    public function content(): Content
    {
        return new Content(
            view: 'emails.account-assigned',
            with: [
                'order' => $this->order,
                'platform' => $this->platform,
                'uid' => $this->uid,
                'accountData' => $this->accountData,
            ],
        );
    }

    /**
     * Get the attachments for the message.
     *
     * @return array<int, \Illuminate\Mail\Mailables\Attachment>
     */
    public function attachments(): array
    {
        return [];
    }
}
