<?php

namespace App\Exceptions;

use Illuminate\Foundation\Exceptions\Handler as ExceptionHandler;
use Throwable;

class Handler extends ExceptionHandler
{
    /**
     * The list of the inputs that are never flashed to the session on validation exceptions.
     *
     * @var array<int, string>
     */
    protected $dontFlash = [
        'current_password',
        'password',
        'password_confirmation',
    ];

    /**
     * Register the exception handling callbacks for the application.
     */
    public function register(): void
    {
        $this->reportable(function (Throwable $e) {
            // Log all exceptions for debugging
            if (config('app.debug')) {
                \Log::error('Exception occurred', [
                    'message' => $e->getMessage(),
                    'file' => $e->getFile(),
                    'line' => $e->getLine(),
                    'trace' => $e->getTraceAsString()
                ]);
            }
        });

        // Handle API Authentication Exceptions (401)
        $this->renderable(function (\Illuminate\Auth\AuthenticationException $e, $request) {
            if ($request->is('api/*')) {
                return response()->json([
                    'message' => 'Bạn cần đăng nhập để truy cập tài nguyên này.',
                    'errors' => ['auth' => ['Vui lòng đăng nhập để tiếp tục.']]
                ], 401);
            }
        });

        // Handle Validation Exceptions (422)
        $this->renderable(function (\Illuminate\Validation\ValidationException $e, $request) {
            if ($request->is('api/*')) {
                return response()->json([
                    'message' => 'Dữ liệu không hợp lệ.',
                    'errors' => $e->errors(),
                ], 422);
            }
        });

        // Handle Model Not Found (404)
        $this->renderable(function (\Illuminate\Database\Eloquent\ModelNotFoundException $e, $request) {
            if ($request->is('api/*')) {
                return response()->json([
                    'message' => 'Không tìm thấy tài nguyên.',
                    'errors' => ['not_found' => ['Tài nguyên bạn yêu cầu không tồn tại.']]
                ], 404);
            }
        });

        // Handle Method Not Allowed (405)
        $this->renderable(function (\Symfony\Component\HttpKernel\Exception\MethodNotAllowedHttpException $e, $request) {
            if ($request->is('api/*')) {
                return response()->json([
                    'message' => 'Phương thức HTTP không được phép.',
                    'errors' => ['method' => ['Phương thức ' . $request->method() . ' không được hỗ trợ cho endpoint này.']]
                ], 405);
            }
        });

        // Handle Too Many Requests (429)
        $this->renderable(function (\Illuminate\Http\Exceptions\ThrottleRequestsException $e, $request) {
            if ($request->is('api/*')) {
                return response()->json([
                    'message' => 'Quá nhiều yêu cầu.',
                    'errors' => ['throttle' => ['Vui lòng thử lại sau vài giây.']]
                ], 429);
            }
        });

        // Handle General Server Errors (500)
        $this->renderable(function (Throwable $e, $request) {
            if ($request->is('api/*')) {
                // Log the error
                \Log::error('API Error', [
                    'url' => $request->fullUrl(),
                    'method' => $request->method(),
                    'message' => $e->getMessage(),
                    'file' => $e->getFile(),
                    'line' => $e->getLine(),
                ]);

                return response()->json([
                    'message' => 'Đã xảy ra lỗi máy chủ.',
                    'errors' => [
                        'server' => [
                            config('app.debug') 
                                ? $e->getMessage() 
                                : 'Vui lòng thử lại sau hoặc liên hệ hỗ trợ nếu vấn đề vẫn tiếp tục.'
                        ]
                    ],
                    'debug' => config('app.debug') ? [
                        'file' => $e->getFile(),
                        'line' => $e->getLine(),
                    ] : null
                ], 500);
            }
        });
    }
}
