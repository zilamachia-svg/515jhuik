<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

// Đây là class Model, nằm ở app/Models/Setting.php
class Setting extends Model
{
    use HasFactory;
    
    protected $table = 'settings';
    protected $primaryKey = 'key';
    protected $keyType = 'string';
    public $incrementing = false;
    protected $fillable = ['key', 'value', 'group'];

    /**
     * Lấy cài đặt theo nhóm (ví dụ: 'contact', 'homepage')
     */
    public static function getGroup(string $groupName): array
    {
        return static::where('group', $groupName)
                     ->pluck('value', 'key')
                     ->toArray();
    }
}