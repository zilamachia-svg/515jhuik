<?php

namespace App\Models;

use Illuminate\Contracts\Auth\MustVerifyEmail;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Laravel\Sanctum\HasApiTokens;
use Spatie\Permission\Traits\HasRoles;

class User extends Authenticatable implements MustVerifyEmail
{
    use HasApiTokens, HasFactory, Notifiable, HasRoles;

    protected $fillable = [
        'name',
        'email',
        'password',
        'balance',
        'referral_link',
        'provider',
        'provider_id',
        'avatar',
    ];

    protected $hidden = [
        'password',
        'remember_token',
    ];

    protected $casts = [
        'email_verified_at' => 'datetime',
        // Don't cast balance as decimal - cause issues with Brick\Math library
        // Instead, cast to float in UserResource
        'password' => 'hashed',
    ];

    // Quan hệ: 1 user có nhiều đơn hàng
    public function orders()
    {
        return $this->hasMany(Order::class);
    }

    // Quan hệ: 1 user có nhiều deposits
    public function deposits()
    {
        return $this->hasMany(Deposit::class);
    }
}
