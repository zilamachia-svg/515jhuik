<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class AccountData extends Model
{
    use SoftDeletes;

    protected $table = 'account_data';

    protected $fillable = [
        'product_id',
        'platform',
        'uid',
        'pass',
        'password_2fa',
        'email',
        'passmail',
        'emailkp',
        'friend_count',
        'created_date',
        'birthday',
        'cookie',
        'token',
        'is_used',
        'used_by_customer_id',
        'used_at',
        'notes',
    ];

    protected $casts = [
        'is_used' => 'boolean',
        'used_at' => 'datetime',
        'friend_count' => 'integer',
    ];

    /**
     * Mối quan hệ với Product
     */
    public function product()
    {
        return $this->belongsTo(Product::class, 'product_id', 'id');
    }

    /**
     * Mối quan hệ với Customer nếu đã được sử dụng
     */
    public function customer()
    {
        return $this->belongsTo(User::class, 'used_by_customer_id', 'id');
    }

    /**
     * Mối quan hệ với Order
     */
    public function order()
    {
        return $this->hasOne(Order::class, 'account_data_id', 'id');
    }

    /**
     * Scope: Lấy tài khoản chưa được sử dụng
     */
    public function scopeAvailable($query)
    {
        return $query->where('is_used', false)->whereNull('used_by_customer_id');
    }

    /**
     * Scope: Lấy tài khoản theo platform
     */
    public function scopeByPlatform($query, $platform)
    {
        return $query->where('platform', $platform);
    }

    /**
     * Scope: Lấy tài khoản theo sản phẩm
     */
    public function scopeByProduct($query, $productId)
    {
        return $query->where('product_id', $productId);
    }

    /**
     * Đánh dấu tài khoản là đã sử dụng
     */
    public function markAsUsed($customerId)
    {
        $this->update([
            'is_used' => true,
            'used_by_customer_id' => $customerId,
            'used_at' => now(),
        ]);
    }

    /**
     * Lấy dữ liệu tài khoản để hiển thị cho khách hàng
     * (Ẩn mật khẩu nếu cần)
     */
    public function getDisplayData($showPassword = false)
    {
        $data = [
            'platform' => $this->platform,
            'uid' => $this->uid,
            'email' => $this->email,
            'emailkp' => $this->emailkp,
            'friend_count' => $this->friend_count,
            'created_date' => $this->created_date,
            'birthday' => $this->birthday,
            'cookie' => $this->cookie,
            'token' => $this->token,
            'password_2fa' => $this->password_2fa,
        ];

        if ($showPassword) {
            $data['pass'] = $this->pass;
            $data['passmail'] = $this->passmail;
        }

        return $data;
    }

    /**
     * Lấy dữ liệu đầy đủ (bao gồm mật khẩu)
     */
    public function getFullData()
    {
        return [
            'id' => $this->id,
            'platform' => $this->platform,
            'uid' => $this->uid,
            'pass' => $this->pass,
            'password_2fa' => $this->password_2fa,
            'email' => $this->email,
            'passmail' => $this->passmail,
            'emailkp' => $this->emailkp,
            'friend_count' => $this->friend_count,
            'created_date' => $this->created_date,
            'birthday' => $this->birthday,
            'cookie' => $this->cookie,
            'token' => $this->token,
            'is_used' => $this->is_used,
            'used_at' => $this->used_at,
            'used_by_customer_id' => $this->used_by_customer_id,
            'notes' => $this->notes,
        ];
    }
}
