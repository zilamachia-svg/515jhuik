<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use App\Models\Order; // Import Model Order

class Product extends Model
{
    use HasFactory;

    protected $fillable = [
        'name',
        'description',
        'price',
        'stock',
        'country',
        'category',
        'image_url',
        'is_active',
    ];

    /**
     * Mối quan hệ: Sản phẩm thuộc về nhiều đơn hàng
     * Bắt buộc phải có hàm này thì Dashboard mới thống kê được
     */
    public function orders()
    {
        // Lưu ý: 'order_items' là tên bảng trung gian. 
        // Nếu database của bạn dùng tên khác (vd: order_product), hãy sửa ở đây.
        return $this->belongsToMany(Order::class, 'order_items', 'product_id', 'order_id');
    }
}