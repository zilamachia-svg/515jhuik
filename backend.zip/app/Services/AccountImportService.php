<?php

namespace App\Services;

use App\Models\AccountData;
use App\Models\Product;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;

class AccountImportService
{
    /**
     * Import tài khoản từ CSV
     * Format: uid|pass|2fa|email|passmail|emailkp|friend|created_date|birthday|cookie|token
     */
    public function importFromPipeFormat($filePath, $platform, $productId = null)
    {
        $results = [
            'success' => 0,
            'failure' => 0,
            'total' => 0,
            'logs' => []
        ];

        try {
            if (!file_exists($filePath)) {
                throw new \Exception("File không tồn tại: $filePath");
            }

            $file = fopen($filePath, 'r');
            $lineNumber = 0;

            DB::transaction(function () use ($file, $platform, $productId, &$results) {
                while (($line = fgets($file)) !== false) {
                    $lineNumber = ++$results['total'];
                    $line = trim($line);

                    if (empty($line)) {
                        continue;
                    }

                    try {
                        // Parse pipe-delimited format
                        $parts = explode('|', $line);

                        if (count($parts) < 4) {
                            throw new \Exception("Dòng không đủ trường dữ liệu (cần tối thiểu 4 trường)");
                        }

                        // Validate platform
                        $validPlatforms = ['facebook', 'tiktok', 'instagram', 'gmail', 'outlook'];
                        if (!in_array($platform, $validPlatforms)) {
                            throw new \Exception("Platform không hợp lệ: $platform");
                        }

                        // Map dữ liệu
                        $uid = trim($parts[0]);
                        $pass = trim($parts[1]);
                        $password_2fa = trim($parts[2] ?? '');
                        $email = trim($parts[3] ?? '');
                        $passmail = trim($parts[4] ?? '');
                        $emailkp = trim($parts[5] ?? '');
                        $friend_count = $this->parseNumber($parts[6] ?? '');
                        $created_date = trim($parts[7] ?? '');
                        $birthday = trim($parts[8] ?? '');
                        $cookie = trim($parts[9] ?? '');
                        $token = trim($parts[10] ?? '');

                        // Validate required fields
                        if (empty($uid) || empty($pass) || empty($email)) {
                            throw new \Exception("Các trường bắt buộc (uid, pass, email) không được trống");
                        }

                        // Check if account already exists
                        $existing = AccountData::where('platform', $platform)
                            ->where('uid', $uid)
                            ->first();

                        if ($existing) {
                            // Update existing account
                            $existing->update([
                                'pass' => $this->encryptData($pass),
                                'password_2fa' => $password_2fa,
                                'email' => $email,
                                'passmail' => !empty($passmail) ? $this->encryptData($passmail) : null,
                                'emailkp' => $emailkp,
                                'friend_count' => $friend_count,
                                'created_date' => $created_date,
                                'birthday' => $birthday,
                                'cookie' => !empty($cookie) ? $this->encryptData($cookie) : null,
                                'token' => !empty($token) ? $this->encryptData($token) : null,
                                'notes' => "Cập nhật lúc: " . now()->format('d/m/Y H:i:s'),
                            ]);

                            $results['logs'][] = [
                                'line' => $lineNumber,
                                'message' => "Dòng $lineNumber: Cập nhật tài khoản $platform ($uid)",
                                'type' => 'update',
                                'timestamp' => now()->toIso8601String(),
                            ];
                        } else {
                            // Create new account
                            AccountData::create([
                                'platform' => $platform,
                                'product_id' => $productId,
                                'uid' => $uid,
                                'pass' => $this->encryptData($pass),
                                'password_2fa' => $password_2fa,
                                'email' => $email,
                                'passmail' => !empty($passmail) ? $this->encryptData($passmail) : null,
                                'emailkp' => $emailkp,
                                'friend_count' => $friend_count,
                                'created_date' => $created_date,
                                'birthday' => $birthday,
                                'cookie' => !empty($cookie) ? $this->encryptData($cookie) : null,
                                'token' => !empty($token) ? $this->encryptData($token) : null,
                                'is_used' => false,
                                'notes' => "Nhập lúc: " . now()->format('d/m/Y H:i:s'),
                            ]);

                            $results['logs'][] = [
                                'line' => $lineNumber,
                                'message' => "Dòng $lineNumber: Tạo tài khoản $platform ($uid)",
                                'type' => 'create',
                                'timestamp' => now()->toIso8601String(),
                            ];
                        }

                        $results['success']++;

                    } catch (\Exception $e) {
                        $results['failure']++;
                        $results['logs'][] = [
                            'line' => $lineNumber,
                            'message' => "Dòng $lineNumber: LỖI - " . $e->getMessage(),
                            'type' => 'error',
                            'timestamp' => now()->toIso8601String(),
                        ];

                        Log::error("AccountImport Error Line $lineNumber", [
                            'platform' => $platform,
                            'error' => $e->getMessage(),
                        ]);
                    }
                }
            });

            fclose($file);

        } catch (\Exception $e) {
            $results['logs'][] = [
                'message' => "LỖI CHUNG: " . $e->getMessage(),
                'type' => 'error',
                'timestamp' => now()->toIso8601String(),
            ];

            Log::error("AccountImportService Error", [
                'file' => $filePath,
                'platform' => $platform,
                'error' => $e->getMessage(),
            ]);
        }

        return $results;
    }

    /**
     * Import từ CSV với header
     */
    public function importFromCSV($filePath, $platform, $productId = null, $columnMap = [])
    {
        $results = [
            'success' => 0,
            'failure' => 0,
            'total' => 0,
            'logs' => []
        ];

        try {
            if (!file_exists($filePath)) {
                throw new \Exception("File không tồn tại: $filePath");
            }

            $file = fopen($filePath, 'r');
            $headers = fgetcsv($file);

            if (!$headers) {
                throw new \Exception("File CSV rỗng hoặc không hợp lệ");
            }

            // Default column map
            if (empty($columnMap)) {
                $columnMap = [
                    'uid' => 'uid',
                    'pass' => 'pass',
                    'password_2fa' => '2fa',
                    'email' => 'email',
                    'passmail' => 'passmail',
                    'emailkp' => 'emailkp',
                    'friend_count' => 'friend',
                    'created_date' => 'created_date',
                    'birthday' => 'birthday',
                    'cookie' => 'cookie',
                    'token' => 'token',
                ];
            }

            $lineNumber = 1;

            DB::transaction(function () use ($file, $headers, $columnMap, $platform, $productId, &$results, &$lineNumber) {
                while (($row = fgetcsv($file)) !== false) {
                    $lineNumber++;
                    $results['total']++;

                    try {
                        $rowData = array_combine($headers, $row);

                        // Extract mapped values
                        $uid = $rowData[$columnMap['uid']] ?? '';
                        $pass = $rowData[$columnMap['pass']] ?? '';
                        $password_2fa = $rowData[$columnMap['password_2fa']] ?? '';
                        $email = $rowData[$columnMap['email']] ?? '';
                        $passmail = $rowData[$columnMap['passmail']] ?? '';
                        $emailkp = $rowData[$columnMap['emailkp']] ?? '';
                        $friend_count = $this->parseNumber($rowData[$columnMap['friend_count']] ?? '');
                        $created_date = $rowData[$columnMap['created_date']] ?? '';
                        $birthday = $rowData[$columnMap['birthday']] ?? '';
                        $cookie = $rowData[$columnMap['cookie']] ?? '';
                        $token = $rowData[$columnMap['token']] ?? '';

                        if (empty($uid) || empty($pass) || empty($email)) {
                            throw new \Exception("Các trường bắt buộc không được trống");
                        }

                        // Check if exists
                        $existing = AccountData::where('platform', $platform)
                            ->where('uid', $uid)
                            ->first();

                        if ($existing) {
                            $existing->update([
                                'pass' => $this->encryptData($pass),
                                'password_2fa' => $password_2fa,
                                'email' => $email,
                                'passmail' => !empty($passmail) ? $this->encryptData($passmail) : null,
                                'emailkp' => $emailkp,
                                'friend_count' => $friend_count,
                                'created_date' => $created_date,
                                'birthday' => $birthday,
                                'cookie' => !empty($cookie) ? $this->encryptData($cookie) : null,
                                'token' => !empty($token) ? $this->encryptData($token) : null,
                            ]);

                            $results['logs'][] = [
                                'line' => $lineNumber,
                                'message' => "Dòng $lineNumber: Cập nhật tài khoản $platform",
                                'type' => 'update',
                            ];
                        } else {
                            AccountData::create([
                                'platform' => $platform,
                                'product_id' => $productId,
                                'uid' => $uid,
                                'pass' => $this->encryptData($pass),
                                'password_2fa' => $password_2fa,
                                'email' => $email,
                                'passmail' => !empty($passmail) ? $this->encryptData($passmail) : null,
                                'emailkp' => $emailkp,
                                'friend_count' => $friend_count,
                                'created_date' => $created_date,
                                'birthday' => $birthday,
                                'cookie' => !empty($cookie) ? $this->encryptData($cookie) : null,
                                'token' => !empty($token) ? $this->encryptData($token) : null,
                                'is_used' => false,
                            ]);

                            $results['logs'][] = [
                                'line' => $lineNumber,
                                'message' => "Dòng $lineNumber: Tạo tài khoản $platform",
                                'type' => 'create',
                            ];
                        }

                        $results['success']++;

                    } catch (\Exception $e) {
                        $results['failure']++;
                        $results['logs'][] = [
                            'line' => $lineNumber,
                            'message' => "Dòng $lineNumber: LỖI - " . $e->getMessage(),
                            'type' => 'error',
                        ];
                    }
                }
            });

            fclose($file);

        } catch (\Exception $e) {
            Log::error("AccountImportService CSV Error", [
                'file' => $filePath,
                'platform' => $platform,
                'error' => $e->getMessage(),
            ]);
        }

        return $results;
    }

    /**
     * Mã hóa dữ liệu nhạy cảm
     */
    private function encryptData($data)
    {
        if (empty($data)) {
            return null;
        }
        return encrypt($data);
    }

    /**
     * Parse number from string
     */
    private function parseNumber($value)
    {
        if (empty($value)) {
            return null;
        }
        return (int) preg_replace('/[^0-9]/', '', $value);
    }

    /**
     * Get available accounts for product
     */
    public function getAvailableAccounts($productId, $platform = null)
    {
        $query = AccountData::byProduct($productId)->available();

        if ($platform) {
            $query->byPlatform($platform);
        }

        return $query->get();
    }

    /**
     * Allocate account to customer after purchase
     */
    public function allocateAccount($orderId, $customerId)
    {
        try {
            $order = \App\Models\Order::findOrFail($orderId);
            $product = $order->product;

            // Get available account
            $account = AccountData::byProduct($product->id)
                ->available()
                ->first();

            if (!$account) {
                throw new \Exception("Không có tài khoản khả dụng cho sản phẩm này");
            }

            // Mark as used
            $account->markAsUsed($customerId);

            // Update order with account
            $order->update([
                'account_data_id' => $account->id,
            ]);

            return $account;

        } catch (\Exception $e) {
            Log::error("AccountAllocateError", [
                'order_id' => $orderId,
                'customer_id' => $customerId,
                'error' => $e->getMessage(),
            ]);
            throw $e;
        }
    }
}
