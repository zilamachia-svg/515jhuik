<?php

namespace App\Services;

use App\DataTransferObjects\ProductImportDTO;
use App\Models\Product;
use App\Models\ProductCategory;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Str;

class ProductImportService
{
    private array $importLog = [];
    private int $successCount = 0;
    private int $failureCount = 0;

    /**
     * Import sản phẩm từ file CSV
     * Format: name, description, price, stock, country, category, image_url, is_active, sku, type, regular_price, sale_price, short_description
     */
    public function importFromCsv(string $filePath, array $columnMap = []): array
    {
        if (!file_exists($filePath)) {
            throw new \Exception("File không tồn tại: {$filePath}");
        }

        $file = fopen($filePath, 'r');
        if (!$file) {
            throw new \Exception("Không thể mở file: {$filePath}");
        }

        try {
            $this->importLog = [];
            $this->successCount = 0;
            $this->failureCount = 0;

            // Đọc header nếu có
            $headers = fgetcsv($file);
            if (!$headers) {
                throw new \Exception("File CSV không có dữ liệu");
            }

            // Nếu không có columnMap, sử dụng headers từ file
            if (empty($columnMap)) {
                $columnMap = array_flip($headers);
            }

            $rowNumber = 1;
            while (($row = fgetcsv($file)) !== false) {
                $rowNumber++;

                // Skip dòng trống
                if (array_filter($row) === array_fill(0, count($row), null)) {
                    continue;
                }

                try {
                    // Mapping dữ liệu từ CSV
                    $rowData = array_combine($headers, $row);
                    if ($rowData === false) {
                        throw new \Exception("Không thể map dữ liệu từ dòng {$rowNumber}");
                    }

                    $dto = ProductImportDTO::fromCsvRow($rowData, $columnMap);

                    // Validate
                    $errors = $dto->validate();
                    if (!empty($errors)) {
                        $this->addLog("Dòng {$rowNumber}: Lỗi validate - " . implode(', ', $errors), 'error');
                        $this->failureCount++;
                        continue;
                    }

                    // Xử lý category
                    if (!empty($dto->category)) {
                        $category = ProductCategory::firstOrCreate(
                            ['name' => $dto->category],
                            ['slug' => Str::slug($dto->category)]
                        );
                        $dto->category_id = $category->id;
                    }

                    // Tạo hoặc cập nhật sản phẩm
                    $productData = $dto->toArray();
                    
                    // Nếu có SKU, tìm theo SKU
                    if (!empty($dto->sku)) {
                        $product = Product::where('sku', $dto->sku)->first();
                        if ($product) {
                            $product->update($productData);
                            $this->addLog("Dòng {$rowNumber}: Cập nhật sản phẩm '{$dto->name}'", 'success');
                        } else {
                            Product::create([...$productData, 'sku' => $dto->sku]);
                            $this->addLog("Dòng {$rowNumber}: Tạo sản phẩm '{$dto->name}'", 'success');
                        }
                    } else {
                        // Tạo sản phẩm mới
                        Product::create($productData);
                        $this->addLog("Dòng {$rowNumber}: Tạo sản phẩm '{$dto->name}'", 'success');
                    }

                    $this->successCount++;

                } catch (\Exception $e) {
                    $this->addLog("Dòng {$rowNumber}: Lỗi - {$e->getMessage()}", 'error');
                    $this->failureCount++;
                    Log::error("ProductImport error at row {$rowNumber}", [
                        'error' => $e->getMessage(),
                        'row_data' => $row,
                    ]);
                }
            }

            fclose($file);

            return $this->getResult();

        } catch (\Exception $e) {
            fclose($file);
            throw $e;
        }
    }

    /**
     * Import sản phẩm từ file TXT (mỗi sản phẩm trên một dòng)
     * Format: name|price|stock|description
     */
    public function importFromTxt(string $filePath): array
    {
        if (!file_exists($filePath)) {
            throw new \Exception("File không tồn tại: {$filePath}");
        }

        $this->importLog = [];
        $this->successCount = 0;
        $this->failureCount = 0;

        $lines = file($filePath, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
        if (!$lines) {
            throw new \Exception("File TXT không có dữ liệu");
        }

        $rowNumber = 1;
        foreach ($lines as $line) {
            $rowNumber++;

            try {
                // Parse dòng dữ liệu: name|price|stock|description|category|country
                $parts = array_map('trim', explode('|', $line));

                if (count($parts) < 3) {
                    $this->addLog("Dòng {$rowNumber}: Format không hợp lệ", 'error');
                    $this->failureCount++;
                    continue;
                }

                $dto = new ProductImportDTO(
                    name: $parts[0],
                    price: (float) ($parts[1] ?? 0),
                    stock: (int) ($parts[2] ?? 0),
                    description: $parts[3] ?? null,
                    category: $parts[4] ?? null,
                    country: $parts[5] ?? null,
                );

                // Validate
                $errors = $dto->validate();
                if (!empty($errors)) {
                    $this->addLog("Dòng {$rowNumber}: Lỗi validate - " . implode(', ', $errors), 'error');
                    $this->failureCount++;
                    continue;
                }

                // Xử lý category
                if (!empty($dto->category)) {
                    $category = ProductCategory::firstOrCreate(
                        ['name' => $dto->category],
                        ['slug' => Str::slug($dto->category)]
                    );
                    $dto->category_id = $category->id;
                }

                Product::create($dto->toArray());
                $this->addLog("Dòng {$rowNumber}: Tạo sản phẩm '{$dto->name}'", 'success');
                $this->successCount++;

            } catch (\Exception $e) {
                $this->addLog("Dòng {$rowNumber}: Lỗi - {$e->getMessage()}", 'error');
                $this->failureCount++;
            }
        }

        return $this->getResult();
    }

    /**
     * Thêm log
     */
    private function addLog(string $message, string $type = 'info'): void
    {
        $this->importLog[] = [
            'message' => $message,
            'type' => $type,
            'timestamp' => now()->toIso8601String(),
        ];
    }

    /**
     * Lấy kết quả import
     */
    private function getResult(): array
    {
        return [
            'success' => $this->successCount,
            'failure' => $this->failureCount,
            'total' => $this->successCount + $this->failureCount,
            'logs' => $this->importLog,
        ];
    }

    /**
     * Tạo file CSV template để user tải về
     */
    public static function generateCsvTemplate(): string
    {
        $headers = [
            'name',
            'description',
            'price',
            'stock',
            'country',
            'category',
            'image_url',
            'is_active',
            'sku',
            'type',
            'regular_price',
            'sale_price',
        ];

        $content = implode(',', $headers) . "\n";

        // Thêm ví dụ
        $example = [
            'Sản phẩm mẫu 1',
            'Đây là mô tả sản phẩm',
            '100000',
            '50',
            'Việt Nam',
            'Điện tử',
            'https://example.com/image.jpg',
            'yes',
            'SKU001',
            'simple',
            '100000',
            '80000',
        ];

        $content .= '"' . implode('","', $example) . '"' . "\n";

        return $content;
    }
}
