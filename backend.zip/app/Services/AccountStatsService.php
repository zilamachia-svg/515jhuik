<?php

namespace App\Services;

use App\Models\Account;
use App\Models\AccountCategory;
use App\Models\ActivityLog;
use Illuminate\Support\Collection;

class AccountStatsService
{
    /**
     * Get total number of accounts
     */
    public function getTotalAccounts(): int
    {
        return Account::count();
    }

    /**
     * Get number of active accounts
     */
    public function getActiveAccounts(): int
    {
        return Account::active()->count();
    }

    /**
     * Get recent account activities
     */
    public function getRecentActivities(): Collection
    {
        return ActivityLog::with(['causer', 'subject'])
            ->orderBy('created_at', 'desc')
            ->take(10)
            ->get();
    }

    /**
     * Get accounts grouped by category
     */
    public function getAccountsByCategory(): Collection
    {
        return AccountCategory::withCount('accounts')
            ->having('accounts_count', '>', 0)
            ->get()
            ->map(function ($category) {
                return [
                    'name' => $category->name,
                    'count' => $category->accounts_count,
                    'percentage' => $this->calculatePercentage($category->accounts_count)
                ];
            });
    }

    /**
     * Calculate percentage based on total accounts
     */
    protected function calculatePercentage(int $count): float
    {
        $total = $this->getTotalAccounts();
        if ($total === 0) return 0;
        return round(($count / $total) * 100, 1);
    }
}
