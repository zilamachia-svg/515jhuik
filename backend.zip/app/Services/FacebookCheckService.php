<?php

namespace App\Services;

use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Cache;

class FacebookCheckService
{
    private $accessToken;
    private $appId;
    private $appSecret;
    private $apiVersion;

    public function __construct()
    {
        $this->accessToken = env('FACEBOOK_ACCESS_TOKEN');
        $this->appId = env('FACEBOOK_APP_ID');
        $this->appSecret = env('FACEBOOK_APP_SECRET');
        $this->apiVersion = env('FACEBOOK_API_VERSION', 'v18.0');
    }

    /**
     * Check if a Facebook account is live
     * 
     * @param string $uid Facebook User ID
     * @return bool
     */
    public function checkAccountLive(string $uid): bool
    {
        // Validate token exists
        if (empty($this->accessToken)) {
            Log::warning('Facebook access token not configured');
            return false;
        }

        // Check cache first (cache for 5 minutes to avoid rate limits)
        $cacheKey = "fb_check_{$uid}";
        $cached = Cache::get($cacheKey);
        if ($cached !== null) {
            return $cached;
        }

        try {
            // Method 1: Check using Graph API with access token
            $isLive = $this->checkViaGraphAPI($uid);
            
            // Cache result for 5 minutes
            Cache::put($cacheKey, $isLive, now()->addMinutes(5));
            
            return $isLive;
        } catch (\Exception $e) {
            Log::error("Facebook check error for UID {$uid}: " . $e->getMessage());
            return false;
        }
    }

    /**
     * Check account via Facebook Graph API
     * 
     * @param string $uid
     * @return bool
     */
    private function checkViaGraphAPI(string $uid): bool
    {
        try {
            // Option 1: Use User Access Token (recommended)
            // This requires a valid user access token with appropriate permissions
            $response = Http::timeout(10)->get("https://graph.facebook.com/{$this->apiVersion}/{$uid}", [
                'access_token' => $this->accessToken,
                'fields' => 'id,name', // Minimal fields to check if account exists
            ]);

            if ($response->successful()) {
                $data = $response->json();
                // If we get user data, account is live
                return isset($data['id']) && $data['id'] === $uid;
            }

            // If 404 or other error, account might be dead or token doesn't have permission
            if ($response->status() === 404) {
                return false; // Account not found = Die
            }

            // For other errors, log and return false
            Log::warning("Facebook API error for UID {$uid}: " . $response->body());
            return false;

        } catch (\Exception $e) {
            Log::error("Graph API check failed for UID {$uid}: " . $e->getMessage());
            return false;
        }
    }

    /**
     * Alternative: Check using App Access Token (less reliable)
     * 
     * @param string $uid
     * @return bool
     */
    private function checkViaAppToken(string $uid): bool
    {
        // Generate app access token
        $appToken = "{$this->appId}|{$this->appSecret}";
        
        try {
            $response = Http::timeout(10)->get("https://graph.facebook.com/{$this->apiVersion}/{$uid}", [
                'access_token' => $appToken,
                'fields' => 'id',
            ]);

            return $response->successful() && isset($response->json()['id']);
        } catch (\Exception $e) {
            Log::error("App token check failed: " . $e->getMessage());
            return false;
        }
    }

    /**
     * Get long-lived access token from short-lived token
     * 
     * @param string $shortLivedToken
     * @return string|null
     */
    public function getLongLivedToken(string $shortLivedToken): ?string
    {
        try {
            $response = Http::post("https://graph.facebook.com/{$this->apiVersion}/oauth/access_token", [
                'grant_type' => 'fb_exchange_token',
                'client_id' => $this->appId,
                'client_secret' => $this->appSecret,
                'fb_exchange_token' => $shortLivedToken,
            ]);

            if ($response->successful()) {
                $data = $response->json();
                return $data['access_token'] ?? null;
            }

            return null;
        } catch (\Exception $e) {
            Log::error("Failed to exchange token: " . $e->getMessage());
            return null;
        }
    }

    /**
     * Test Facebook token validity
     * 
     * @param string|null $token Token to test (if null, uses configured token)
     * @return array
     */
    public function testToken(?string $token = null): array
    {
        $testToken = $token ?? $this->accessToken;

        if (empty($testToken)) {
            return [
                'valid' => false,
                'message' => 'Token không được cung cấp.',
            ];
        }

        try {
            // Test token by getting app info
            $response = Http::timeout(10)->get("https://graph.facebook.com/{$this->apiVersion}/me", [
                'access_token' => $testToken,
                'fields' => 'id,name',
            ]);

            if ($response->successful()) {
                $data = $response->json();
                return [
                    'valid' => true,
                    'message' => 'Token hợp lệ.',
                    'user_id' => $data['id'] ?? null,
                    'user_name' => $data['name'] ?? null,
                ];
            }

            // Check error type
            $error = $response->json();
            $errorMessage = $error['error']['message'] ?? 'Token không hợp lệ.';
            $errorCode = $error['error']['code'] ?? null;

            return [
                'valid' => false,
                'message' => $errorMessage,
                'error_code' => $errorCode,
            ];
        } catch (\Exception $e) {
            Log::error("Token test error: " . $e->getMessage());
            return [
                'valid' => false,
                'message' => 'Lỗi khi kiểm tra token: ' . $e->getMessage(),
            ];
        }
    }
}