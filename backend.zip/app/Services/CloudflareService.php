<?php

namespace App\Services;

use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;

class CloudflareService
{
    private $zoneId;
    private $apiToken;
    private $baseUrl;

    public function __construct()
    {
        $this->zoneId = env('CLOUDFLARE_ZONE_ID');
        $this->apiToken = env('CLOUDFLARE_API_TOKEN');
        $this->baseUrl = env('APP_URL', 'https://haidangmeta.com');
    }

    /**
     * Purge cache by URL
     * 
     * @param array $urls Array of full URLs to purge
     * @return bool
     */
    public function purgeByUrl(array $urls): bool
    {
        if (empty($this->zoneId) || empty($this->apiToken)) {
            Log::warning('Cloudflare credentials not configured');
            return false;
        }

        try {
            $response = Http::withHeaders([
                'Authorization' => "Bearer {$this->apiToken}",
                'Content-Type' => 'application/json',
            ])->post("https://api.cloudflare.com/client/v4/zones/{$this->zoneId}/purge_cache", [
                'files' => $urls,
            ]);

            if ($response->successful()) {
                Log::info('Cloudflare cache purged by URL', ['urls' => $urls]);
                return true;
            }

            Log::error('Cloudflare purge failed', [
                'status' => $response->status(),
                'body' => $response->body(),
            ]);
            return false;
        } catch (\Exception $e) {
            Log::error('Cloudflare purge error: ' . $e->getMessage());
            return false;
        }
    }

    /**
     * Purge cache by tags
     * 
     * @param array $tags Array of cache tags to purge
     * @return bool
     */
    public function purgeByTags(array $tags): bool
    {
        if (empty($this->zoneId) || empty($this->apiToken)) {
            Log::warning('Cloudflare credentials not configured');
            return false;
        }

        try {
            $response = Http::withHeaders([
                'Authorization' => "Bearer {$this->apiToken}",
                'Content-Type' => 'application/json',
            ])->post("https://api.cloudflare.com/client/v4/zones/{$this->zoneId}/purge_cache", [
                'tags' => $tags,
            ]);

            if ($response->successful()) {
                Log::info('Cloudflare cache purged by tags', ['tags' => $tags]);
                return true;
            }

            Log::error('Cloudflare purge failed', [
                'status' => $response->status(),
                'body' => $response->body(),
            ]);
            return false;
        } catch (\Exception $e) {
            Log::error('Cloudflare purge error: ' . $e->getMessage());
            return false;
        }
    }

    /**
     * Purge cache by prefix
     * 
     * @param array $prefixes Array of URL prefixes to purge
     * @return bool
     */
    public function purgeByPrefix(array $prefixes): bool
    {
        if (empty($this->zoneId) || empty($this->apiToken)) {
            Log::warning('Cloudflare credentials not configured');
            return false;
        }

        try {
            $response = Http::withHeaders([
                'Authorization' => "Bearer {$this->apiToken}",
                'Content-Type' => 'application/json',
            ])->post("https://api.cloudflare.com/client/v4/zones/{$this->zoneId}/purge_cache", [
                'prefixes' => $prefixes,
            ]);

            if ($response->successful()) {
                Log::info('Cloudflare cache purged by prefix', ['prefixes' => $prefixes]);
                return true;
            }

            Log::error('Cloudflare purge failed', [
                'status' => $response->status(),
                'body' => $response->body(),
            ]);
            return false;
        } catch (\Exception $e) {
            Log::error('Cloudflare purge error: ' . $e->getMessage());
            return false;
        }
    }

    /**
     * Purge everything (use with caution!)
     * 
     * @return bool
     */
    public function purgeEverything(): bool
    {
        if (empty($this->zoneId) || empty($this->apiToken)) {
            Log::warning('Cloudflare credentials not configured');
            return false;
        }

        try {
            $response = Http::withHeaders([
                'Authorization' => "Bearer {$this->apiToken}",
                'Content-Type' => 'application/json',
            ])->post("https://api.cloudflare.com/client/v4/zones/{$this->zoneId}/purge_cache", [
                'purge_everything' => true,
            ]);

            if ($response->successful()) {
                Log::info('Cloudflare cache purged everything');
                return true;
            }

            Log::error('Cloudflare purge failed', [
                'status' => $response->status(),
                'body' => $response->body(),
            ]);
            return false;
        } catch (\Exception $e) {
            Log::error('Cloudflare purge error: ' . $e->getMessage());
            return false;
        }
    }

    /**
     * Helper: Build full URL from path
     */
    private function buildUrl(string $path): string
    {
        return rtrim($this->baseUrl, '/') . '/' . ltrim($path, '/');
    }
}

