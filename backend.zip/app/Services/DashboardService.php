<?php

namespace App\Services;

use App\Models\Order;
use App\Models\User;
use App\Models\Product;
use App\Models\Deposit;
use Illuminate\Support\Facades\DB;

class DashboardService
{
    /**
     * Get summary statistics for the admin dashboard
     */
    public function getDashboardData()
    {
        try {
            // Lấy thống kê cơ bản (Nếu lỗi thì trả về 0)
            $totalUsers = \App\Models\User::count();
            $totalOrders = \App\Models\Order::count();
            
            // Tạm thời comment phần tính doanh thu và top sản phẩm lại
            // $revenue = ...
            // $topProducts = ...
            
            return [
                'total_users' => $totalUsers,
                'total_orders' => $totalOrders,
                'revenue' => 0,      // Tạm để 0
                'top_products' => [] // Trả về rỗng để không lỗi
            ];
        } catch (\Exception $e) {
            // Nếu lỗi quá nặng, trả về dữ liệu giả để không sập trang
            return [
                'total_users' => 0,
                'total_orders' => 0,
                'revenue' => 0,
                'top_products' => [],
                'error_message' => $e->getMessage() // Để debug xem lỗi gì
            ];
        }
    }

    protected function getTotalUsers(): int
    {
        return User::count();
    }

    protected function getTotalOrders(): int
    {
        return Order::count();
    }

    protected function getTotalProducts(): int
    {
        return Product::count();
    }

    protected function getTotalDeposits(): float
    {
        return (float) Deposit::where('status', 'Hoàn thành')->sum('amount');
    }

    protected function getRecentOrders()
    {
        return Order::with(['user:id,name,email', 'product:id,name'])
                   ->latest()
                   ->take(5)
                   ->get();
    }

    protected function getRecentDeposits()
    {
        return Deposit::with('user:id,name,email')
                     ->latest()
                     ->take(5)
                     ->get();
    }

    protected function getTopProducts()
    {
        // Thực hiện an toàn: nếu model Product có method orders(), dùng withCount,
        // nếu không thì truy vấn trực tiếp bảng pivot `order_items` làm fallback.
        try {
            $product = new Product();

            if (method_exists($product, 'orders')) {
                return Product::withCount('orders')
                    ->orderBy('orders_count', 'desc')
                    ->take(5)
                    ->get();
            }

            // Fallback: count theo bảng order_items
            $rows = DB::table('order_items')
                ->select('product_id', DB::raw('COUNT(*) as orders_count'))
                ->groupBy('product_id')
                ->orderBy('orders_count', 'desc')
                ->take(5)
                ->get();

            $productIds = $rows->pluck('product_id')->all();
            if (empty($productIds)) {
                return [];
            }

            // Load products and map counts
            $products = Product::whereIn('id', $productIds)->get()->keyBy('id');

            // Preserve order from $productIds
            $result = [];
            foreach ($productIds as $id) {
                if (isset($products[$id])) {
                    $p = $products[$id];
                    $p->orders_count = (int) ($rows->firstWhere('product_id', $id)->orders_count ?? 0);
                    $result[] = $p;
                }
            }

            return collect($result);
        } catch (\Exception $e) {
            return [];
        }
    }

    protected function getDailyStats()
    {
        $days = 7; // Lấy thống kê 7 ngày gần nhất

        $orderStats = Order::select(
            DB::raw('DATE(created_at) as date'),
            DB::raw('COUNT(*) as count'),
            DB::raw('SUM(total_price) as total')
        )
            ->whereDate('created_at', '>=', now()->subDays($days))
            ->groupBy('date')
            ->get();

        $depositStats = Deposit::select(
            DB::raw('DATE(created_at) as date'),
            DB::raw('COUNT(*) as count'),
            DB::raw('SUM(amount) as total')
        )
            ->where('status', 'Hoàn thành')
            ->whereDate('created_at', '>=', now()->subDays($days))
            ->groupBy('date')
            ->get();

        return [
            'orders' => $orderStats,
            'deposits' => $depositStats,
        ];
    }
}