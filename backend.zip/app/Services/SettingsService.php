<?php

namespace App\Services;

use Illuminate\Support\Facades\Cache;
use App\Models\Setting;

class SettingsService
{
    public static function get(string $key, $default = null)
    {
        return Cache::remember("setting_$key", 3600, function () use ($key, $default) {
            return Setting::where('key', $key)->value('value') ?? $default;
        });
    }

    public static function set(string $key, $value, string $group = null)
    {
        Cache::forget("setting_$key");

        return Setting::updateOrCreate(
            ['key' => $key],
            ['value' => $value, 'group' => $group]
        );
    }

    public static function allByGroup(string $group)
    {
        return Setting::where('group', $group)->get(['key', 'value']);
    }
}
