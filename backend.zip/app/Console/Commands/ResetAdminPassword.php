<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;

class ResetAdminPassword extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'user:reset-password {email} {password}';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Command description';

    /**
     * Execute the console command.
     */
    public function handle()
{
    $email = $this->argument('email');
    $password = $this->argument('password');

    $user = \App\Models\User::where('email', $email)->first();
    if (!$user) {
        $this->error('Không tìm thấy Email này!');
        return;
    }

    $user->password = bcrypt($password);
    $user->save();

    $this->info("Đã đổi mật khẩu thành công cho: $email");
}
}
