<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;

class AddCacheTags
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle(Request $request, Closure $next)
    {
        $response = $next($request);

        // Add cache tags for Cloudflare based on route
        if ($request->is('api/v1/posts') || $request->is('api/v1/posts/*')) {
            $tags = ['posts', 'content'];
            
            // If it's a specific post, add post ID tag
            if ($postId = $request->route('post')) {
                $tags[] = "post-{$postId}";
            }
            
            $response->headers->set('Cache-Tag', implode(',', $tags));
        } elseif ($request->is('api/v1/products') || $request->is('api/v1/products/*')) {
            $tags = ['products', 'store'];
            
            // If it's a specific product, add product ID tag
            if ($productId = $request->route('product')) {
                $tags[] = "product-{$productId}";
            }
            
            $response->headers->set('Cache-Tag', implode(',', $tags));
        } elseif ($request->is('api/v1/faq')) {
            $response->headers->set('Cache-Tag', 'faq,content');
        } elseif ($request->is('api/v1/users/*')) {
            $tags = ['users'];
            
            // If it's a specific user, add user ID tag
            if ($userId = $request->route('user')) {
                $tags[] = "user-{$userId}";
            }
            
            $response->headers->set('Cache-Tag', implode(',', $tags));
        }

        // Always set no-cache for API endpoints
        if ($request->is('api/*')) {
            $response->headers->set('Cache-Control', 'no-store, no-cache, must-revalidate, max-age=0');
            $response->headers->set('Pragma', 'no-cache');
            $response->headers->set('Expires', '0');
        }

        return $response;
    }
}