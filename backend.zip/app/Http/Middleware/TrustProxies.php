<?php

namespace App\Http\Middleware;

use Illuminate\Http\Middleware\TrustProxies as Middleware;
use Illuminate\Http\Request;

class TrustProxies extends Middleware
{
    /**
     * The trusted proxies for this application.
     *
     * CẤU HÌNH THEO SETUP CLOUDFLARE:
     * 
     * - Nếu Cloudflare DNS record là GRAY CLOUD (DNS only): 
     *   → protected $proxies = null;
     * 
     * - Nếu Cloudflare DNS record là ORANGE CLOUD (Proxy enabled - KHUYẾN NGHỊ):
     *   → protected $proxies = '*';
     * 
     * KHUYẾN NGHỊ: Bật Orange Cloud trên Cloudflare để có:
     * - Bảo vệ DDoS
     * - CDN cache
     * - SSL tự động
     * - Ẩn IP server
     *
     * @var array<int, string>|string|null
     */
    protected $proxies = '*'; // Trust Cloudflare proxy (Orange Cloud)
    
    // Nếu chưa bật Cloudflare proxy (Gray Cloud), đổi thành: protected $proxies = null;
    // Nếu có Nginx reverse proxy, đổi thành: protected $proxies = ['127.0.0.1', '::1'];
    // Nếu có AWS ELB, đổi thành: protected $proxies = ['10.0.0.0/8']; // VPC CIDR

    /**
     * The headers that should be used to detect proxies.
     *
     * @var int
     */
    protected $headers =
        Request::HEADER_X_FORWARDED_FOR |
        Request::HEADER_X_FORWARDED_HOST |
        Request::HEADER_X_FORWARDED_PORT |
        Request::HEADER_X_FORWARDED_PROTO |
        Request::HEADER_X_FORWARDED_AWS_ELB;
}