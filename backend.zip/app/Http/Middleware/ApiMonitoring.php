<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;
use Symfony\Component\HttpFoundation\Response;

/**
 * API Monitoring Middleware
 * Tracks API performance metrics, request/response logging, and error tracking
 */
class ApiMonitoring
{
    /**
     * Handle an incoming request.
     *
     * @param  \Closure(\Illuminate\Http\Request): (\Symfony\Component\HttpFoundation\Response)  $next
     */
    public function handle(Request $request, Closure $next): Response
    {
        $startTime = microtime(true);
        $startMemory = memory_get_usage();

        // Log request
        $this->logRequest($request);

        // Process request
        $response = $next($request);

        // Calculate metrics
        $duration = (microtime(true) - $startTime) * 1000; // Convert to milliseconds
        $memoryUsed = memory_get_usage() - $startMemory;
        $memoryPeak = memory_get_peak_usage();

        // Log response
        $this->logResponse($request, $response, $duration, $memoryUsed, $memoryPeak);

        // Add performance headers
        $response->headers->set('X-Response-Time', round($duration, 2) . 'ms');
        $response->headers->set('X-Memory-Used', $this->formatBytes($memoryUsed));
        $response->headers->set('X-Memory-Peak', $this->formatBytes($memoryPeak));

        return $response;
    }

    /**
     * Log request details
     */
    private function logRequest(Request $request): void
    {
        // Only log in production or when explicitly enabled
        if (!config('app.debug') && !config('api.monitoring.enabled', false)) {
            return;
        }

        $logData = [
            'type' => 'api_request',
            'method' => $request->method(),
            'url' => $request->fullUrl(),
            'path' => $request->path(),
            'ip' => $request->ip(),
            'user_agent' => $request->userAgent(),
            'user_id' => $request->user()?->id,
            'timestamp' => now()->toIso8601String(),
        ];

        // Log sensitive data only in debug mode
        if (config('app.debug')) {
            $logData['headers'] = $request->headers->all();
            $logData['query'] = $request->query->all();
            // Don't log request body for security (may contain passwords, tokens, etc.)
        }

        Log::channel('api')->info('API Request', $logData);
    }

    /**
     * Log response details
     */
    private function logResponse(Request $request, Response $response, float $duration, int $memoryUsed, int $memoryPeak): void
    {
        // Only log in production or when explicitly enabled
        if (!config('app.debug') && !config('api.monitoring.enabled', false)) {
            return;
        }

        $statusCode = $response->getStatusCode();
        $isError = $statusCode >= 400;

        $logData = [
            'type' => 'api_response',
            'method' => $request->method(),
            'path' => $request->path(),
            'status_code' => $statusCode,
            'duration_ms' => round($duration, 2),
            'memory_used' => $this->formatBytes($memoryUsed),
            'memory_peak' => $this->formatBytes($memoryPeak),
            'user_id' => $request->user()?->id,
            'timestamp' => now()->toIso8601String(),
        ];

        // Log error details
        if ($isError) {
            $logData['error'] = true;
            
            // Try to get error message from response
            try {
                $content = json_decode($response->getContent(), true);
                if (isset($content['message'])) {
                    $logData['error_message'] = $content['message'];
                }
            } catch (\Exception $e) {
                // Ignore JSON decode errors
            }

            Log::channel('api')->warning('API Error Response', $logData);
        } else {
            Log::channel('api')->info('API Success Response', $logData);
        }

        // Track slow requests (> 1 second)
        if ($duration > 1000) {
            Log::channel('api')->warning('Slow API Request', [
                'path' => $request->path(),
                'duration_ms' => round($duration, 2),
                'method' => $request->method(),
            ]);
        }
    }

    /**
     * Format bytes to human readable format
     */
    private function formatBytes(int $bytes, int $precision = 2): string
    {
        $units = ['B', 'KB', 'MB', 'GB', 'TB'];
        
        for ($i = 0; $bytes > 1024 && $i < count($units) - 1; $i++) {
            $bytes /= 1024;
        }
        
        return round($bytes, $precision) . ' ' . $units[$i];
    }
}

