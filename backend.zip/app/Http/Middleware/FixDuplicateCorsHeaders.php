<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;

class FixDuplicateCorsHeaders
{
    /**
     * Fix duplicate CORS headers that may be set by multiple sources.
     * This ensures Access-Control-Allow-Credentials is only 'true' not 'true, true'
     */
    public function handle(Request $request, Closure $next)
    {
        $response = $next($request);

        // Fix duplicate CORS credentials header - ALWAYS set to single 'true'
        // This handles duplicates from multiple sources (Laravel, Cloudflare, LiteSpeed, etc.)
        if ($response->headers->has('Access-Control-Allow-Credentials')) {
            $value = $response->headers->get('Access-Control-Allow-Credentials');
            
            // If there are any commas (indicating duplicates), always reset to 'true'
            if (strpos($value, ',') !== false || $value !== 'true') {
                $response->headers->set('Access-Control-Allow-Credentials', 'true');
            }
        }

        return $response;
    }
}
