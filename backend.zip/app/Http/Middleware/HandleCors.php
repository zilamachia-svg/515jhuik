    <?php

    namespace App\Http\Middleware;

    use Illuminate\Http\Request;
    use Illuminate\Foundation\Http\Middleware\HandleCors as Middleware;

    class HandleCors extends Middleware
    {
        /**
         * Handle an incoming request.
         */
        public function handle(Request $request, \Closure $next)
        {
            $requestOrigin = $request->headers->get('Origin');
            $origin = null;
            
            // First, check if it's a localhost origin (for development)
            // Allow any localhost port for development flexibility
            if ($requestOrigin && (
                str_starts_with($requestOrigin, 'http://localhost:') ||
                str_starts_with($requestOrigin, 'http://127.0.0.1:')
            )) {
                $origin = $requestOrigin;
            }
            
            // If not localhost, check against allowed origins list
            if (!$origin && $requestOrigin) {
                $allowedOrigins = [
                    'https://haidangmeta.com',
                    'https://www.haidangmeta.com',
                    'http://localhost:3000',
                    'http://127.0.0.1:3000',
                    'http://localhost:3001',
                    'http://127.0.0.1:3001',
                    'http://localhost:5173',
                    'http://127.0.0.1:5173',
                    'http://localhost:4000',
                    'http://127.0.0.1:4000',
                ];
                
                // Merge with config allowed origins
                $configOrigins = config('cors.allowed_origins', []);
                $allowedOrigins = array_merge($allowedOrigins, $configOrigins);
                
                if (in_array($requestOrigin, $allowedOrigins)) {
                    $origin = $requestOrigin;
                }
            }
            
            // Fallback: use config method or default
            if (!$origin) {
                $origin = $this->getAllowedOrigin($request) ?? 'https://haidangmeta.com';
            }

            // Handle preflight requests (OPTIONS)
            if ($request->isMethod('OPTIONS')) {
                return response('', 200)
                    ->header('Access-Control-Allow-Origin', $origin)
                    ->header('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, PATCH, OPTIONS')
                    ->header('Access-Control-Allow-Headers', 'Content-Type, Authorization, X-Requested-With, X-XSRF-TOKEN, Accept, Origin')
                    ->header('Access-Control-Allow-Credentials', 'true')
                    ->header('Access-Control-Max-Age', '86400')
                    ->header('Cache-Control', 'no-store, no-cache, must-revalidate, max-age=0')
                    ->header('Pragma', 'no-cache');
            }

            $response = $next($request);

            // Force CORS headers to all responses (bypass Cloudflare cache issues)
            $response->headers->set('Access-Control-Allow-Origin', $origin);
            $response->headers->set('Access-Control-Allow-Credentials', 'true');
            $response->headers->set('Access-Control-Expose-Headers', 'XSRF-TOKEN, Cache-Tag');

            // Add cache control headers for API endpoints (to prevent Cloudflare caching)
            if ($request->is('api/*') || $request->is('sanctum/*')) {
                $response->headers->set('Cache-Control', 'no-store, no-cache, must-revalidate, max-age=0');
                $response->headers->set('Pragma', 'no-cache');
                $response->headers->set('Expires', '0');
            }

            return $response;
        }

        /**
         * Get allowed origin for the request
         */
        private function getAllowedOrigin(Request $request): ?string
        {
            $allowedOrigins = config('cors.allowed_origins', []);
            $origin = $request->headers->get('Origin');

            // If wildcard is allowed, return it (but note: can't use with credentials)
            if (in_array('*', $allowedOrigins)) {
                // If credentials are required, we can't use wildcard
                if (config('cors.supports_credentials', true)) {
                    // Return the actual origin if it matches any pattern
                    if ($origin) {
                        foreach ($allowedOrigins as $allowed) {
                            if ($allowed !== '*' && $this->matchesOrigin($origin, $allowed)) {
                                return $origin;
                            }
                        }
                    }
                    return null;
                }
                return '*';
            }

            if ($origin && in_array($origin, $allowedOrigins)) {
                return $origin;
            }

            // Try pattern matching
            if ($origin) {
                foreach ($allowedOrigins as $allowed) {
                    if ($this->matchesOrigin($origin, $allowed)) {
                        return $origin;
                    }
                }
            }

            return null;
        }

        /**
         * Check if origin matches pattern (supports wildcards)
         */
        private function matchesOrigin(string $origin, string $pattern): bool
        {
            // Exact match
            if ($origin === $pattern) {
                return true;
            }

            // Wildcard pattern matching (e.g., *.example.com)
            $pattern = str_replace(['.', '*'], ['\.', '.*'], $pattern);
            return (bool) preg_match('/^' . $pattern . '$/', $origin);
        }
    }