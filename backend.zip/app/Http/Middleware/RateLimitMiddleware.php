<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\RateLimiter;
use Illuminate\Support\Facades\Log;
use Symfony\Component\HttpFoundation\Response;

class RateLimitMiddleware
{
    /**
     * Handle an incoming request.
     *
     * @param Request $request
     * @param Closure $next
     * @param int $limit
     * @param int $decay
     * @return Response
     */
    public function handle(Request $request, Closure $next, int $limit = 60, int $decay = 60): Response
    {
        $userId = $request->user()?->id;
        if (!$userId) {
            return $next($request);
        }

        $key = $this->resolveKey($request, $userId);

        if (RateLimiter::tooManyAttempts($key, $limit)) {
            Log::warning('Rate limit exceeded', [
                'user_id' => $userId,
                'endpoint' => $request->path(),
                'method' => $request->method(),
                'ip' => $request->ip(),
            ]);

            return response()->json([
                'success' => false,
                'message' => 'Bạn đã gửi quá nhiều yêu cầu. Vui lòng thử lại sau ' . RateLimiter::availableIn($key) . ' giây.',
            ], 429);
        }

        RateLimiter::hit($key, $decay);

        return $next($request);
    }

    /**
     * Resolve the rate limit key.
     */
    protected function resolveKey(Request $request, int $userId): string
    {
        return 'rate-limit:' . $userId . ':' . $request->path();
    }
}
