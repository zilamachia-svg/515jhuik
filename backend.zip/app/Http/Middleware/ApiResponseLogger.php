<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;

class ApiResponseLogger
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle(Request $request, Closure $next)
    {
        // Generate request ID for tracking
        $requestId = substr(md5(uniqid()), 0, 8);
        
        // Process the request
        $response = $next($request);

        // Filter sensitive headers
        $safeHeaders = collect($request->headers->all())
            ->except([
                'authorization',
                'cookie',
                'x-xsrf-token',
                'x-csrf-token',
                'php-auth-pw'
            ])
            ->map(function($header) {
                return is_array($header) ? $header[0] : $header;
            })
            ->toArray();

        // Filter sensitive response headers    
        $safeResponseHeaders = collect($response->headers->all())
            ->except([
                'set-cookie',
                'authorization'
            ])
            ->map(function($header) {
                return is_array($header) ? $header[0] : $header;
            })
            ->toArray();

        // Basic request info that's safe to log
        $log = [
            'request_id' => $requestId,
            'timestamp' => now()->toIso8601String(),
            'method' => $request->method(),
            'path' => $request->path(), // Don't log query parameters
            'ip' => $request->ip(),
            'user_agent' => $request->userAgent(),
            'status' => $response->status(),
            'duration_ms' => defined('LARAVEL_START') ? round((microtime(true) - LARAVEL_START) * 1000, 2) : 0,
            'safe_headers' => $safeHeaders,
            'response_type' => $safeResponseHeaders['content-type'] ?? 'unknown'
        ];

        // For errors, log minimal error info without exposing internals
        if ($response->status() >= 400) {
            $content = json_decode($response->getContent(), true);
            $log['error'] = [
                'code' => $response->status(),
                'message' => $content['message'] ?? 'Unknown error',
                // Don't log full stack traces or detailed errors
            ];
        }

        // Log authenticated user ID if available (but no other user details)
        if ($request->user()) {
            $log['user_id'] = $request->user()->id;
        }

        Log::channel('api')->info("API {$request->method()} [{$requestId}]", $log);

        return $response;
    }
}