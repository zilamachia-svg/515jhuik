<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class UploadFileRequest extends FormRequest
{
    public function authorize(): bool
    {
        return true;
    }

    public function rules(): array
    {
        return [
            'files' => 'required|array',
            'files.*' => [
                'required',
                'file',
                'mimes:jpg,jpeg,png,gif,pdf,doc,docx,xls,xlsx,zip',
                'max:10240',
            ],
        ];
    }
}