<?php

namespace App\Http\Requests\Auth;

use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Log;
use Illuminate\Validation\ValidationException;
use App\Models\User;

class LoginRequest extends FormRequest
{
    public function authorize(): bool
    {
        return true;
    }

    public function rules(): array
    {
        return [
            'email' => ['required', 'email', 'max:255'],
            'password' => ['required', 'string', 'min:6'],
        ];
    }

    public function messages(): array
    {
        return [
            'email.required' => 'Email là bắt buộc.',
            'email.email' => 'Email không hợp lệ.',
            'email.max' => 'Email không được vượt quá 255 ký tự.',
            'password.required' => 'Mật khẩu là bắt buộc.',
            'password.string' => 'Mật khẩu phải là chuỗi ký tự.',
            'password.min' => 'Mật khẩu phải trên 6 ký tự.',
        ];
    }

    protected function failedValidation(\Illuminate\Contracts\Validation\Validator $validator)
    {
        Log::error('Login validation failed', [
            'errors' => $validator->errors()->toArray(),
            'input' => $this->all(),
        ]);
        parent::failedValidation($validator);
    }

    public function authenticate(): void
    {
        // Find user by email and verify password
        $user = User::where('email', $this->email)->first();
        
        // DEBUG: Log login attempt with detailed info
        Log::info('Login attempt', [
            'email' => $this->email,
            'password_provided' => $this->password ? 'yes' : 'no',
            'password_length' => $this->password ? strlen($this->password) : 0,
            'user_found' => $user ? 'yes' : 'no',
            'user_email' => $user ? $user->email : null,
            'password_check' => $user ? Hash::check($this->password, $user->password) : false,
            'request_data' => $this->all(),
        ]);
        
        if (!$user || !Hash::check($this->password, $user->password)) {
            throw ValidationException::withMessages([
                'email' => ['Thông tin đăng nhập không chính xác. Vui lòng kiểm tra lại email và mật khẩu.'],
            ]);
        }
        
        // Login the user
        Auth::login($user, $this->boolean('remember'));
    }
}