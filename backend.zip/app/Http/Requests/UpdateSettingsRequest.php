<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class UpdateSettingsRequest extends FormRequest
{
    public function authorize(): bool
    {
        // Chỉ admin mới được cập nhật settings
        return $this->user() && $this->user()->hasRole('admin');
    }

    public function rules(): array
    {
        return [
            // Branding settings (Logo, Favicon URLs)
            'branding' => 'nullable|array',
            'branding.logo_url' => 'nullable|string|max:500',
            'branding.favicon_url' => 'nullable|string|max:500',
            
            // Contact settings
            'contact' => 'nullable|array',
            'contact.email' => 'nullable|email|max:255',
            'contact.zalo' => 'nullable|string|max:255',
            'contact.telegram' => 'nullable|string|max:255',
            'contact.facebook' => 'nullable|string|max:255',

            // Homepage settings
            'homepage' => 'nullable|array',
            'homepage.welcomeTitle' => 'nullable|string|max:255',
            'homepage.welcomeSubtitle' => 'nullable|string|max:500',

            // Tools settings
            'tools' => 'nullable|array',
            'tools.facebook_access_token' => 'nullable|string|max:1000',
            'tools.gemini_api_key' => 'nullable|string|max:500',
            'tools.messenger_page_id' => 'nullable|string|max:255',
            'tools.messenger_app_id' => 'nullable|string|max:255',
            'tools.facebook_domain_verification' => 'nullable|string|max:255',
            'tools.facebook_app_id' => 'nullable|string|max:255',
        ];
    }

    /**
     * Get custom messages for validator errors.
     */
    public function messages(): array
    {
        return [
            'branding.logo_url.max' => 'URL logo không được vượt quá 500 ký tự.',
            'branding.favicon_url.max' => 'URL favicon không được vượt quá 500 ký tự.',
            'contact.email.email' => 'Email không hợp lệ.',
            'tools.facebook_access_token.max' => 'Token Facebook không được vượt quá 1000 ký tự.',
            'tools.gemini_api_key.max' => 'API key Gemini không được vượt quá 500 ký tự.',
        ];
    }
}