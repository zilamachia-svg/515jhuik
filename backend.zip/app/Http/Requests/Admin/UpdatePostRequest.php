<?php

namespace App\Http\Requests\Admin;

use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;

class UpdatePostRequest extends FormRequest
{
    public function authorize(): bool
    {
        return true;
    }

    public function rules(): array
    {
        // Lấy ID từ Post model được bind vào route
        $postId = $this->route('post')->id;

        return [
            'title' => 'sometimes|required|string|max:255',
            'slug' => [
                'sometimes',
                'string',
                'max:255',
                Rule::unique('posts', 'slug')->ignore($postId) // Bỏ qua chính nó
            ],
            'content' => 'sometimes|required|string',
            // Xác thực status là string
            'status' => ['sometimes', 'required', 'string', Rule::in(['published', 'draft'])],
        ];
    }
}