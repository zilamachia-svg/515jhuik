<?php

namespace App\Http\Requests\Admin;

use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule; // Import Rule

class StorePostRequest extends FormRequest
{
    public function authorize(): bool
    {
        return true; 
    }

    public function rules(): array
    {
        return [
            'title' => 'required|string|max:255',
            // Slug là 'sometimes' vì nó được tạo tự động từ title
            'slug' => 'sometimes|string|max:255|unique:posts,slug', 
            'content' => 'required|string',
            // Xác thực status là string
            'status' => ['required', 'string', Rule::in(['published', 'draft'])],
        ];
    }
}