<?php

namespace App\Http\Requests\Admin;

use Illuminate\Foundation\Http\FormRequest;

class UpdateProductRequest extends FormRequest
{
    public function authorize()
    {
        return true;
    }

    public function rules()
    {
        return [
            'name'        => 'sometimes|string|max:255',
            'description' => 'sometimes|string|max:1000',
            'price'       => 'sometimes|numeric|min:0',
            'stock'       => 'sometimes|integer|min:0',
            'country'     => 'sometimes|string|size:2',
            'category'    => 'sometimes|string|in:VIA,Clone,BM,Fanpage',
            'image_url'   => 'nullable|string',
            'is_active'   => 'boolean'
        ];
    }
}
