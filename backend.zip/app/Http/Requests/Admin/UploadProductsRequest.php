<?php

namespace App\Http\Requests\Admin;

use Illuminate\Foundation\Http\FormRequest;

class UploadProductsRequest extends FormRequest
{
    public function authorize()
    {
        return true;
    }

    public function rules()
    {
        return [
            'category' => 'required|string|in:VIA,Clone,BM,Fanpage',
            'products' => 'required|array|min:1',
            'products.*' => 'required|string'
        ];
    }
}
