<?php

namespace App\Http\Requests\Admin;

use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;

class StorePaymentMethodRequest extends FormRequest
{
    public function authorize(): bool
    {
        return true;
    }

    public function rules(): array
    {
        return [
            'type' => ['required', 'string', Rule::in(['bank', 'momo'])],
            'name' => 'required|string|max:255',
            'account_name' => 'required|string|max:255',
            'account_number' => 'required|string|max:255',
            'qr_code_url' => 'nullable|url|max:2048',
            'is_active' => 'sometimes|boolean',
            'id' => 'nullable|string|max:50|unique:payment_methods,id',
        ];
    }
}