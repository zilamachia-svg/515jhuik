<?php

namespace App\Http\Requests\Admin;

use Illuminate\Foundation\Http\FormRequest;

class StoreProductRequest extends FormRequest
{
    public function authorize()
    {
        return true;
    }

    public function rules()
    {
        return [
            'name'        => 'required|string|max:255',
            'description' => 'required|string|max:1000',
            'price'       => 'required|numeric|min:0',
            'stock'       => 'required|integer|min:0',
            'country'     => 'required|string|size:2',
            'category'    => 'required|string|in:VIA,Clone,BM,Fanpage',
            'image_url'   => 'nullable|string',
            'is_active'   => 'boolean'
        ];
    }
}
