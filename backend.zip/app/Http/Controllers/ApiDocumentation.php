<?php

/**
 * @OA\Info(
 * title="Hải Đăng Meta API",
 * version="1.0.0",
 * description="API Documentation for Hải Đăng Meta - E-commerce platform for digital products",
 * @OA\Contact(
 * email="support@haidangmeta.com"
 * )
 * )
 *
 * @OA\Server(
 * url=L5_SWAGGER_CONST_HOST,
 * description="API Server"
 * )
 *
 * @OA\SecurityScheme(
 * securityScheme="sanctum",
 * type="http",
 * scheme="bearer",
 * bearerFormat="JWT",
 * description="Laravel Sanctum authentication"
 * )
 *
 * @OA\Tag(
 * name="Authentication",
 * description="User authentication endpoints"
 * )
 *
 * @OA\Tag(
 * name="Products",
 * description="Product management endpoints"
 * )
 *
 * @OA\Tag(
 * name="Orders",
 * description="Order management endpoints"
 * )
 *
 * @OA\Tag(
 * name="Users",
 * description="User management endpoints"
 * )
 *
 * @OA\Tag(
 * name="Deposits",
 * description="Deposit management endpoints"
 * )
 */