<?php

namespace App\Http\Controllers;

use App\Models\Post;
use App\Models\Product;
use Illuminate\Http\Response;
use Illuminate\Support\Facades\Route;

class SitemapController extends Controller
{
    /**
     * Generate sitemap.xml
     */
    public function index(): Response
    {
        $baseUrl = config('app.url', 'https://haidangmeta.com');
        
        $xml = '<?xml version="1.0" encoding="UTF-8"?>' . "\n";
        $xml .= '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">' . "\n";
        
        // Static pages
        $staticPages = [
            ['url' => '', 'priority' => '1.0', 'changefreq' => 'daily'],
            ['url' => '/store', 'priority' => '0.9', 'changefreq' => 'daily'],
            ['url' => '/deposit', 'priority' => '0.8', 'changefreq' => 'weekly'],
            ['url' => '/posts', 'priority' => '0.8', 'changefreq' => 'daily'],
            ['url' => '/faq', 'priority' => '0.7', 'changefreq' => 'weekly'],
            ['url' => '/contact', 'priority' => '0.6', 'changefreq' => 'monthly'],
            ['url' => '/terms', 'priority' => '0.5', 'changefreq' => 'yearly'],
            ['url' => '/privacy-policy', 'priority' => '0.5', 'changefreq' => 'yearly'],
            ['url' => '/warranty', 'priority' => '0.5', 'changefreq' => 'yearly'],
            ['url' => '/conditions', 'priority' => '0.5', 'changefreq' => 'yearly'],
            ['url' => '/guide', 'priority' => '0.7', 'changefreq' => 'monthly'],
        ];
        
        foreach ($staticPages as $page) {
            $xml .= $this->generateUrlElement($baseUrl . $page['url'], $page['priority'], $page['changefreq']);
        }
        
        // Dynamic product pages (only active products)
        $products = Product::where('is_active', true)
            ->select('id', 'updated_at')
            ->orderBy('updated_at', 'desc')
            ->limit(1000) // Limit to prevent huge sitemap
            ->get();
        
        foreach ($products as $product) {
            $xml .= $this->generateUrlElement(
                $baseUrl . '/store?product=' . $product->id,
                '0.8',
                'weekly',
                $product->updated_at
            );
        }
        
        // Dynamic post pages
        $posts = Post::where('status', 'published')
            ->select('slug', 'updated_at')
            ->orderBy('updated_at', 'desc')
            ->limit(500) // Limit to prevent huge sitemap
            ->get();
        
        foreach ($posts as $post) {
            $xml .= $this->generateUrlElement(
                $baseUrl . '/posts/' . $post->slug,
                '0.7',
                'weekly',
                $post->updated_at
            );
        }
        
        $xml .= '</urlset>';
        
        return response($xml, 200)
            ->header('Content-Type', 'application/xml');
    }
    
    /**
     * Generate URL element for sitemap
     */
    private function generateUrlElement(string $url, string $priority, string $changefreq, $lastmod = null): string
    {
        $xml = "  <url>\n";
        $xml .= "    <loc>" . htmlspecialchars($url, ENT_XML1) . "</loc>\n";
        $xml .= "    <priority>" . $priority . "</priority>\n";
        $xml .= "    <changefreq>" . $changefreq . "</changefreq>\n";
        
        if ($lastmod) {
            $xml .= "    <lastmod>" . $lastmod->format('Y-m-d\TH:i:s\Z') . "</lastmod>\n";
        } else {
            $xml .= "    <lastmod>" . date('Y-m-d\TH:i:s\Z') . "</lastmod>\n";
        }
        
        $xml .= "  </url>\n";
        
        return $xml;
    }
}

