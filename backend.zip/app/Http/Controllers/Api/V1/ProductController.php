<?php

namespace App\Http\Controllers\Api\V1;

use App\Http\Controllers\Controller;
use App\Http\Resources\ProductResource;
use App\Models\Product;
use App\Models\ProductCategory;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Cache;

class ProductController extends Controller
{
    /**
     * Get all products
     * 
     * ⚠️ Note: This endpoint loads all active products. Consider using index() with pagination for better performance.
     */
    public function all(Request $request): JsonResponse
    {
        // ✅ Optimized query with proper ordering and limit
        // Limit to 100 products to prevent memory issues
        // Note: Product model doesn't have category/supplier relationships yet
        // If relationships are added later, use: Product::with(['category', 'supplier'])
        $products = Product::where('is_active', true)
            ->orderBy('created_at', 'desc')
            ->orderBy('id', 'desc')
            ->limit(100) // Prevent loading too many products
            ->get();

        return response()->json([
            'success' => true,
            'data' => ProductResource::collection($products),
        ]);
    }

    /**
     * Get paginated products
     */
    public function index(Request $request): JsonResponse
    {
        // ✅ Optimized query
        // Note: Add eager loading when relationships are defined
        $query = Product::where('is_active', true);

        if ($request->has('search')) {
            $query->where('name', 'like', '%' . $request->search . '%');
        }

        if ($request->has('category_id')) {
            $query->where('category_id', $request->category_id);
        }

        // ✅ Limit max per_page to prevent large queries
        $perPage = min($request->get('per_page', 20), 100);
        
        $products = $query
            ->orderBy('created_at', 'desc')
            ->orderBy('id', 'desc') // Secondary sort for consistency
            ->paginate($perPage);

        return response()->json([
            'success' => true,
            'data' => ProductResource::collection($products->items()),
            'pagination' => [
                'current_page' => $products->currentPage(),
                'last_page' => $products->lastPage(),
                'per_page' => $products->perPage(),
                'total' => $products->total(),
            ],
        ]);
    }

    /**
     * Get product filters
     */
    public function filters(Request $request): JsonResponse
    {
        // ✅ Cache filters for 1 hour (data changes infrequently)
        $filters = Cache::remember('products:filters', 3600, function () {
            return [
                'categories' => ProductCategory::pluck('name', 'id')->toArray(),
                'price_range' => [
                    'min' => Product::min('price') ?? 0,
                    'max' => Product::max('price') ?? 0,
                ],
            ];
        });

        return response()->json([
            'success' => true,
            'data' => $filters,
        ]);
    }

    /**
     * Get single product
     */
    public function show(Request $request, $id): JsonResponse
    {
        // ✅ Cache single product for 30 minutes
        // Note: Add eager loading when relationships are defined
        $product = Cache::remember("product:{$id}", 1800, function () use ($id) {
            return Product::where('is_active', true)
                ->findOrFail($id);
        });

        return response()->json([
            'success' => true,
            'data' => new ProductResource($product),
        ]);
    }
}

