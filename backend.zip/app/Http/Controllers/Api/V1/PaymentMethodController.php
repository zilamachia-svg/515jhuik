<?php

namespace App\Http\Controllers\Api\V1;

use App\Http\Controllers\Controller;
use App\Http\Resources\PaymentMethodResource;
use App\Models\PaymentMethod;
use Illuminate\Http\Request;

class PaymentMethodController extends Controller
{
    public function index()
    {
        $methods = PaymentMethod::where('is_active', true)
                              ->orderBy('name', 'asc')
                              ->get();
        
        // Return consistent structure with 'methods' key
        return response()->json([
            'methods' => PaymentMethodResource::collection($methods)
        ]);
    }
}