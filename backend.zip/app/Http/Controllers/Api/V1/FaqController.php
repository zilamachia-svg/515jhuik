<?php

namespace App\Http\Controllers\Api\V1;

use App\Http\Controllers\Controller;
use App\Http\Resources\FaqResource;
use App\Models\Faq;

class FaqController extends Controller
{
    /**
     * [GET] /api/v1/faq
     * Returns a list of active FAQs, sorted by 'order'.
     */
    public function index()
    {
        $faqs = Faq::where('is_active', true)
                   ->orderBy('order', 'asc')
                   ->get();

        return FaqResource::collection($faqs);
    }
}