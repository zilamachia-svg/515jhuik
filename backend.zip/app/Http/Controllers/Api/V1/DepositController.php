<?php

namespace App\Http\Controllers\Api\V1;

use App\Http\Controllers\Controller;
use App\Http\Resources\DepositResource;
use App\Models\Deposit;
use Illuminate\Http\Request;
use Illuminate\Validation\ValidationException;

class DepositController extends Controller
{
    public function index(Request $request)
    {
        $limit = $request->input('limit', 15);
        $deposits = Deposit::where('user_id', auth()->id())
                         ->latest()
                         ->paginate($limit);

        return DepositResource::collection($deposits);
    }

    public function store(Request $request)
    {
        $user = $request->user();
        
        // Kiểm tra email đã được xác thực chưa
        if (!$user->email_verified_at) {
            throw ValidationException::withMessages([
                'email' => ['Vui lòng xác thực email trước khi nạp tiền. Vào Cài đặt > Xác thực Email để xác thực.']
            ]);
        }

        $request->validate([
            'amount' => 'required|numeric|min:10000|max:50000000',
            'payment_method_id' => 'required|exists:payment_methods,id',
        ]);

        $deposit = Deposit::create([
            'user_id' => $user->id,
            'amount' => $request->amount,
            'method' => $request->payment_method_id,
            'status' => 'pending',
            'transaction_code' => 'SE' . str_pad((string) rand(0, 999999), 6, '0', STR_PAD_LEFT),
        ]);

        return response()->json([
            'message' => 'Yêu cầu nạp tiền đã được tạo thành công.',
            'deposit' => new DepositResource($deposit),
        ], 201);
    }
}
