<?php

namespace App\Http\Controllers\Api\V1\Admin;

use App\Http\Controllers\Controller;
use App\Http\Requests\Admin\StoreProductRequest;
use App\Http\Requests\Admin\UpdateProductRequest;
use App\Http\Requests\Admin\UploadProductsRequest;
use App\Http\Resources\ProductResource;
use App\Models\Product;
use App\Models\ProductData;
use App\Services\CloudflareService;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class ProductController extends Controller
{
    protected $cloudflare;

    public function __construct(CloudflareService $cloudflare)
    {
        $this->cloudflare = $cloudflare;
    }

    public function index(Request $request)
    {
        $query = Product::query();

        $query->when($request->input('search'), function ($q, $search) {
            $q->where('name', 'like', "%{$search}%");
        });

        $products = $query->latest()->paginate(20);
        return ProductResource::collection($products);
    }

    public function store(StoreProductRequest $request)
    {
        $product = Product::create($request->validated());
        
        // Purge cache after creating product
        $this->purgeProductCache($product);

        return response(new ProductResource($product), 201);
    }

    public function update(UpdateProductRequest $request, Product $product)
    {
        $product->update($request->validated());
        
        // Purge cache after updating product
        $this->purgeProductCache($product);

        return new ProductResource($product);
    }

    public function destroy(Product $product)
    {
        if ($product->productData()->exists()) {
            return response()->json([
                'message' => 'Không thể xóa. Sản phẩm vẫn còn dữ liệu (items) trong kho.'
            ], 422);
        }
        
        if ($product->orders()->exists()) {
             return response()->json([
                'message' => 'Không thể xóa. Sản phẩm đã có trong lịch sử đơn hàng.'
            ], 422);
        }

        $productId = $product->id;
        $product->delete();

        // Purge cache after deleting product
        $this->cloudflare->purgeByTags(["product-{$productId}", "products", "store"]);
        $this->cloudflare->purgeByPrefix([
            '/api/v1/products/',
            '/store/',
        ]);

        return response()->noContent();
    }

    public function upload(UploadProductsRequest $request)
    {
        $validated = $request->validated();
        $productId = $validated['product_id'];
        $dataLines = $validated['data_lines'];
        $count = count($dataLines);

        $product = Product::lockForUpdate()->findOrFail($productId);

        $itemsToInsert = [];
        $now = now();

        foreach ($dataLines as $line) {
            $itemsToInsert[] = [
                'product_id' => $productId,
                'data_line' => $line,
                'order_id' => null,
                'created_at' => $now,
                'updated_at' => $now,
            ];
        }

        try {
            DB::transaction(function () use ($product, $itemsToInsert, $count) {
                ProductData::insert($itemsToInsert);
                $product->increment('stock', $count);
            });
        } catch (\Exception $e) {
            return response()->json(['message' => 'Lỗi khi thêm dữ liệu vào kho.', 'error' => $e->getMessage()], 500);
        }

        // Purge cache after updating stock
        $this->purgeProductCache($product);

        return response()->json([
            'message' => "Thêm thành công {$count} items vào kho.",
            'new_stock' => $product->stock,
        ], 201);
    }

    /**
     * Purge cache for a product
     */
    private function purgeProductCache(Product $product): void
    {
        // Option 1: Purge by Tags (Recommended)
        $this->cloudflare->purgeByTags([
            "product-{$product->id}",
            "products",
            "store"
        ]);

        // Option 2: Purge by Prefix
        $this->cloudflare->purgeByPrefix([
            '/api/v1/products/',
            '/store/',
        ]);
    }
}