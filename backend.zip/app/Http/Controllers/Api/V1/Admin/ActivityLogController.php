<?php

namespace App\Http\Controllers\Api\V1\Admin;

use App\Http\Controllers\Controller;
use App\Models\ActivityLog;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class ActivityLogController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth:sanctum');
        $this->middleware('admin');
    }

    /**
     * Get activity logs
     */
    public function index(Request $request): JsonResponse
    {
        $query = ActivityLog::with('admin:id,name,email')
            ->latest();

        // Filter by action
        if ($request->has('action')) {
            $query->where('action', $request->action);
        }

        // Filter by target_type
        if ($request->has('target_type')) {
            $query->where('target_type', $request->target_type);
        }

        // Filter by admin
        if ($request->has('admin_id')) {
            $query->where('admin_id', $request->admin_id);
        }

        // Filter by date range
        if ($request->has('from')) {
            $query->whereDate('created_at', '>=', $request->from);
        }
        if ($request->has('to')) {
            $query->whereDate('created_at', '<=', $request->to);
        }

        // Search
        if ($request->has('search')) {
            $search = $request->search;
            $query->where(function ($q) use ($search) {
                $q->where('action', 'like', "%{$search}%")
                    ->orWhere('target_type', 'like', "%{$search}%")
                    ->orWhere('target_id', $search);
            });
        }

        $logs = $query->paginate($request->input('per_page', 20));

        return response()->json([
            'success' => true,
            'data' => $logs,
        ]);
    }

    /**
     * Export logs
     */
    public function export(Request $request): JsonResponse
    {
        // In a real app, this would generate CSV/Excel
        // For now, return all logs without pagination
        $logs = ActivityLog::with('admin:id,name,email')
            ->latest()
            ->limit(1000)
            ->get();

        return response()->json([
            'success' => true,
            'data' => $logs,
            'message' => 'Exported ' . $logs->count() . ' logs',
        ]);
    }
}
