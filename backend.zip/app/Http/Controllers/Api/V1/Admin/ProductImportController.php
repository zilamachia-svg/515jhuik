<?php

namespace App\Http\Controllers\Api\V1\Admin;

use App\Http\Controllers\Controller;
use App\Services\ProductImportService;
use Illuminate\Http\Request;
use Illuminate\Http\JsonResponse;

class ProductImportController extends Controller
{
    public function __construct(private ProductImportService $importService) {}

    /**
     * Upload và import sản phẩm từ CSV
     */
    public function importCsv(Request $request): JsonResponse
    {
        $request->validate([
            'file' => 'required|file|mimes:csv,txt',
            'column_map' => 'nullable|json', // Mapping tùy chỉnh các cột
        ]);

        try {
            $file = $request->file('file');
            $filePath = $file->store('imports', 'local');
            $fullPath = storage_path("app/{$filePath}");

            $columnMap = [];
            if ($request->has('column_map')) {
                $columnMap = json_decode($request->input('column_map'), true);
            }

            $result = $this->importService->importFromCsv($fullPath, $columnMap);

            // Xóa file tạm
            @unlink($fullPath);

            return response()->json([
                'message' => 'Import thành công!',
                'data' => $result,
            ], 200);

        } catch (\Exception $e) {
            return response()->json([
                'message' => 'Lỗi import',
                'error' => $e->getMessage(),
            ], 400);
        }
    }

    /**
     * Upload và import sản phẩm từ TXT
     */
    public function importTxt(Request $request): JsonResponse
    {
        $request->validate([
            'file' => 'required|file|mimes:txt',
        ]);

        try {
            $file = $request->file('file');
            $filePath = $file->store('imports', 'local');
            $fullPath = storage_path("app/{$filePath}");

            $result = $this->importService->importFromTxt($fullPath);

            // Xóa file tạm
            @unlink($fullPath);

            return response()->json([
                'message' => 'Import thành công!',
                'data' => $result,
            ], 200);

        } catch (\Exception $e) {
            return response()->json([
                'message' => 'Lỗi import',
                'error' => $e->getMessage(),
            ], 400);
        }
    }

    /**
     * Tải về template CSV
     */
    public function downloadTemplate(): JsonResponse
    {
        try {
            $content = ProductImportService::generateCsvTemplate();

            return response()->json([
                'template' => $content,
                'message' => 'Template CSV đã được tạo',
            ], 200);

        } catch (\Exception $e) {
            return response()->json([
                'error' => $e->getMessage(),
            ], 400);
        }
    }

    /**
     * Hỗ trợ multi-file import (batch)
     */
    public function importBatch(Request $request): JsonResponse
    {
        $request->validate([
            'files' => 'required|array|min:1',
            'files.*' => 'required|file|mimes:csv,txt',
        ]);

        try {
            $batchResults = [
                'total_files' => count($request->file('files')),
                'results' => [],
                'summary' => [
                    'total_success' => 0,
                    'total_failure' => 0,
                ],
            ];

            foreach ($request->file('files') as $index => $file) {
                $filePath = $file->store('imports', 'local');
                $fullPath = storage_path("app/{$filePath}");
                $fileName = $file->getClientOriginalName();

                try {
                    if ($file->getClientOriginalExtension() === 'csv') {
                        $result = $this->importService->importFromCsv($fullPath);
                    } else {
                        $result = $this->importService->importFromTxt($fullPath);
                    }

                    $batchResults['results'][$fileName] = $result;
                    $batchResults['summary']['total_success'] += $result['success'];
                    $batchResults['summary']['total_failure'] += $result['failure'];

                } catch (\Exception $e) {
                    $batchResults['results'][$fileName] = [
                        'error' => $e->getMessage(),
                    ];
                } finally {
                    @unlink($fullPath);
                }
            }

            return response()->json([
                'message' => 'Import batch hoàn thành!',
                'data' => $batchResults,
            ], 200);

        } catch (\Exception $e) {
            return response()->json([
                'message' => 'Lỗi import batch',
                'error' => $e->getMessage(),
            ], 400);
        }
    }
}
