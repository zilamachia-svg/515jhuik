<?php
namespace App\Http\Controllers\Api\V1\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\User;
use App\Models\Order;
use App\Models\Deposit;
use Illuminate\Support\Facades\DB;
use OpenApi\Annotations as OA;

class DashboardController extends Controller
{
    /**
     * @OA\Get(
     * path="/api/v1/admin/dashboard",
     * summary="Lấy thống kê tổng quan Dashboard",
     * tags={"Admin Dashboard"},
     * security={{"bearerAuth":{}}},
     * @OA\Response(response=200, description="Thành công"),
     * @OA\Response(response=500, description="Lỗi Server")
     * )
     */
    public function index()
    {
        try {
            // Logic tính toán an toàn
            $totalUsers = User::count();
            $newUsersToday = User::whereDate('created_at', today())->count();
            
            // Dùng COALESCE(SUM, 0) để tránh trả về NULL, giúp Frontend không crash
            $totalRevenue = Order::sum('total_price') ?? 0.0;
            $totalOrders = Order::count();

            // Trả về dữ liệu đầy đủ key (bao gồm totalRevenue)
            return response()->json([
                'success' => true,
                'data' => [
                    'users' => [
                        'total' => $totalUsers,
                        'new_today' => $newUsersToday
                    ],
                    'deposits' => [
                        'total_amount' => Deposit::sum('amount') ?? 0.0,
                        'today_amount' => Deposit::whereDate('created_at', today())->sum('amount') ?? 0.0
                    ],
                    'orders' => [
                        'total' => $totalOrders,
                        'revenue' => (float) $totalRevenue
                    ],
                    // KEY BẮT BUỘC CHO FRONTEND (Fix lỗi 'Cannot read properties of undefined (reading totalRevenue)')
                    'totalRevenue' => (float) $totalRevenue, 
                    'totalOrders' => $totalOrders,
                ]
            ]);
        } catch (\Exception $e) {
            // Bắt lỗi và trả về JSON cụ thể để debug
            return response()->json([
                'success' => false,
                'message' => 'Lỗi Backend Dashboard: ' . $e->getMessage(),
                'file' => $e->getFile(),
                'line' => $e->getLine()
            ], 500); // Vẫn dùng 500 để Frontend biết là lỗi server
        }
    }
}