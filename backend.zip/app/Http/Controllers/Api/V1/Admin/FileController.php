<?php

namespace App\Http\Controllers\Api\V1\Admin;

use App\Http\Controllers\Controller;
use App\Http\Requests\UploadFileRequest;
use App\Http\Resources\FileResource;
use App\Models\UploadedFile;
use Illuminate\Support\Facades\Storage;

class FileController extends Controller
{
    public function index()
    {
        $files = UploadedFile::latest()->paginate(30);
        return FileResource::collection($files);
    }

    public function upload(UploadFileRequest $request)
    {
        $uploadedFiles = [];

        if ($request->hasFile('files')) {
            foreach ($request->file('files') as $file) {
                $path = $file->store('uploads', 'public');

                $uploadedFiles[] = UploadedFile::create([
                    'name' => $file->getClientOriginalName(),
                    'path' => $path,
                    'type' => $file->getMimeType(),
                    'size' => $file->getSize(),
                ]);
            }
        }

        return FileResource::collection($uploadedFiles);
    }

    public function destroy(UploadedFile $file)
    {
        Storage::disk('public')->delete($file->path);
        $file->delete();
        return response()->noContent();
    }
}
