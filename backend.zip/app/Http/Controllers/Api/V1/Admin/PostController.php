<?php

namespace App\Http\Controllers\Api\V1\Admin;

use App\Http\Controllers\Controller;
use App\Http\Requests\Admin\StorePostRequest;
use App\Http\Requests\Admin\UpdatePostRequest;
use App\Http\Resources\PostResource;
use App\Models\Post;
use App\Services\CloudflareService;
use Illuminate\Http\Request;

class PostController extends Controller
{
    protected $cloudflare;

    public function __construct(CloudflareService $cloudflare)
    {
        $this->cloudflare = $cloudflare;
    }

    public function index(Request $request)
    {
        $query = Post::query()->with('author');

        $query->when($request->input('search'), function ($q, $search) {
            $q->where('title', 'like', "%{$search}%");
        });

        $query->when($request->input('status'), function ($q, $status) {
            $q->where('status', $status);
        });
        
        $query->when($request->input('author_id'), function ($q, $authorId) {
            $q->where('author_id', $authorId);
        });

        $posts = $query->latest()
                     ->paginate($request->input('limit', 15));

        return PostResource::collection($posts);
    }

    public function store(StorePostRequest $request)
    {
        $data = $request->validated();
        $data['author_id'] = $request->user()->id;

        $post = Post::create($data);

        // Purge cache after creating post
        $this->purgePostCache($post);

        return response(new PostResource($post->load('author')), 201);
    }

    public function update(UpdatePostRequest $request, Post $post)
    {
        $post->update($request->validated());

        // Purge cache after updating post
        $this->purgePostCache($post);

        return new PostResource($post->load('author'));
    }

    public function destroy(Post $post)
    {
        $postId = $post->id;
        $postSlug = $post->slug;
        
        $post->delete();

        // Purge cache after deleting post
        $this->cloudflare->purgeByTags(["post-{$postId}", "posts", "content"]);
        $this->cloudflare->purgeByPrefix([
            '/api/v1/posts/',
            '/posts/',
        ]);

        return response()->noContent();
    }

    /**
     * Purge cache for a post
     */
    private function purgePostCache(Post $post): void
    {
        $baseUrl = env('APP_URL', 'https://yourdomain.com');
        
        // Option 1: Purge by Tags (Recommended)
        $this->cloudflare->purgeByTags([
            "post-{$post->id}",
            "posts",
            "content"
        ]);

        // Option 2: Purge by URL (if post is published)
        if ($post->status === 'published') {
            $this->cloudflare->purgeByUrl([
                "{$baseUrl}/api/v1/posts/{$post->slug}",
                "{$baseUrl}/posts/{$post->slug}",
            ]);
        }

        // Option 3: Purge by Prefix (more aggressive)
        $this->cloudflare->purgeByPrefix([
            '/api/v1/posts/',
            '/posts/',
        ]);
    }
}