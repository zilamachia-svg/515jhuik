<?php

namespace App\Http\Controllers\Api\V1\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Supplier;
use Illuminate\Database\Eloquent\ModelNotFoundException;

class SupplierController extends Controller
{
    /**
     * Lấy danh sách tất cả nhà cung cấp
     */
    public function index()
    {
        // Sử dụng phương thức paginate để tránh tải quá nhiều dữ liệu
        return response()->json(Supplier::paginate(10));
    }

    /**
     * Tạo nhà cung cấp mới
     */
    public function store(Request $request)
    {
        $data = $request->validate([
            'name'    => 'required|string|max:255|unique:suppliers,name',
            'contact' => 'nullable|string|max:255',
            'email'   => 'nullable|email|max:255|unique:suppliers,email',
        ]);
        
        $supplier = Supplier::create($data);
        return response()->json($supplier, 201); // 201 Created
    }

    /**
     * Cập nhật thông tin nhà cung cấp
     */
    public function update(Request $request, $id)
    {
        try {
            $supplier = Supplier::findOrFail($id);
        } catch (ModelNotFoundException $e) {
            return response()->json(['message' => 'Supplier not found.'], 404);
        }

        $data = $request->validate([
            'name'    => 'required|string|max:255|unique:suppliers,name,' . $supplier->id, // Loại trừ ID hiện tại
            'contact' => 'nullable|string|max:255',
            'email'   => 'nullable|email|max:255|unique:suppliers,email,' . $supplier->id,
        ]);

        $supplier->update($data);
        return response()->json($supplier, 200); // 200 OK
    }

    /**
     * Xoá nhà cung cấp
     */
    public function destroy($id)
    {
        try {
            $supplier = Supplier::findOrFail($id);
        } catch (ModelNotFoundException $e) {
            return response()->json(['message' => 'Supplier not found.'], 404);
        }

        $supplier->delete();
        return response()->json(['message' => 'Deleted successfully.'], 200);
    }
}
