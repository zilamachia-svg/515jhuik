<?php

namespace App\Http\Controllers\Api\V1\Admin;

use App\Http\Controllers\Controller;
use App\Http\Requests\Admin\StorePaymentMethodRequest;
use App\Http\Requests\Admin\UpdatePaymentMethodRequest;
use App\Http\Resources\PaymentMethodResource;
use App\Models\PaymentMethod;
use Illuminate\Http\Request;

class PaymentMethodController extends Controller
{
    public function index()
    {
        $methods = PaymentMethod::orderBy('name', 'asc')->get();
        
        return PaymentMethodResource::collection($methods);
    }

    public function store(StorePaymentMethodRequest $request)
    {
        $method = PaymentMethod::create($request->validated());
        
        return response(new PaymentMethodResource($method), 201);
    }

    public function update(UpdatePaymentMethodRequest $request, PaymentMethod $payment_method)
    {
        $payment_method->update($request->validated());
        
        return new PaymentMethodResource($payment_method);
    }

    public function destroy(PaymentMethod $payment_method)
    {
        $payment_method->delete();
        
        return response()->noContent();
    }
}
