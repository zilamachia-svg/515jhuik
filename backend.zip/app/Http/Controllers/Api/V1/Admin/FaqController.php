<?php

namespace App\Http\Controllers\Api\V1\Admin;

use App\Http\Controllers\Controller;
use App\Http\Requests\StoreFaqRequest;
use App\Http\Requests\UpdateFaqRequest;
use App\Http\Resources\FaqResource;
use App\Models\Faq;
use App\Services\CloudflareService;

class FaqController extends Controller
{
    protected $cloudflare;

    public function __construct(CloudflareService $cloudflare)
    {
        $this->cloudflare = $cloudflare;
    }

    public function index()
    {
        $faqs = Faq::orderBy('order', 'asc')->paginate(20);
        return FaqResource::collection($faqs);
    }

    public function store(StoreFaqRequest $request)
    {
        $faq = Faq::create($request->validated());
        
        // Purge cache after creating FAQ
        $this->purgeFaqCache();

        return response(new FaqResource($faq), 201);
    }

    public function update(UpdateFaqRequest $request, Faq $faq)
    {
        $faq->update($request->validated());
        
        // Purge cache after updating FAQ
        $this->purgeFaqCache();

        return new FaqResource($faq);
    }

    public function destroy(Faq $faq)
    {
        $faq->delete();
        
        // Purge cache after deleting FAQ
        $this->purgeFaqCache();

        return response()->noContent();
    }

    /**
     * Purge cache for FAQs
     */
    private function purgeFaqCache(): void
    {
        // Option 1: Purge by Tags
        $this->cloudflare->purgeByTags(['faq', 'content']);

        // Option 2: Purge by Prefix
        $this->cloudflare->purgeByPrefix(['/api/v1/faq', '/faq']);
    }
}