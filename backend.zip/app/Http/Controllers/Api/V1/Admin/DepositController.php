<?php

namespace App\Http\Controllers\Api\V1\Admin;

use App\Http\Controllers\Controller;
use App\Http\Requests\Admin\UpdateDepositRequest;
use App\Http\Resources\Admin\DepositResource as AdminDepositResource;
use App\Models\Deposit;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class DepositController extends Controller
{
    public function index(Request $request)
    {
        $query = Deposit::query()->with('user');

        $query->when($request->input('status'), function ($q, $status) {
            $q->where('status', $status);
        });

        $query->when($request->input('search'), function ($q, $search) {
            $q->where(function ($subQuery) use ($search) {
                $subQuery->where('transaction_code', 'like', "%{$search}%")
                         ->orWhereHas('user', function ($userQuery) use ($search) {
                             $userQuery->where('email', 'like', "%{$search}%")
                                     ->orWhere('name', 'like', "%{$search}%");
                         });
            });
        });

        $limit = $request->input('limit', 20);
        $deposits = $query->latest()->paginate($limit);

        return AdminDepositResource::collection($deposits);
    }

    public function update(UpdateDepositRequest $request, Deposit $deposit)
    {
        $newStatus = $request->validated('status');

        if ($deposit->status === 'Hoàn thành') {
            return response()->json(['message' => 'Giao dịch đã được xử lý trước đó.'], 409);
        }

        try {
            DB::transaction(function () use ($deposit, $newStatus) {
                $deposit->update(['status' => $newStatus]);

                if ($newStatus === 'Hoàn thành') {
                    $user = $deposit->user()->lockForUpdate()->first();
                    $user->increment('balance', $deposit->amount);
                }
            });
        } catch (\Exception $e) {
            return response()->json(['message' => 'Lỗi máy chủ, không thể cập nhật giao dịch.'], 500);
        }

        return new AdminDepositResource($deposit->fresh('user'));
    }
}
