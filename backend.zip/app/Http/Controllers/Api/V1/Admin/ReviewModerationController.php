<?php

namespace App\Http\Controllers\Api\V1\Admin;

use App\Http\Controllers\Controller;
use App\Models\ProductReview;
use App\Models\ActivityLog;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class ReviewModerationController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth:sanctum');
        $this->middleware('admin');
    }

    /**
     * Get all reviews (including pending)
     */
    public function index(Request $request): JsonResponse
    {
        $query = ProductReview::with(['product:id,name', 'user:id,name,email'])
            ->latest();

        // Filter by status
        if ($request->has('status')) {
            if ($request->status === 'pending') {
                $query->pending();
            } elseif ($request->status === 'approved') {
                $query->approved();
            }
        }

        // Filter by product
        if ($request->has('product_id')) {
            $query->forProduct($request->product_id);
        }

        $reviews = $query->paginate(20);

        return response()->json([
            'success' => true,
            'data' => $reviews,
        ]);
    }

    /**
     * Approve a review
     */
    public function approve($id): JsonResponse
    {
        $review = ProductReview::findOrFail($id);
        $review->update(['is_approved' => true]);

        ActivityLog::log('approve_review', 'ProductReview', $id, [
            'product_id' => $review->product_id,
            'user_id' => $review->user_id,
        ]);

        return response()->json([
            'success' => true,
            'message' => 'Đã duyệt đánh giá',
            'data' => $review,
        ]);
    }

    /**
     * Reject a review
     */
    public function reject($id): JsonResponse
    {
        $review = ProductReview::findOrFail($id);
        
        ActivityLog::log('reject_review', 'ProductReview', $id, [
            'product_id' => $review->product_id,
            'user_id' => $review->user_id,
        ]);

        $review->delete();

        return response()->json([
            'success' => true,
            'message' => 'Đã từ chối đánh giá',
        ]);
    }
}
