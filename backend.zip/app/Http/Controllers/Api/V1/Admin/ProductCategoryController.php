<?php

namespace App\Http\Controllers\Api\V1\Admin;

use App\Http\Controllers\Controller;
use App\Http\Requests\StoreProductCategoryRequest;
use App\Http\Requests\UpdateProductCategoryRequest;
use App\Http\Resources\ProductCategoryResource;
use App\Models\ProductCategory;
use Illuminate\Http\Request;

class ProductCategoryController extends Controller
{
    public function index()
    {
        // Define the order of existing categories
        $existingCategoriesOrder = [
            'Facebook Account',
            'VIA US',
            'Clone Philippines',
            'Tài khoản khác'
        ];
        
        $categories = ProductCategory::withCount('products')->get();
        
        // Sort: existing categories first (in order), then new ones by created_at (newest first)
        $sortedCategories = $categories->sortBy(function ($category) use ($existingCategoriesOrder) {
            $index = array_search($category->name, $existingCategoriesOrder);
            if ($index !== false) {
                // Existing category: use its index (0-3)
                return $index;
            }
            // New category: put after existing ones, newest first (use negative timestamp)
            // This ensures newest categories appear first after the 4 existing ones
            return 100 - strtotime($category->created_at);
        })->values();
        
        return ProductCategoryResource::collection($sortedCategories);
    }

    public function store(StoreProductCategoryRequest $request)
    {
        $category = ProductCategory::create($request->validated());
        
        return response(new ProductCategoryResource($category->loadCount('products')), 201);
    }

    public function update(UpdateProductCategoryRequest $request, ProductCategory $product_category)
    {
        $product_category->update($request->validated());
        
        return new ProductCategoryResource($product_category->loadCount('products'));
    }

    public function destroy(ProductCategory $product_category)
    {
        if ($product_category->products()->exists()) {
            return response()->json([
                'message' => 'Không thể xóa danh mục. Vui lòng xóa/di chuyển các sản phẩm liên quan trước.'
            ], 422);
        }

        $product_category->delete();

        return response()->noContent();
    }
}
