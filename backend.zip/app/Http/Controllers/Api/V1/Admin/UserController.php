<?php

namespace App\Http\Controllers\Api\V1\Admin;

use App\Http\Controllers\Controller;
use App\Http\Requests\StoreUserRequest;
use App\Http\Requests\UpdateUserRequest;
use App\Http\Resources\UserResource;
use App\Models\User;
use App\Models\Deposit;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\DB;
use OpenApi\Annotations as OA; // <--- QUAN TRỌNG: Đã thêm dòng này

class UserController extends Controller
{
    public function index(Request $request)
    {
        $query = User::query();

        $query->when($request->input('search'), function ($q, $search) {
            $q->where('name', 'like', "%{$search}%")
              ->orWhere('email', 'like', "%{$search}%");
        });

        $users = $query->latest()->paginate(20);

        return UserResource::collection($users);
    }

    public function store(StoreUserRequest $request)
    {
        $user = User::create($request->validated());

        return response(new UserResource($user), 201);
    }

    public function update(UpdateUserRequest $request, User $user)
    {
        $data = $request->validated();

        if (empty($data['password'])) {
            unset($data['password']);
        }

        $user->update($data);

        return new UserResource($user);
    }

    public function destroy(User $user)
    {
        if ($user->id === auth()->id()) {
            return response()->json(['message' => 'Không thể tự xóa chính mình.'], 403);
        }

        $user->delete();
        return response()->noContent();
    }

    public function authors()
    {
        $authors = User::where('role', 'admin')
                       ->select('id', 'name')
                       ->orderBy('name')
                       ->get();
        
        return response()->json($authors);
    }

    /**
     * @OA\Get(
     * path="/api/v1/admin/users/top-depositors",
     * summary="Lấy danh sách người dùng nạp tiền nhiều nhất",
     * description="Trả về danh sách top users dựa trên tổng số tiền nạp (completed, pending hoặc all).",
     * tags={"Admin Users"},
     * security={{"bearerAuth":{}}},
     * @OA\Parameter(
     * name="limit",
     * in="query",
     * description="Số lượng user muốn lấy (Mặc định: 10)",
     * required=false,
     * @OA\Schema(type="integer", default=10)
     * ),
     * @OA\Parameter(
     * name="status",
     * in="query",
     * description="Trạng thái đơn nạp để tính toán (completed, pending, all)",
     * required=false,
     * @OA\Schema(type="string", default="completed", enum={"completed", "pending", "all"})
     * ),
     * @OA\Response(
     * response=200,
     * description="Thành công",
     * @OA\JsonContent(
     * @OA\Property(property="data", type="array",
     * @OA\Items(
     * @OA\Property(property="id", type="integer", example=1),
     * @OA\Property(property="name", type="string", example="Nguyen Van A"),
     * @OA\Property(property="email", type="string", example="admin@example.com"),
     * @OA\Property(property="avatar", type="string", nullable=true),
     * @OA\Property(property="total_deposits", type="number", format="float", example=5000000),
     * @OA\Property(property="deposit_count", type="integer", example=5)
     * )
     * ),
     * @OA\Property(property="meta", type="object",
     * @OA\Property(property="limit", type="integer", example=10),
     * @OA\Property(property="status", type="string", example="completed"),
     * @OA\Property(property="count", type="integer", example=5)
     * )
     * )
     * ),
     * @OA\Response(response=401, description="Chưa đăng nhập"),
     * @OA\Response(response=403, description="Không có quyền truy cập")
     * )
     */
    public function topDepositors(Request $request)
    {
        $limit = (int) $request->input('limit', 10);
        $status = $request->input('status', 'completed'); // completed, pending, all

        // Build query to get users with their total deposits
        $query = User::select('users.id', 'users.name', 'users.email', 'users.avatar')
            ->selectRaw('COALESCE(SUM(deposits.amount), 0) as total_deposits')
            ->selectRaw('COUNT(deposits.id) as deposit_count')
            ->leftJoin('deposits', function ($join) use ($status) {
                $join->on('users.id', '=', 'deposits.user_id');
                if ($status !== 'all') {
                    $join->where('deposits.status', '=', $status);
                }
            })
            // LƯU Ý: MySQL Strict Mode yêu cầu group by đủ các cột select không tổng hợp
            ->groupBy('users.id', 'users.name', 'users.email', 'users.avatar')
            ->havingRaw('total_deposits > 0') // Only show users with deposits
            ->orderByDesc('total_deposits')
            ->orderByDesc('deposit_count')
            ->limit($limit);

        $topDepositors = $query->get();

        return response()->json([
            'data' => $topDepositors->map(function ($user) {
                return [
                    'id' => $user->id,
                    'name' => $user->name,
                    'email' => $user->email,
                    'avatar' => $user->avatar,
                    'total_deposits' => (float) $user->total_deposits,
                    'deposit_count' => (int) $user->deposit_count,
                ];
            }),
            'meta' => [
                'limit' => $limit,
                'status' => $status,
                'count' => $topDepositors->count()
            ]
        ]);
    }
}