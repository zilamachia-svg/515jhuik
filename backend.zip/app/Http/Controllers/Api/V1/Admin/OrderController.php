<?php

namespace App\Http\Controllers\Api\V1\Admin;

use App\Http\Controllers\Controller;
use App\Http\Resources\Admin\OrderResource as AdminOrderResource;
use App\Models\Order;
use Illuminate\Http\Request;

class OrderController extends Controller
{
    public function index(Request $request)
    {
        $query = Order::query()->with(['user:id,name,email', 'product:id,name']);

        $query->when($request->input('search'), function ($q, $search) {
            $q->where(function ($sub) use ($search) {
                $sub->where('id', 'like', "%{$search}%")
                    ->orWhereHas('user', fn($uq) => $uq->where('email', 'like', "%{$search}%"))
                    ->orWhereHas('product', fn($pq) => $pq->where('name', 'like', "%{$search}%"));
            });
        });
        
        $query->when($request->input('status'), fn($q, $status) => $q->where('status', $status));

        $orders = $query->latest()->paginate(20);

        return AdminOrderResource::collection($orders);
    }

    public function show(Order $order)
    {
        $order->load(['user', 'product']);

        return new AdminOrderResource($order);
    }
}
