<?php

namespace App\Http\Controllers\Api\V1\Admin;

use App\Http\Controllers\Controller;
use App\Models\Product;
use App\Models\ActivityLog;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class BatchOperationsController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth:sanctum');
        $this->middleware('admin');
    }

    /**
     * Batch delete products
     */
    public function batchDelete(Request $request): JsonResponse
    {
        $request->validate([
            'product_ids' => 'required|array',
            'product_ids.*' => 'exists:products,id',
        ]);

        $productIds = $request->product_ids;
        
        ActivityLog::log('batch_delete', 'Product', null, [
            'product_ids' => $productIds,
            'count' => count($productIds),
        ]);

        Product::whereIn('id', $productIds)->delete();

        return response()->json([
            'success' => true,
            'message' => 'Đã xóa ' . count($productIds) . ' sản phẩm',
        ]);
    }

    /**
     * Batch update status
     */
    public function batchUpdateStatus(Request $request): JsonResponse
    {
        $request->validate([
            'product_ids' => 'required|array',
            'product_ids.*' => 'exists:products,id',
            'status' => 'required|in:active,inactive,out_of_stock',
        ]);

        $productIds = $request->product_ids;
        $status = $request->status;

        ActivityLog::log('batch_update_status', 'Product', null, [
            'product_ids' => $productIds,
            'new_status' => $status,
            'count' => count($productIds),
        ]);

        Product::whereIn('id', $productIds)->update(['status' => $status]);

        return response()->json([
            'success' => true,
            'message' => 'Đã cập nhật trạng thái ' . count($productIds) . ' sản phẩm',
        ]);
    }

    /**
     * Batch adjust price
     */
    public function batchAdjustPrice(Request $request): JsonResponse
    {
        $request->validate([
            'product_ids' => 'required|array',
            'product_ids.*' => 'exists:products,id',
            'adjustment_type' => 'required|in:percentage,fixed',
            'adjustment_value' => 'required|numeric',
        ]);

        $productIds = $request->product_ids;
        $type = $request->adjustment_type;
        $value = $request->adjustment_value;

        DB::transaction(function () use ($productIds, $type, $value) {
            $products = Product::whereIn('id', $productIds)->get();

            foreach ($products as $product) {
                $newPrice = $product->price;

                if ($type === 'percentage') {
                    // Tăng/giảm theo %
                    $newPrice = $product->price * (1 + $value / 100);
                } else {
                    // Tăng/giảm cố định
                    $newPrice = $product->price + $value;
                }

                // Đảm bảo giá không âm
                $newPrice = max(0, $newPrice);

                $product->update(['price' => $newPrice]);
            }
        });

        ActivityLog::log('batch_adjust_price', 'Product', null, [
            'product_ids' => $productIds,
            'adjustment_type' => $type,
            'adjustment_value' => $value,
            'count' => count($productIds),
        ]);

        return response()->json([
            'success' => true,
            'message' => 'Đã điều chỉnh giá ' . count($productIds) . ' sản phẩm',
        ]);
    }

    /**
     * Export selected products
     */
    public function export(Request $request): JsonResponse
    {
        $request->validate([
            'product_ids' => 'required|array',
            'product_ids.*' => 'exists:products,id',
        ]);

        $products = Product::with('category')
            ->whereIn('id', $request->product_ids)
            ->get();

        ActivityLog::log('export_products', 'Product', null, [
            'product_ids' => $request->product_ids,
            'count' => $products->count(),
        ]);

        return response()->json([
            'success' => true,
            'data' => $products,
            'message' => 'Exported ' . $products->count() . ' products',
        ]);
    }
}
