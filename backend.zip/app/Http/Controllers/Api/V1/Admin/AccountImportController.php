<?php

namespace App\Http\Controllers\Api\V1\Admin;

use App\Http\Controllers\Controller;
use App\Models\AccountData;
use App\Models\Order;
use App\Services\AccountImportService;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;

class AccountImportController extends Controller
{
    protected $accountImportService;

    public function __construct(AccountImportService $accountImportService)
    {
        $this->accountImportService = $accountImportService;
        $this->middleware('auth:sanctum');
        $this->middleware('role:admin');
    }

    /**
     * Import tài khoản từ file pipe-delimited
     * POST /api/v1/admin/accounts/import/pipe
     *
     * Format: uid|pass|2fa|email|passmail|emailkp|friend|created_date|birthday|cookie|token
     */
    public function importPipe(Request $request)
    {
        $request->validate([
            'file' => 'required|file|mimes:txt,csv',
            'platform' => 'required|in:facebook,tiktok,instagram,gmail,outlook',
            'product_id' => 'nullable|exists:products,id',
        ]);

        try {
            $file = $request->file('file');
            $platform = $request->input('platform');
            $productId = $request->input('product_id');

            // Save temp file
            $tempPath = $file->store('temp_imports');
            $filePath = storage_path('app/' . $tempPath);

            // Import
            $results = $this->accountImportService->importFromPipeFormat(
                $filePath,
                $platform,
                $productId
            );

            // Clean up temp file
            @unlink($filePath);

            return response()->json([
                'message' => 'Import thành công!',
                'data' => $results,
            ], 200);

        } catch (\Exception $e) {
            Log::error('AccountImport Error', ['error' => $e->getMessage()]);
            return response()->json([
                'message' => 'Import thất bại!',
                'error' => $e->getMessage(),
            ], 500);
        }
    }

    /**
     * Import tài khoản từ CSV với header
     * POST /api/v1/admin/accounts/import/csv
     */
    public function importCSV(Request $request)
    {
        $request->validate([
            'file' => 'required|file|mimes:csv,txt',
            'platform' => 'required|in:facebook,tiktok,instagram,gmail,outlook',
            'product_id' => 'nullable|exists:products,id',
            'column_map' => 'nullable|json',
        ]);

        try {
            $file = $request->file('file');
            $platform = $request->input('platform');
            $productId = $request->input('product_id');
            $columnMap = $request->input('column_map') ? json_decode($request->input('column_map'), true) : null;

            $tempPath = $file->store('temp_imports');
            $filePath = storage_path('app/' . $tempPath);

            $results = $this->accountImportService->importFromCSV(
                $filePath,
                $platform,
                $productId,
                $columnMap
            );

            @unlink($filePath);

            return response()->json([
                'message' => 'Import thành công!',
                'data' => $results,
            ], 200);

        } catch (\Exception $e) {
            Log::error('AccountCSVImport Error', ['error' => $e->getMessage()]);
            return response()->json([
                'message' => 'Import thất bại!',
                'error' => $e->getMessage(),
            ], 500);
        }
    }

    /**
     * Lấy tài khoản khả dụng cho sản phẩm
     * GET /api/v1/admin/accounts/available
     */
    public function getAvailable(Request $request)
    {
        $request->validate([
            'product_id' => 'required|exists:products,id',
            'platform' => 'nullable|in:facebook,tiktok,instagram,gmail,outlook',
        ]);

        try {
            $productId = $request->input('product_id');
            $platform = $request->input('platform');

            $accounts = $this->accountImportService->getAvailableAccounts($productId, $platform);

            return response()->json([
                'message' => 'Lấy tài khoản thành công!',
                'data' => [
                    'total' => $accounts->count(),
                    'accounts' => $accounts->map(fn($acc) => $acc->getDisplayData(false))->toArray(),
                ],
            ], 200);

        } catch (\Exception $e) {
            return response()->json([
                'message' => 'Lỗi!',
                'error' => $e->getMessage(),
            ], 500);
        }
    }

    /**
     * Lấy tài khoản đã gán cho đơn hàng
     * GET /api/v1/customer/account/{order_id}
     */
    public function getOrderAccount(Request $request, $orderId)
    {
        try {
            $order = Order::findOrFail($orderId);

            // Check if user owns this order
            if ($order->user_id !== $request->user()?->id) {
                return response()->json([
                    'message' => 'Không có quyền truy cập!',
                ], 403);
            }

            if (!$order->account_data_id) {
                return response()->json([
                    'message' => 'Chưa có tài khoản được gán cho đơn hàng này!',
                ], 404);
            }

            $account = AccountData::findOrFail($order->account_data_id);

            // Return full data to order owner
            return response()->json([
                'message' => 'Lấy tài khoản thành công!',
                'data' => $account->getFullData(),
            ], 200);

        } catch (\Exception $e) {
            return response()->json([
                'message' => 'Lỗi!',
                'error' => $e->getMessage(),
            ], 500);
        }
    }

    /**
     * Liệt kê tất cả tài khoản (Admin only)
     * GET /api/v1/admin/accounts
     */
    public function index(Request $request)
    {
        $query = AccountData::query();

        // Filter by platform
        if ($request->has('platform')) {
            $query->where('platform', $request->input('platform'));
        }

        // Filter by product
        if ($request->has('product_id')) {
            $query->where('product_id', $request->input('product_id'));
        }

        // Filter by status
        if ($request->input('status') === 'available') {
            $query->available();
        } elseif ($request->input('status') === 'used') {
            $query->where('is_used', true);
        }

        $accounts = $query->paginate(50);

        return response()->json([
            'message' => 'Lấy danh sách tài khoản thành công!',
            'data' => $accounts,
        ], 200);
    }

    /**
     * Xóa tài khoản
     * DELETE /api/v1/admin/accounts/{id}
     */
    public function destroy($id)
    {
        try {
            $account = AccountData::findOrFail($id);

            if ($account->is_used) {
                return response()->json([
                    'message' => 'Không thể xóa tài khoản đã được sử dụng!',
                ], 400);
            }

            $account->delete();

            return response()->json([
                'message' => 'Xóa tài khoản thành công!',
            ], 200);

        } catch (\Exception $e) {
            return response()->json([
                'message' => 'Lỗi!',
                'error' => $e->getMessage(),
            ], 500);
        }
    }

    /**
     * Tải template import
     * GET /api/v1/admin/accounts/import/template
     */
    public function downloadTemplate($platform)
    {
        $platforms = ['facebook', 'tiktok', 'instagram', 'gmail', 'outlook'];

        if (!in_array($platform, $platforms)) {
            return response()->json([
                'message' => 'Platform không hợp lệ!',
            ], 400);
        }

        $headers = [
            'uid|pass|2fa|email|passmail|emailkp|friend|created_date|birthday|cookie|token',
            '100064336657554|Chongbackvia111@test||nazmaaranovr@hotmail.com|Passmoi2025@dfr|nazmaaranovr33@smvmail.com|32|02/03/2021 19:32|12/12/2000|dpr=0.699999988079071;pas=100064336657554%3AwWjGeencIJ|EAAAAUaZA8jlABPDt1W8F8MS8wam9vwncM5VkwDkmBT4UfIySygQnZBP85uGIspb0XfCW1wMHODCiFj9xhnKsjTIBdmXeiH9gSxYRvx9VwhaGFGOJZCgPfwFpG8BApEZARZCVsgG0EZAeSi8ZBtwoZBsR5CSZBnhyW3ZBFB3S4WYgBfWW3kVhZBqnrhkokakuE8ZAYhhIG2DYZCJKrQGfv9QZDZD',
            '987654321|TestPass123||test@email.com|EmailPass123||42|15/05/2020 10:15|20/06/1995|session_cookie_here|access_token_here',
        ];

        $content = implode("\n", $headers);
        $filename = "template_accounts_$platform.txt";

        return response($content, 200)
            ->header('Content-Type', 'text/plain; charset=utf-8')
            ->header('Content-Disposition', "attachment; filename=\"$filename\"");
    }
}
