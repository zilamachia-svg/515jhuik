<?php

namespace App\Http\Controllers\Api\V1\Admin;

use App\Http\Controllers\Controller;
use App\Http\Requests\UpdateSettingsRequest;
use App\Models\Setting;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\DB;

class SettingsController extends Controller
{
    /**
     * [GET] /admin/settings
     * Trả về toàn bộ các cài đặt (bao gồm cả tokens cho admin).
     */
    public function get()
    {
        $settings = [
            'branding' => Setting::getGroup('branding'),
            'contact' => Setting::getGroup('contact'),
            'homepage' => Setting::getGroup('homepage'),
            'tools' => Setting::getGroup('tools'), // Bao gồm cả tokens
        ];
        
        return response()->json([
            'settings' => $settings,
        ]);
    }

    /**
     * [PUT] /admin/settings
     * Cập nhật cài đặt.
     * 
     * SỬ DỤNG updateOrCreate để:
     * - Không ghi đè dữ liệu không được gửi lên
     * - Chỉ cập nhật các field được gửi trong request
     * - Tạo mới nếu chưa tồn tại
     * - Giữ nguyên các settings khác không được gửi lên
     * 
     * SỬ DỤNG Transaction để:
     * - Đảm bảo tính nhất quán dữ liệu
     * - Rollback nếu có lỗi xảy ra
     */
    public function update(UpdateSettingsRequest $request)
    {
        $validatedData = $request->validated();
        
        try {
            DB::transaction(function () use ($validatedData) {
                // Cập nhật nhóm 'branding' (Logo, Favicon URLs)
                // Chỉ cập nhật các key được gửi lên, không ghi đè các key khác
                if (isset($validatedData['branding']) && is_array($validatedData['branding'])) {
                    foreach ($validatedData['branding'] as $key => $value) {
                        Setting::updateOrCreate(
                            [
                                'key' => $key,
                                'group' => 'branding'
                            ],
                            [
                                'value' => $value ?? ''
                            ]
                        );
                    }
                }
                
                // Cập nhật nhóm 'contact'
                // Chỉ cập nhật các key được gửi lên
                if (isset($validatedData['contact']) && is_array($validatedData['contact'])) {
                    foreach ($validatedData['contact'] as $key => $value) {
                        Setting::updateOrCreate(
                            [
                                'key' => $key,
                                'group' => 'contact'
                            ],
                            [
                                'value' => $value ?? ''
                            ]
                        );
                    }
                }
                
                // Cập nhật nhóm 'homepage'
                // Chỉ cập nhật các key được gửi lên
                if (isset($validatedData['homepage']) && is_array($validatedData['homepage'])) {
                    foreach ($validatedData['homepage'] as $key => $value) {
                        Setting::updateOrCreate(
                            [
                                'key' => $key,
                                'group' => 'homepage'
                            ],
                            [
                                'value' => $value ?? ''
                            ]
                        );
                    }
                }

                // Cập nhật nhóm 'tools' (Facebook token, Gemini API key, Messenger)
                // Chỉ cập nhật các key được gửi lên
                if (isset($validatedData['tools']) && is_array($validatedData['tools'])) {
                    foreach ($validatedData['tools'] as $key => $value) {
                        // Cho phép xóa token bằng cách gửi empty string
                        Setting::updateOrCreate(
                            [
                                'key' => $key,
                                'group' => 'tools'
                            ],
                            [
                                'value' => $value ?? ''
                            ]
                        );
                    }
                }
            });
            
            // Clear cache sau khi cập nhật để đảm bảo settings mới được load
            Cache::forget('website_settings_public');
            Cache::forget('website_settings_admin');
            
        } catch (\Exception $e) {
            return response()->json([
                'message' => 'Lỗi khi cập nhật cài đặt.',
                'error' => config('app.debug') ? $e->getMessage() : 'Internal server error'
            ], 500);
        }
        
        // Trả về settings đã cập nhật
        return $this->get();
    }
}