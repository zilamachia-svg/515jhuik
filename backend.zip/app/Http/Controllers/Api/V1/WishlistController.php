<?php

namespace App\Http\Controllers\Api\V1;

use App\Http\Controllers\Controller;
use App\Models\Wishlist;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class WishlistController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth:sanctum');
    }

    /**
     * Get user's wishlist
     */
    public function index(): JsonResponse
    {
        $wishlist = Wishlist::with('product.category')
            ->forUser(auth()->id())
            ->latest()
            ->get();

        return response()->json([
            'success' => true,
            'data' => $wishlist,
            'count' => $wishlist->count(),
        ]);
    }

    /**
     * Add product to wishlist
     */
    public function store(Request $request): JsonResponse
    {
        $request->validate([
            'product_id' => 'required|exists:products,id',
        ]);

        $userId = auth()->id();
        $productId = $request->product_id;

        // Check if already in wishlist
        if (Wishlist::hasProduct($userId, $productId)) {
            return response()->json([
                'success' => false,
                'message' => 'Sản phẩm đã có trong danh sách yêu thích',
            ], 409);
        }

        $wishlist = Wishlist::create([
            'user_id' => $userId,
            'product_id' => $productId,
        ]);

        $wishlist->load('product');

        return response()->json([
            'success' => true,
            'message' => 'Đã thêm vào danh sách yêu thích',
            'data' => $wishlist,
        ], 201);
    }

    /**
     * Remove product from wishlist
     */
    public function destroy($productId): JsonResponse
    {
        $deleted = Wishlist::where('user_id', auth()->id())
            ->where('product_id', $productId)
            ->delete();

        if (!$deleted) {
            return response()->json([
                'success' => false,
                'message' => 'Không tìm thấy sản phẩm trong danh sách yêu thích',
            ], 404);
        }

        return response()->json([
            'success' => true,
            'message' => 'Đã xóa khỏi danh sách yêu thích',
        ]);
    }

    /**
     * Check if product is in wishlist
     */
    public function check($productId): JsonResponse
    {
        $exists = Wishlist::hasProduct(auth()->id(), $productId);

        return response()->json([
            'success' => true,
            'in_wishlist' => $exists,
        ]);
    }

    /**
     * Get wishlist count
     */
    public function count(): JsonResponse
    {
        $count = Wishlist::forUser(auth()->id())->count();

        return response()->json([
            'success' => true,
            'count' => $count,
        ]);
    }
}
