<?php

namespace App\Http\Controllers\Api\V1;

use App\Http\Controllers\Controller;
use App\Models\Notification;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Cache;

class NotificationController extends Controller
{
    // Middleware is already applied in routes/api.php
    // No need to add it again in constructor to avoid conflicts

    /**
     * Get user's notifications
     */
    public function index(Request $request): JsonResponse
    {
        $userId = Auth::id();
        if (!$userId) {
            return response()->json([
                'success' => false,
                'message' => 'Unauthenticated',
            ], 401);
        }
        
        $query = Notification::where('user_id', $userId)
            ->latest();

        // Filter by type
        if ($request->has('type')) {
            $query->where('type', $request->type);
        }

        // Filter by read status
        if ($request->has('unread_only') && $request->unread_only) {
            $query->unread();
        }

        $notifications = $query->paginate(20);

        return response()->json([
            'success' => true,
            'data' => $notifications,
        ]);
    }

    /**
     * Get unread count
     * Cached for 30 seconds to reduce database load
     */
    public function unreadCount(): JsonResponse
    {
        $userId = Auth::id();
        if (!$userId) {
            return response()->json([
                'success' => false,
                'message' => 'Unauthenticated',
            ], 401);
        }
        
        $cacheKey = "user_{$userId}_unread_notifications_count";
        
        // Cache for 30 seconds to reduce database queries
        $count = Cache::remember($cacheKey, 30, function () use ($userId) {
            return Notification::where('user_id', $userId)
                ->whereNull('read_at')
                ->count();
        });

        return response()->json([
            'success' => true,
            'count' => $count,
        ]);
    }

    /**
     * Mark notification as read
     */
    public function markAsRead($id): JsonResponse
    {
        $userId = Auth::id();
        if (!$userId) {
            return response()->json([
                'success' => false,
                'message' => 'Unauthenticated',
            ], 401);
        }
        
        $notification = Notification::where('user_id', $userId)
            ->findOrFail($id);

        $wasUnread = is_null($notification->read_at);
        $notification->markAsRead();

        // Clear cache when marking as read
        if ($wasUnread) {
            Cache::forget("user_{$userId}_unread_notifications_count");
        }

        return response()->json([
            'success' => true,
            'message' => 'Đã đánh dấu là đã đọc',
        ]);
    }

    /**
     * Mark all as read
     */
    public function markAllAsRead(): JsonResponse
    {
        $userId = Auth::id();
        if (!$userId) {
            return response()->json([
                'success' => false,
                'message' => 'Unauthenticated',
            ], 401);
        }
        
        Notification::where('user_id', $userId)
            ->whereNull('read_at')
            ->update(['read_at' => now()]);

        // Clear cache
        Cache::forget("user_{$userId}_unread_notifications_count");

        return response()->json([
            'success' => true,
            'message' => 'Đã đánh dấu tất cả là đã đọc',
        ]);
    }

    /**
     * Delete notification
     */
    public function destroy($id): JsonResponse
    {
        $userId = Auth::id();
        if (!$userId) {
            return response()->json([
                'success' => false,
                'message' => 'Unauthenticated',
            ], 401);
        }
        
        $notification = Notification::where('user_id', $userId)
            ->findOrFail($id);

        $wasUnread = is_null($notification->read_at);
        $notification->delete();

        // Clear cache if unread notification was deleted
        if ($wasUnread) {
            Cache::forget("user_{$userId}_unread_notifications_count");
        }

        return response()->json([
            'success' => true,
            'message' => 'Đã xóa thông báo',
        ]);
    }

    /**
     * Delete all notifications
     */
    public function deleteAll(): JsonResponse
    {
        $userId = Auth::id();
        if (!$userId) {
            return response()->json([
                'success' => false,
                'message' => 'Unauthenticated',
            ], 401);
        }
        
        Notification::where('user_id', $userId)->delete();

        // Clear cache
        Cache::forget("user_{$userId}_unread_notifications_count");

        return response()->json([
            'success' => true,
            'message' => 'Đã xóa tất cả thông báo',
        ]);
    }
}
