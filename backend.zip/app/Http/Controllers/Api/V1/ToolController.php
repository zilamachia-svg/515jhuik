<?php

namespace App\Http\Controllers\Api\V1;

use App\Http\Controllers\Controller;
use App\Services\FacebookCheckService;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class ToolController extends Controller
{
    protected $facebookCheckService;

    public function __construct(FacebookCheckService $facebookCheckService)
    {
        $this->facebookCheckService = $facebookCheckService;
    }

    /**
     * Check live Facebook accounts by UIDs
     * 
     * @param Request $request
     * @return \Illuminate\Http\JsonResponse
     */
    public function checkLiveFB(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'uids' => 'required|array',
            'uids.*' => 'required|string|regex:/^\d+$/', // UID phải là số
        ], [
            'uids.required' => 'Danh sách UID là bắt buộc.',
            'uids.array' => 'UID phải là mảng.',
            'uids.*.regex' => 'UID phải là số.',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'message' => 'Dữ liệu không hợp lệ.',
                'errors' => $validator->errors(),
            ], 422);
        }

        $uids = $request->input('uids', []);
        $results = [];

        foreach ($uids as $uid) {
            try {
                $isLive = $this->facebookCheckService->checkAccountLive($uid);
                $results[] = [
                    'uid' => $uid,
                    'status' => $isLive ? 'Live' : 'Die',
                ];
            } catch (\Exception $e) {
                // Log error but continue with other UIDs
                \Log::error("Error checking UID {$uid}: " . $e->getMessage());
                $results[] = [
                    'uid' => $uid,
                    'status' => 'Die', // Default to Die on error
                ];
            }
        }

        return response()->json([
            'results' => $results,
        ]);
    }

    /**
     * Test Facebook token validity
     * 
     * @param Request $request
     * @return \Illuminate\Http\JsonResponse
     */
    public function testFacebookToken(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'token' => 'nullable|string|max:1000',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'message' => 'Dữ liệu không hợp lệ.',
                'errors' => $validator->errors(),
            ], 422);
        }

        $token = $request->input('token');
        $result = $this->facebookCheckService->testToken($token);

        return response()->json($result);
    }
}