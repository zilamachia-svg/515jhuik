<?php

namespace App\Http\Controllers\Api\V1;

use App\Events\AccountAssigned;
use App\Http\Controllers\Controller;
use App\Http\Requests\StoreOrderRequest;
use App\Http\Resources\OrderResource;
use App\Models\Order;
use App\Models\Product;
use App\Models\AccountData;
use App\Services\AccountImportService;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Illuminate\Validation\ValidationException;

class OrderController extends Controller
{
    public function index(Request $request)
    {
        // ✅ Eager load all necessary relationships to prevent N+1
        $userId = $request->user()?->id;
        
        $orders = Order::where('user_id', $userId)
                     ->with([
                         'product:id,name,price,image_url',
                         'productData:id,order_id,data',
                         'user:id,name,email'
                     ])
                     ->orderBy('created_at', 'desc')
                     ->orderBy('id', 'desc')
                     ->paginate(15);

        return OrderResource::collection($orders);
    }

    public function store(StoreOrderRequest $request)
    {
        $user = $request->user();
        
        // Kiểm tra email đã được xác thực chưa
        if (!$user->email_verified_at) {
            throw ValidationException::withMessages([
                'email' => ['Vui lòng xác thực email trước khi mua hàng. Vào Cài đặt > Xác thực Email để xác thực.']
            ]);
        }
        
        $validated = $request->validated();
        $quantity = $validated['quantity'];
        
        $product = Product::lockForUpdate()->find($validated['product_id']);

        if (!$product) {
            throw ValidationException::withMessages([
                'product_id' => 'Sản phẩm không tồn tại.'
            ]);
        }

        if ($product->stock < $quantity) {
            throw ValidationException::withMessages([
                'quantity' => 'Sản phẩm không đủ số lượng trong kho.'
            ]);
        }

        // KIỂM TRA TÀI KHOẢN TRƯỚC KHI TẠO ĐƠN HÀNG
        $availableAccounts = AccountData::byProduct($product->id)
            ->available()
            ->count();
        
        if ($availableAccounts === 0) {
            throw ValidationException::withMessages([
                'product' => 'Sản phẩm này hiện không có tài khoản trong kho. Vui lòng thử lại sau.'
            ]);
        }

        $total_price = $product->price * $quantity;

        if ($user->balance < $total_price) {
            throw ValidationException::withMessages([
                'user' => 'Số dư không đủ để thực hiện giao dịch.'
            ]);
        }

        $order = null;
        try {
            DB::transaction(function () use ($user, $product, $quantity, $total_price, &$order) {
                $user->decrement('balance', $total_price);
                $product->decrement('stock', $quantity);

                $order = Order::create([
                    'user_id' => $user->id,
                    'product_id' => $product->id,
                    'quantity' => $quantity,
                    'total_price' => $total_price,
                    'status' => 'Đã hoàn thành',
                ]);

                // 🔥 TỰ ĐỘNG GÁN TÀI KHOẢN NẾU CÓ
                $account = AccountData::byProduct($product->id)
                    ->available()
                    ->lockForUpdate()
                    ->first();

                if ($account) {
                    $account->markAsUsed($user->id);
                    $order->update(['account_data_id' => $account->id]);
                    
                    // LOG ASSIGNMENT
                    Log::info('Account assigned', [
                        'order_id' => $order->id,
                        'account_id' => $account->id,
                        'user_id' => $user->id,
                        'platform' => $account->platform,
                    ]);
                    
                    // EMIT EVENT FOR NOTIFICATIONS
                    AccountAssigned::dispatch($order, $account->platform, $account->uid);
                } else {
                    // ACCOUNT DISAPPEARED - ROLLBACK
                    throw new \Exception('Không có tài khoản khả dụng. Giao dịch sẽ bị hoàn lại.');
                }
            });
        } catch (\Exception $e) {
            Log::error('Order creation failed', [
                'error' => $e->getMessage(),
                'user_id' => $user->id,
                'product_id' => $product->id,
            ]);
            
            return response()->json([
                'message' => $e->getMessage() ?: 'Lỗi máy chủ, không thể tạo đơn hàng. Vui lòng liên hệ hỗ trợ.',
            ], 500);
        }

        return response()->json([
            'message' => 'Mua hàng thành công! Tài khoản đã được gán cho bạn.',
            'order_id' => $order?->id,
            'download_link' => $order ? route('orders.download', $order) : null,
            'new_balance' => $user->fresh()->balance,
        ], 201);
    }

    public function download(Request $request, Order $order)
    {
        if ($request->user()->id !== $order->user_id) {
            abort(403, 'Không có quyền truy cập.');
        }

        if ($order->status !== 'Đã hoàn thành') {
            abort(404, 'Đơn hàng chưa hoàn thành.');
        }

        // ✅ Eager load product, user, và account
        $order->load('product:id,name', 'user:id,name,email', 'accountData');

        $fileContent = "╔════════════════════════════════════════════════════════════════╗\n";
        $fileContent .= "║                   THÔNG TIN ĐƠN HÀNG                          ║\n";
        $fileContent .= "╚════════════════════════════════════════════════════════════════╝\n\n";
        
        $fileContent .= "Mã đơn hàng:      {$order->id}\n";
        $fileContent .= "Ngày mua:        " . $order->created_at->format('H:i:s d/m/Y') . "\n";
        $fileContent .= "Trạng thái:      {$order->status}\n\n";
        
        $fileContent .= "╔════════════════════════════════════════════════════════════════╗\n";
        $fileContent .= "║                   THÔNG TIN KHÁCH HÀNG                         ║\n";
        $fileContent .= "╚════════════════════════════════════════════════════════════════╝\n\n";
        
        $fileContent .= "Tên khách hàng:   {$order->user->name}\n";
        $fileContent .= "Email:           {$order->user->email}\n\n";
        
        $fileContent .= "╔════════════════════════════════════════════════════════════════╗\n";
        $fileContent .= "║                   CHI TIẾT SẢN PHẨM                            ║\n";
        $fileContent .= "╚════════════════════════════════════════════════════════════════╝\n\n";
        
        $fileContent .= "Sản phẩm:        {$order->product->name}\n";
        $fileContent .= "Số lượng:        {$order->quantity}\n";
        $fileContent .= "Đơn giá:         " . number_format($order->total_price / $order->quantity, 0, ',', '.') . " ₫\n";
        $fileContent .= "Thành tiền:      " . number_format($order->total_price, 0, ',', '.') . " ₫\n\n";

        // 🔥 HIỂN THỊ TÀI KHOẢN NẾU CÓ
        if ($order->accountData) {
            $fileContent .= "╔════════════════════════════════════════════════════════════════╗\n";
            $fileContent .= "║                   THÔNG TIN TÀI KHOẢN                          ║\n";
            $fileContent .= "╚════════════════════════════════════════════════════════════════╝\n\n";
            
            $fileContent .= "Nền tảng:        " . strtoupper($order->accountData->platform) . "\n";
            $fileContent .= "UID:             {$order->accountData->uid}\n";
            $fileContent .= "Mật khẩu:        {$order->accountData->pass}\n";
            
            if ($order->accountData->password_2fa) {
                $fileContent .= "2FA:             {$order->accountData->password_2fa}\n";
            }
            
            $fileContent .= "Email:           {$order->accountData->email}\n";
            
            if ($order->accountData->passmail) {
                $fileContent .= "Mật khẩu Email:  {$order->accountData->passmail}\n";
            }
            
            if ($order->accountData->emailkp) {
                $fileContent .= "Email Backup:    {$order->accountData->emailkp}\n";
            }
            
            if ($order->accountData->birthday) {
                $fileContent .= "Ngày sinh:       {$order->accountData->birthday}\n";
            }
            
            if ($order->accountData->created_date) {
                $fileContent .= "Ngày tạo:        {$order->accountData->created_date}\n";
            }
            
            if ($order->accountData->friend_count) {
                $fileContent .= "Số bạn bè:       {$order->accountData->friend_count}\n";
            }
            
            if ($order->accountData->cookie) {
                $fileContent .= "Cookie:          {$order->accountData->cookie}\n";
            }
            
            if ($order->accountData->token) {
                $fileContent .= "Token:           {$order->accountData->token}\n";
            }
            
            $fileContent .= "\n";
        } else {
            $fileContent .= "╔════════════════════════════════════════════════════════════════╗\n";
            $fileContent .= "║                   DỮ LIỆU SẢN PHẨM                             ║\n";
            $fileContent .= "╚════════════════════════════════════════════════════════════════╝\n\n";
            $fileContent .= "(Dữ liệu sản phẩm sẽ được hiển thị tại đây)\n";
            $fileContent .= "Ví dụ: user|pass\nuser2|pass2\n\n";
        }
        
        $fileContent .= "═══════════════════════════════════════════════════════════════════\n";
        $fileContent .= "Cảm ơn bạn đã mua hàng! Chúc bạn sử dụng vui vẻ.\n";
        $fileContent .= "═══════════════════════════════════════════════════════════════════\n";

        $fileName = "order_{$order->id}.txt";

        return response($fileContent, 200, [
            'Content-Type' => 'text/plain; charset=utf-8',
            'Content-Disposition' => "attachment; filename=\"{$fileName}\"",
        ]);
    }
}
