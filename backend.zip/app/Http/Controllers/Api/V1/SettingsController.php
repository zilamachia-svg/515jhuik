<?php

namespace App\Http\Controllers\Api\V1; // (Namespace chính xác)

use App\Http\Controllers\Controller;
use App\Models\Setting; // (Sử dụng Model key-value)
use Illuminate\Support\Facades\Cache;

class SettingsController extends Controller
{
    /**
     * [GET] /settings
     * Trả về các cài đặt công khai.
     */
    public function get()
    {
        // Sử dụng Cache để tăng hiệu suất
        $settings = Cache::remember('website_settings_public', 3600, function () {
            return [
                'contact' => Setting::getGroup('contact'),
                'homepage' => Setting::getGroup('homepage'),
            ];
        });

        // Expose minimal runtime feature flags to the public settings payload
        $settings['featureFlags'] = [
            'require_email_verification' => config('app.require_email_verification', false),
        ];

        return response()->json([
            'settings' => $settings,
        ]);
    }
}