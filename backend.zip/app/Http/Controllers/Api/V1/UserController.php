<?php

namespace App\Http\Controllers\Api\V1;

use App\Http\Controllers\Controller;
use App\Http\Requests\UpdateProfileRequest;
use App\Http\Resources\UserResource;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Cache;

class UserController extends Controller
{
    public function me(Request $request)
    {
        try {
            $user = $request->user();
            
            // Ensure user is authenticated
            if (!$user) {
                return response()->json([
                    'message' => 'Bạn cần đăng nhập để truy cập thông tin này.',
                    'errors' => ['auth' => ['Phiên đăng nhập đã hết hạn. Vui lòng đăng nhập lại.']]
                ], 401);
            }

            // ✅ Cache user data for 5 minutes to reduce database queries
            // Fresh() ensures we get latest data, but cache reduces query frequency
            $cachedUser = Cache::remember("user:{$user->id}:me", 300, function () use ($user) {
                return $user->fresh(); // Get fresh data from database
            });

            return response()->json([
                'user' => new UserResource($cachedUser)
            ]);
        } catch (\Exception $e) {
            Log::error('Error fetching user data', [
                'error' => $e->getMessage(),
                'trace' => $e->getTraceAsString()
            ]);

            return response()->json([
                'message' => 'Không thể tải thông tin người dùng.',
                'errors' => ['server' => ['Đã xảy ra lỗi khi tải dữ liệu.']]
            ], 500);
        }
    }

    public function updateMe(UpdateProfileRequest $request)
    {
        $user = null;
        try {
            $user = $request->user();
            
            if (!$user) {
                return response()->json([
                    'message' => 'Bạn cần đăng nhập để cập nhật thông tin.',
                    'errors' => ['auth' => ['Phiên đăng nhập đã hết hạn.']]
                ], 401);
            }

            $user->update($request->validated());
            
            // ✅ Clear user cache after update to ensure fresh data
            Cache::forget("user:{$user->id}:me");
            
            return response()->json([
                'user' => new UserResource($user->fresh())
            ]);
        } catch (\Illuminate\Validation\ValidationException $e) {
            throw $e;
        } catch (\Exception $e) {
            Log::error('Error updating user profile', [
                'user_id' => $user ? $user->id : null,
                'error' => $e->getMessage(),
                'trace' => $e->getTraceAsString()
            ]);

            return response()->json([
                'message' => 'Không thể cập nhật thông tin.',
                'errors' => ['server' => ['Đã xảy ra lỗi khi cập nhật dữ liệu.']]
            ], 500);
        }
    }

    /**
     * Send email verification code
     */
    public function sendVerificationCode(Request $request)
    {
        try {
            $user = $request->user();
            
            if (!$user) {
                return response()->json([
                    'message' => 'Bạn cần đăng nhập để thực hiện thao tác này.',
                    'errors' => ['auth' => ['Phiên đăng nhập đã hết hạn.']]
                ], 401);
            }

            $request->validate([
                'email' => 'required|email|max:255',
            ]);

            $email = $request->email;
            
            // Generate 6-digit verification code
            $code = str_pad((string) rand(0, 999999), 6, '0', STR_PAD_LEFT);
            
            // Store code in cache for 10 minutes
            $cacheKey = "email_verification_code_{$user->id}_{$email}";
            Cache::put($cacheKey, $code, 600); // 10 minutes

            // TODO: Send email with verification code
            // For now, we'll log it (in production, use Laravel Mail)
            Log::info("Email verification code for user {$user->id} ({$email}): {$code}");
            
            // In development, you can check logs for the code
            // In production, implement actual email sending here
            // Mail::to($email)->send(new EmailVerificationMail($code));

            return response()->json([
                'message' => 'Mã xác thực đã được gửi đến email của bạn.',
                'success' => true,
            ]);
        } catch (\Illuminate\Validation\ValidationException $e) {
            throw $e;
        } catch (\Exception $e) {
            Log::error('Error sending verification code', [
                'user_id' => $request->user()?->id,
                'error' => $e->getMessage(),
                'trace' => $e->getTraceAsString()
            ]);

            return response()->json([
                'message' => 'Không thể gửi mã xác thực.',
                'errors' => ['server' => ['Đã xảy ra lỗi khi gửi mã xác thực.']]
            ], 500);
        }
    }

    /**
     * Verify email with code
     */
    public function verifyEmailCode(Request $request)
    {
        try {
            $user = $request->user();
            
            if (!$user) {
                return response()->json([
                    'message' => 'Bạn cần đăng nhập để thực hiện thao tác này.',
                    'errors' => ['auth' => ['Phiên đăng nhập đã hết hạn.']]
                ], 401);
            }

            $request->validate([
                'email' => 'required|email|max:255',
                'code' => 'required|string|size:6',
            ]);

            $email = $request->email;
            $code = $request->code;
            
            // Check verification code from cache
            $cacheKey = "email_verification_code_{$user->id}_{$email}";
            $storedCode = Cache::get($cacheKey);

            if (!$storedCode || $storedCode !== $code) {
                return response()->json([
                    'message' => 'Mã xác thực không đúng hoặc đã hết hạn.',
                    'errors' => ['code' => ['Vui lòng kiểm tra lại mã xác thực hoặc yêu cầu gửi lại mã.']]
                ], 422);
            }

            // Update user email and mark as verified
            $user->email = $email;
            $user->email_verified_at = now();
            $user->save();

            // Clear the verification code from cache
            Cache::forget($cacheKey);

            return response()->json([
                'message' => 'Xác thực email thành công!',
                'user' => new UserResource($user->fresh()),
                'success' => true,
            ]);
        } catch (\Illuminate\Validation\ValidationException $e) {
            throw $e;
        } catch (\Exception $e) {
            Log::error('Error verifying email code', [
                'user_id' => $request->user()?->id,
                'error' => $e->getMessage(),
                'trace' => $e->getTraceAsString()
            ]);

            return response()->json([
                'message' => 'Không thể xác thực email.',
                'errors' => ['server' => ['Đã xảy ra lỗi khi xác thực email.']]
            ], 500);
        }
    }
}