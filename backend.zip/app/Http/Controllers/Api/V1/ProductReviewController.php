<?php

namespace App\Http\Controllers\Api\V1;

use App\Http\Controllers\Controller;
use App\Models\ProductReview;
use App\Models\Order;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class ProductReviewController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth:sanctum')->except(['index', 'summary']);
    }

    /**
     * Get reviews for a product
     */
    public function index($productId): JsonResponse
    {
        $reviews = ProductReview::forProduct($productId)
            ->approved()
            ->with('user:id,name,email')
            ->latest()
            ->paginate(10);

        return response()->json([
            'success' => true,
            'data' => $reviews,
        ]);
    }

    /**
     * Get review summary for a product
     */
    public function summary($productId): JsonResponse
    {
        $average = ProductReview::getAverageRating($productId);
        $distribution = ProductReview::getRatingDistribution($productId);
        $total = ProductReview::forProduct($productId)->approved()->count();

        return response()->json([
            'success' => true,
            'data' => [
                'average_rating' => round($average, 1),
                'total_reviews' => $total,
                'rating_distribution' => $distribution,
            ],
        ]);
    }

    /**
     * Create a review
     */
    public function store(Request $request, $productId): JsonResponse
    {
        $request->validate([
            'rating' => 'required|integer|min:1|max:5',
            'title' => 'nullable|string|max:200',
            'comment' => 'required|string|min:10|max:1000',
        ]);

        $userId = auth()->id();

        // Check if user already reviewed this product
        $existing = ProductReview::forProduct($productId)
            ->where('user_id', $userId)
            ->first();

        if ($existing) {
            return response()->json([
                'success' => false,
                'message' => 'Bạn đã đánh giá sản phẩm này rồi',
            ], 409);
        }

        // Check if user purchased this product
        $hasPurchased = Order::where('user_id', $userId)
            ->where('product_id', $productId)
            ->where('status', 'completed')
            ->exists();

        $review = ProductReview::create([
            'product_id' => $productId,
            'user_id' => $userId,
            'rating' => $request->rating,
            'title' => $request->title,
            'comment' => $request->comment,
            'verified_purchase' => $hasPurchased,
            'is_approved' => false, // Cần admin duyệt
        ]);

        $review->load('user:id,name,email');

        return response()->json([
            'success' => true,
            'message' => 'Đánh giá của bạn đã được gửi và đang chờ duyệt',
            'data' => $review,
        ], 201);
    }

    /**
     * Update a review
     */
    public function update(Request $request, $reviewId): JsonResponse
    {
        $request->validate([
            'rating' => 'required|integer|min:1|max:5',
            'title' => 'nullable|string|max:200',
            'comment' => 'required|string|min:10|max:1000',
        ]);

        $review = ProductReview::findOrFail($reviewId);

        // Only owner can update
        if ($review->user_id !== auth()->id()) {
            return response()->json([
                'success' => false,
                'message' => 'Unauthorized',
            ], 403);
        }

        $review->update([
            'rating' => $request->rating,
            'title' => $request->title,
            'comment' => $request->comment,
            'is_approved' => false, // Reset approval after edit
        ]);

        return response()->json([
            'success' => true,
            'message' => 'Đánh giá đã được cập nhật',
            'data' => $review,
        ]);
    }

    /**
     * Delete a review
     */
    public function destroy($reviewId): JsonResponse
    {
        $review = ProductReview::findOrFail($reviewId);

        // Only owner or admin can delete
        if ($review->user_id !== auth()->id() && !auth()->user()->isAdmin()) {
            return response()->json([
                'success' => false,
                'message' => 'Unauthorized',
            ], 403);
        }

        $review->delete();

        return response()->json([
            'success' => true,
            'message' => 'Đánh giá đã được xóa',
        ]);
    }

    /**
     * Vote helpful
     */
    public function voteHelpful($reviewId): JsonResponse
    {
        $review = ProductReview::findOrFail($reviewId);
        $review->increment('helpful_count');

        return response()->json([
            'success' => true,
            'data' => [
                'helpful_count' => $review->helpful_count,
            ],
        ]);
    }

    /**
     * Vote unhelpful
     */
    public function voteUnhelpful($reviewId): JsonResponse
    {
        $review = ProductReview::findOrFail($reviewId);
        $review->increment('unhelpful_count');

        return response()->json([
            'success' => true,
            'data' => [
                'unhelpful_count' => $review->unhelpful_count,
            ],
        ]);
    }
}
