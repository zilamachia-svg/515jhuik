<?php

namespace App\Http\Controllers\Api\V1; // <-- NAMESPACE ĐÃ ĐƯỢC SỬA

use App\Http\Controllers\Controller; // Thêm 'use'
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Illuminate\Http\JsonResponse;
use App\Models\Deposit; // Giả định
use App\Models\User;    // Giả định

class WebhookController extends Controller // Thêm 'extends Controller'
{
    /**
     * [POST] /webhooks/sepay
     * Xử lý thông báo thanh toán từ Sepay.
     */
    public function handleSepay(Request $request): JsonResponse
    {
        // 1. Xác thực Bearer Token (theo tài liệu SePay)
        $authHeader = $request->header('Authorization');
        $expectedToken = config('services.sepay.webhook_token');
        
        if (!$expectedToken) {
            Log::error('SEPAY_WEBHOOK_TOKEN is not set.');
            return response()->json(['error' => 'Webhook token not configured'], 500);
        }
        
        // Kiểm tra Bearer token
        if (!$authHeader || !str_starts_with($authHeader, 'Bearer ')) {
            Log::warning('SePay webhook missing or invalid Authorization header.', ['ip' => $request->ip()]);
            return response()->json(['error' => 'Unauthorized'], 401);
        }
        
        $providedToken = substr($authHeader, 7); // Remove "Bearer " prefix
        
        if (!hash_equals($expectedToken, $providedToken)) {
            Log::warning('SePay webhook token mismatch.', ['ip' => $request->ip()]);
            return response()->json(['error' => 'Invalid token'], 403);
        }

        // 2. Phân tích Dữ liệu (theo format SePay)
        $payload = $request->all();
        Log::info('SePay Webhook Received:', $payload);

        // 3. Kiểm tra Idempotency (sử dụng field 'id' từ SePay)
        $sepayId = $payload['id'] ?? null;
        if (!$sepayId) {
            return response()->json(['error' => 'Missing id'], 400);
        }
        
        if (Deposit::where('external_transaction_id', (string) $sepayId)->exists()) {
            Log::info('SePay transaction already processed.', ['id' => $sepayId]);
            return response()->json(['message' => 'Transaction already processed'], 200);
        }

        // 4. Validate transfer type (phải là "in" - tiền vào)
        $transferType = $payload['transferType'] ?? null;
        if ($transferType !== 'in') {
            Log::warning('SePay transfer type is not "in".', ['transferType' => $transferType]);
            return response()->json(['message' => 'Transfer type is not incoming'], 200);
        }

        // 5. Extract order code từ field 'content' (ví dụ: "Thanh toan QR SE123456" -> "SE123456")
        $content = $payload['content'] ?? '';
        $matchPattern = config('services.sepay.match_pattern', '/SE\d+/');
        preg_match($matchPattern, $content, $matches);
        $orderCode = $matches[0] ?? null;

        if (!$orderCode) {
            Log::warning('SePay order code not found in content.', ['content' => $content]);
            return response()->json(['error' => 'Order code not found in content'], 400);
        }

        // 6. Tìm Deposit theo transaction_code (order code)
        $deposit = Deposit::where('transaction_code', $orderCode)
                           ->where('status', 'pending')
                           ->first();

        if (!$deposit) {
            Log::warning('Deposit not found or not pending.', ['order_code' => $orderCode]);
            return response()->json(['error' => 'Deposit not found or not pending'], 404);
        }

        // 7. Validate amount (có thể có sai số nhỏ)
        $transferAmount = (float) ($payload['transferAmount'] ?? 0);
        $depositAmount = (float) $deposit->amount;
        $tolerance = 1000; // Cho phép sai số 1000 VNĐ

        if (abs($transferAmount - $depositAmount) > $tolerance) {
            Log::warning('SePay amount mismatch.', [
                'expected' => $depositAmount,
                'received' => $transferAmount,
                'difference' => abs($transferAmount - $depositAmount)
            ]);
            return response()->json(['error' => 'Amount mismatch'], 400);
        }

        // 8. Xử lý Giao dịch
        try {
            DB::beginTransaction();

            // Cập nhật Deposit
            $deposit->update([
                'status' => 'completed',
                'external_transaction_id' => (string) $sepayId,
            ]);

            // Cộng tiền cho User
            $user = $deposit->user;
            if ($user) {
                $user->increment('balance', $deposit->amount);
            } else {
                throw new \Exception("User not found for deposit ID: {$deposit->id}");
            }

            DB::commit();

            Log::info('SePay webhook processed successfully.', [
                'deposit_id' => $deposit->id,
                'order_code' => $orderCode,
                'amount' => $transferAmount
            ]);

        } catch (\Exception $e) {
            DB::rollBack();
            Log::error('SePay webhook processing failed', [
                'error' => $e->getMessage(),
                'order_code' => $orderCode,
                'trace' => $e->getTraceAsString()
            ]);
            return response()->json(['error' => 'Internal Server Error'], 500);
        }

        // 9. Phản hồi cho SePay
        return response()->json(['message' => 'Webhook processed successfully'], 200);
    }
}