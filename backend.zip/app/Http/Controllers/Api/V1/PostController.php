<?php

namespace App\Http\Controllers\Api\V1;

use App\Http\Controllers\Controller;
use App\Http\Resources\PostResource;
use App\Models\Post;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class PostController extends Controller
{
    /**
     * Get paginated posts
     */
    public function index(Request $request): JsonResponse
    {
        $query = Post::where('status', 'published')
            ->with('author')
            ->latest();

        if ($request->has('search')) {
            $query->where('title', 'like', '%' . $request->search . '%');
        }

        $posts = $query->paginate($request->get('per_page', 15));

        return response()->json([
            'success' => true,
            'data' => PostResource::collection($posts->items()),
            'pagination' => [
                'current_page' => $posts->currentPage(),
                'last_page' => $posts->lastPage(),
                'per_page' => $posts->perPage(),
                'total' => $posts->total(),
            ],
        ]);
    }

    /**
     * Get single post by slug
     */
    public function show(Request $request, string $slug): JsonResponse
    {
        $post = Post::where('status', 'published')
            ->where('slug', $slug)
            ->with('author')
            ->firstOrFail();

        return response()->json([
            'success' => true,
            'data' => new PostResource($post),
        ]);
    }
}

