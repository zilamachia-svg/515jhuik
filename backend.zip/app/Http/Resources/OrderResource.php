<?php

namespace App\Http\Resources;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class OrderResource extends JsonResource
{
    public function toArray(Request $request): array
    {
        return [
            'id' => $this->id,
            'product' => [
                'id' => $this->whenLoaded('product', fn() => $this->product->id),
                'name' => $this->whenLoaded('product', fn() => $this->product->name),
            ],
            'quantity' => $this->quantity,
            'totalPrice' => (float) $this->total_price,
            'unitPrice' => (float) ($this->total_price / $this->quantity),
            'purchaseDate' => $this->created_at->format('H:i:s d/m/Y'),
            'purchaseDateFull' => $this->created_at->toIso8601String(),
            'status' => $this->status,
            'user' => [
                'id' => $this->whenLoaded('user', fn() => $this->user->id),
                'name' => $this->whenLoaded('user', fn() => $this->user->name),
                'email' => $this->whenLoaded('user', fn() => $this->user->email),
            ],
        ];
    }
}