<?php

namespace App\Http\Resources\Admin;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class DepositResource extends \App\Http\Resources\DepositResource
{
    public function toArray(Request $request): array
    {
        $data = parent::toArray($request);

        $userData = $this->whenLoaded('user', [
            'user_name' => $this->user->name,
            'user_email' => $this->user->email,
        ]);

        return array_merge($data, $userData);
    }
}