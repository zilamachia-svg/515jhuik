<?php

namespace App\DataTransferObjects;

class ContactSettings
{
    public $email = '';
    public $zalo = '';
    public $telegram = '';
    public $facebook = '';

    public function __construct(array $data = [])
    {
        foreach ($data as $key => $value) {
            if (property_exists($this, $key)) {
                $this->$key = $value;
            }
        }
    }

    public function toArray(): array
    {
        return [
            'email' => $this->email,
            'zalo' => $this->zalo,
            'telegram' => $this->telegram,
            'facebook' => $this->facebook,
        ];
    }
}