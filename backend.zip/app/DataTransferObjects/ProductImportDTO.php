<?php

namespace App\DataTransferObjects;

use Illuminate\Validation\Validator;

class ProductImportDTO
{
    public function __construct(
        public string $name,
        public ?string $description = null,
        public float $price = 0,
        public int $stock = 0,
        public ?string $country = null,
        public ?string $category = null,
        public ?string $image_url = null,
        public bool $is_active = true,
        public ?int $category_id = null,
        public ?string $sku = null,
        public ?string $type = null, // simple, variable, grouped
        public ?float $regular_price = null,
        public ?float $sale_price = null,
        public ?string $short_description = null,
        public ?array $product_data = null, // Dữ liệu sản phẩm (accounts, etc.)
    ) {}

    /**
     * Tạo DTO từ CSV row
     */
    public static function fromCsvRow(array $row, array $columnMap = []): self
    {
        // Nếu không có columnMap, sử dụng mặc định
        if (empty($columnMap)) {
            $columnMap = [
                'name' => 'name',
                'description' => 'description',
                'price' => 'price',
                'stock' => 'stock',
                'country' => 'country',
                'category' => 'category',
                'image_url' => 'image_url',
                'is_active' => 'is_active',
                'sku' => 'sku',
                'type' => 'type',
            ];
        }

        // Map dữ liệu từ row
        $data = [];
        foreach ($columnMap as $key => $csvColumn) {
            if (isset($row[$csvColumn])) {
                $data[$key] = $row[$csvColumn];
            }
        }

        return new self(
            name: trim($data['name'] ?? ''),
            description: !empty($data['description']) ? trim($data['description']) : null,
            price: (float) ($data['price'] ?? 0),
            stock: (int) ($data['stock'] ?? 0),
            country: !empty($data['country']) ? trim($data['country']) : null,
            category: !empty($data['category']) ? trim($data['category']) : null,
            image_url: !empty($data['image_url']) ? trim($data['image_url']) : null,
            is_active: $data['is_active'] === 'yes' || $data['is_active'] === '1' || $data['is_active'] === true ? true : false,
            sku: !empty($data['sku']) ? trim($data['sku']) : null,
            type: !empty($data['type']) ? trim($data['type']) : 'simple',
            regular_price: isset($data['regular_price']) ? (float)$data['regular_price'] : null,
            sale_price: isset($data['sale_price']) ? (float)$data['sale_price'] : null,
        );
    }

    /**
     * Chuyển DTO sang mảng để lưu vào database
     */
    public function toArray(): array
    {
        return [
            'name' => $this->name,
            'description' => $this->description,
            'price' => $this->price,
            'stock' => $this->stock,
            'country' => $this->country,
            'category' => $this->category,
            'image_url' => $this->image_url,
            'is_active' => $this->is_active,
            'category_id' => $this->category_id,
        ];
    }

    /**
     * Validate dữ liệu
     */
    public function validate(): array
    {
        $errors = [];

        if (empty($this->name)) {
            $errors['name'] = 'Tên sản phẩm không được để trống';
        }

        if ($this->price < 0) {
            $errors['price'] = 'Giá sản phẩm phải >= 0';
        }

        if ($this->stock < 0) {
            $errors['stock'] = 'Số lượng tồn kho phải >= 0';
        }

        if (strlen($this->name) > 255) {
            $errors['name'] = 'Tên sản phẩm không được vượt quá 255 ký tự';
        }

        return $errors;
    }
}
