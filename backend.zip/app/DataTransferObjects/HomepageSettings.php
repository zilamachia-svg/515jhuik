<?php

namespace App\DataTransferObjects;

class HomepageSettings
{
    public $welcomeTitle = 'Chào mừng';
    public $welcomeSubtitle = 'Mô tả ngắn';

    public function __construct(array $data = [])
    {
        foreach ($data as $key => $value) {
            if (property_exists($this, $key)) {
                $this->$key = $value;
            }
        }
    }

    public function toArray(): array
    {
        return [
            'welcomeTitle' => $this->welcomeTitle,
            'welcomeSubtitle' => $this->welcomeSubtitle,
        ];
    }
}