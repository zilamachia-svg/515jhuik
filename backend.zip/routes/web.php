<?php

use App\Http\Controllers\SitemapController;
use Illuminate\Support\Facades\Route;

// API Health Check - accessible at /api/health
Route::get('/api/health', function () {
    return response()->json([
        'message' => 'Hải Đăng Meta API',
        'version' => '1.0.0',
        'status' => 'running'
    ]);
});

// SEO: Sitemap
Route::get('/sitemap.xml', [SitemapController::class, 'index']);

// Sanctum CSRF cookie endpoint is automatically registered by Sanctum
// No need to manually define it here

// SPA Catch-all Route - Serve React app for all non-API routes
// This must be the last route defined
Route::get('/{any}', function () {
    return view('app');
})->where('any', '^(?!api|sanctum).*$');