<?php

use Illuminate\Foundation\Inspiring;
use Illuminate\Support\Facades\Artisan;
use Illuminate\Support\Facades\Cache; // Import Cache

Artisan::command('inspire', function () {
    $this->comment(Inspiring::quote());
})->purpose('Display an inspiring quote');

// --- BỔ SUNG LỆNH QUẢN LÝ HỆ THỐNG ---

// Lệnh chạy Queue Worker (quan trọng cho các tác vụ nặng: Upload Products, Check Live)
Artisan::command('queue:run', function () {
    $this->comment('Bắt đầu Queue Worker (Database driver)...');
    // Chạy worker với timeout 60s và thử lại 3 lần
    $this->call('queue:work', [
        '--queue' => 'default,uploads', // Chỉ định các queue cần xử lý
        '--tries' => 3,
        '--timeout' => 60,
    ]);
})->purpose('Chạy Queue Worker cho các tác vụ bất đồng bộ (Upload, Check Live)');


// Lệnh xóa toàn bộ Cache (dùng khi cập nhật dữ liệu Product, Settings...)
Artisan::command('cache:clearall', function () {
    $this->comment('Đang xóa toàn bộ Cache...');
    
    // Xóa Cache Laravel
    $this->call('cache:clear');
    
    // Xóa Cache Config và Route (quan trọng sau khi deploy)
    $this->call('config:clear');
    $this->call('route:clear');

    $this->info('Đã xóa sạch Cache hệ thống.');
})->purpose('Xóa toàn bộ Cache (Application, Config, Route).');


// Lệnh xóa Cache API Products (dùng khi Admin cập nhật sản phẩm)
Artisan::command('cache:clear:products', function () {
    // Xóa cache key cụ thể
    Cache::forget('api.products.active'); 
    
    $this->info('Đã xóa Cache API Products.');
})->purpose('Xóa Cache cụ thể cho API Products để cập nhật dữ liệu nhanh.');