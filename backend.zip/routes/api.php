<?php

use Illuminate\Support\Facades\Route;
use Illuminate\Support\Facades\Auth;
use Illuminate\Http\Request;

// USER controllers
use App\Http\Controllers\Api\V1\AuthController;
use App\Http\Controllers\Api\V1\UserController;
use App\Http\Controllers\Api\V1\DepositController;
use App\Http\Controllers\Api\V1\FaqController;
use App\Http\Controllers\Api\V1\PaymentMethodController;
use App\Http\Controllers\Api\V1\PostController;
use App\Http\Controllers\Api\V1\ProductController;
use App\Http\Controllers\Api\V1\OrderController;
use App\Http\Controllers\Api\V1\SettingsController;
use App\Http\Controllers\Api\V1\WebhookController;
use App\Http\Controllers\Api\V1\ToolController;

// ADMIN controllers
use App\Http\Controllers\Api\V1\Admin\DashboardController;
use App\Http\Controllers\Api\V1\Admin\DepositController as AdminDepositController;
use App\Http\Controllers\Api\V1\Admin\OrderController as AdminOrderController;
use App\Http\Controllers\Api\V1\Admin\PaymentMethodController as AdminPaymentMethodController;
use App\Http\Controllers\Api\V1\Admin\PostController as AdminPostController;
use App\Http\Controllers\Api\V1\Admin\ProductController as AdminProductController;
use App\Http\Controllers\Api\V1\Admin\ProductCategoryController as AdminProductCategoryController;
use App\Http\Controllers\Api\V1\Admin\FileController as AdminFileController;
use App\Http\Controllers\Api\V1\Admin\SettingsController as AdminSettingsController;
use App\Http\Controllers\Api\V1\Admin\UserController as AdminUserController;
use App\Http\Controllers\Api\V1\Admin\FaqController as AdminFaqController;
use App\Http\Controllers\Api\V1\Admin\SupplierController;
use App\Http\Controllers\Api\V1\Admin\ActivityLogController;
use App\Http\Controllers\Api\V1\Admin\ProductImportController;
use App\Http\Controllers\Api\V1\Admin\AccountImportController;
use App\Http\Controllers\Api\V1\Admin\ReviewModerationController;
use App\Http\Controllers\Api\V1\Admin\BatchOperationsController;

// NEW FEATURES
use App\Http\Controllers\Api\V1\WishlistController;
use App\Http\Controllers\Api\V1\ProductReviewController;
use App\Http\Controllers\Api\V1\NotificationController;

// API Version Check
Route::get('/v1', function () {
    return response()->json(['status' => 'running', 'version' => '1.0.0']);
});

// ================= GROUP V1 =================
Route::prefix('v1')->name('api.v1.')->group(function () {

    // --- PUBLIC ROUTES ---
    Route::get('/products/all',         [ProductController::class, 'all']);
    Route::get('/products',             [ProductController::class, 'index']);
    Route::get('/products/filters',     [ProductController::class, 'filters']);
    Route::get('/posts',                [PostController::class, 'index']);
    Route::get('/posts/{slug}',         [PostController::class, 'show']);
    Route::get('/payment-methods',      [PaymentMethodController::class, 'index']);
    Route::get('/settings',             [SettingsController::class, 'get']);
    Route::get('/faq',                  [FaqController::class, 'index']);
    Route::post('/tools/check-live-fb', [ToolController::class, 'checkLiveFB']);
    Route::post('/tools/test-facebook-token', [ToolController::class, 'testFacebookToken']);

    // WEBHOOKS
    Route::post('/webhooks/sepay',      [WebhookController::class, 'handleSepay']);

    // AUTH (NO MIDDLEWARE)
    Route::post('/register',            [AuthController::class, 'register']);
    Route::post('/login',               [AuthController::class, 'login'])->name('login');
    Route::post('/forgot-password',     [AuthController::class, 'forgotPassword']);
    Route::post('/reset-password',      [AuthController::class, 'resetPassword']);
    Route::get('/test-session', function () { return response()->json(['auth' => Auth::check()]); });

    // --- AUTHENTICATED ROUTES ---
    Route::middleware(['auth:sanctum'])->group(function () {
        Route::post('/logout',          [AuthController::class, 'logout']);
        Route::get('/me',               [UserController::class, 'me']);
        Route::put('/me',               [UserController::class, 'updateMe']);
        
        // Email Verification
        Route::post('/me/email/send-verification-code', [UserController::class, 'sendVerificationCode']);
        Route::post('/me/email/verify-code', [UserController::class, 'verifyEmailCode']);
        Route::post('email/resend-verification', [AuthController::class, 'resendVerification']);

        // Orders & Deposits
        Route::get('/orders',           [OrderController::class, 'index']);
        Route::post('/orders',          [OrderController::class, 'store']);
        Route::get('/orders/{order}/download', [OrderController::class, 'download'])->name('orders.download');
        Route::get('/orders/{orderId}/account', [AccountImportController::class, 'getOrderAccount'])->name('orders.account');
        Route::get('/deposits',         [DepositController::class, 'index']);
        Route::post('/deposits',        [DepositController::class, 'store']);

        // Wishlist
        Route::get('/wishlist',                 [WishlistController::class, 'index']);
        Route::post('/wishlist',                [WishlistController::class, 'store']);
        Route::delete('/wishlist/{productId}',  [WishlistController::class, 'destroy']);
        Route::get('/wishlist/check/{productId}', [WishlistController::class, 'check']);
        Route::get('/wishlist/count',           [WishlistController::class, 'count']);

        // Notifications
        Route::get('/notifications/unread-count', [NotificationController::class, 'unreadCount']);
        Route::post('/notifications/mark-all-read', [NotificationController::class, 'markAllAsRead']);
        Route::delete('/notifications',         [NotificationController::class, 'deleteAll']);
        Route::get('/notifications',            [NotificationController::class, 'index']);
        Route::patch('/notifications/{id}/read', [NotificationController::class, 'markAsRead']);
        Route::delete('/notifications/{id}',    [NotificationController::class, 'destroy']);

        // Reviews (Auth)
        Route::post('/products/{productId}/reviews',    [ProductReviewController::class, 'store']);
        Route::put('/reviews/{reviewId}',               [ProductReviewController::class, 'update']);
        Route::delete('/reviews/{reviewId}',            [ProductReviewController::class, 'destroy']);
        Route::post('/reviews/{reviewId}/helpful',      [ProductReviewController::class, 'voteHelpful']);
        Route::post('/reviews/{reviewId}/unhelpful',    [ProductReviewController::class, 'voteUnhelpful']);
    });

    // Public Reviews
    Route::get('/products/{productId}/reviews',         [ProductReviewController::class, 'index']);
    Route::get('/products/{productId}/reviews/summary', [ProductReviewController::class, 'summary']);

    // --- ADMIN ROUTES ---
    Route::prefix('admin')->name('admin.')->middleware(['auth:sanctum', 'role:admin'])->group(function () {
        Route::get('/dashboard',                        [DashboardController::class, 'index']);
        
        // Users
        Route::get('/users/top-depositors',             [AdminUserController::class, 'topDepositors']);
        Route::apiResource('users',                     AdminUserController::class)->except(['show']);

        // Resources
        Route::get('/deposits',                         [AdminDepositController::class, 'index']);
        Route::put('/deposits/{deposit}',               [AdminDepositController::class, 'update']);
        Route::get('/orders',                           [AdminOrderController::class, 'index']);
        Route::get('/orders/{order}',                   [AdminOrderController::class, 'show']);
        Route::apiResource('payment-methods',           AdminPaymentMethodController::class)->except(['show']);
        Route::apiResource('posts',                     AdminPostController::class)->except(['show']);
        
        // Products & Import
        Route::post('/products/upload',                 [AdminProductController::class, 'upload']);
        Route::apiResource('products',                  AdminProductController::class)->except(['show']);
        Route::apiResource('product-categories',        AdminProductCategoryController::class)->except(['show']);
        
        Route::prefix('products')->name('products.')->group(function () {
            Route::post('/import/csv',                  [ProductImportController::class, 'importCsv']);
            Route::post('/import/txt',                  [ProductImportController::class, 'importTxt']);
            Route::post('/import/batch',                [ProductImportController::class, 'importBatch']);
            Route::get('/import/template',              [ProductImportController::class, 'downloadTemplate']);
        });

        Route::prefix('accounts')->name('accounts.')->group(function () {
            Route::post('/import/pipe',                 [AccountImportController::class, 'importPipe']);
            Route::post('/import/csv',                  [AccountImportController::class, 'importCSV']);
            Route::get('/available',                    [AccountImportController::class, 'getAvailable']);
            Route::get('/template/{platform}',          [AccountImportController::class, 'downloadTemplate']);
            Route::get('',                              [AccountImportController::class, 'index']);
            Route::delete('/{id}',                      [AccountImportController::class, 'destroy']);
        });
        
        Route::apiResource('suppliers',                 SupplierController::class)->except(['show']);
        Route::get('/files',                            [AdminFileController::class, 'index']);
        Route::post('/files/upload',                    [AdminFileController::class, 'upload']);
        Route::delete('/files/{file}',                  [AdminFileController::class, 'destroy']);
        Route::get('/settings',                         [AdminSettingsController::class, 'get']);
        Route::put('/settings',                         [AdminSettingsController::class, 'update']);
        Route::apiResource('faq',                       AdminFaqController::class)->except(['show']);
        Route::get('/logs',                             [ActivityLogController::class, 'index']);
        Route::post('/logs/export',                     [ActivityLogController::class, 'export']);
        Route::get('/reviews',                          [ReviewModerationController::class, 'index']);
        Route::post('/reviews/{id}/approve',            [ReviewModerationController::class, 'approve']);
        Route::post('/reviews/{id}/reject',             [ReviewModerationController::class, 'reject']);
        
        // Batch
        Route::post('/products/batch-delete',           [BatchOperationsController::class, 'batchDelete']);
        Route::post('/products/batch-status',           [BatchOperationsController::class, 'batchUpdateStatus']);
        Route::post('/products/batch-price',            [BatchOperationsController::class, 'batchAdjustPrice']);
        Route::post('/products/export',                 [BatchOperationsController::class, 'export']);
    }); // Đóng Admin

}); // Đóng V1